package dir2_traffic_signal_control.demo2_multiperiod_and_multischeme_signal_control;

import com.jidatraffic.tessng.TessPlugin;
import com.jidatraffic.tessng.CustomerNet;

// 用户插件，继承自TessPlugin
public class MyPlugin extends TessPlugin {
    // 自定义路网控制逻辑
    private MyNet myNet;

    /**
     * 构造方法
     */
    public MyPlugin() {
        super();
    }

    /**
     * 在TESS NG 工厂类创建TESS NG 对象时调用
     */
    @Override
    public void init() {
        myNet = new MyNet();
    }

    /**
     * 返回插件路网子接口，此方法由TESS NG 调用
     */
    @Override
    public CustomerNet customerNet() {
        return myNet;
    }
}
