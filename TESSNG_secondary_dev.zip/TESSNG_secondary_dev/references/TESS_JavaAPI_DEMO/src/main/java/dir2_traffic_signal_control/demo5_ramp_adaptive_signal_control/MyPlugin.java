package dir2_traffic_signal_control.demo5_ramp_adaptive_signal_control;

import com.jidatraffic.tessng.TessPlugin;
import com.jidatraffic.tessng.CustomerNet;
import com.jidatraffic.tessng.CustomerSimulator;

// 用户插件，继承自TessPlugin
public class MyPlugin extends TessPlugin {
    // 自定义路网控制逻辑
    private MyNet myNet;
    // 自定义仿真控制逻辑
    private MySimulator mySimulator;

    /**
     * 构造方法
     */
    public MyPlugin() {
        super();
    }

    /**
     * 在TESS NG 工厂类创建TESS NG 对象时调用
     */
    @Override
    public void init() {
        myNet = new MyNet();
        mySimulator = new MySimulator();
    }

    /**
     * 返回插件路网子接口，此方法由TESS NG 调用
     */
    @Override
    public CustomerNet customerNet() {
        return myNet;
    }

    /**
     * 返回插件仿真子接口，此方法由TESS NG 调用
     */
    @Override
    public CustomerSimulator customerSimulator() {
        return mySimulator;
    }
}
