package dir1_scene_modeling.demo5_road_work_zone_modeling;

import com.jidatraffic.tessng.*;

public class MySimulator extends CustomerSimulator {
    public MySimulator() {
        super();// 初始化逻辑
    }
}

