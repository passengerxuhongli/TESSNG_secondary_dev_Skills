package dir1_scene_modeling.demo6_accident_zone_modeling;

import javax.json.Json;
import javax.json.JsonObject;
import com.jidatraffic.tessng.TessngFactory;
import config.GlobalConfig;

public class Main {
    // 加载库文件
    static {
        try {
            System.loadLibrary("TESS_WIN_Java");
        } catch (UnsatisfiedLinkError e) {
            System.err.println("Native code library failed to load. See the chapter on Dynamic Linking Problems in the SWIG Java documentation for help.\n" + e);
            System.exit(1);
        }
    }

    public static void main(String[] args) {
        // 构建配置参数
        JsonObject jsonObject = Json.createObjectBuilder()
                .add("__secdevlang", "java")
                .add("__workspace", GlobalConfig.workSpacePath)
                .add("__netfilepath", GlobalConfig.netFilePath + "/场景建模-施工改扩建.tess")
                .add("__simuafterload", true)
                .build();

        // 创建自定义插件类实例
        MyPlugin myPlugin = new MyPlugin();
        // 创建 TESS NG 工厂类实例
        TessngFactory tessngFactory = new TessngFactory();
        // 通过工厂类构建 TESS NG 仿真核心对象
        tessngFactory.build(myPlugin, jsonObject);
        // 退出
        System.exit(0);
    }
}
