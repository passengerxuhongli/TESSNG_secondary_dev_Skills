package config;

public class GlobalConfig {
    // 工作空间路径
    public static final String workSpacePath = System.getProperty("user.dir") + "/out";
    // 路网文件路径
    public static final String netFilePath = System.getProperty("user.dir") + "/src/main/resources/net";
    // json文件路径
    public static final String jsonFilePath = System.getProperty("user.dir") + "/src/main/resources/json";
    // 输出文件路径
    public static final String outputFilePath = System.getProperty("user.dir") + "/out";
}
