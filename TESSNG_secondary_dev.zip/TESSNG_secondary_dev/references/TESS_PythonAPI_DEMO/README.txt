使用步骤

1. 准备版本号为 3.6.6 或 3.8.5 的Python 环境，环境路径中需要不含中文；

2. 安装 tessng 包，可在对应环境的 CMD 命令行下输入以下命令：pip install tessng -i https://pypi.tuna.tsinghua.edu.cn/simple/；

3. 在 IDE 中选择对应的 Python 环境，并运行 main.py 文件；

4. 首次运行代码时，会弹出软件激活界面，选择具有二次开发权限的 key ，提交并关闭界面；

5. 之后再次运行代码时，会正常弹出仿真界面，并运行仿真。
