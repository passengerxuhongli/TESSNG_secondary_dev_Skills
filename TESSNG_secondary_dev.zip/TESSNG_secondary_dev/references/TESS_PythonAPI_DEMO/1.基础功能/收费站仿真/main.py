from MyPlugin import MyPlugin


if __name__ == '__main__':
    tess_file_path: str = "network/收费站.tess"
    my_tess = MyPlugin(tess_file_path)
    my_tess.start()
