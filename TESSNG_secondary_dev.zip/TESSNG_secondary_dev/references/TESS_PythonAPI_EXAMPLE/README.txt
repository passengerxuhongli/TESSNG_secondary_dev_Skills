使用步骤

1. 准备版本号为 3.6.6 或 3.8.5 的Python 环境，环境路径中需要不含中文；

2. 安装 tessng 包，可在对应环境的 CMD 命令行下输入以下命令：pip install tessng -i https://pypi.tuna.tsinghua.edu.cn/simple/；或将目录下Python36_SDK解压至当前目录，注意使用离线包时需将导入的tessng修改为Tessng。

3. 在 IDE 中选择对应的 Python 环境，并运行 main.py 文件；

4. 首次运行代码时，会弹出软件激活界面，选择具有二次开发权限的 key ，提交并关闭界面；

5. 之后再次运行代码时，会正常弹出仿真界面，并运行仿真。


其他说明

1. main.py 为主程序代码，MyPlugin.py 为插件启动代码，MyGUI.py 为自定义界面代码，MyNet 为自定义路网控制逻辑代码，MySimulator.py 为自定义仿真控制逻辑代码；

2. 仿真结果将保存在同级目录下的 WorkSpace/SimuResult 文件夹内，也可以自定义仿真程序的工作空间路径，如改为已安装的 TESS NG 仿真软件的安装路径；

3. 如果想避免运行新的仿真程序时重复激活软件，可以将已激活的仿真程序下的 WorkSpace/Cert 文件夹拷贝到新的仿真程序对应的工作空间目录下；

4. 类与函数的定义可参阅 Tessng.pyi 文件，更多使用说明可参阅网址：http://jidatraffic.com:82/。
