# Configuration Extraction Report

**Total Files:** 29
**Total Settings:** 443
**Detected Patterns:** None

## Configuration Files

### .claude\settings.local.json

- **Type:** json
- **Purpose:** general_configuration
- **Settings:** 1

### SecondDev_V4.1_CN\TESS_JavaAPI_DEMO\.env

- **Type:** env
- **Purpose:** api_configuration
- **Settings:** 2

### SecondDev_V4.1_CN\TESS_JavaAPI_EXAMPLE\.env

- **Type:** env
- **Purpose:** api_configuration
- **Settings:** 2

### SecondDev_V4.1_CN\TESS_JavaAPI_DEMO\src\main\resources\json\信号控制-多时段多方案.json

- **Type:** json
- **Purpose:** api_configuration
- **Settings:** 2

### SecondDev_V4.1_CN\TESS_JavaAPI_DEMO\src\main\resources\json\信号控制-干线.json

- **Type:** json
- **Purpose:** api_configuration
- **Settings:** 21

### SecondDev_V4.1_CN\TESS_JavaAPI_DEMO\src\main\resources\json\车辆引导-路径诱导.json

- **Type:** json
- **Purpose:** api_configuration
- **Settings:** 10

### SecondDev_V4.1_CN\TESS_PythonAPI_DEMO\2.信号控制\单点信号控制\config.py

- **Type:** python
- **Purpose:** api_configuration
- **Settings:** 5

### SecondDev_V4.1_CN\TESS_PythonAPI_DEMO\2.信号控制\多时段多方案信号控制\light_data.json

- **Type:** json
- **Purpose:** api_configuration
- **Settings:** 2

### SecondDev_V4.1_CN\TESS_PythonAPI_DEMO\2.信号控制\干线绿波信号控制\param.json

- **Type:** json
- **Purpose:** api_configuration
- **Settings:** 21

### SecondDev_V4.1_CN\TESS_PythonAPI_DEMO\4.车道管控与车辆引导\可变车道管控\data\桐乡振兴路干线参数信息.json

- **Type:** json
- **Purpose:** api_configuration
- **Settings:** 19

### SecondDev_V4.1_CN\TESS_PythonAPI_DEMO\4.车道管控与车辆引导\车辆路径诱导\JsonData\DecisionPoint3801_FlowRation.json

- **Type:** json
- **Purpose:** api_configuration
- **Settings:** 10

### SecondDev_V4.1_CN\TESS_PythonAPI_DEMO\4.车道管控与车辆引导\车辆速度引导\my_code\config.py

- **Type:** python
- **Purpose:** api_configuration
- **Settings:** 24

### SecondDev_V4.1_CN\TESS_PythonAPI_DEMO\其他\SecondaryDevCases-master\Data\flow_ratio_quarter.json

- **Type:** json
- **Purpose:** api_configuration
- **Settings:** 15

### SecondDev_V4.1_CN\TESS_PythonAPI_DEMO\其他\SecondaryDevCases-master\Data\Signal_Plan_Data.json

- **Type:** json
- **Purpose:** api_configuration
- **Settings:** 44

### SecondDev_V4.1_CN\TESS_PythonAPI_DEMO\其他\SecondaryDevCases-master\Data\Signal_Plan_Data_1109.json

- **Type:** json
- **Purpose:** api_configuration
- **Settings:** 44

### SecondDev_V4.1_EN\TESS_JavaAPI_DEMO\.env

- **Type:** env
- **Purpose:** api_configuration
- **Settings:** 2

### SecondDev_V4.1_EN\TESS_JavaAPI_EXAMPLE\.env

- **Type:** env
- **Purpose:** api_configuration
- **Settings:** 2

### SecondDev_V4.1_EN\TESS_JavaAPI_DEMO\src\main\resources\json\信号控制-多时段多方案.json

- **Type:** json
- **Purpose:** api_configuration
- **Settings:** 2

### SecondDev_V4.1_EN\TESS_JavaAPI_DEMO\src\main\resources\json\信号控制-干线.json

- **Type:** json
- **Purpose:** api_configuration
- **Settings:** 21

### SecondDev_V4.1_EN\TESS_JavaAPI_DEMO\src\main\resources\json\车辆引导-路径诱导.json

- **Type:** json
- **Purpose:** api_configuration
- **Settings:** 10

### SecondDev_V4.1_EN\TESS_PythonAPI_DEMO\2.Signal_Control\Artery_GreenWave_Signal_Control\param.json

- **Type:** json
- **Purpose:** api_configuration
- **Settings:** 21

### SecondDev_V4.1_EN\TESS_PythonAPI_DEMO\2.Signal_Control\Multi-time_Period_And_Multi-Scheme_Signal_Control\light_data.json

- **Type:** json
- **Purpose:** api_configuration
- **Settings:** 2

### SecondDev_V4.1_EN\TESS_PythonAPI_DEMO\2.Signal_Control\Signal_Control\config.py

- **Type:** python
- **Purpose:** api_configuration
- **Settings:** 5

### SecondDev_V4.1_EN\TESS_PythonAPI_DEMO\4.Lane_Control_and_Vehicle_Control\Variable_Lane_Control\data\桐乡振兴路干线参数信息.json

- **Type:** json
- **Purpose:** api_configuration
- **Settings:** 19

### SecondDev_V4.1_EN\TESS_PythonAPI_DEMO\4.Lane_Control_and_Vehicle_Control\Vehicle_Route_Guidance\JsonData\DecisionPoint3801_FlowRation.json

- **Type:** json
- **Purpose:** api_configuration
- **Settings:** 10

### SecondDev_V4.1_EN\TESS_PythonAPI_DEMO\4.Lane_Control_and_Vehicle_Control\Vehicle_Speed_Guidance\my_code\config.py

- **Type:** python
- **Purpose:** api_configuration
- **Settings:** 24

### SecondDev_V4.1_EN\TESS_PythonAPI_DEMO\Others\SecondaryDevCases-master\Data\flow_ratio_quarter.json

- **Type:** json
- **Purpose:** api_configuration
- **Settings:** 15

### SecondDev_V4.1_EN\TESS_PythonAPI_DEMO\Others\SecondaryDevCases-master\Data\Signal_Plan_Data.json

- **Type:** json
- **Purpose:** api_configuration
- **Settings:** 44

### SecondDev_V4.1_EN\TESS_PythonAPI_DEMO\Others\SecondaryDevCases-master\Data\Signal_Plan_Data_1109.json

- **Type:** json
- **Purpose:** api_configuration
- **Settings:** 44

