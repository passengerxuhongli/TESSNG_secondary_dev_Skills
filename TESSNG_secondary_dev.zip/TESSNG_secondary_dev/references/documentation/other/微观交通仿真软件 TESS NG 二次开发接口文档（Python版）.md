# 微观交通仿真软件 TESS NG 二次开发接口文档（Python版）

[TOC]

<div style="page-break-after: always;"></div>

# 1.简介

## 1.1.相关链接

* [上海济达交通科技有限公司官网](https://jidatraffic.com/#/home)
* [TESSNG 二次开发 官网文档](http://jidatraffic.com:82/)
* [TESS NG 二次开发 GitHub地址](https://github.com/jIDa-traffic/TESSNG_SecondaryDev)
* [TESS NG 二次开发 Gitee地址](https://gitee.com/jidatraffic/tessng-secondary-doc)



## 1.2.研发背景

​	**国产微观交通仿真软件 TESS NG** 融合了交通工程、软件工程与系统仿真等交叉学科的最新技术研发而成，具有以下显著特点：完全自主知识产权、便捷高效的建模能力、开放的外部接口模块，以及可定制化的用户服务等。

　　在功能扩展和项目建设过程中，TESS NG 通过强化设计，将大量功能的实现进行高度抽象，并将这些抽象逻辑与核心功能深度融合。抽象逻辑进一步细化为接口方法，而具体的接口实现则交由用户根据实际应用场景来完成。在这一架构设计下，TESS NG 已成功开发出车路协同、在线仿真、微宏观一体化仿真等插件模块，相关接口的设计与应用也日臻成熟。

　　TESS NG 的二次开发能力通过用户编写代码与软件进行交互实现，从而扩展功能与定制场景。用户不仅可以实现高度自动化和个性化的仿真业务，还能够构建符合特定需求的交通数字孪生和科研实验环境，这也是开展交通研究与应用的重要途径之一。

　　目前，TESS NG 的二次开发支持 **C++、Python 和 Java** 三种编程语言，三种语言的接口名称完全一致。



## 1.3.应用场景

​	TESS NG 的二次开发功能支持丰富多样的仿真场景构建，其可实现的应用场景广泛，包括但不限于以下表格所涵盖的内容。

| 序号 |     分类     |       场景       |                             应用                             |
| :--: | :----------: | :--------------: | :----------------------------------------------------------: |
|  1   | 城市道路仿真 |     信号控制     |                     单点webster信控算法                      |
|  2   |              |     公交优先     |                         干线绿波算法                         |
|  3   |              |   车辆路径诱导   | 通过调整车流在决策点的路径比例完成诱导<br/>对诱导点位下游道路排队长度的评价分析 |
|  4   | 高速公路仿真 |     匝道信控     |                  上匝道 ALINEA 信控算法应用                  |
|  5   |              |   车道限速管控   |                  高速公路车道限速动态化管理                  |
|  6   |              |   应急事件处理   |                    车辆事故与事件仿真模拟                    |
|  7   |              |     道路施工     |                        三类施工区仿真                        |
|  8   | 仿真课程教学 | 连续交叉速度引导 |                     绿波车速诱导策略应用                     |
|  9   |              |    交通流还原    |                 高快速路跟驰换道模型参数标定                 |
|  10  |              |   AI 算法预研    |             基于强化学习的快速路可变限速优化研究             |
|  11  | 仿真路网构建 |     路网编辑     |          路网、路段、连接段等仿真元素的增删改查操作          |
|  12  |              |     信控编辑     |         信号灯、灯组的增删改查及双环结构信控加载支持         |
|  13  |              |     需求编辑     | 发车点流量加载配置<br/>单车指定位置加载设置<br/>车辆组成自定义<br/>决策点与路径比例的增删改查 |
|  14  | 仿真过程控制 |     流程控制     | 仿真的开始、暂停、恢复与关闭操作<br/>仿真快照功能应用<br/>仿真信息、路网信息、车辆信息的获取<br/>车辆轨迹平面坐标与地理坐标转换<br/>加速度、仿真精度、随机种子等参数设置 |
|  15  |              |     动作控制     | 限速区、事故区、施工区的设置<br/>车辆移动、信息修改、变道及航向角调整<br/>信号灯颜色、路径、相位信息更新<br/>车道启闭、路方案、路径信息管理<br/>跟驰模型、换道模型参数修改 |
|  16  |              |     仿真输出     | 检测器与采集器的设置<br/>按指定时间频率输出数据<br/>检测器、采集器与仿真路网绑定关系获取<br/>车辆轨迹输出<br/>仿真路网结构化数据输出 |
|  17  | 交互界面开发 |      菜单栏      |      支持用户新增自定义菜单，达成与 TESS NG 软件的交互       |
|  18  |              |      工具栏      |     支持用户新增自定义工具栏，达成与 TESS NG 软件的交互      |



## 1.4.接口架构

​	TESS NG 通过实现 TessInterface 及其三个子接口，将自身主要功能暴露给用户，用户启动 TESS NG 后可以获取 TESS NG 的顶层接口，再通过顶层接口获取三个子接口，调用子接口方法。TESS NG 加载插件后可以调用插件实现的接口方法，用户可以在插件方法中通过 TessInterface 及其子接口控制仿真运行，及仿真过程中车辆驾驶行为、信号灯色、路径车辆分配等等。

​	二次开发的整体架构如下图所示。

<img src="http://129.211.28.237:5566/document/images/0_interface_architecture" alt="二次开发整体架构图" style="zoom: 50%;" />



## 1.5.更新日志

**【 2025-01-21 】**

- TESSNG内核由V3.1升级到V4.0，二次开发版本可使用V4.0专业版基础功能

- 【新增】ISignalPlan 信控方案接口，支持多时段信控方案，替代原有的ISignalGroup接口。

- 【新增】ISignalLamp 信号灯接口，支持创建信号灯并关联信号机。

- 【新增】ICrosswalkSignalLamp 行人信号灯接口，支持创建信号灯并关联信号机。

- 【新增】IRoadWorkZone 占道施工接口，支持创建施工区。

- 【新增】IAccIDentZone 事故区接口升级，包含IAccIDentZoneInterval事故时段，可创建多时段不同参数的事故区。

- 【新增】ILimitedZone 限制区，其本身为借道施工的一部分，可不直接使用，但用户也可以用它做一些自定义的限制形式的区域。

- 【新增】IReconstruction 借道施工（改扩建），可精细化生成，控制改扩建路网。

- 【新增】IReduceSpeedArea 新增限速区接口，可支持分时段IReduceSpeedInterval分车型IReduceSpeedVehiType进行车道限速。

- 【新增】新增收费站系列接口，包括收费车道ITollLane，收费决策点ITollDecisionPoint，收费路径ITollRouting，收费站停车点ITollPoint。

- 【新增】停车场系列接口，包括停车位IParkingStall，停车区域IParkingRegion，停车决策点IParkingDecisionPoint，停车路径IParkingRouting。

- 【新增】节点构建及路径重构接口IJunction，包括自动计算节点流向，输入观测值进行路径重构。

- 【新增】行人面域接口包括：行人面域基类IPedestrian，障碍物面域IObstacleRegion，行人上下客面域IPassengerRegion，椭圆面域。IPedestrianEllipseRegion，扇形面域IPedestrianFanShapeRegion，多边形面域IPedestrianPolygonRegion，矩形面域IPedestrianRectRegion，三角形面域IPedestrianTriangleRegion。

- 【新增】行人人行道面域IPedestrianSIDeWalkRegion接口。

- 【新增】行人人行横道（斑马线）IPedestrianCrossWalkRegion接口。

- 【新增】行人楼梯面域IPedestrianStairRegion接口。

- 【新增】行人人行横道信号灯接口ICrosswalkSignalLamp。

- 【新增】行人路径系列接口，包括：行人路径IPedestrianPath，行人路径途经点IPedestrianPathPoint。

- 【新增】NetInterface类下新增IJunction节点对象的增删改查，新增行人面域，路径的增删改查，新增事故区，施工区，改扩建，限速区，信号灯，信号机，信控方案，星空相位的增删改查，新增停车场，收费站的增删改查。

- 【新增】SimuInterface类下新增获取行人状态，运动中行人信息的接口，新增单步仿真的接口。

- 【优化】统一接口的单位，V3系列默认像素制，V4常用的速度，长度等概念改为米制单位，并提供unitOfMeasure参数显示指定单位类型，从而避免繁琐的m2p，p2m的转化。



**【 2025-09-30 】**

- 【新增】设置车辆安全时距和停车距离的接口 setSafeTimeInterval 和 setStoppingDistance。
- 【新增】读取和设置是否输出信号灯头数据的接口 isRecordSignalLampStatus 和 setIsRecordSignalLampStatus。
- 【移除】变道相关弃用的插件函数 reSetChangeLaneFreelyParam 和 isPassbyEventZone。

<div style="page-break-after: always;"></div>

# 2.快速入门

​	本节提供快速上手指南，通过安装运行、示例讲解，读者可以迅速理解如何在本地环境中构建并运行 TESS NG 的 Python API 示例。这些内容为后续的插件开发与接口调用奠定实践基础，帮助开发者先跑通流程，再逐步深入功能扩展。



## 2.1.安装运行（Windows）

#### <span style="color: green;">Step1：下载示例代码包</span>

1. 在 [济达交通官网](https://www.jidatraffic.com/#/simulation) 下载 TESS NG 最新版本；

   <img src="http://129.211.28.237:5566/document/images/python_2_1_01" alt="图1" style="zoom: 60%;" />

2. 安装完成后，在软件目录的 **`SecondDev`** 文件夹中，可找到名为 **`TESS_PythonAPI_EXAMPLE`** 的 Python 版示例代码包。

   <img src="http://129.211.28.237:5566/document/images/python_2_1_02" alt="图2" style="zoom: 60%;" />

#### <span style="color: green;">Step2：配置开发环境</span>

1. **安装 Python**：

   - 访问 [Python 官方下载页面](https://www.python.org/ftp/python/)，进入 `Index of /ftp/python/` 目录，为确保与 tessng 包兼容，需要选择并下载 **Python 3.6 或 3.8 版本**的安装包；

   - 以 3.6.6 版本为例，点击进入 3.6.6/ 子目录，选择 `python-3.6.6-amd64.exe` 文件下载；

   - 双击下载完成的 `python-3.x.x-xxx.exe` 文件，启动安装程序；

   - 推荐在初始界面勾选 **“Add Python to PATH”**（自动配置环境变量），可避免后续手动设置；

   - 若未勾选 “Add Python to PATH”，需手动将安装目录（如`C:\Python36\`）及子目录 `Scripts`（如`C:\Python36\Scripts`）添加至系统环境变量 `Path`；

   - 可以点击 ”Install Now“ 使用默认路径快速安装，或选择 ”Customize installation” 自定义安装路径，确认后点击 ”Install” 开始安装，等待安装进度完成。

      <img src="http://129.211.28.237:5566/document/images/python_2_1_03" alt="图3" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_04" alt="图4" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_05" alt="图5" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_06" alt="图6" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_07" alt="图7" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_08" alt="图8" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_09" alt="图9" style="zoom: 60%;" />

3. **验证安装结果**：

   - 安装完成后，按下 `Win + R`，输入 `cmd` 打开系统终端；

   - 分别执行命令`python --version`和`pip --version`命令，若输出类似`Python 3.6.6`和`pip 10.0.1 from ... (python 3.6)`的版本信息，说明安装成功。

   <img src="http://129.211.28.237:5566/document/images/python_2_1_10" alt="图10" style="zoom: 60%;" />

4. **安装 tessng 包**：

   - 打开系统终端，输入命令 `pip install tessng` 并执行，等待包资源下载与安装完成；
   - 若提示 pip 版本过低，可先执行 `python -m pip install --upgrade pip` 更新 pip；
   - 若下载速度较慢，可通过镜像源加速，例如执行 `pip install tessng -i https://mirrors.aliyun.com/pypi/simple/`；
   - 此外，也可前往 [PyPI 官网](https://pypi.org/project/tessng/) 下载 tessng 的 whl 格式安装文件，通过执行 `pip install 本地路径\文件名.whl` 进行本地安装。

   <img src="http://129.211.28.237:5566/document/images/python_2_1_11" alt="图11" style="zoom: 60%;" />


#### <span style="color: green;">Step3：选择并配置 IDE</span>

- 推荐使用 **JetBrains PyCharm**（社区版或专业版均可），操作流程如下：

1. **安装 PyCharm**：

   - 访问 [PyCharm 官网](https://www.jetbrains.com/pycharm/)，下载适用于 Windows 系统的安装包；
   - 双击下载完成的 `pycharm-x.x.x.exe` 文件，启动安装程序；
   - 跟随安装向导依次点击 “下一步”，可根据需求选择自定义安装目录；
   - 点击 “安装”，等待安装进度完成。

   <img src="http://129.211.28.237:5566/document/images/python_2_1_12" alt="图12" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_13" alt="图13" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_14" alt="图14" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_15" alt="图15" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_16" alt="图16" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_17" alt="图17" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_18" alt="图18" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_19" alt="图19" style="zoom: 60%;" />

2. **配置 Python 解释器**：

   - 启动 PyCharm，点击“打开”按钮，选择并打开 `TESS_PythonAPI_EXAMPLE` 文件夹；
   - 依次点击顶部菜单栏 “文件> 设置 > Python > 解释器”，点击右侧的 “添加解释器 > 添加本地解释器”，打开“添加 Python解释器”窗口；
   - 在配置窗口中：
     - “环境”选择“生成新的”；
     - “类型”选择“Virtualenv”；
     - “基础 Python”选择已下载的 Python 安装目录下的 `python.exe` ；
     - 勾选“从基础解释器继承软件包”；
     - 点击“确定”按钮，等待虚拟环境创建完成；

   - 若项目目录中生成 `venv` 文件夹，且软件包列表中包含 tessng，说明配置完成。

   <img src="http://129.211.28.237:5566/document/images/python_2_1_20" alt="图20" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_21" alt="图21" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/python_2_1_22" alt="图22" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/python_2_1_23" alt="图23" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/python_2_1_24" alt="图24" style="zoom: 60%;" />

#### <span style="color: green;">Step4：运行示例项目</span>

1. **启动代码**：

   - 在 PyCharm 左侧的 “项目” 面板中，找到项目根目录下的 `main.py` 文件，双击打开该文件的代码界面。在代码编辑区域任意位置右键，选择 “运行 'main'”，即可启动程序。

   <img src="http://129.211.28.237:5566/document/images/python_2_1_25" alt="图25" style="zoom: 60%;" />

2. **软件激活**：

   - 首次启动时会弹出 TESS NG 软件激活窗口，按提示完成激活（需使用有效授权）；
   - 激活成功后关闭窗口，再次点击 “运行” 按钮，即可正常启动示例项目。

   <img src="http://129.211.28.237:5566/document/images/python_2_1_26" alt="图26" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/python_2_1_27" alt="图27" style="zoom: 60%;" />



## 2.2.示例讲解

#### <span style="color: dodgerblue;">Note 1：目录结构及说明</span>

​	`TESS_PythonAPI_EXAMPLE` 采用轻量化文件组织方式，核心文件直接对应功能模块，结构清晰易上手，各文件说明如下：

- **main.py**：项目主入口文件，负责初始化 TESS NG 实例并启动程序
- **MyPlugin.py**：自定义插件核心实现文件，负责初始化插件
- **MyNet.py**：自定义路网插件实现文件，可以在路网加载前后执行自定义操作，控制路网元素的绘制
- **MySimulator.py**：自定义仿真插件实现文件，可以在仿真前后以及仿真过程中执行自定义操作，既能全局控制仿真的启停逻辑，也能精细化干预单个车辆的驾驶行为
- **MyGUI.py**：自定义界面插件实现文件，用于扩展 TESS NG 交互界面（如新增按钮、弹窗、数据展示面板等）
- **requirements.txt**：项目环境依赖配置文件，记录运行示例所需的 Python 包及版本（如 `tessng` 等），可通过 `pip install -r requirements.txt` 快速部署环境 

#### <span style="color: dodgerblue;">Note 2：插件注册机制与仿真控制逻辑</span>

​	很多 TESS NG 初用者常会困惑：自己编写的自定义插件代码是如何被 TESS NG 调用的？结合项目主入口文件`main.py`的实现逻辑，可清晰理解这一过程，同时需明确仿真场景的核心开发思路，具体说明如下：

1. 先解答核心疑问：**自定义代码如何被 TESS NG 调用？**关键在于 `main.py` 中 `factory.build(my_plugin, config)` 这行代码。它是连接用户自定义插件与 TESS NG 仿真核心的 “桥梁”，`TessngFactory`（TESS NG 提供的工厂类）的`build`方法，会将用户通过 `my_plugin = MyPlugin()`创建的自定义插件实例（`MyPlugin`是用户编写的插件类，封装了所有自定义逻辑），通过 TESS NG 底层接口注册到仿真核心。注册完成后，TESS NG 会在仿真运行的关键节点（如仿真启动、每一步仿真推进、仿真结束等），自动调用 `MyPlugin` 及其子插件 `MyNet` 和 `MySimulator` 中用户重写的钩子方法，无需手动编写 “调用代码”，从而实现功能拓展。
2. 再明确仿真场景开发的核心思路：初用者易陷入 “如何把 TESS NG 仿真嵌入自己计算代码” 的误区，正确做法是 “**将自定义计算代码嵌入 TESS NG 仿真流程**”。TESS NG 已提供成熟的仿真框架（如路网加载、仿真推进、界面交互等基础能力），`main.py`的核心作用就是 “配置并启动这个框架”。用户无需自己搭建仿真框架，只需将计算代码（如自定义车辆行为、数据采集、特殊场景触发逻辑等）封装到 `MyPlugin` 及其子插件 `MyNet` 和 `MySimulator` 的特定方法中（例如 TESS NG 提供的每步仿真触发方法 `afterOneStep`、仿真启动触发方法 `afterStart`），待 `factory.build` 完成插件注册后，这些逻辑会被 TESS NG 自动嵌入仿真流程，随仿真推进执行。

 ​	项目主入口文件 `main.py` 的代码如下：

```python
import os
from PySide2.QtWidgets import QApplication
from tessng import TessngFactory
from MyPlugin import MyPlugin


if __name__ == "__main__":
# 创建工作空间文件夹
workspace_dir_path: str = os.path.join(os.getcwd(), "WorkSpace")
os.makedirs(workspace_dir_path, exist_ok=True)

# 构建配置
config = {
  "__netfilepath": "",                # TODO 路网文件路径
  "__workspace": "D:/TESSNG/V4.0.20",  # 工作空间路径
  "__simuafterload": True,            # 加载路网后是否自动开启仿真
  "__custsimubysteps": False,         # 是否自定义仿真函数调用频率
}

# 创建 Qt 应用程序实例
app = QApplication()
# 创建自定义插件类实例
my_plugin = MyPlugin()
# 创建 TESS NG 工厂类实例
factory = TessngFactory()
# 通过工厂类构建 TESS NG 仿真核心对象
tessng = factory.build(my_plugin, config)
# 判断仿真核心对象是否创建成功
if tessng is not None:
  # 启动 Qt 应用程序的事件循环，进入事件循环后，程序会持续响应用户操作和仿真事件
  app.exec_()
```

#### <span style="color: dodgerblue;">Note 3：修改启动路网</span>

​	修改 `main.py` 中的 `config` 配置属性：

- `"__netfilepath"`：用于指定 TESS NG 启动时默认加载的路网文件路径；

- `"__simuafterload"`：用于指定 TESS NG 加载路网文件后是否立即开启仿真。

  例如：


```python
config = {
	"__netfilepath": "C:/TESSNG_4.1.0/Examles/杭州武林门区域路网公交优先方案.tess",	
	"__simuafterload": True
}
```

#### <span style="color: dodgerblue;">Note 4：路网元素的增删查改及属性操作</span>

​	可通过 `netiface` 接口实现对路网元素（如路段、连接段等）的**新增、删除、查询、修改**，同时获取路网元素对象后，支持对其属性进行**查询**与**修改**。

- 以下示例为：路网元素的增删查改（通过 `netiface` 接口）。

```python
from tessng import UnitOfMeasure

# 1. 查询所有路段：获取当前路网中所有路段的列表
links = self.netiface.links()

# 2. 按ID查询指定路段：获取ID为1的路段（若不存在则返回None）
link = self.netiface.findLink(1)

# 3. 新增路段：传入路段顶点坐标（link_points）、车道数（7）、路段名称（"曹安公路"），创建并返回新路段对象
link_points = [QPointF(-300, 0), QPointF(300, 0)]
link1 = self.netiface.createLink(link_points, 7, "曹安公路", True, UnitOfMeasure.Metric)

# 4. 删除路段：传入需删除的路段对象（link1），从路网中移除该路段
netiface.removeLink(link1)
```

- 以下示例为：路网元素属性的查询与修改（通过元素对象）。


```python
# 1. 属性查询：获取路段link1的相关属性
lane_count = link1.laneCount()  # 查询路段车道数（返回整数，如3）
lane_length = link1.length()  # 查询路段长度（返回浮点数，单位：m）

# 2. 属性修改：修改路段link1的名称与限速
link1.setName("曹安公路")  # 设置路段名称为"曹安公路"
link1.setLimitSpeed(80)  # 设置路段限速为80km/h
```

#### <span style="color: dodgerblue;">Note 5：路网加载前后的自定义操作</span>

​	在自定义路网插件（`MyNet` 类）中，可通过重写 `beforeLoadNet` 和 `afterLoadNet` 方法，实现**路网加载前的预处理**与**路网加载后的后续操作**。

- 以下示例为：路网加载完成后，先判断当前路网是否存在路段；若不存在，则调用自定义方法 `create_network()` 创建基础路网（含路段、连接段、发车点等）。

```python
# MyNet.py：自定义路网插件的实现文件
def afterLoadNet(self) -> None:
    # 获取路段数
    link_count = self.netiface.linkCount()
    # 如果路网上没有路段，则调用自定义的创建路网的方法
    if link_count == 0:
        # 自定义方法：内部实现路段、连接段、发车点的创建逻辑
        self.create_network()
```

#### <span style="color: dodgerblue;">Note 6：路网元素的显示控制</span>

​	在自定义路网插件（`MyNet` 类）中，可通过重写 `labelNameAndFont` 方法实现对路网元素（如路段、连接段）标签的精细化显示控制 —— 包括标签内容（显示名称 / ID / 不显示）、字体大小的自定义，满足不同场景下的路网可视化需求。

- 以下示例为：名称为“曹安公路”的路段的标签显示路段名称，其它路段标签显示ID，连接段标签则都显示名称。

```python
# MyNet.py：自定义路网插件的实现文件
def ref_labelNameAndFont(self, itemType, itemId, ref_outPropName, ref_outFontSize) -> None:
    # 1. 仿真正在运行时（非暂停）：路段、车道不绘制标签，避免干扰仿真观察
   if self.simuiface.isRunning():
        ref_outPropName.value = GraphicsItemPropName.None_  # 不显示任何标签
        return;  # 直接返回，无需执行后续逻辑

    # 2. 默认配置：标签显示元素ID，字体大小为6米
    ref_outPropName.value = GraphicsItemPropName.Id
    ref_outFontSize.value = 6

    # 3. 连接段特殊配置：全部显示名称（无论ID，统一以名称标识）
    if itemType == NetItemType.GConnectorType:
    	ref_outPropName.value = GraphicsItemPropName.Name
    # 4. 路段特殊配置：仅ID为1、5、6的路段显示名称，其余显示ID
    elif itemType == NetItemType.GLinkType:
        if itemId == 1 or itemId == 5 or itemId == 6:
            ref_outPropName.value = GraphicsItemPropName.Name
```

#### <span style="color: dodgerblue;">Note 7：仿真信息的查询和修改</span>

​	可通过 `simuiface` 接口实现对**仿真核心参数**的查询与修改，包括仿真时长、精度、倍速等。

```python
# 1. 仿真信息查询：获取当前仿真的关键参数
simu_interval = simuiface.simuIntervalScheming()  # 查询预设仿真总时长（单位：s）
simu_accuracy = simuiface.simuAccuracy()  # 查询仿真精度
simu_multiples = simuiface.acceMultiples()  # 查询仿真倍速
simu_time = simuiface.simuTimeIntervalWithAcceMutiples()  # 查询当前已仿真时间（单位：ms）

# 2. 仿真信息修改：设置仿真的关键参数
simuiface.setSimuIntervalScheming(3600)  # 设置仿真总时长为3600s
simuiface.setSimuAccuracy(1)  # 设置仿真精度为1
simuiface.setAcceMultiples(5)  # 设置仿真倍速为5
```

#### <span style="color: dodgerblue;">Note 8：仿真车辆的增删查及属性操作</span>

​	可通过 `simuiface` 接口实现对**仿真车辆**的新增、删除、查询，同时支持获取车辆对象后，查询其所有属性，并修改**静态属性**（不随仿真动态变化的属性，如长度、最大速度）。

- 以下示例为：仿真车辆的增删查改（通过 `simuiface`  接口）。

```python
# 1. 查询车辆：获取指定范围的车辆列表
all_vehicles = simuiface.allVehiStarted()  # 获取当前所有已启动的车辆
link_vehicles = simuiface.vehisInLink(1)  # 获取当前在ID为1的路段上行驶的车辆

# 2. 新增车辆：在指定路段动态创建车辆（需先配置车辆参数 DynaVehiParam）
dvp = Online.DynaVehiParam()  # 车辆动态参数对象
dvp.vehiTypeCode = random.randint(0, 4) + 1  # 随机设置车辆类型编码（1-4，对应不同车型）
dvp.roadId = 6  # 指定车辆初始所在路段ID（此处为6）
dvp.laneNumber = random.randint(0, 3)  # 随机设置初始车道号（0-2，对应路段的第1-3车道）
dvp.dist = 50  # 车辆在路段上的初始距离（距路段起点50m）
dvp.speed = 20  # 车辆初始速度（单位：m/s）
dvp.color = "#00AFF0"  # 车辆显示颜色
# 调用接口创建车辆，返回新车辆对象（若创建失败则返回None）
vehicle1 = self.simuiface.createGVehicle(dvp)
# 判断车辆是否创建成功
if vehicle1 is not None:
	print(f"在路段上创建了车辆：{vehicle1.id()}")

# 3. 删除车辆：停止指定车辆（vehicle1）的行驶并从仿真中移除
simuiface.stopVehicleDriving(vehicle1)
```

- 以下示例为：车辆属性的查询与静态修改（通过车辆对象）。


```python
# 1. 属性查询：获取车辆vehicle的相关属性
road_name = vehicle.roadName()  # 车辆所在路段名或连接段名
speed = vehicle.currSpeed()  # 获取车辆的当前速度，单位：m/s

# 2. 属性修改：修改车辆vehicle的长度与限速
vehicle.setLength(5);  # 修改车辆的长度，单位：m
vehicle.setMaxSpeed(80/3.6);  # 修改车辆的最大速度，单位：m/s
```

#### <span style="color: dodgerblue;">Note 9：仿真车辆的动态属性修改</span>

​	车辆的**动态属性**（如实时速度、加速度，随仿真过程动态变化）无法直接通过车辆对象修改，需在**自定义仿真插件（`MySimulator` 类）** 中，重写特定对象方法实现 —— 本质是对 TESS NG 实时计算的动态数值进行修正或覆盖。

- 以下示例为：在 `reSetSpeed` 方法中，根据车辆 ID 和所在路段，强制指定部分车辆的实时速度（使 ID 2~N 的车辆跟随 ID 1 的车辆速度）。

```python
# MySimulator.py：自定义仿真插件的实现文件
def ref_reSetSpeed(self, vehicle, ref_inOutSpeed) -> bool:
    # 1. 处理车辆ID（取余避免ID过长，仅保留后5位）
    tmp_vehicle_id = vehicle.id() % 100000

    # 2. 获取车辆当前所在路段名称
    road_name = vehicle.roadName()

    # 3. 仅对"曹安公路"上的车辆执行速度控制逻辑
    if road_name == "曹安公路":
        # 若为ID=1的车辆：记录其当前速度（作为基准速度）
        if tmp_vehicle_id == 1:
            self.plane_speed = vehicle.currSpeed()
       # 若为ID 2~self.squareVehiCount的车辆：强制将其速度设为基准速度
        elif 2 <= tmp_vehicle_id <= self.square_vehi_count:
           # 覆盖TESS NG计算的速度值
            ref_inOutSpeed.value = self.plane_speed
           # 返回True表示速度修改生效
            return True
   # 返回False表示不修改速度，使用TESS NG默认计算值
    return False
```

#### <span style="color: dodgerblue;">Note 10：特定仿真时机的自定义操作</span>

​	在自定义仿真插件（`MySimulator` 类）中，可通过重写 TESS NG 提供的特定方法，在**不同仿真节点触发自定义逻辑**：既支持在**仿真全局时机**（如仿真启动前、结束后）执行操作，也支持在**车辆特定行为时机**（如车辆创建、车辆移除、车辆换道前）触发逻辑，满足精细化的仿真定制需求。

- 通过重写 `beforeStart`（仿真启动前）和 `afterStop`（仿真结束后）方法，可实现仿真全局的预处理与后处理，例如初始化仿真参数、循环启动仿真、导出仿真结果等。以下示例为：仿真结束后，判断累计仿真次数是否 ≤ 3；若满足条件，则自动重新启动仿真（实现循环仿真）。

```python
# MySimulator.py：自定义仿真插件的实现文件
def afterStop(self) -> None:
    # 1. simuCount为自定义变量，用于统计累计仿真次数
    if self.simu_count <= 3:
        # 2. 调用接口重新启动仿真
        self.simuiface.startSimu()
```

- 通过重写与车辆行为绑定的方法，可在车辆满足特定条件时触发逻辑，例如车辆创建后初始化属性、车辆移除后记录数据等。以下示例为：在仿真车辆创建后，根据车辆 ID 设置车辆的车型、位置和长度。

```python
# MySimulator.py：自定义仿真插件的实现文件
from tessng import m2p

def initVehicle(self, vehicle) -> None:
    # 1. 获取当前车辆的基础信息（所在路段名称、路段ID）
    road_name = vehicle.roadName()  # 车辆当前所在路段/连接段的名称
    # 车辆所在路段ID或连接段ID
    road_id = vehicle.roadId()  # 车辆当前所在路段/连接段的ID

    # 2. 仅对「曹安公路」上的车辆执行特殊定制逻辑
   if road_name == '曹安公路':
        # 处理车辆ID：取余100000，剔除首位数（首位数通常关联车辆来源，如发车点、公交线路）
       tmp_vehicle_id = vehicle.id() % 100000

       # 3. 针对特定ID的车辆，设置专属车型与初始位置
        if tmp_vehicle_id == 1:
            # 将ID=1的车辆设置为「12号车型」
            vehicle.setVehiType(12)
            # 初始化车辆的初始车道、位置和速度
            vehicle.initLane(3, m2p(105), 0)
        # 中间可补充其他ID车辆的定制逻辑，tmp_vehicle_id=2、3等

        # 4. 针对ID 23~28的车辆，设置特定长度
        if tmp_vehicle_id >= 23 and tmp_vehicle_id <= 28:
            vehicle.setLength(m2p(4.5), True)
```



<div style="page-break-after: always;"></div>

# 3.接口详情

​	本节将首先介绍**全局配置参数（config.json）**，然后依次介绍**插件（Plugin）**、**接口（Interface）** 和 **对象（Object）**三个层次的内容，帮助读者从整体到细节逐步理解 TESS NG 的二次开发模式。



## 3.1.全局配置参数

​	TESS NG 可识别的全局配置参数 config.json 如下: 

```json
{
	"__netfilepath": "xxx.tess", 		
	"__simuafterload": false, 
	"__timebycpu": false, 
	"__writesimuresult": true, 
	"__custsimubysteps": false,
    "__allowspopup": false
}
```

**__netfilepath**

​	 指定 TESSNG 启动后加载的路网文件路径，支持绝对路径或相对路径。若文件不存在，将默认打开空白路网。

**__simuafterload**

​	指定TESSNG加载路网文件后是否自动启动仿真，默认为 False。 

**__timebycpu**

​	指定仿真周期的时间计算依据：基于 CPU 时钟的现实时长，或基于仿真精度的时长，默认为 False。在线仿真且算力紧张时，可尝试将此属性设为 True。

**__writesimuresult**

​	控制是否输出仿真结果，默认为 True。若设为 False，仿真结束后不写入结果文件，且仿真过程中，车辆驶出路网一段时间后会被回收到可用队列，以减少内存占用。

**__custsimubysteps**

​	设置 TESSNG 调用插件方法的频次依据，默认为 False。设为 False 时，每个计算周期调用一次（不依据插件端设置的频次）；设为 True 时，将依据插件设置的频次调用其实现的方法。

**__allowspopup**

​	控制是否允许弹出提示弹窗，以避免阻塞程序运行，默认为True。



## 3.2.插件

​	通常，软件的功能拓展通过定义插件接口并由用户实现插件来完成。TESS NG亦采用此模式，其包含顶级插件接口TessPlugin，以及PyCustomerNet、PyCustomerSimulator两个子插件接口。与仅能调用接口方法而无法改变内部运行逻辑的TessInterface接口不同，用户通过实现TessPlugin及其子接口的方法，能够深入TESS NG的内部运行过程，在路网加载、仿真过程、窗体交互等环节施加影响，进而改变其运行逻辑，实现更深层次的功能拓展。这两个子插件的所有方法均提供默认实现，用户可通过需求选择性实现部分或全部方法。

​	由于插件接口方法的调用场景与目的存在差异，为统一对插件接口方法的理解，多数方法采用如下结构形式：

```python
def ref_method(outParam: type) -> bool: 
{
    outParam.value = 1
	return True
}
```

​	TESS NG调用这些方法时遵循如下逻辑：**若返回值为False，则视为用户无响应，将忽略该调用；若返回值为True，表明用户有响应，此时将通过参数outParam的值进行后续处理**。以示例中的场景为例：当曹安公路上的车辆排成队列时，需对飞机后方的车辆重新设置速度，使其与飞机保持一致，此时，PyCustomerSimulator的子类MySimulator可通过实现 `ref_reSetSpeed` 方法来达成这一需求。

```python
def ref_reSetSpeed(self, vehicle, ref_inOutSpeed) -> bool:
    tmp_vehicle_id = vehicle.id() % 100000
    road_name = vehicle.roadName()
    if road_name == "曹安公路":
        if tmp_vehicle_id == 1:
            self.plane_speed = vehicle.currSpeed()
        elif 2 <= tmp_vehicle_id <= self.square_vehi_count:
            ref_inOutSpeed.value = self.plane_speed
            return True
    return False
```

​	TESS NG在计算车辆的速度后会调用插件的reSetSpeed方法，如果该方法返回True，视插件对此方法作出响应，这时再用outSpeed值取代原先计算的车速。TESS NG调用插件 `reSetSpeed` 方法的过程（C++代码）如下：

```cpp
if (gpTessPlugin && gpTessPlugin->customerSimulator())
{
   qreal outSpeed = mrCurrSpeed；
   if (gpTessPlugin->customerSimulator()->reSetSpeed(mpGVehicle，outSpeed))
   {
       mrCurrSpeed = outSpeed；
   }
}
```

### 3.2.1.顶级插件（TessPlugin）

​	TessPlugin是用户开发的顶级插件接口，下面有两个子插件接口：PyCustomerNet、PyCustomerSimulator，用户通过实现这两个子插件分别在路网、仿真过程两个方面与TESSNG进行交互。

**def init(self) -> None**

​	插件初始化，可在此实现方法里实例化CustomerNet、CustomerSimulator两个类的子类。

**def customerNet(self) -> Tessng.CustomerNet**

​	返回customerNet对象。

**def customerSimulator(self) -> Tessng.CustomerSimulator**

​	返回CustomerSimulator对象。


### 3.2.2.路网插件（PyCustomerNet）

​	PyCustomerNet是TessPlugin的子插件接口，用户通过实现该插件，可以在路网加载前后执行自定义操作，控制路网元素的绘制，并定义视窗事件的响应逻辑。

#### 3.2.2.1.路网加载

**def beforeLoadNet(self) -> None**

​	加载路网前调用，用户可以通过此方法在加载路网前作必要的初始化准备工作。

**def afterLoadNet(self) -> None**

​	加载路网后调用。

示例：

```python
def afterLoadNet(self) -> None:
    # 获取路段数
    link_count = self.netiface.linkCount()
    # 如果路网上没有路段，则调用自定义的创建路网的方法
    if link_count == 0:
        self.create_network()
```

#### 3.2.2.2.路网元素绘制

**def isPermitForCustDraw(self) -> bool**

​	是否允许调用客户绘制。本方法的目的是减少不必要的代码调用，消除对运行效率的负面影响。

返回：

​	是否绘制，True表示绘制，False表示不绘制，默认为True。

**def isDrawLinkCenterLine(self, linkId: int) -> bool**

​	是否绘制路段中心线。

参数：

​	[ in ] linkID：路段ID。

返回：

​	是否绘制，True表示绘制，False表示不绘制，默认为True。

示例：

```python
def isDrawLinkCenterLine(self, linkId: int) -> bool:
    # ID为1的路段不绘制中心线
    return link_id != 1
```

**def isDrawLinkCorner(self, linkId: int) -> bool**

​	是否绘制路段四个拐角的圆形和正方型。

参数：

​	[ in ] linkID：路段ID。

返回：

​	是否绘制，True表示绘制，False表示不绘制，默认为True。

**def isDrawLaneCenterLine(self, laneId: int) -> bool**

​	是否绘制车道中心线。

参数：

​	[ in ] laneID：车道ID。

返回：

​	是否绘制，True表示绘制，False表示不绘制，默认为False。

**def linkType(self, list[str] lType) -> bool**

​	路段类型。

参数：

​	[ in ] lType：用户定义的路段类型列表。

返回：

​	是否自定义。

**def laneType(self, List[str] lType) -> bool**

​	车道类型。

参数：

​	[ in ] lType：用户定义的车道类型列表。

返回：

​	是否自定义。

**def paint(self, itemType: int, itemId: int, painter: PySide2.QtGui.QPainter) -> bool**

​	绘制路网元素。

参数：

​	[ in ] itemType：路网元素类型。

​	[ in ] itemID：路网元素ID。

​	[ in ] painter：QPainter对象。

返回：

​	如果返回True，TESSNG认为插件已绘制，TESSNG不再绘制，否则TESSNG进行绘制。

**def paintLaneObject(self, pILaneObj: Tessng.ILaneObject, painter: PySide2.QtGui.QPainter) -> bool**

​	绘制车道或车道连接。

参数：

​	[ in ] pILaneObj：车道或车道连接。

​	[ in ] painter：QPainter对象。

返回：

​	如果返回True，TESSNG认为插件已绘制，TESSNG不再绘制，否则TESSNG进行绘制。

**def linkBuildGLanes(self, pILink: Tessng.ILink) -> bool**

​	创建车道。

参数：

​	[ in ] pILink：路段对象。

返回：

​	如果返回True，TESSNG认为插件已创建了车道，TESSNG不再创建。

**def linkBrushColor(self, linkId: int, color: PySide2.QtGui.QColor) -> bool**

​	路段笔刷颜色。

参数：

​	[ in ] linkID：路段ID。

​	[ out ] color：QColor对象。

返回：

​	True表示用color颜色绘制路段。

示例：

```python
from PySide2.QtGui import QColor

def linkBrushColor(self, linkId: int, color: QColor) -> bool:
    # 指定路段设置为红色
    target_link_ids = [1, 2, 3]
    if linkId in target_link_ids:
        color.setNamedColor("#FF0000")
        return True
    return False
```

**def laneBrushAndPen(self, laneId: int, brush: PySide2.QtGui.QBrush, pen: PySide2.QtGui.QPen) -> bool**

​	通过指定车道ID设置绘制车道的笔刷。

参数：

​	[ in ] laneID：车道ID。

​	[ out ] brush：QBrush 对象。

​	[ out ] pen：QPen 对象。

返回：

​	True表示用brush及pen参数绘制ID等于laneID的车道。

**def connectorAreaBrushColor(self, connAreaId: int, color: PySide2.QtGui.QColor) -> bool**

​	面域笔刷颜色。

参数：

​	[ in ] connAreaID：面域ID。

​	[ out ] color：笔刷颜色。

返回：

​	True表示TESSNG用color绘制面域。

**def labelNameAndFont(self, itemType: int, itemId: int, outPropName: int, outFontSize: float) -> None**

**def ref_labelNameAndFont(self, itemType: int, itemId: int, ref_outPropName: Tessng.objint, ref_outFontSize: Tessng.objreal) -> None**

​	通过路网元素类型及ID确定用标签用ID或名称作为绘制内容。

参数：

​	[ in ] itemType：路段元素类型。

​	[ in ] itemID：路网元素ID。

​	[ out ] outPropName：枚举值。如果赋值GraphicsItemPropName::ID，则用ID作为绘制内容，如果赋值GraphicsItemPropName::Name，则用路网元素名作为绘制内容。

​	 [ out ] outFontSize：字体大小。单位：m。

返回：	

​	True表示通过设定的ref_PropName 值确定用ID或名称绘制标签，并且用指定大小绘制。

示例：

```python
from tessng import objint, objreal

def ref_labelNameAndFont(self, itemType: int, itemId: int, ref_outPropName: objint, ref_outFontSize: objreal) -> None:
    # 如果仿真正在进行，路段和车道都不绘制标签
    if self.simuiface.isRunning():
        ref_outPropName.value = GraphicsItemPropName.None_
        return

    # 默认绘制ID
    ref_outPropName.value = GraphicsItemPropName.Id
    # 标签大小为6m
    ref_outFontSize.value = 6

    # 如果是连接段一律绘制名称
    if itemType == NetItemType.GConnectorType:
        ref_outPropName.value = GraphicsItemPropName.Name
    # 如果是路段，则根据ID判断是否绘制名称
    elif itemType == NetItemType.GLinkType:
        if itemId == 1 or itemId == 5 or itemId == 6:
            ref_outPropName.value = GraphicsItemPropName.Name
```

#### 3.2.2.3.视窗事件响应

**def afterViewMousePressEvent(self, event: PySide2.QtGui.QMouseEvent) -> None**

​	用于实现鼠标点击后的自定义响应逻辑。

参数：

​	[ in ] event：鼠标事件对象。

示例：

```python
from PySide2.QtGui import QMouseEvent

def afterViewMousePressEvent(self, event: QMouseEvent) -> None:
	# 获取鼠标坐标
    mouse_pos = event.pos()
    # 转为仿真场景坐标
    scene_pos = self.netiface.graphicsView().mapToScene(mouse_pos)
    x = scene_pos.x()
    y = scene_pos.y()
```

**def afterViewMouseReleaseEvent(self, event: PySide2.QtGui.QMouseEvent) -> None**

​	用于实现鼠标释放后的自定义响应逻辑。

参数：

​	[ in ] event：鼠标事件对象。

**def afterViewMouseDoubleClickEvent(self, event: PySide2.QtGui.QMouseEvent) -> None**

​	用于实现鼠标双击后的自定义响应逻辑。

参数：

​	[ in ] event：鼠标事件对象。

**def afterViewMouseMoveEvent(self, event: PySide2.QtGui.QMouseEvent) -> None**

​	用于实现鼠标移动后的自定义响应逻辑。

参数：

​	[ in ] event：鼠标事件对象。

**def afterViewWheelEvent(self, event: PySide2.QtGui.QWheelEvent) -> None**

​	用于实现鼠标滚动后的自定义响应逻辑。

参数：

​	[ in ] event：鼠标滚轮事件对象。

**def afterViewKeyReleaseEvent(self, event: PySide2.QtGui.QKeyEvent) -> None**

​	用于实现键盘释放后的自定义响应逻辑。

参数：

​	[ in ] event：键盘事件对象。

**def afterViewResizeEvent(self, event: PySide2.QtGui.QResizeEvent) -> None**

​	用于实现屏幕缩放后的自定义响应逻辑。

参数：

​	[ in ] event：屏幕缩放事件对象。

**def afterViewScrollContentsBy(self, dx: int, dy: int) -> None**

​	用于实现视窗滚动条移动后的自定义响应逻辑。

参数：

​	[ in ] dx：水平方向的滚动偏移量，大于0时表示向左滚动。单位：像素。

​	[ in ] dy：垂直方向的滚动偏移量，大于0时表示向上滚动。单位：像素。

### 3.2.3.仿真插件（PyCustomerSimulator）

​	PyCustomerSimulator是TessPlugin子插件接口，用户通过实现该插件，可以在仿真前后以及仿真过程中执行自定义操作，既能全局控制仿真的启停逻辑，也能精细化干预单个车辆的驾驶行为。

#### 3.2.3.1.仿真启停

**def beforeStart(self, keepOn: bool) -> None**

**def ref_beforeStart(self, ref_keepOn: Tessng.objbool) -> None**

​	用于实现启动仿真前的自定义操作。如果需要，用户可通过设置keepOn为False来放弃仿真。

参数：

​	[ out ] keepOn：是否继续，默认为True。

**def afterStart(self) -> None**

​	用于实现启动仿真后的自定义操作。

**def afterStop(self) -> None**

​	用于实现结束仿真后的自定义操作。

示例：

```python
def afterStop(self) -> None:
    # 如果仿真次数不足3次，则重启仿真
    if self.simu_count <= 3:
        self.simuiface.startSimu()
```

**def afterOneStep(self) -> None**

​	用于实现完成一帧仿真后的自定义操作。这个时候所有车辆都完成同一个批次的计算。通常在这个方法中获取车辆轨迹、检测器数据、进行必要的小计等。在这个方法中进行的计算基本不影响仿真结果的一致性，但效率不高，如果计算量大对仿真效率会有影响。

**def duringOneStep(self) -> None**

​	该方法在各个工作线程进行同一批次的计算过程中调用，这时存在部分车辆计算完成，部分车辆仍在计算过程中。这个方法中的计算不够安全，但效率较高。

**def calcSimuConfig(self, config: Online.SimuConfig) -> bool**

​	计算仿真参数 。

参数：

​	[ out ] config：仿真参数信息。

返回：

​	True表示用config中的参数更新仿真参数。如果仿真已启动，仿真精度及线程数不能更新，仿真时长及加速倍数可以更新。

#### 3.2.3.2.车辆控制

**def initVehicle(self, pIVehicle: Tessng.IVehicle) -> None**

​	用于实现车辆创建后的自定义操作。用户可以在这个方法里对车辆的车道序号、起始位置、车辆大小进行初始化。

参数：

​	[ in ] pIVehicle：车辆对象。

示例：

```python
from tessng import IVehicle

def initVehicle(self, pIVehicle: IVehicle) -> None:
    # 如果是小客车，则设为蓝色
	if pIVehicle.vehicleTypeCode() == 1:
		pIVehicle.setColor("#00AFF0")
```

**def isStopDriving(self, pIVehicle: Tessng.IVehicle) -> bool**

​	用于判断是否要停止车辆的运行。

参数：

​	[ in ] pIVehicle：车辆对象。

返回：

​	True表示将停止该车辆运行，移出路网。

示例：

```python
from tessng import IVehicle

def isStopDriving(self, pIVehicle: IVehicle) -> bool:
    # 如果车辆进入12号路段，则移除
    if pIVehicle.roadIsLink() and pIVehicle.roadId() == 12:
        return True
    return False
```

**def beforeStopVehicle(self, pIVehicle: Tessng.IVehicle) -> None**

​	用于实现车辆移除前的自定义操作。

参数：

​	[ in ] pIVehicle：车辆对象。 

**def afterStopVehicle(self, pIVehicle: Tessng.IVehicle) -> None**

​	用于实现车辆移除后的自定义操作。

参数：

​	[ in ] pIVehicle：车辆对象。

**def afterStep(self, pIVehicle: Tessng.IVehicle) -> None**

​	用于实现车辆完成一帧仿真后的自定义操作。可以在此获取车辆当前信息，如当前道路、位置、方向角、速度、期望速度、前后左右车辆等。

参数：

​	[ in ] pIVehicle：车辆对象。

**def calcAcce(self, pIVehicle: Tessng.IVehicle, acce: float) -> bool**

**def calcAcce(self, pIVehicle: Tessng.IVehicle, acce: float, unit: UnitOfMeasure) -> bool**

**def ref_calcAcce(self, pIVehicle: Tessng.IVehicle, acce: Tessng.objreal) -> bool**

**def ref_calcAcce_unit(self, pIVehicle: Tessng.IVehicle, ref_acce: Tessng.objreal, ref_unit: Tessng.objUnitOfMeasure) -> bool**

​	计算车辆的加速度。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ out ] acce：车辆加速度。单位：像素/s²。

返回：	

​	如果返回True，则将acce作为当前加速度。

示例：

```python
from tessng import IVehicle, objreal, objUnitOfMeasure

def ref_calcAcce_unit(self, pIVehicle: IVehicle, ref_acce: objreal, ref_unit: objUnitOfMeasure) -> bool:
    if pIVehicle.roadName() == "曹安公路":
        # 根据速度不同，直接计算加速度
        if pIVehicle.currSpeed() > 20/3.6:
            ref_acce.value = -3
            return True;
        elif pIVehicle.currSpeed() > 10/3.6:
            ref_acce.value = -1
          	return True
	return False
```

**def reSetAcce(self, pIVehicle: Tessng.IVehicle, inOutAcce: float) -> bool**

**def reSetAcce(self, pIVehicle: Tessng.IVehicle, inOutAcce: float, unit: UnitOfMeasure) -> bool**

**def ref_reSetAcce(self, pIVehicle: Tessng.IVehicle, ref_inOutAcce: Tessng.objreal) -> bool**

**def ref_reSetAcce_unit(self, pIVehicle: Tessng.IVehicle, ref_inOutAcce: Tessng.objreal, ref_unit: Tessng.objUnitOfMeasure) -> bool**

​	重新计算车辆的加速度。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in, out ] inOutAcce：车辆加速度。单位：像素/s²。

返回：

​	如果返回True，则将inOutAcce作为当前加速度。

示例：

```python
from tessng import IVehicle, objreal, objUnitOfMeasure

def ref_reSetAcce_unit(self, pIVehicle: IVehicle, ref_inOutAcce: objreal, ref_unit: objUnitOfMeasure) -> bool:
    if pIVehicle.roadName() == "曹安公路":
        # 根据速度不同，对已计算出的加速度进行修正
        if pIVehicle.currSpeed() > 20/3.6:
            acce.value += -3
            return True
        elif pIVehicle.currSpeed() > 10/3.6:
            acce.value += -1
          	return True
	return False
```

**def reCalcdesirSpeed(self, pIVehicle: Tessng.IVehicle, inOutDesirSpeed: float) -> bool**

**def reCalcdesirSpeed(self, pIVehicle: Tessng.IVehicle, inOutDesirSpeed: float, unit: UnitOfMeasure) -> bool**

**ref_reCalcdesirSpeed(self, pIVehicle: Tessng.IVehicle, ref_desirSpeed: Tessng.objreal) -> bool**

**ref_reCalcdesirSpeed_unit(self, pIVehicle: Tessng.IVehicle, ref_inOutDesirSpeed: Tessng.objreal, ref_unit: Tessng.objUnitOfMeasure) -> bool**

​	重新计算车辆的期望速度。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in, out ] inOutDesirSpeed：车辆期望速度。单位：像素/s²。

返回：

​	如果返回True，则将inOutDesirSpeed作为期望速度。

**def calcMaxLimitedSpeed(self, pIVehicle: Tessng.IVehicle, inOutLimitedSpeed: float) -> bool**

**def calcMaxLimitedSpeed(self, pIVehicle: Tessng.IVehicle, inOutLimitedSpeed: float, unit: UnitOfMeasure) -> bool**

**ref_calcMaxLimitedSpeed(self, pIVehicle: Tessng.IVehicle, ref_inOutLimitedSpeed: Tessng.objreal) -> bool**

**ref_calcMaxLimitedSpeed_unit(self, pIVehicle: Tessng.IVehicle, ref_inOutLimitedSpeed: Tessng.objreal, ref_unit: Tessng.objUnitOfMeasure) -> bool**

​	重新计算车辆的当前最大限速。在没有插件干预的情况下，车辆速度大于道路限度时按道路最大限速行驶，在此方法的干预下，可以提高限速，让车辆大于道路限速行驶。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in, out ] inOutLimitedSpeed：车辆最大限速，单位：像素/秒。

返回：

​	如果返回True，则将inOutLimitedSpeed作为当前道路最大限速。

**def calcSpeedLimitByLane(self, pILink: Tessng.ILink, laneNumber: int, outSpeed: float) -> bool**

**def calcSpeedLimitByLane(self, pILink: Tessng.ILink, laneNumber: int, outSpeed: float, unit: UnitOfMeasure) -> bool**

**ref_calcSpeedLimitByLane(self, pILink: Tessng.ILink, laneNumber: int, ref_outSpeed: Tessng.objreal) -> bool**

**def ref_cadLimitByLane_unit(self, pILink: Tessng.ILink, laneNumber: int, ref_outSpeed: Tessng.objreal, ref_unit: Tessng.objUnitOfMeasure) -> bool**

​	由车道确定的限制车速。

参数：

​	[ in ] pILink：路段对象。

​	[ in ] laneNumber：laneNumber：车道序号，最右侧编号为0。

​	[ in, out ] outSpeed：车辆限速。单位：km/h。

返回：	

​	如果返回True，则将outSpeed作为车道限速。

**def reSetSpeed(self, pIVehicle: Tessng.IVehicle, inOutSpeed: float) -> bool**

**def reSetSpeed(self, pIVehicle: Tessng.IVehicle, inOutSpeed: float, unit: UnitOfMeasure) -> bool**

**ref_reSetSpeed(self, pIVehicle: Tessng.IVehicle, ref_inOutSpeed: Tessng.objreal) -> bool**

**ref_reSetSpeed_unit(self, pIVehicle: Tessng.IVehicle, ref_inOutSpeed: Tessng.objreal, ref_unit: Tessng.objUnitOfMeasure) -> bool**

​	重新计算车辆的速度。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in, out ] inOutSpeed：车辆速度。单位：像素/s。

返回：

​	如果返回True，则将inOutSpeed作为车辆当前速度。

示例：

```python
from tessng import IVehicle, objreal, objUnitOfMeasure

def ref_reSetSpeed_unit(self, vehicle: IVehicle, ref_inOutSpeed: objreal, ref_unit: objUnitOfMeasure) -> bool:
    if vehicle.id() == 100001:
        # 直接指定车辆的速度
        ref_inOutSpeed.value = 80 / 3.6;
        return True
    return False
```

**def reCalcAngle(self, pIVehicle: Tessng.IVehicle, inOutAngle: float) -> bool**

**def ref_reCalcAngle(self, pIVehicle:Tessng.IVehicle, ref_outAngle:Tessng.objreal) -> bool**

​	重新计算车辆的角度。北向为0度，顺时针。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in, out ] inOutAngle：车辆角度。单位：角度。

返回：

​	如果返回True，则将inOutAngle作为车辆当前角度。

**def reSetFollowingType(self, pIVehicle: Tessng.IVehicle, outTypeValue: int) -> bool**

**def ref_reSetFollowingType(self, pIVehicle: Tessng.IVehicle, ref_outTypeValue: Tessng.objint) -> bool**

​	重新设置车辆的跟驰类型。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ out ] outTypeValue：跟驰类型。0：停车，1：正常，5：急减速，6：急加速，7：汇入，8：穿越，9：协作减速，10：协作加速，11：减速待转，12：加速待转。

返回：	

​	如果返回True，则将outTypeValue作为车辆的跟驰类型。

**def reSetFollowingParam(self, pIVehicle: Tessng.IVehicle, inOutSafeInterval: float, inOutSafeDistance: float) -> bool**

**def reSetFollowingParam(self, pIVehicle: Tessng.IVehicle, inOutSafeInterval: float, inOutSafeDistance: float, unit: UnitOfMeasure) -> bool**

**def ref_reSetFollowingParam(self, pIVehicle: Tessng.IVehicle, ref_inOutSafeInterval: Tessng.objreal, ref_inOutSafeDistance: Tessng.objreal) -> bool**

**def ref_reSetFollowingParam_unit(self, pIVehicle: Tessng.IVehicle, ref_inOutSafeInterval: Tessng.objreal, ref_inOutSafeDistance: Tessng.objreal, ref_unit: Tessng.objUnitOfMeasure) -> bool**

​	重新设置车辆的跟驰模型的安全间距和安全时距。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in, out ] inOutSafeInterval：安全时距，单位：秒。

​	[ in, out ] inOutSafeDistance：安全间距，单位：像素。

返回：

​	如果返回True，则将inOutSafeInterval作为车辆的安全时距，将inOutSafeDistance作为车辆的安全间距。

**def reSetFollowingParams(self) -> list[Online.FollowingModelParam]**

​	重新设置车辆的跟驰模型参数，使用得到跟驰模型数据取代当前仿真正在采用的跟驰模型，影响所有车辆。

返回：

​	跟驰参数列表，可对机动车和非机车的跟驰参数重新设置，**设置以后会一直被采用**，直到被新的参数所代替。

**def reSetDistanceFront(self, pIVehicle: Tessng.IVehicle, distance: float, s0: float) -> bool**

**def reSetDistanceFront(self, pIVehicle: Tessng.IVehicle, distance: float, s0: float, unit: UnitOfMeasure) -> bool**

**def ref_reSetDistanceFront(self, pIVehicle: Tessng.IVehicle, distance: Tessng.objreal, s0: Tessng.objreal) -> bool**

**def ref_reSetDistanceFront_unit(self, pIVehicle: Tessng.IVehicle, ref_distance: Tessng.objreal, ref_s0: Tessng.objreal, ref_unit: Tessng.objUnitOfMeasure) -> bool**

​	重新设置车辆的前车间距和停车距离。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in, out ] distance：当前车辆与前车的距离。单位：像素。

​	[ in, out ] s0：停车距离。单位：像素。

返回：

​	如果返回True，则将distance作为车辆的前车距，将s0作为车辆的停车距离。

**def calcChangeLaneSafeDist(self, pIVehicle: Tessng.IVehicle, dist: float) -> bool**

**def calcChangeLaneSafeDist(self, pIVehicle: Tessng.IVehicle, dist: float, unit: UnitOfMeasure) -> bool**

**def ref_calcChangeLaneSafeDist(self, pIVehicle: Tessng.IVehicle, ref_dist: Tessng.objreal) -> bool**

**def ref_calcChangeLaneSafeDist_unit(self, pIVehicle: Tessng.IVehicle, ref_dist: Tessng.objreal, ref_unit: Tessng.objUnitOfMeasure) -> bool**

​	计算车辆的安全变道距离。

参数：

​	[ in ] pIVehicle：车辆，计算该车辆安全变道距离。

​	[ in, out ] dist：安全变道距离。单位：像素。

返回：

​	如果返回True，则将dist作为车辆的安全变道距离。

**def reCalcToLeftLane(self, pIVehicle: Tessng.IVehicle) -> bool**

​	计算是否要左强制变道，仅在TESSNG判定无需执行向左强制变道时生效，不能阻止TESSNG对车辆向左强制变道的控制。

参数：

​	[ in ] pIVehicle：车辆对象。

返回：

​	如果返回True，则控制车辆向左强制变道。

**def reCalcToRightLane(self, pIVehicle: Tessng.IVehicle) -> bool**

​	计算是否要右强制变道，仅在TESSNG判定无需执行向右强制变道时生效，不能阻止TESSNG对车辆向右强制变道的控制。

参数：

​	[ in ] pIVehicle：车辆对象。

返回：

​	如果返回True，则控制车辆向右强制变道。

**def beforeToLeftFreely(self, pIVehicle: Tessng.IVehicle, bKeepOn: bool) -> None**

**def ref_beforeToLeftFreely(self, pIVehicle: Tessng.IVehicle, ref_keepOn: Tessng.objbool) -> None**

​	TESSNG计算是否向左自由变道前的处理。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in, out ] bKeepOn：是否继续，如果被赋值为False，则TESSNG不再计算是否可以向左自由变道。

**def beforeToRightFreely(self, pIVehicle: Tessng.IVehicle, bKeepOn: bool) -> None**

**def ref_beforeToRightFreely(self, pIVehicle: Tessng.IVehicle, ref_keepOn: Tessng.objbool) -> None**

​	TESSNG计算是否向右自由变道前的处理。

​	[ in ] pIVehicle：车辆对象。

​	[ in, out ] bKeepOn：是否继续，如果被赋值为False，则TESSNG不再计算是否可以向右自由变道。

**def reCalcToLeftFreely(self, pIVehicle: Tessng.IVehicle) -> bool**

​	重新计算车辆是否要向左自由变道，仅在TESSNG判定无需执行向左自由变道时生效，不能阻止TESSNG对车辆向左自由变道的控制。

参数：

​	[ in ] pIVehicle：车辆对象。

返回：

​	如果返回True，则控制车辆向左自由变道。

**def reCalcToRightFreely(self, pIVehicle: Tessng.IVehicle) -> bool**

​	重新计算车辆是否要向右自由变道，仅在TESSNG判定无需执行向右自由变道时生效，不能阻止TESSNG对车辆向右自由变道的控制。

参数：

​	[ in ] pIVehicle：车辆对象。

返回：

​	如果返回True，则控制车辆向右自由变道。

**def reCalcDismissChangeLane(self, pIVehicle: Tessng.IVehicle) -> bool**

​	重新计算车辆是否撤销变道。

参数：

​	[ in ] pIVehicle：车辆对象。

返回：

​	如果返回True，且当前变道完成度不超过三分之一，则撤销当前变道行为。

示例：

```python
from tessng import IVehicle

def reCalcDismissChangeLane(self, pIVehicle: IVehicle) -> bool:
    # 距离路段终点小于50m时撤销一切自由变道，达到禁止自由变道的效果
	if pIVehicle.vehicleDriving().distToEndpoint(True, True, UnitOfMeasure.Metric) < 50:
        return True
    return False
```

**def calcLimitedLaneNumber(self, pIVehicle: Tessng.IVehicle) -> list[int]**

​	计算限制车道序号：如管制、危险等，最右侧编号为0。

参数：

​	[ in ] pVehicle：车辆对象。

返回：

​	车道序号序列，保存车辆不可以驶入的车道序号。

示例：

```python
from tessng import IVehicle

def calcLimitedLaneNumber(self, pIVehicle: IVehicle) -> list[int]:
    # 如果车辆在路段上且车辆长度大于8m，则禁止驶入最内侧车道
    if pIVehicle.roadIsLink() and pIVehicle.length(UnitOfMeasure.Metric) > 8:
       limit_lane_number = pIVehicle.lane().link().laneCount()
       return [limit_lane_number]
    return []
```

**def candIDateLaneConnectors(self, pIVehicle: Tessng.IVehicle, lInLC: list[Tessng.ILaneConnector]) -> list[Tessng.ILaneConnector]**

​	计算当车辆离开路段时后续可经过的车道连接，用户可以从可通行的车道连接序列中筛选或重新计算。如果车辆有路径，则忽略。

参数：

​	[ in ] pVehicle：车辆对象。

​	[ in ] lInLC：已计算出的当前车道可达的所有车道连接。

返回：

​	后续可达的车道连接序列。

**def candIDateLaneConnector(self, pIVehicle: Tessng.IVehicle, pCurrLaneConnector: Tessng.ILaneConnector) -> Tessng.ILaneConnector**

​	计算车辆后续要走的车道连接，此时车辆正跨出当前路段，将驶到pCurrLaneConnector上。此方法可以改变后续车道连接。如果返回的车道连接为空，TESSNG会忽略此方法的调用。如果返回的车道连接不在原有路径上，或者此方法设置了新路径且新路径不经过返回的车道连接，TESSNG调用此方法后会将路径设为空。

参数：

​	[ in ] pVehicle：车辆对象。

​	[ in ] pCurrLaneConnector：已计算出的当前车道要走的车道连接。

返回：

​	重新设置的车道连接。

**def beforeNextPoint(self, pIVehicle: Tessng.IVehicle, keepOn: bool) -> None**

**def ref_beforeNextPoint(self, pIVehicle: Tessng.IVehicle, ref_keepOn: Tessng.objbool) -> None**

​	计算车辆移动到下一点前的操作，用户可以通过此方法让TESSNG放弃对指定车辆到下一点的计算。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ out ] keepOn：是否继续，如果keepOn赋值为False，TESSNG放弃移动到下一点的计算，但不移出路网。

**def beforeMergingToLane(self, pIVehicle: Tessng.IVehicle, keepOn: bool) -> None**

**def ref_beforeMergingToLane(self, pIVehicle: Tessng.IVehicle, ref_keepOn: Tessng.objbool) -> None**

​	在车道连接上汇入车道前的计算，可以让TESS NG放弃汇入计算，以便于用户实现自己的汇入逻辑。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ out ] keepOn：是否放弃，如果keepOn赋值为False，TESSNG放弃汇入。

**def beforeNextRoad(self, pIVehicle: Tessng.IVehicle, pRoad: PySide2.QtWidgets.QGraphicsItem, keepOn: bool) -> None**

**def ref_beforeNextRoad(self, pIVehicle: Tessng.IVehicle, pRoad: PySide2.QtWidgets.QGraphicsItem, ref_keepOn: Tessng.objbool) -> None**

​	计算下一道路前的处理。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in ] pRoad：暂不使用的参数。

​	[ in, out ] keepOn：是否继续计算，如果keepOn赋值为False，TESSNG不再计算后续道路。

**def afterCalcTracingType(self, pIVehicle: Tessng.IVehicle) -> None**

​	计算跟驰类型后的处理。

参数：

​	[ in ] pIVehicle：车辆对象。

**def busArriving(self, pIVehicle: Tessng.IVehicle, pStationLine: Tessng.IBusStationLine, alightingCount: int, alightingTime: int, boardingCount: int, boardingTime: int) -> None**

​	公交到站后的处理。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in ] pStationLine：站点线路。

​	[ in ] alightingCount：下客人数。单位：人。

​	[ in ] alightingTime：下客所需总时间。单位：s。

​	[ in ] boardingCount：上客人数。单位：人。

​	[ in ] boardingTime：上客所需总时间。单位：s。

**def leaveForNextLaneObj(self, pIVehicle: Tessng.IVehicle, pCurrLaneObj: Tessng.ILaneObject, pNextLaneObj: Tessng.ILaneObject) -> None**

​	车辆即将跨道路时调用。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in ] pCurrLaneObj：当前车道对象。

​	[ in ] pNextLaneObj：即将进入的车道对象。

**def travelOnChangingTrace(self, pIVehicle: Tessng.IVehicle) -> bool**

​	车辆行驶在变道轨迹上时调用。

参数：

​	[ in ] pIVehicle：车辆对象。

**bool leaveOffChangingTrace(self, pIVehicle:Tessng.IVehicle, differ: float, s: float)**

**def ref_leaveOffChangingTrace(self, pIVehicle:Tessng.IVehicle, differ: float, ref_s: Tessng.objreal) -> bool**

​	车辆驶出变道轨迹时调用。

参数：

​	[ in ] pIVehicle：车辆对象。

**def isCalcVehicleVector3D(self) -> bool**

​	是否计算车辆3D属性，如欧拉角等。

返回：

​	如果返回True，表示需要计算车辆的3D属性。

**def calcVehicleEuler(self, pIVehicle: Tessng.IVehicle, bPosIDire: bool = True) -> PySide2.QtGui.QVector3D**

​	计算车辆的欧拉角。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in ] bPosIDire：车头方向是否正向计算，如果bPosIDire为False则反向计算。

返回：

​	车辆的欧拉角。

**def vehiRunInfo(self, pIVehicle: Tessng.IVehicle) -> str**

​	控制车辆运行状态弹窗中的文本框的文本信息。在仿真过程中选中某辆车，且按下Ctrl+i可弹窗车辆运行状态弹窗。

返回：

​	显示在车辆运行状态弹窗中的文本框的文本信息。

示例：

```python
from tessng import IVehicle

def vehiRunInfo(self, pIVehicle: IVehicle) -> str:
	return f"车辆当前在ID={pIVehicle.roadId()}的道路上"
```

**def boundingRect(self, pIVehicle: Tessng.IVehicle, outRect: PySide2.QtCore.QRectF) -> bool**

​	获取车辆边界矩形。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ out ] outRect：车辆边界矩形。

**def shape(self, pIVehicle: Tessng.IVehicle, outShape: PySide2.QtGui.QPainterPath) -> bool**

​	获取车辆图形路径。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ out ] outShape：车辆形状路径。

**def paintVehicle(self, pIVehicle: Tessng.IVehicle, painter: PySide2.QtGui.QPainter) -> bool**

​	绘制车辆。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in ] painter：QPainter对象。

返回：	

​	如果返回True，TESSNG认为用户已经绘制车辆，TESSNG不再绘制车辆。

**def paintVehicleWithRotation(self, pIVehicle: Tessng.IVehicle, painter: PySide2.QtGui.QPainter, inOutRotation: float) -> bool**

​	绘制车辆，绘制前将车辆对象旋转指定角度。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in ] painter：QPainter对象。

​	[ in ] inOutRotation：旋转的角度。单位：度。

返回：

​	如果返回True，TESSNG认为用户已经绘制车辆，TESSNG不再绘制车辆。

**def rePaintVehicle(self, pIVehicle: Tessng.IVehicle, painter: PySide2.QtGui.QPainter) -> None**

​	添加TESSNG绘制车辆后的自定义绘制内容。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in ] painter：QPainter对象。

示例：

```python
from PySide2.QtCore import QPointF
from PySide2.QtGui import QPainter, QFont, QPainterPath, QFontMetrics, QColor
from tessng import IVehicle

def rePaintVehicle(self, pIVehicle: IVehicle, painter: QPainter) -> None:
    # 在车身上添加车辆名称标签
    label: str = vehicle.name()

    # 创建QFont对象，设置字体和字号
    font = QFont('Arial', 1)
    # 设置字体为非粗体
    font.setBold(False)

    # 创建QFontMetrics对象，获取字体度量信息
    fontMetrics = QFontMetrics(font)
    # 获取文本的边界矩形
    boundingRect = fontMetrics.boundingRect(label)
    # 计算文本位置
    new_x = -boundingRect.center().x() - vehicle.width() * 0.5
    new_y = -boundingRect.center().y()
    position = QPointF(new_x, new_y)

    # 创建QPainterPath对象绘制文本
    textPath = QPainterPath()
    # 将文本添加到路径中
    textPath.addText(position, font, label)
    
    # 设置画笔的缩放比例
    painter.scale(1, 1)
    # 填充路径绘制文本
    painter.fillPath(textPath, QColor("#c94f4f"))
```

#### 3.2.3.3.信号灯控制

**def beforeCalcLampColor(self, keepOn: bool) -> bool**

**def ref_beforeCalcLampColor(self, ref_keepOn: Tessng.objbool) -> bool**

​	用于实现计算信号灯色前的自定义操作。

参数：

​	[ in, out ] 是否继续计算。

返回：	

​	如果返回True，且keepOn被赋值为False，则TESSNG不再计算信号灯色。

**def calcLampColor(self, pSignalLamp: Tessng.ISignalLamp) -> bool**

​	计算信号灯的灯色。

参数：

​	[ in ] pSignalLamp：信号灯对象。

返回：

​	如果返回True，表明用户已修改了信号灯颜色，TESS NG不再计算灯色。

示例：

```python
from tessng import ISignalLamp

def calcLampColor(self, pSignalLamp: ISignalLamp) -> bool:
    # 若信号灯ID为1，则设为绿色
	if pSignalLamp.id() == 1: 
		pSignalLamp.setLampColor("G")
		return True
	return False
```

#### 3.2.3.4.其他

**def beforeCreateGVehiclesForBusLine(self, pBusLine: Tessng.IBusLine, keepOn: bool) -> None**

**def ref_beforeCreateGVehiclesForBusLine(self, pBusLine: Tessng.IBusLine, ref_keepOn: Tessng.objbool) -> None**

​	用于实现创建公交车辆前的自定义操作。

参数：

​	[ in ] pBusLine：公交线路。

​	[ in, out ] keepOn：是否继续执行创建公交车辆。

返回：

​	如果返回True，且keepOn被赋值为False，则TESSNG不再创建公交车辆。

**def calcDynaFlowRatioParameters(self) -> list[Online.DecipointFlowRatioByInterval]**

​	计算动态流量分配信息。

返回：

​	决策点流量分配信息序列。

示例：

```python
from tessng import Online

def calcDynaFlowRatioParameters(self) -> list:
    # 当前仿真计算批次
    batch_number = self.simuiface.batchNumber()
    # 在计算第20批次时修改某决策点各路径流量比
    if batch_number == 20:
        # 一个决策点某个时段各路径车辆分配比
        dfi = Online.DecipointFlowRatioByInterval()
        # 决策点编号
        dfi.deciPointID = 5
        # 起始时间 单位：秒
        dfi.startDateTime = 1
        # 结束时间 单位：秒
        dfi.endDateTime = 999999
        # 路径流量比
        rfr1 = Online.RoutingFlowRatio(1, 3)
        rfr2 = Online.RoutingFlowRatio(2, 4)
        rfr3 = Online.RoutingFlowRatio(3, 3)
        dfi.mlRoutingFlowRatio = [rfr1, rfr2, rfr3]
        return [dfi]
    return []
```

**def calcDynaDispatchParameters(self) -> list[Online.DispatchInterval]**

​	计算动态发车信息。

返回：

​	动态发车信息序列。

示例：

```python
from tessng import Online

def calcDynaDispatchParameters(self) -> list:
    di = Online.DispatchInterval()
    # 发车点ID
    di.dispatchId = 1
    # 开始时间，单位：s
    di.fromTime = 0
    # 结束时间，单位：s
    di.toTime = 300
    # 车辆数
    di.vehiCount = 300
    # 车辆组成列表
    di.mlVehicleConsDetail = [
        Online.VehiComposition(1, 60),
        Online.VehiComposition(2, 40)
    ]
    return [di]
```



## 3.3.接口

​	与侧重 “流程扩展与逻辑干预”的插件不同，接口聚焦于**“数据交互与状态调控”**，其包含顶级接口TessInterface ，以及NetInterface、SimuInterface、GuiInterface三个子接口，为用户提供了路网、仿真、窗体三类核心信息的获取与设置能力，用户可通过它直接读取路网的拓扑结构、仿真的实时参数（如时间步长、车辆总数）、窗体的显示配置（如尺寸、视图缩放比例），也能主动修改这些信息以调整系统基础状态。

​	顶级接口对象具备全局变量的特性，可在代码的任意位置进行实例化。不过，从代码可维护性与使用便捷性的角度出发，我们更建议在**构造函数**中完成各接口的初始化操作，例如：

```python
# MySimulator.py
class MySimulator(PyCustomerSimulator, QObject):
    def __init__(self):
        PyCustomerSimulator.__init__(self)
        QObject.__init__(self)
        # 代表TESS NG的接口
        self.iface = tessngIFace()
        # 代表TESS NG 的路网子接口
        self.netiface = self.iface.netInterface()
        # 代表TESS NG 的仿真子接口
        self.simuiface = self.iface.simuInterface()
        # 代表TESS NG 的界面子接口
        self.guiiface = self.iface.guiInterface()
```

### 3.3.1.顶级接口（TessInterface）

​	TessInterface 是TESSN对外暴露的顶级接口，下面有三个子接口：NetInterface、SimuInterface、GuiInterface，分别用于访问或控制路网、仿真过程和用户交互界面。

**def config(self) -> dict**

​	获取json对象，其中保存了config.json配置文件中的信息，每次加载路网时会重新加载配置信息。

**def setConfigProperty(self, key: str, value: any) -> None**

​	设置配置属性。

**def loadPluginFromMem(self) -> bool**

​	加载插件。

**def releasePlugins(self) -> None**

​	卸载插件。

**def netInterface(self) -> Tessng.NetInterface**

​	返回用于访问控制路网的接口NetInterface。

示例：

```python
iface = tessngIFace()
netiface = self.iface.netInterface()
```

**def simuInterface(self) -> Tessng.SimuInterface**

​	返回用于控制仿真过程的接口SimuInterface。

示例：

```python
iface = tessngIFace()
simuiface = self.iface.simuInterface()
```

**def guiInterface(self) -> Tessng.GuiInterface**

​	返回用于访问控制用户介面的接口GuiInterface。

示例：

```python
iface = tessngIFace()
guiiface = self.iface.guiInterface()
```

### 3.3.2.路网接口（NetInterface）

​	NetInterface是TessInterface的子接口，用于访问、控制路网元素的接口，通过这个接口可以对路段和连接段等路网元素进行查询、创建、删除和更改。

#### 3.3.2.1.路网

**def netFilePath(self) -> str**

​	获取路网文件全路径名，如果是专业数据保存的路网，返回的是路网ID。

示例：

```python
net_file_path: str = self.netiface.netFilePath()
```

**def saveRoadNet(self) -> None**

​	保存当前路网文件。

**def openNetFle(self, filePath: str) -> None**

​	打开路网文件。

参数：

​	[ in ] filePath：路网文件全路径名。

**def createEmptyNetFile(self, filePath: str, dbver: int = 5) -> bool**

​	创建空白路网。

参数：

​	[ in ] filePath：空白路网全路径名。

​	[ in ] dbver：数据库版本。

**def openNetByNetID(self, netId: int) -> None**

​	从专业数据库加载路网。

**def netAttrs(self) -> Tessng.IRoadNet**

​	获取路网属性对象。

**def roadNet(self) -> Tessng.IRoadNet**

​	获取路网属性对象。同netAttrs。

**def setNetAttrs(self, name: str, sourceType: str = "TESSNG", centerPoint: PySide2.QtCore.QPointF = QPointF(), backgroundUrl: str = "", otherAttrsJson: dict = QJsonObject()) -> Tessng.IRoadNet**

​	设置路网基本信息。

参数：

​	[ in ] name：路网名称。

​	[ in ] sourceType：数据来源分类，默认为 "TESSNG"，表示路网由TESSNG软件直接创建。取值"OPENDRIVE"，表示路网是经过opendrive路网导入而来。

​	[ in ] centerPoint：中心点坐标所在路网，默认为(0，0)，用户也可以将中心点坐标保存到otherAttrsJson字段里。

​	[ in ] backgroundUrl：底图路径。

​	[ in ] otherAttrsJson：保存在json对象中的其它属性，如大地坐标等信息。

返回：

​	路网属性对象。

**def graphicsScene(self) -> PySide2.QtWidgets.QGraphicsScene**

​	获取场景对象。

**def graphicsView(self) -> PySide2.QtWidgets.QGraphicsView**

​	获取视图对象。

**def sceneScale(self) -> float**

​	获取场景中的像素比。单位：m/像素。

**def sceneWidth(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取场景宽度。单位：像素。

**def sceneHeigth(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取场景高度。单位：像素。

**def backgroundMap(self) -> bytes**

​	获取背景图字节。

**def boundingRect(self) -> PySide2.QtCore.QRectF**

​	获取路网边界。

**def getIDByItemName(self, name: str) -> int**

​	通过路网元素名获取自增ID。

参数：

​	[ in ] name：路网元素名。

**def initSequence(self, schemaName: str = "") -> bool**

​	初始化数据库序列，对保存路网的专业数据库序列进行初始化，目前支持PostgreSql。

参数：

​	[ in ] schemaName：数据库的schema名称。

#### 3.3.2.2.道路

**def sections(self) -> list[Tessng.ISection]**

​	获取所有道路。

#### 3.3.2.3.路段

**def linkCount(self) -> int**

​	获取路段数。

**def linkIds(self) -> list[int]**

​	获取路段路段ID序列。

**def links(self) -> list[Tessng.ILink]**

​	获取路段对象序列。

示例：

```python
for link in self.netiface.links():
    print(link.id())
```

**def findLink(self, id: int) -> Tessng.ILink**

​	通过路段ID获取路段对象。

**def linkCenterPoints(self, linkId: int, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

​	获取指定路段中心线断点序列。单位：像素。

参数：

​	[ in ] linkID：指定路段ID。

**def createLink(self, lCenterPoint: list[PySide2.QtCore.QPointF], laneCount: int, linkName: str = "", bAddToScene: bool = True, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.ILink**

​	创建路段。单位：像素。

参数：

​	[ in ] lCenterPoint：路段中心线断点序列。

​	[ in ] laneCount：车道数。

​	[ in ] linkName：路段名称。

​	[ in ] bAddToScene：是否添加到场景。

返回：

​	路段对象。

示例：

```python
from PySide2.QtCore import QPointF
from tessng import UnitOfMeasure

link_points = [QPointF(-300, 0), QPointF(300, 0)]
link = self.netiface.createLink(link_points, 7, "曹安公路", True, UnitOfMeasure.Metric)
```

**def createLink3D(self, lCenterV3: list[PySide2.QtGui.QVector3D], laneCount: int, linkName: str = "", bAddToScene: bool = True, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.ILink**

​	创建3D路段。单位：像素。

参数：

​	[ in ] lCenterV3：路段中心线三维断点集。

​	[ in ] laneCount：车道数。

​	[ in ] linkName：路段名称。

​	[ in ] bAddToScene：是否添加到场景。

​	[ in ] unit：单位参数，默认为Default，Metric表示米制单位，Default表示无单位限制。

返回：

​	路段对象。

示例：

```python
from PySide2.QtGui import QVector3D
from tessng import UnitOfMeasure

link_points = [QVector3D(-300, 0, 10), QVector3D(300, 0, 20)]
link = self.netiface.createLink3D(link_points, 7, "曹安公路", True, UnitOfMeasure.Metric)
```

**def createLinkWithLaneWidth(self, lCenterPoint: list[PySide2.QtCore.QPointF], lLaneWidth: list[float], linkName: str = "", bAddToScene: bool = True, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.ILink**

​	创建指定车道宽度的路段。单位：像素。

参数：

​	[ in ] lCenterPoint：路段中心线断点序列。

​	[ in ] lLaneWidth：车道宽度列表。

​	[ in ] linkName：路段名称。

​	[ in ] bAddToScene：是否添加到场景。

返回：

​	路段对象。

示例：

```python
from PySide2.QtCore import QPointF
from tessng import UnitOfMeasure

link_points = [QPointF(-300, 0), QPointF(300, 0)]
lane_width_list = [1, 3.5, 3.5, 3.5]
link = self.netiface.createLinkWithLaneWidth(link_points, lane_width_list, "曹安公路", True, UnitOfMeasure.Metric)
```

**def createLink3DWithLaneWidth(self, lCenterV3: list[PySide2.QtGui.QVector3D], lLaneWidth: list[float], linkName: str = "", bAddToScene: bool = True, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.ILink**

​	创建指定车道宽度的3D路段。单位：像素。

参数：

​	[ in ] lCenterV3：路段中心线三维断点序列。

​	[ in ] lLaneWidth：车道宽度列表。

​	[ in ] linkName：路段名称。

​	[ in ] bAddToScene：是否添加到场景。

返回：

​	路段对象。

示例：

```python
from PySide2.QtGui import QVector3D
from tessng import UnitOfMeasure

link_points = [QVector3D(-300, 0, 10), QVector3D(300, 0, 20)]
lane_width_list = [1, 3.5, 3.5, 3.5]
link = self.netiface.createLink3DWithLaneWidth(link_points, 7, "曹安公路", True, UnitOfMeasure.Metric)
```

**def createLink3DWithLanePoints(self, lCenterLineV3: list[PySide2.QtGui.QVector3D], lanesWithPoints: list[dict[str, list[PySide2.QtGui.QVector3D]]], linkName: str = "", bAddToScene: bool = True, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.ILink**

​	创建指定车道断点的3D路段。单位：像素。

参数：

​	[ in ] lCenterLineV3：路段中心线三维断点序列。

​	[ in ] lanesWithPoints：车道点集的集合。

​	[ in ] linkName：路段名称。

​	[ in ] bAddToScene：是否添加到场景。

返回：

​	路段对象。

示例：

```python
from PySide2.QtGui import QVector3D
from tessng import UnitOfMeasure

# 路段中心线
link_points = [QVector3D(-300, 0, 10), QVector3D(300, 0, 20)]

# 各车道的左中右线
lanes_points = [
	{
        "left": [QVector3D(-300, 0, 10), QVector3D(300, 0, 20)],
        "center": [QVector3D(-300, 1.75, 10), QVector3D(300, 1.75, 20)],
        "right": [QVector3D(-300, 3.5, 10), QVector3D(300, 3.5, 20)]
    },
    {
        "left": [QVector3D(-300, -3.5, 10), QVector3D(300, -3.5, 20)],
        "center": [QVector3D(-300, -1.75, 10), QVector3D(300, -1.75, 20)],
        "right": [QVector3D(-300, 0, 10), QVector3D(300, 0, 20)]
    }
]

link = self.netiface.createLink3DWithLanePoints(link_points, lanes_points, "曹安公路", True, UnitOfMeasure.Metric)
```

**def createLink3DWithLanePointsAndAttrs(self, lCenterLineV3: list[PySide2.QtGui.QVector3D], lanesWithPoints: list[dict[str, list[PySide2.QtGui.QVector3D]]], lLaneType: list[str], lAttr: list[dict], linkName: str = "", bAddToScene: bool = True, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.ILink**

​	创建指定车道断点和属性的3D路段。单位：像素。

参数：

​	[ in ] lCenterLineV3：路段中心线三维断点序列。

​	[ in ] lanesWithPoints：车道点集的集合。

​	[ in ] lLaneType：车道类型序列。

​	[ in ] lAttr：车道附加属性序列。

​	[ in ] linkName：路段名称。

​	[ in ] bAddToScene：是否添加到场景。

返回：

​	路段对象。

**def removeLink(self, pLink: Tessng.ILink) -> None**

​	移除路段。

参数：

​	[ in ] pLink：路段对象。

示例：

```python
# 移除ID为1的路段
link = self.netiface.findLink(1)
self.netiface.removeLink(link)
```

**def updateLink(self, link: Tessng.\_Link, lLane: list[Tessng.\_Lane] = [], lPoint: list[PySide2.QtCore.QPointF] = [], unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.ILink**

​	更新路段。单位：像素。

参数：

​	[ in ] link：路段基本信息。

​	[ in ] lLane：车道列表。

​	[ in ] lPoint：断点列表。

返回：

​	更新后的路段对象。

**def moveLinks(self, lLink: list[Tessng.ILink], offset: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	移动路段及相关连接段。单位：像素。

参数：

​	[ in ] lLink：路段对象序列。

​	[ in ] offset：偏移量。

示例：

```python
from PySide2.QtCore import QPointF

# 获取所有路段
links = self.netiface.links()
# 移动所有路段
self.netiface.moveLinks(links, QPointF(100, 100))
```

**def judgeLinkToCross(self, linkId: int) -> bool**

​	判断路段下游是否进入交叉口，以面域是否存在多连接段，以及当前路段与后续路段之间的角度为依据。

参数：

​	[ in ] linkID：路段ID。

返回：

​	路段下游是否进入交叉口。

#### 3.3.2.4.车道

**def findLane(self, id: int) -> Tessng.ILane**

​	通过车道ID获取车道对象。

**def laneCenterPoints(self, laneId: int, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

​	获取指定ID的车道中心线断点序列。单位：像素。

参数：

​	[ in ] laneID：车道ID。

返回：

​	指定车道的中心线断点序列。

#### 3.3.2.5.连接段

**def connectorCount(self) -> int**

​	获取连接段数。

**def connectorIds(self) -> list[int]**

​	获取连接段ID序列。

**def connectors(self) -> list[Tessng.IConnector]**

​	获取连接段对象序列。

**def findConnector(self, id: int) -> Tessng.IConnector**

​	通过连接段ID获取连接段对象。

**def findConnectorByLinkIds(self, fromLinkId: int, toLinkId: int) -> Tessng.IConnector**

​	通过上游路段ID和下游路段ID获取连接段对象。

**def createConnector(self, fromLinkId: int, toLinkId: int, lFromLaneNumber: list[int], lToLaneNumber: list[int], connName: str = "", bAddToScene: bool = True) -> Tessng.IConnector**

​	创建连接段。

参数：

​	[ in ] fromLinkID：上游路段ID。

​	[ in ] toLinkID：下游路段ID。

​	[ in ] lFromLaneNumber：上游路段车道序号序列。

​	[ in ] LToLaneNumber：下游车道序号序列。

​	[ in ] connName：连接段名，默认为空，将以两条路段的ID连接起来作为名称。

​	[ in ] bAddToScene：创建后是否放入路网场景，默认为True。

返回：

​	连接段对象。

示例：

```python
# 创建连接路段1和路段2的连接段
from_lane_numbers = [1, 2, 3]
to_lane_numbers = [1, 2, 3]
connector = self.netiface.createConnector(1, 2, from_lane_numbers, to_lane_numbers, "连接段1")
```

**def createConnector3DWithPoints(self, fromLinkId: int, toLinkId: int, lFromLaneNumber: list[int], lToLaneNumber: list[int], laneConnectorWithPoints: list[dict[str, list[PySide2.QtGui.QVector3D]]], connName: str = "", bAddToScene: bool = True, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.IConnector**

​	创建指定断点的3D连接段。单位：像素。

参数：

​	[ in ] fromLinkID：上游路段ID。

​	[ in ] toLinkID：下游路段ID。

​	[ in ] lFromLaneNumber：上游路段车道序号列表。

​	[ in ] lToLaneNumber：下游路段车道序号列表。

​	[ in ] laneConnectorWithPoints：车道连接点集的集合。

​	[ in ] connName：连接段名称。

​	[ in ] bAddToScene：是否添加到场景。

返回：

​	连接段对象。

**def removeConnector(self, pConnector: Tessng.IConnector) -> None**

​	移除连接段。

参数：

​	[ in ] pConnector：连接段对象。

**def updateConnector(self, connector: Tessng.\_Connector) -> Tessng.IConnector**

​	更新连接段。单位：像素。

参数：

​	[ in ] connector：连接段基本信息。

返回：

​	连接段对象。

#### 3.3.2.6.车道连接

**def findLaneConnector(self, id: int) -> Tessng.ILaneConnector**

​	通过车道连接ID获取车道连接对象。

**def findLaneConnector(self, fromLaneId: int, toLaneId: int) -> Tessng.ILaneConnector**

​	通过上游车道ID和下游车道ID获取车道连接对象。

**def crossPoints(self, pLaneConnector: Tessng.ILaneConnector) -> list[Online.CrossPoint]**

​	当前车道连接穿过其它车道连接形成的交叉点序列。

参数：

​	[ in ] pLaneConnector：车道连接对象。

返回：

​	交叉点序列。

#### 3.3.2.7.连接段面域

**def allConnectorArea(self) -> list[Tessng.IConnectorArea]**

​	获取所有连接段面域对象序列。

**def findConnectorArea(self, id: int) -> Tessng.IConnectorArea**

​	通过面域ID获取面域对象。

#### 3.3.2.8.路网网格

**def buildNetGrID(self, width: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	路网网格化。

参数：

​	[ in ] width：单元格宽度。单位：像素。

**def findSectionOn1Cell(self, point: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[Tessng.ISection]**

​	通过point获取所在单元格所有道路。

参数：

​	[ in ] point：获取点坐标。单位：像素。

返回：

​	道路对象序列。

**def findSectionOn4Cell(self, point: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[Tessng.ISection]**

​	通过point获取最近4个单元格所有道路。

参数：

​	[ in ] point：获取点坐标。单位：像素。

返回：

​	道路对象序列。

**def findSectionOn9Cell(self, point: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[Tessng.ISection]**

​	通过point获取最近9个单元格所有道路。

参数：

​	[ in ] point：获取点坐标。单位：像素。

返回：

​	道路对象序列。

**def locateOnCrid(self, point: PySide2.QtCore.QPointF, cellCount: int = 1, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[Online.Location]**

​	point周围若干个单元格里获取车道基类对象。

参数：

​	[ in ] point：获取点坐标。单位：像素。

​	[ in ] cellCount：单元格数，小于1时默认为1，大于1小于4时默认为4，大于4时默认为9。

返回：	

​	定位信息序列，按最短距离从小到大排序。

示例：

```python
from PySide2.QtCore import QPointF
from tessng import UnitOfMeasure

# 目标点
target_point = QPointF(50, 50);
# 将目标点投影到附近一定范围内的车道上，获取定位信息序列
locations = self.netiface.locateOnCrid(target_point, 9, UnitOfMeasure.Metric);  # 使用前需要先执行netiface.buildNetGrid(10)
for location in locations:
    print(f"车道/车道连接ID为：{location.pLaneObject->id()}")
    print(f"投影点为：({location.point.x()}, {location.point.y()})")
    print(f"目标点与投影点的间距为：{location.leastDist} m")
    print(f"投影点与车道起点的间距为：{location.distToStart} m")
    print(f"投影点在所在车道的分段序号为：{location.segmIndex}")
```

**def locateOnSections(self, point: PySide2.QtCore.QPointF, lSection: list[Tessng.ISection], referDistance: float = 0, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[Online.Location]**

​	通过point对道路列表中每一个道路所有车道求最短距离。

参数：

​	[ in ] point：获取点坐标。单位：像素。

​	[ in ] lSection：道路列表。

​	[ in ] referDistance：LaneObject上与point最近的点到LaneObject起点距离，只为提高计算效率，默认值为0。

返回：

​	定位信息序列，按最短距离从小到大排序。

#### 3.3.2.9.车型

**def createVehicleType(self, \_vt: Tessng.\_VehicleType) -> bool**

​	创建车型。

参数：

​	[ in ] vt：车辆类型数据。需要指定与现有车型不同的车型名称，否则会创建失败。新创建车型的编码将自动设置为当前最大编码值加 1。

返回：

​	是否创建成功。

示例：

```python
from tessng import _VehicleType

# 构建参数
vehicle_type = _VehicleType()
vehicle_type.vehicleTypeName = "新建车型1"  # 车型名称
vehicle_type.Length = 4.5  # 长度，单位：m
vehicle_type.lengthSD = 0.5  # 长度标准差，单位：m
vehicle_type.width = 2  # 宽度，单位：m
vehicle_type.widthSD = 0.2  # 宽度标准差，单位：m
vehicle_type.avgSpeed = 60  # 期望速度，单位：km/h
vehicle_type.speedSD = 10  # 期望速度标准差，单位：km/h
vehicle_type.avgAcce = 4  # 期望加速度，单位：m/s²
vehicle_type.acceSD = 0.5  # 期望加速度标准差，单位：m/s²
vehicle_type.avgDece = 6  # 期望减速度，单位：m/s²
vehicle_type.deceSD = 0.5  # 期望减速度标准差，单位：m/s²
vehicle_type.maxAcce = 5.5  # 最大加速度，单位：m/s²
vehicle_type.maxDece = 7.5  # 最大减速度，单位：m/s²
vehicle_type.maxSpeed = 80  # 最大速度，单位：km/h
vehicle_type.commercialVehicle = False  # 是否是营运车辆
vehicle_type.maxPassengerCapacity = 1  # 核载人数，单位：人
# 创建车型
result = self.netiface.createVehicleType(vehicle_type)
print(f"创建车型是否成功：{result}")
```

#### 3.3.2.10.车辆组成

**def createVehicleComposition(self, name: str, lVehiComp: list[Online.VehicleComposition]) -> int**

​	创建车型组成。

参数：

​	[ in ] name：车型组成名。

​	[ in ] lVehiComp：不同车型占比序列。

返回：

​	车型组成ID，但如果车型组成名已存在或相关车型编码不存在或相关车型占比小于0则返回-1。

示例：

```python
from tessng import Online

# 构建车辆类型比例列表
vehi_type_proportion_list = [
    Online.VehiComposition(1, 0.3),  # 小客车，占比0.3
    Online.VehiComposition(2, 0.2),  # 大客车，占比0.2
    Online.VehiComposition(3, 0.1),  # 公交车，占比0.1
    Online.VehiComposition(4, 0.4)   # 货车，占比0.4
]
# 创建车辆组成
vehi_composition_id = self.netiface.createVehicleComposition("动态创建车型组成", vehi_type_proportion_list)
```

**def removeVehicleComposition(self, vehiCompId: int) -> bool**

​	移除车型组成。

参数：

​	[ in ] vehiCompID：车型组成ID。

#### 3.3.2.11.发车点

**def dispatchPoints(self) -> list[Tessng.IDispatchPoint]**

​	获取所有发车点序列。

**def findDispatchPoint(self, id: int) -> Tessng.IDispatchPoint**

​	通过发车点ID获取发车点。

**def createDispatchPoint(self, pLink: Tessng.ILink, dpName: str = "", bAddToScene: bool = True) -> Tessng.IDispatchPoint**

​	创建发车点。

参数：

​	[ in ] pLink：路段，在其上创建发车点。

​	[ in ] dpName：发车点名称，默认为空，将以发车点ID作为名称。

​	[ in ] bAddToScene：创建后是否放入路网场景，默认为True。

示例：

```python
# 获取路段对象
link = self.netiface.findLink(1)
# 创建发车点
dp = self.netiface.createDispatchPoint(link)
if dp is not None:
    # 添加发车间隔，含车型组成、时间间隔、发车数
    dp.addDispatchInterval(1, 600, 300)
    dp.addDispatchInterval(1, 600, 400)
```

**def removeDispatchPoint(self, pDispPoint: Tessng.IDispatchPoint) -> bool**

​	移除发车点。

参数：

​	[ in ] pDispPoint：发车点对象。

#### 3.3.2.12.决策点

**def decisionPoints(self) -> list[Tessng.IDecisionPoint]**

​	获取所有决策点序列。

**def findDecisionPoint(self, id: int) -> Tessng.IDecisionPoint**

​	通过决策点ID获取决策点。

**def createDecisionPoint(self, pLink: Tessng.ILink, distance: float, name: str = "", unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.IDecisionPoint**

​	创建决策点。

参数：

​	[ in ] pLink：决策点所在的路段。

​	[ in ] distance：决策点距离路段起点的距离。单位：像素。

​	[ in ] name：决策点的名称。

返回：

​	决策点对象。

示例：

```python
link = self.netiface.findLink(1)
location = 50
decision_point_name = "新建决策点"
decision_point = self.netiface.createDecisionPoint(link, location, decision_point_name, UnitOfMeasure.Metric)
```

**def updateDecipointPoint(self, deciPoint: Tessng.\_DecisionPoint, lFlowRatio: list[\_RoutingFLowRatio] = []) -> Tessng.IDecisionPoint**

​	更新决策点及其各路径不同时间段流量比。

参数：

​	[ in ] deciPoint：决策点数据。

​	[ in ] lFlowRatio：各路径按时间段流量比的数据集合。


返回：

​	决策点对象。

示例：

```python
from tessng import _RoutingFLowRatio, _DecisionPoint

# 初始化左、直、右流量比对象
flowRatio_left = _RoutingFLowRatio()
flowRatio_left.RoutingFLowRatioID = 1
flowRatio_left.routingID = decisionRouting1.id()
flowRatio_left.startDateTime = 0
flowRatio_left.endDateTime = 999999
flowRatio_left.ratio = 2.0

flowRatio_straight = _RoutingFLowRatio()
flowRatio_straight.RoutingFLowRatioID = 2
flowRatio_straight.routingID = decisionRouting2.id()
flowRatio_straight.startDateTime = 0
flowRatio_straight.endDateTime = 999999
flowRatio_straight.ratio = 3.0

flowRatio_right = _RoutingFLowRatio()
flowRatio_right.RoutingFLowRatioID = 3
flowRatio_right.routingID = decisionRouting3.id()
flowRatio_right.startDateTime = 0
flowRatio_right.endDateTime = 999999
flowRatio_right.ratio = 1.0

# 初始化决策点数据
decision_point_data = _DecisionPoint()
decision_point_data.deciPointID = decision_point.id()
decision_point_data.deciPointName = decision_point.name()
decisionPoint_pos = QPointF()
if decisionPoint.link().getPointByDist(decision_point.distance(), decisionPoint_pos): 
    decision_point_data.X = decisionPoint_pos.x()
    decision_point_data.Y = decisionPoint_pos.y()
    decision_point_data.Z = decision_point.link().z()

# 构造流量比列表
flow_ratio_list = [flowRatio_left, flowRatio_straight, flowRatio_right]
# 更新决策点的路径流量比配置
updated_decision_point = self.netiface.updateDecipointPoint(decision_point_data, flow_ratio_list)
```

#### 3.3.2.13.车辆路径

**def findRouting(self, id: int) -> Tessng.IRouting**

​	通过路径ID获取路径对象。

**def createRouting(self, lILink: list[Tessng.ILink]) -> Tessng.IRouting**

​	创建路径，不与决策点绑定。

参数：

​	[ in ] lILink：路段对象序列，需要是不间断的。

返回：

​	路径对象。

示例：

```python
# 路段ID列表
link_id_list = [1, 2, 3, 4]
# 构建路段对象列表
link_list = [self.netiface.findLink(link_id) for link_id in link_id_list]
# 创建车辆路径
routing = self.netiface.createRouting(link_list)
```

**def createDeciRouting(self, pDeciPoint: Tessng.IDecisionPoint, lILink: list[Tessng.ILink]) -> Tessng.IRouting**

​	为决策点添加车辆路径。

参数：

​	[ in ] pDeciPoint：决策点对象。

​	[ in ] lILink：路段对象序列，需要从决策点所在路段开始，且是不间断的。

返回：

​	路径对象。

**def removeDeciRouting(self, pDeciPoint: Tessng.IDecisionPoint, pRouting: Tessng.IRouting) -> bool**

​	移除决策点的车辆路径。

参数：

​	[ in ] pDeciPoint：决策点对象。

​	[ in ] pRouting：路径对象。

返回：

​	是否移除成功。

**def shortestRouting(self, pFromLink: Tessng.ILink, pToLink: Tessng.ILink) -> Tessng.IRouting**

​	计算两路段之间的最短路径。

参数：

​	[ in ] pFromLink：起始路段。

​	[ in ] pToLink：目标路段。

返回：	

​	路径对象。

#### 3.3.2.14.信号机

**def signalControllerCount(self) -> int**

​	获取信号机数量。

**def signalControllerIds(self) -> list[int]**

​	获取信号机ID序列。

**def signalControllers(self) -> list[Tessng.ISignalController]**

​	获取所有信号机对象序列。

**def findSignalControllerById(self, id: int) -> Tessng.ISignalController**

​	通过ID获取信号机对象。

**def findSignalControllerByName(self, name: str) -> Tessng.ISignalController**

​	通过名称获取信号机对象，如果同名返回第一个。

**def createSignalController(self, name: str) -> Tessng.ISignalController**

​	创建信号机。

参数：

​	[ in ] name：信号机名称。

返回：

​	信号机对象。

示例：

```python
# 信号机名称
signal_controller_name = "双龙大道-吉印大道交叉口"
# 创建信号机
signal_controller = self.netiface.createSignalController(signal_controller_name)
```

#### 3.3.2.15.信号控制方案

**def signalPlanCount(self) -> int**

​	获取信控方案组数。

**def signalPlanIds(self) -> list[int]**

​	获取信控方案ID序列。

**def signalPlans(self) -> list[Tessng.ISignalPlan]**

​	获取信控方案对象序列。

**def findSignalPlanById(self, id: int) -> Tessng.ISignalPlan**

​	通过ID获取信控方案对象。

**def findSignalPlanByName(self, name: str) -> Tessng.ISignalPlan**

​	通过名称获取信控方案对象。

**def createSignalPlan(self, pITrafficLight: Tessng.ISignalController, name: str, cycle: int, phasedifference: int, startTime: int, endTime: int) -> Tessng.ISignalPlan**

​	创建信控方案。

参数：

​	[ in ] pITrafficLight：信号机对象。

​	[ in ] name：方案名称。

​	[ in ] cycle：周期时长。

​	[ in ] phasedifference：相位差。

​	[ in ] startTime：起始时间。

​	[ in ] endTime：结束时间。

返回：

​	信控方案对象。

示例：

```python
# 获取信号机对象
signal_controller = self.netiface.findSignalControllerById(1)
# 信控方案名称
signal_plan_name = "平峰方案"
# 周期时长，单位：s
cycle_time = 120
# 相位差，单位：s
phase_difference = 0
# 起始时间，单位：s
start_time = 0
# 结束时间，单位：s
end_time = 3600
# 创建信控方案
signal_plan = self.netiface.createSignalPlan(signal_controller, signal_plan_name, cycle_time, phase_difference, start_time, end_time)
```

#### 3.3.2.16.信号灯相位

**def findSignalPhase(self, id: int) -> Tessng.ISignalPhase**

​	通过信号灯相位ID获取信号灯相位对象。

**def createSignalPlanSignalPhase(self, SignalPlan:Tessng.ISignalPlan, name:str, lColor:list[Online.ColorInterval]) -> Tessng.ISignalPhase**

​	创建信号灯相位。

参数：

​	[ in ] SignalPlan：信控方案对象。

​	[ in ] name：相位名称。

​	[ in ] lColor：灯色对象列表。

返回：

​	信号灯相位对象。

示例：

```python
from tessng import Online

# 获取信控相位对象
signal_plan = self.netiface.findSignalPlanById(1)
# 相位名称
signal_phase_name = "东西直行"
# 构建灯色对象列表
color = ["R", "G", "Y", "R"]
intervals = [30, 26, 3, 61]
color_interval_list = [
    Online.ColorInterval(color, duration)
    for color, duration in zip(colors, durations)
]
# 创建信号灯相位
signal_phase = self.netiface.createSignalPlanSignalPhase(signal_plan, signal_phase_name, color_interval_list)
```

**def removeSignalPhase(self, pPlan: Tessng.ISignalPlan, phaseId: int) -> None**

​	移除已有信号灯相位，相位移除后，原相位序列自动重排。

参数：

​	[ in ] pPlan：信控方案对象。

​	[ in ] phaseID：将要移除的相位ID。

#### 3.3.2.17.信号灯灯头

**def signalLampCount(self) -> int**

​	获取信号灯数。

**def signalLampIds(self) -> list[int]**

​	获取信号灯ID序列。

**def signalLamps(self) -> list[Tessng.ISignalLamp]**

​	获取信号灯对象序列。

**def findSignalLamp(self, id: int) -> Tessng.ISignalLamp**

​	通过信号灯ID获取信号灯对象。

**def createSignalLamp(self, pPhase: Tessng.ISignalPhase, name: str, laneId: int, toLaneId: int, distance: float) -> Tessng.ISignalLamp**

​	创建信号灯。

参数：

​	[ in ] pPhase：相位对象。

​	[ in ] name：信号灯名称。

​	[ in ] laneID：信号灯所在车道ID，或所在车道连接上游车道ID。

​	[ in ] toLaneID：信号灯所在车道连接下游车道ID。

​	[ in ] distance：信号灯距车道或车道连接起点距离。单位：像素。

返回：

​	信号灯对象。

示例：

```python
from tessng import m2p

# 获取相位对象
signal_phase = self.netiface.findSignalPhase(1)
# 信号灯名称
signal_lamp_name = "东直1"
# 车道ID
lane_id = 1
# 下游车道ID
to_lane_id = -1
# 位置，单位：m
distance = m2p(50)
# 创建信号灯
signal_lamp = self.netiface.createSignalLamp(signal_plan, signal_lamp_name, lane_id, to_lane_id, distance)
```

**def createTrafficSignalLamp(self, pTrafficLight: Tessng.ISignalController, name: str, laneId: int, toLaneId: int, distance: float) -> Tessng.ISignalLamp**

​	创建信号灯。

参数：

​	[ in ] pTrafficLight：信号机。

​	[ in ] name：信号灯名称。

​	[ in ] laneID：信号灯所在车道ID，或所在车道连接上游车道ID。

​	[ in ] toLaneID：信号灯所在车道连接下游道ID。

​	[ in ] distance：信号灯距车道或车道连接起点距离。单位：像素。

返回：

​	信号灯对象。

**def addSignalPhaseToLamp(self, SignalPhaseId: int, signalLamp: Tessng.ISignalLamp) -> None**

​	信号灯添加绑定的相位。

参数：

​	[ in ] SignalPhaseID：信号相位ID。

​	[ in ] signalLamp：信号灯对象。

**def removeSignalPhaseFromLamp(self, SignalPhaseId: int, signalLamp: Tessng.ISignalLamp) -> None**

​	信号灯移除某个绑定的相位，如果相位列表只存在一个相位则将关联的相位设置为空。

参数：

​	[ in ] SignalPhaseID：信号相位ID。

​	[ in ] signalLamp：信号灯对象。

**def transferSignalPhase(self, pFromISignalPhase: Tessng.ISignalPhase, pToISignalPhase: Tessng.ISignalPhase, signalLamp: Tessng.ISignalLamp) -> None**

​	信号灯更换绑定的相位，但不允许跨越信号机。

参数：

​	[ in ] pFromISignalPhase：原相位。

​	[ in ] pToISignalPhase：目标相位。

​	[ in ] signalLamp：信号灯对象。

#### 3.3.2.18.数据采集器

**def vehiInfoCollectors(self) -> list[Tessng.IVehicleDrivInfoCollector]**

​	获取所有数据采集器对象序列。

**def findVehiInfoCollector(self, id: int) -> Tessng.IVehicleDrivInfoCollector**

​	通过ID获取数据采集器对象。

**def createVehiCollectorOnLink(self, pLane: Tessng.ILane, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.IVehicleDrivInfoCollector**

​	在路段的车道上创建数据采集器。

参数：

​	[ in ] pLane：车道对象。

​	[ in ] dist：距车道起点距离。单位：像素。

返回：

​	数据采集器对象。

示例：

```python
# 获取车道对象
lane = self.netiface.findLane(1)
# 位置，单位：m
dist = 50
# 在路段上创建数据采集器
collector = self.netiface.createVehiCollectorOnLink(lane, dist, UnitOfMeasure.Metric)
```

**def createVehiCollectorOnConnector(self, pLaneConnector: Tessng.ILaneConnector, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.IVehicleDrivInfoCollector**

​	在连接段的车道连接上创建数据采集器。

参数：

​	[ in ] pLaneConnector：车道连接对象。

​	[ in ] dist：距车道连接起点距离。单位：像素。

返回：

​	数据采集器对象。

示例：

```python
# 获取车道连接对象
lane_connector = self.netiface.findLaneConnector(1, 4)
# 位置，单位：m
dist = 50
# 在连接段上创建数据采集器
collector = self.netiface.createVehiCollectorOnConnector(lane_connector, dist, UnitOfMeasure.Metric)
```

**def removeVehiCollector(self, pCollector: Tessng.IVehicleDrivInfoCollector) -> bool**

​	移除车辆信息采集器。

参数：

​	[ in ] pCollector：车辆信息采集器对象。

返回：

​	是否移除成功。

#### 3.3.2.19.排队计数器

**def vehiQueueCounters(self) -> list[Tessng.IVehicleQueueCounter]**

​	获取所有排队计数器对象序列。

**def findVehiQueueCounter(self, id: int) -> Tessng.IVehicleQueueCounter**

​	通过ID获取排队计数器对象。

**def createVehiQueueCounterOnLink(self, pLane: Tessng.ILane, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.IVehicleQueueCounter**

​	在路段的车道上创建车辆排队计数器。

参数：

​	[ in ] pLane：车道对象。

​	[ in ] dist：距车道起点距离。单位：像素。

返回：

​	排队计数器对象。

示例：

```python
# 获取车道对象
lane = self.netiface.findLane(1)
# 位置，单位：m
dist = 80
# 在路段上创建排队计数器
counter = self.netiface.createVehiQueueCounterOnLink(lane, dist, UnitOfMeasure.Metric)
```

**def createVehiQueueCounterOnConnector(self, pLaneConnector: Tessng.ILaneConnector, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.IVehicleQueueCounter**

​	在连接段的车道连接上创建车辆排队计数器。

参数：

​	[ in ] pLaneConnector：车道连接对象。

​	[ in ] dist：距车道连接起点距离。单位：像素。

返回：

​	排队计数器对象。

示例：

```python
# 获取车道连接对象
lane_connector = self.netiface.findLaneConnector(1, 4)
# 位置，单位：m
dist = 80
# 在连接段上创建排队计数器
counter = self.netiface.createVehiQueueCounterOnConnector(lane_connector, dist, UnitOfMeasure.Metric)
```

#### 3.3.2.20.行程时间检测器

**def vehiTravelDetectors(self) -> list[Tessng.IVehicleTravelDetector]**

​	获取所有车辆行程时间检测器对象序列。

**def findVehiTravelDetector(self, id: int) -> Tessng.IVehicleTravelDetector**

​	通过ID获取车辆行程时间检测器对象。

**def createVehicleTravelDetector_link2link(self, pStartLink: Tessng.ILink, pEndLink: Tessng.ILink, dist1: float, dist2: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[Tessng.IVehicleTravelDetector]**

​	创建路段到路段的行程时间检测器。

参数：

​	[ in ] pStartLink：起始路段对象。

​	[ in ] pEndLink：终止路段对象。

​	[ in ] dist1：检测器起点距路段起始点距离。单位：像素。

​	[ in ] dist2：检测器终点距路段起始点距离。单位：像素。

返回：

​	行程时间检测器对象。

示例：

```python
# 获取起始路段对象
start_link = self.netiface.findLink(1)
# 获取终止路段对象
end_link = self.netiface.findLink(2)
# 检测器起点在起始路段的位置，单位：m
start_dist = 10
# 检测器终点在终止路段的位置，单位：m
end_dist = 90
# 创建起点在路段、终点也在路段的行程时间检测器
detectors = self.netiface.createVehicleTravelDetector_link2link(start_link, end_link, start_dist, end_dist, UnitOfMeasure.Metric)
```

**def createVehicleTravelDetector_link2conn(self, pStartLink: Tessng.ILink, pEndLaneConnector: Tessng.ILaneConnector, dist1: float, dist2: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[Tessng.IVehicleTravelDetector]**

​	创建路段到连接段的行程时间检测器。

参数：

​	[ in ] pStartLink：起始路段对象。

​	[ in ] pEndLaneConnector：终止车道连接对象。

​	[ in ] dist1：检测器起点距路段起始点距离。单位：像素。

​	[ in ] dist2：检测器终点距车道连接起始点距离。单位：像素。

返回：

​	行程时间检测器对象。

示例：

```python
# 获取起始路段对象
start_link = self.netiface.findLink(1)
# 获取终止车道连接对象
end_lane_connector = self.netiface.findLaneConnector(1, 4)
# 检测器起点在起始路段的位置，单位：m
start_dist = 10
# 检测器终点在终止车道连接的位置，单位：m
end_dist = 10
# 创建起点在路段、终点在连接段的行程时间检测器
detectors = self.netiface.createVehicleTravelDetector_link2conn(start_link, end_lane_connector, start_dist, end_dist, UnitOfMeasure.Metric)
```

**def createVehicleTravelDetector_conn2link(self, pStartLaneConnector: Tessng.ILaneConnector, pEndLink: Tessng.ILink, dist1: float, dist2: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[Tessng.IVehicleTravelDetector]**

​	创建连接段到路段的行程时间检测器。

参数：

​	[ in ] pStartLaneConnector：起始车道连接对象。

​	[ in ] pEndLink：终止路段对象。

​	[ in ] dist1：检测器起点距车道连接起始点距离。单位：像素。

​	[ in ] dist2：检测器终点距路段起始点距离。单位：像素。

返回：

​	行程时间检测器对象。

示例：

```python
# 获取起始车道连接对象
start_lane_connector = self.netiface.findLaneConnector(1, 4)
# 获取终止路段对象
end_link = self.netiface.findLink(2)
# 检测器起点在起始车道连接的位置，单位：m
start_dist = 10
# 检测器终点在终止路段的位置，单位：m
end_dist = 90
# 创建起点在连接段、终点在路段的行程时间检测器
detectors = self.netiface.createVehicleTravelDetector_conn2link(start_lane_connector, end_link, start_dist, end_dist, UnitOfMeasure.Metric)
```

**def createVehicleTravelDetector_conn2conn(self, pStartLaneConnector: Tessng.ILaneConnector, pEndLaneConnector: Tessng.ILaneConnector, dist1: float, dist2: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[Tessng.IVehicleTravelDetector]**

​	创建连接段到连接段的行程时间检测器。

参数：

​	[ in ] pStartLaneConnector：起始车道连接对象。

​	[ in ] pEndLaneConnector：终止车道连接对象。

​	[ in ] dist1：检测器起点距车道连接起始点距离。单位：像素。

​	[ in ] dist2：检测器终点距车道连接起始点距离。单位：像素。

返回：

​	行程时间检测器对象。

示例：

```python
# 获取起始车道连接对象
start_lane_connector = self.netiface.findLaneConnector(1, 4)
# 获取终止路段对象
end_lane_connector = self.netiface.findLaneConnector(4, 7)
# 检测器起点在起始车道连接的位置，单位：m
start_dist = 10
# 检测器终点在终止车道连接的位置，单位：m
end_dist = 90
# 创建起点在连接段、终点也在连接段的行程时间检测器
detectors = self.netiface.createVehicleTravelDetector_conn2conn(start_lane_connector, end_lane_connector, start_dist, end_dist, UnitOfMeasure.Metric)
```

#### 3.3.2.21.导向箭头

**def guidArrowCount(self) -> int**

​	获取导向箭头数。

**def guidArrowIds(self) -> list[int]**

​	获取导向箭头ID序列。

**def guidArrows(self) -> list[Tessng.IGuIDArrow]**

​	获取导向箭头对象序列。

**def findGuidArrow(self, id: int) -> Tessng.IGuIDArrow**

​	通过导向箭头ID获取导向箭头对象。

**def createGuidArrow(self, pLane: Tessng.ILane, length: float, distToTerminal: float, arrowType: Online.GuideArrowType, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.IGuIDArrow**

​	创建导向箭头。

参数：

​	[ in ] pLane：车道对象。

​	[ in ] length：长度。单位：像素。

​	[ in ] distToTerminal：到车道终点距离。单位：像素。

​	[ in ] arrowType：箭头类型。

返回：

​	导向箭头对象。

示例：

```python
from tessng import Online, UnitOfMeasure

lane = self.netiface.findLane(4)
if lane is not None:
    length = 4
    dist_to_terminal = 10
    arrow_type = Online.GuideArrowType.StraightRight
    guid_arrow = self.netiface.createGuidArrow(lane, length, dist_to_terminal, arrow_type, UnitOfMeasure.Metric)
```

**def removeGuidArrow(self, pArrow: Tessng.IGuIDArrow) -> None**

​	移除导向箭头。

参数：

​	[ in ] pArrow：导向箭头对象。

#### 3.3.2.22.公交线路

**def buslines(self) -> list[Tessng.IBusLine]**

​	获取公交线路对象序列。

**def findBusline(self, buslineId: int) -> Tessng.IBusLine**

​	通过公交线路ID获取公交线路。

**def findBuslineByFirstLinkID(self, linkId: int) -> Tessng.IBusLine**

​	通过公交线路起始路段ID获取公交线路。

**def createBusLine(self, lLink: list[Tessng.ILink]) -> Tessng.IBusLine**

​	创建公交线路，lLink列表中相邻两路段可以是路网上相邻两路段，也可以不相邻，如果不相邻，TESSNG会在它们之间创建一条最短路径。如果lLink列表中相邻路段在路网上不相邻并且二者之间不存在最短路径，则相邻的第二条路段及后续路段无效。

参数：
	[ in ] lLink，公交线路经过的路段对象序列。

返回：

​	公交线路对象。

示例：

```python
link1 = self.netiface.findLink(1)
link2 = self.netiface.findLink(2)
bus_line = self.netiface.createBusLine([link1, link2])
```

**def removeBusLine(self, pBusLine: Tessng.IBusLine) -> bool**

​	移除公交线路。

参数：

​	[ in ] pBusLine：公交线路对象。

#### 3.3.2.23.公交站点

**def busStations(self) -> list[Tessng.IBusStation]**

​	获取公交站点对象序列。

**def findBusStation(self, stationId: int) -> Tessng.IBusStation**

​	通过公交站点ID获取公交站点对象。

**def createBusStation(self, pLane: Tessng.ILane, length: float, dist: float, name: str = "", unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.IBusStation**

​	创建公交站点。

参数：

​	[ in ] pLane：车道对象。

​	[ in ] length：站点长度。单位：像素。

​	[ in ] dist：站点起始点距车道起点距离。单位：像素。

​	[ in ] name：站点名称。	

返回：

​	公交站点对象。

示例：

```python
from tessng import UnitOfMeasure

lane = self.netiface.findLane(1)
bus_station = self.netiface.createBusStation(lane, 30, 50, "公交站1", UnitOfMeasure.Metric)
# 设置站点类型 1：路边式、2：港湾式
bus_station.setType(1)
```

**def removeBusStation(self, pStation: Tessng.IBusStation) -> bool**

​	移除公交站点。

参数：

​	[ in ] pStation：公交站点对象。

#### 3.3.2.24.公交线路-站点

**def findBusStationLineByStationID(self, stationId: int) -> list[Tessng.IBusStationLine]**

​	通过公交站点ID获取公交线路-站点对象。

**def addBusStationToLine(self, pBusLine: Tessng.IBusLine, pStation: Tessng.IBusStation) -> bool**

​	将公交站点关联到公交线路上。

参数：

​	[ in ] pBusLine：公交线路对象。

​	[ in ] pStation：公交站点对象。

**def removeBusStationFromLine(self, pBusLine: Tessng.IBusLine, pStation: Tessng.IBusStation) -> bool**

​	将公交站点与公交线路的关联关系解除。

参数：

​	[ in ] pBusLine：公交线路对象。

​	[ in ] pStation：公交站点对象。

#### 3.3.2.25.事故区

**def accidentZones(self) -> list[Tessng.IAccidentZone]**

​	获取所有事故区对象。

**def findAccidentZone(self, accidentZoneId: int) -> Tessng.IAccidentZone**

​	通过事故区ID获取事故区对象。

**def createAccidentZone(self, param: Online.DynaAccidentZoneParam) -> Tessng.IAccidentZone**

​	创建事故区。

参数：

​	[ in ] param：动态事故区信息。

返回：

​	事故区对象。

示例：

```python
from tessng import Online, UnitOfMeasure

# 构建参数
param = Online.DynaAccidentZoneParam()
# 事故区名称
param.name = "事故区"
# 道路ID
param.roadId = 1
# 位置, 距离路段或连接段起点距离, 单位：m
param.location = 100
# 长度, 单位：m
param.length = 50
# 车道序号列表，从0开始，连续有序
param.mlFromLaneNumber = [0]
# 开始时间，单位：s
param.startTime= 10
# 持续时间，单位：s
param.duration = 600
# 相邻车道限速，单位：km/h
param.limitSpeed = 40
# 创建事故区
accident_zone = self.netiface.createAccidentZone(param, UnitOfMeasure.Metric)
```

**def removeAccidentZone(self, pIAccidentZone: Tessng.IAccidentZone) -> None**

​	移除事故区。

参数：

​	[ in ] pIAccidentZone：事故区对象。

#### 3.3.2.26.施工区

**def roadWorkZones(self) -> list[Tessng.IRoadWorkZone]**

​	获取所有施工区对象序列。

**def findRoadWorkZone(self, roadWorkZoneId: int) -> Tessng.IRoadWorkZone**

​	通过施工区ID获取施工区对象。

**def createRoadWorkZone(self, param: Online.DynaRoadWorkZoneParam, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.IRoadWorkZone**

​	创建施工区。

参数：

​	[ in ] param：施工区参数。单位：像素。

返回：

​	施工区对象。

示例：

```python
from tessng import Online, UnitOfMeasure

# 构建参数
param = Online.DynaRoadWorkZoneParam()
# 施工区名称
param.name= "施工区"
# 道路ID
param.roadId = 1
# 位置, 距离路段或连接段起点距离, 单位：m
param.location = 200
# 长度, 单位：m
param.length = 50  # 长度
param.upCautionLength = 70  # 提前警示长度
param.upTransitionLength = 50  # 过渡区长度
param.upBufferLength = 50  # 缓冲区长度
param.downTransitionLength = 40  # 下游过渡区长度
param.downTerminationLength = 40  # 终止区长度
# 车道序号列表，从0开始，连续有序
param.mlFromLaneNumber = [0]
# 开始时间，单位：s
param.startTime = 0
# 持续时间，单位：s
param.duration = 3600
# 相邻车道限速，单位：km/h
param.limitSpeed = 40
# 创建施工区
road_work_zone = self.netiface.createRoadWorkZone(param, UnitOfMeasure.Metric)
```

**def removeRoadWorkZone(self, pIRoadWorkZone: Tessng.IRoadWorkZone) -> None**

​	移除施工区。

参数：

​	[ in ] pIRoadWorkZone：施工区对象。

**def updateRoadWorkZone(self, param: Online.DynaRoadWorkZoneParam, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

​	更新施工区。

参数：

​	[ in ] param：施工区参数。单位：像素。

#### 3.3.2.27.限行区

**def limitedZones(self) -> list[Tessng.ILimitedZone]**

​	获取所有限行区对象序列。

**def findLimitedZone(self, limitedZoneId: int) -> Tessng.ILimitedZone**

​	通过限行区ID获取限行区对象。

**def createLimitedZone(self, param: Online.DynaLimitedZoneParam, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.ILimitedZone**

​	创建限行区。

参数：

​	[ in ] param：限行区参数。单位：像素。

返回：

​	限行区对象。

示例：

```python
from tessng import Online, UnitOfMeasure

# 构建参数
param = Online.DynaLimitedZoneParam()
# 限行区名称
param.name = "限行区"
# 道路ID
param.roadId = 1
# 位置, 距离路段或连接段起点距离, 单位：m
param.location = 100
# 长度, 单位：m
param.length = 50
# 车道序号列表，从0开始，连续有序
param.mlFromLaneNumber = [0]
# 开始时间，单位：s
param.startTime = 0
# 持续时间，单位：s
param.duration = 600
# 相邻车道限速，单位：km/h
param.limitSpeed = 40
# 创建限行区
limited_zone = self.netiface.createLimitedZone(param, UnitOfMeasure.Metric)
```

**def removeLimitedZone(self, pILimitedZone: Tessng.ILimitedZone) -> None**

​	移除限行区。

参数：

​	[ in ] pILimitedZone：限行区对象。

**def updateLimitedZone(self, param: Online.DynaLimitedZoneParam, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

​	更新限行区。

参数：

​	[ in ] param：限行区参数。单位：像素。

#### 3.3.2.28.改扩建借道

**def reconstructions(self) -> list[Tessng.IReconstruction]**

​	获取所有改扩建对象。

**def findReconstruction(self, reconstructionId: int) -> Tessng.IReconstruction**

​	通过改扩建ID获取改扩建对象。

**def createReconstruction(self, param: Online.DynaReconstructionParam, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.IReconstruction**

​	创建改扩建。

参数：

​	[ in ] param：改扩建参数。单位：像素。

返回：

​	改扩建对象。

示例：

```python
from tessng import Online, UnitOfMeasure

# 构建参数
param = Online.DynaReconstructionParam()
# 施工区ID
param.roadWorkZoneId = rwz_id
# 被借道的路段ID
param.beBorrowedLinkId = 2
# 被借道的车道数量
param.borrowedNum = 1
# 保通开口长度，单位：m
param.passagewayLength = 80
# 保通开口限速，单位：m/s
param.passagewayLimitedSpeed = 40 / 3.6
# 创建改扩建借道
reconstruction = self.netiface.createReconstruction(param, UnitOfMeasure.Metric)
```

**def removeReconstruction(self, pIReconstruction: Tessng.IReconstruction) -> None**

​	移除改扩建。

参数：

​	[ in ] pIReconstruction：改扩建对象。

**def updateReconStruction(self, param: Online.DynaReconstructionParam, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

​	更新改扩建。

参数：

​	[ in ] param：改扩建参数。单位：像素。

**def reCalcPassagewayLength(self, param: Online.DynaReconstructionParam, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	重新计算保通开口长度，可通过保通详细参数计算出保通开口长度。

参数：

​	[ in ] param：改扩建参数。单位：像素。

返回：

​	保通开口长度。

#### 3.3.2.29.限速区

**def reduceSpeedAreas(self) -> list[Tessng.IReduceSpeedArea]**

​	获取所有限速区对象序列。

**def findReduceSpeedArea(self, id: int) -> Tessng.IReduceSpeedArea**

​	通过限速区ID获取限速区对象。

**def createReduceSpeedArea(self, param: Online.DynaReduceSpeedAreaParam) -> Tessng.IReduceSpeedArea**

​	创建限速区。

参数：

​	[ in ] param：限速区参数。单位：像素。

返回：

​	限速区对象。

**def removeReduceSpeedArea(self, pIReduceSpeedArea: Tessng.IReduceSpeedArea) -> None**

​	移除限速区。

参数：

​	[ in ] pIReduceSpeedArea：限速区对象。

**def updateReduceSpeedArea(self, param: Online.DynaReduceSpeedAreaParam) -> bool**

​	更新限速区。

参数：

​	[ in ] param：限速区参数。单位：像素。

#### 3.3.2.30.行人类型

**def pedestrianTypes(self) -> list[Tessng.IPedestrianType]**

​	获取所有行人类型对象序列。

#### 3.3.2.31.行人组成

**def pedestrianCompositions(self) -> list[Online.Pedestrian.PedestrianComposition]**

​	获取所有行人组成信息序列。

**def createPedestrianComposition(self, name: str, mpCompositionRatio: dict[int, float]) -> int**

​	创建行人组成。

参数：

​	[ in ] name：组成名称。

​	[ in ] mpCompositionRatio：组成明细，key为行人类型编码，value为行人类型占比。

返回：

​	行人组成ID，如果创建失败返回-1。

**def removePedestrianComposition(self, compositionId: int) -> bool**

​	移除行人组成。

参数：

​	[ in ] compositionID：行人组成ID。

**def updatePedestrianComposition(self, compositionId: int, mpCompositionRatio: dict[int, float]) -> bool**

​	更新行人组成。

参数：

​	[ in ] compositionID：行人组成ID。

​	[ in ] mpCompositionRatio：组成明细，key为行人类型编码，value为行人类型占比。

返回：

​	是否更新成功。

#### 3.3.2.32.行人面域层级

**def layerInfos(self) -> list[Online.Pedestrian.LayerInfo]**

​	获取所有层级信息。

**def addLayerInfo(self, name: str, height: float, visible: bool, locked: bool) -> Online.Pedestrian.LayerInfo**

​	新增层级，返回新增的层级信息。

参数：

​	[ in ] name：层级名称。

​	[ in ] height：层级高度。

​	[ in ] visible：是否可见。

​	[ in ] locked：是否锁定，锁定后面域不可以修改。

**def removeLayerInfo(self, layerId: int) -> None**

​	删除某个层级，会删除层级当中的所有元素。

参数：

​	[ in ] layerID：层级ID。

**def updateLayerInfo(self, layerId: int, name: str, height: float, visible: bool, locked: bool) -> bool**

​	更新层级信息。

参数：

​	[ in ] layerID：层级ID。

​	[ in ] name：层级名称。

​	[ in ] height：层级高度。

​	[ in ] visible：是否可见。

​	[ in ] locked：是否锁定，锁定后面域不可以修改。

返回：

​	是否更新成功。

#### 3.3.2.33.行人面域

**def pedestrianRegions(self) -> list[Tessng.IPedestrianRegion]**

​	获取所有行人面域对象序列。

**def pedestrianRectRegions(self) -> list[Tessng.IPedestrianRectRegion]**

​	获取所有矩形面域对象序列。

**def pedestrianTriangleRegions(self) -> list[Tessng.IPedestrianTriangleRegion]**

​	获取所有三角形面域对象序列。

**def pedestrianEllipseRegions(self) -> list[Tessng.IPedestrianEllipseRegion]**

​	获取所有椭圆形面域对象序列。

**def pedestrianFanShapeRegions(self) -> list[Tessng.IPedestrianFanShapeRegion]**

​	获取所有扇形面域对象序列。

**def pedestrianPolygonRegions(self) -> list[Tessng.IPedestrianPolygonRegion]**

​	获取所有多边形面域对象序列。

**def pedestrianSIDeWalkRegions(self) -> list[Tessng.IPedestrianSIDeWalkRegion]**

​	获取所有人行道对象序列。

**def pedestrianCrossWalkRegions(self) -> list[Tessng.IPedestrianCrossWalkRegion]**

​	获取所有人行横道对象序列。

**def findPedestrianRegion(self, id: int) -> Tessng.IPedestrianRegion**

​	通过行人面域ID获取行人面域对象。

**def findPedestrianRectRegion(self, id: int) -> Tessng.IPedestrianRectRegion**

​	通过行人面域ID获取矩形面域对象。

**def findPedestrianEllipseRegion(self, id: int) -> Tessng.IPedestrianEllipseRegion**

​	通过行人面域ID获取椭圆形面域对象。

**def findPedestrianTriangleRegion(self, id: int) -> Tessng.IPedestrianTriangleRegion**

​	通过行人面域ID获取三角形面域对象。

**def findPedestrianFanShapeRegion(self, id: int) -> Tessng.IPedestrianFanShapeRegion**

​	通过行人面域ID获取扇形面域对象。

**def findPedestrianPolygonRegion(self, id: int) -> Tessng.IPedestrianPolygonRegion**

​	通过行人面域ID获取多边形面域对象。

**def findPedestrianSIDeWalkRegion(self, id: int) -> Tessng.IPedestrianSIDeWalkRegion**

​	通过行人面域ID获取人行道对象。

**def findPedestrianCrossWalkRegion(self, id: int) -> Tessng.IPedestrianCrossWalkRegion**

​	通过行人面域ID获取人行横道对象。

**def createPedestrianRectRegion(self, startPoint: PySide2.QtCore.QPointF, endPoint: PySide2.QtCore.QPointF) -> Tessng.IPedestrianRectRegion**

​	创建矩形行人面域。

参数：

​	[ in ] startPoint：左上角坐标。

​	[ in ] endPoint：右下角坐标。

返回	

​	矩形行人面域对象。

**def createPedestrianTriangleRegion(self, startPoint: PySide2.QtCore.QPointF, endPoint: PySide2.QtCore.QPointF) -> Tessng.IPedestrianTriangleRegion**

​	创建三角形行人面域。

参数：

​	[ in ] startPoint：左上角坐标。

​	[ in ] endPoint：右下角坐标。

返回：

​	三角形行人面域对象。

**def createPedestrianEllipseRegion(self, startPoint: PySide2.QtCore.QPointF, endPoint: PySide2.QtCore.QPointF) -> Tessng.IPedestrianEllipseRegion**

​	创建椭圆行人面域。

参数：

​	[ in ] startPoint：左上角坐标。

​	[ in ] endPoint：右下角坐标。

返回：	

​	椭圆行人面域对象。

**def createPedestrianFanShapeRegion(self, startPoint: PySide2.QtCore.QPointF, endPoint: PySide2.QtCore.QPointF) -> Tessng.IPedestrianFanShapeRegion**

​	创建扇形行人面域。

参数：

​	[ in ] startPoint：圆心坐标。

​	[ in ] endPoint：外半径终点坐标。

返回：

​	扇形行人面域对象。

**def createPedestrianPolygonRegion(self, polygon: PySide2.QtGui.QPolygonF) -> Tessng.IPedestrianPolygonRegion**

​	创建多边形行人面域。

参数：

​	[ in ] polygon：多边形顶点。

返回：

​	多边形行人面域对象。

**def createPedestrianSIDeWalkRegion(self, vertexs: list[PySide2.QtCore.QPointF]) -> Tessng.IPedestrianSIDeWalkRegion**

​	创建人行道。

参数：

​	[ in ] vertexs：顶点列表。

返回：	

​	人行道对象。

**def createPedestrianCrossWalkRegion(self, startPoint: PySide2.QtCore.QPointF, endPoint: PySide2.QtCore.QPointF) -> Tessng.IPedestrianCrossWalkRegion**

​	创建人行横道。

参数：

​	[ in ] startPoint：左上角坐标。

​	[ in ] endPoint：右下角坐标。

返回：

​	人行横道对象。

**def createPedestrianStairRegion(self, startPoint: PySide2.QtCore.QPointF, endPoint: PySide2.QtCore.QPointF) -> Tessng.IPedestrianStairRegion**

​	创建楼梯。

参数：

​	[ in ] startPoint：起点坐标。

​	[ in ] endPoint：终点坐标。

返回：	

​	楼梯对象。

**def removePedestrianRectRegion(self, pIPedestrianRectRegion: Tessng.IPedestrianRectRegion) -> None**

​	删除矩形行人面域。

参数：

​	[ in ] pIPedestrianRectRegion：矩形行人面域对象。

**def removePedestrianTriangleRegion(self, pIPedestrianTriangleRegion: Tessng.IPedestrianTriangleRegion) -> None**

​	删除三角形行人面域。

参数：

​	[ in ] pIPedestrianTriangleRegion：三角形行人面域对象。

**def removePedestrianEllipseRegion(self, pIPedestrianEllipseRegion: Tessng.IPedestrianEllipseRegion) -> None**

​	删除椭圆行人面域。

参数：

[ in ] pIPedestrianEllipseRegion：椭圆行人面域对象。

**def removePedestrianFanShapeRegion(self, pIPedestrianFanShapeRegion: Tessng.IPedestrianFanShapeRegion) -> None**

​	删除扇形行人面域。

参数：

​	[ in ] pIPedestrianFanShapeRegion：扇形行人面域对象。

**def removePedestrianPolygonRegion(self, pIPedestrianPolygonRegion: Tessng.IPedestrianPolygonRegion) -> None**

​	删除多边形行人面域。

参数：

​	[ in ] pIPedestrianPolygonRegion：多边形行人面域对象。

**def removePedestrianSIDeWalkRegion(self, pIPedestrianSIDeWalkRegion: Tessng.IPedestrianSIDeWalkRegion) -> None**

​	删除人行道。

参数：

​	[ in ] pIPedestrianSIDeWalkRegion：人行道对象。

**def removePedestrianCrossWalkRegion(self, pIPedestrianCrossWalkRegion: Tessng.IPedestrianCrossWalkRegion) -> None**

​	删除人行横道。

参数：

​	[ in ] pIPedestrianCrossWalkRegion：人行横道对象。

**def removePedestrianStairRegion(self, pIPedestrianStairRegion: Tessng.IPedestrianStairRegion) -> None**

​	删除楼梯。

参数：

​	[ in ] pIPedestrianStairRegion：楼梯对象。

#### 3.3.2.34.行人发生点

**def pedestrianPathStartPoints(self) -> list[Tessng.IPedestrianPathPoint]**

​	获取所有行人发生点对象序列。

**def findPedestrianPathStartPoint(self, id: int) -> Tessng.IPedestrianPathPoint**

​	通过行人发生点ID获取行人发生点对象。

**def findPedestrianStartPointConfigInfo(self, id: int) -> Online.Pedestrian.PedestrianPathStartPointConfigInfo**

​	通过行人发生点ID获取行人发生点配置信息。

**def createPedestrianPathStartPoint(self, scenePos: PySide2.QtCore.QPointF) -> Tessng.IPedestrianPathPoint**

​	创建行人发生点。

参数：

​	[ in ] scenePos：场景坐标。

返回：	

​	行人发生点对象。

**def removePedestrianPathStartPoint(self, pIPedestrianPathStartPoint: Tessng.IPedestrianPathPoint) -> None**

​	删除行人发生点。

参数：

​	[ in ] pIPedestrianPathStartPoint：行人发生点对象。

**def updatePedestrianStartPointConfigInfo(self, info: Online.Pedestrian.PedestrianPathStartPointConfigInfo) -> bool**

​	更新行人发生点配置信息。

参数：

​	[ in ] info：行人发生点配置信息。

返回：	

​	是否更新成功。

#### 3.3.2.35.行人结束点

**def pedestrianPathEndPoints(self) -> list[Tessng.IPedestrianPathPoint]**

​	获取所有行人结束点对象序列。

**def findPedestrianPathEndPoint(self, id: int) -> Tessng.IPedestrianPathPoint**

​	通过ID获取行人结束点对象。

**def createPedestrianPathEndPoint(self, scenePos: PySide2.QtCore.QPointF) -> Tessng.IPedestrianPathPoint**

​	创建行人结束点。

参数：

​	[ in ] scenePos：场景坐标。

返回：

​	行人结束点对象。

**def removePedestrianPathEndPoint(self, pIPedestrianPathEndPoint: Tessng.IPedestrianPathPoint) -> None**

​	删除行人结束点。

参数：

​	[ in ] pIPedestrianPathEndPoint：行人结束点对象。

#### 3.3.2.36.行人决策点

**def pedestrianPathDecisionPoints(self) -> list[Tessng.IPedestrianPathPoint]**

​	获取所有行人决策点对象序列。

**def findPedestrianDecisionPoint(self, id: int) -> Tessng.IPedestrianPathPoint**

​	通过行人决策点ID获取行人决策点对象。

**def findPedestrianDecisionPointConfigInfo(self, id: int) -> Online.Pedestrian.PedestrianDecisionPointConfigInfo**

​	通过行人决策点ID获取行人决策点配置信息。

**def createPedestrianDecisionPoint(self, scenePos: PySide2.QtCore.QPointF) -> Tessng.IPedestrianPathPoint**

​	创建行人决策点。

参数：

​	[ in ] scenePos：场景坐标。

返回：

​	行人决策点对象。

**def removePedestrianDecisionPoint(self, pIPedestrianDecisionPoint: Tessng.IPedestrianPathPoint) -> None**

​	删除行人决策点。

参数：

​	[ in ] pIPedestrianDecisionPoint：行人决策点对象。

**def updatePedestrianDecisionPointConfigInfo(self, info: Online.Pedestrian.PedestrianDecisionPointConfigInfo) -> bool**

​	更新行人决策点配置信息。

参数：

​	[ in ] info：行人决策点配置信息。

返回：	

​	是否更新成功。

#### 3.3.2.37.行人路径

**def pedestrianPaths(self) -> list[Tessng.IPedestrianPath]**

​	获取所有行人路径对象序列，包括局部路径。

**def findPedestrianPath(self, id: int) -> Tessng.IPedestrianPath**

​	通过行人路径ID获取行人路径，包括局部路径。

**def createPedestrianPath(self, pStartPoint: Tessng.IPedestrianPathPoint, pEndPoint: Tessng.IPedestrianPathPoint, mIDdlePoints: list[PySide2.QtCore.QPointF]) -> Tessng.IPedestrianPath**

​	创建行人路径（或行人局部路径）。

参数：

​	[ in ] pStartPoint：行人发生点（或行人决策点）。

​	[ in ] pEndPoint：行人结束点。

​	[ in ] mIDdlePoints：一组中间必经点。

返回：	

​	行人路径对象。

**def removePedestrianPath(self, pIPedestrianPath: Tessng.IPedestrianPath) -> None**

​	删除行人路径。

参数：

​	[ in ] pIPedestrianPath：行人路径对象。

#### 3.3.2.38.行人信号灯

**def crosswalkSignalLamps(self) -> list[Tessng.ICrosswalkSignalLamp]**

​	获取所有人行横道红绿灯对象序列。

**def findCrosswalkSignalLamp(self, id: int) -> Tessng.ICrosswalkSignalLamp**

​	通过ID获取人行横道红绿灯对象。

**def addCrossWalkSignalPhaseToLamp(self, SignalPhaseId: int, signalLamp: Tessng.ISignalLamp) -> None**

​	添加行人信号灯。

参数：

​	[ in ] SignalPhaseID：信号相位ID。

​	[ in ] signalLamp：信号灯对象。

**def createCrossWalkSignalLamp(self, pTrafficLight: Tessng.ISignalController, name: str, crosswalkId: int, scenePos: PySide2.QtCore.QPointF, isPositive: bool) -> Tessng.ICrosswalkSignalLamp**

​	创建人行横道信号灯。

参数：

​	[ in ] pTrafficLight：信号机对象。

​	[ in ] name：信号灯名称。

​	[ in ] crosswalkID：人行横道ID。

​	[ in ] scenePos：位于人行横道内的场景坐标。

​	[ in ] isPositive：信号灯管控方向是否为正向。

返回：

​	人行横道信号灯对象。

**def removeCrossWalkSignalLamp(self, pICrosswalkSignalLamp: Tessng.ICrosswalkSignalLamp) -> None**

​	删除人行横道信号灯。

参数：

​	[ in ] pICrosswalkSignalLamp：人行横道信号灯对象。

#### 3.3.2.39.停车场停车时距分布

**def parkingTimeDis(self) -> list[Online.ParkingLot.DynaParkingTimeDis]**

​	获取停车场停车时距分布列表。

**def createParkingTimeDis(self, param: Online.ParkingLot.DynaParkingTimeDis) -> Online.ParkingLot.DynaParkingTimeDis**

​	创建停车场停车时距分布。

参数：

​	[ in ] param：停车时距分布参数。

**def removeParkingTimeDis(self, id: int) -> None**

​	移除停车场停车时距分布。

参数：

​	[ in ] ID：停车时距分布ID。

**def updateParkingTimeDis(self, param: Online.ParkingLot.DynaParkingTimeDis) -> Online.ParkingLot.DynaParkingTimeDis**

​	更新停车场停车时距分布。

参数：

​	[ in ] param：停车时距分布参数。

#### 3.3.2.40.停车区域

**def parkingRegions(self) -> list[Tessng.IParkingRegion]**

​	获取所有停车区序列。

**def findParkingRegion(self, id: int) -> Tessng.IParkingRegion**

​	通过停车区域ID获取停车区域。

**def createParkingRegion(self, param: Online.ParkingLot.DynaParkingRegion) -> Tessng.IParkingRegion**

​	创建停车区域。

参数：

​	[ in ] param：动态停车区信息。

**def removeParkingRegion(self, pIParkingRegion: Tessng.IParkingRegion) -> None**

​	移除停车区域。

参数：

​	[ in ] pIParkingRegion：停车区域对象。

**def removeParkingRegionByID(self, id: int) -> None**

​	通过停车区域ID移除停车区域。

参数：

​	[ in ] ID：停车区域ID。

**def updateParkingRegion(self, param: Online.ParkingLot.DynaParkingRegion) -> Tessng.IParkingRegion**

​	更新停车区域。

参数：

​	[ in ] param：动态停车区域信息。

#### 3.3.2.41.停车路径决策点

**def parkingDecisionPoints(self) -> list[Tessng.IParkingDecisionPoint]**

​	获取所有停车路径决策点序列。

**def findParkingDecisionPoint(self, id: int) -> Tessng.IParkingDecisionPoint**

​	通过停车路径决策点ID获取停车路径决策点对象。

**def createParkingDecisionPoint(self, pLink: Tessng.ILink, distance: float, name: str = "") -> Tessng.IParkingDecisionPoint**

​	创建停车路径决策点。

参数：

​	[ in ] pLink：决策点所在的路段。

​	[ in ] distance：决策点距离路段起点的距离。单位：像素。

​	[ in ] name：决策点名称。

**def removeParkingDecisionPoint(self, pIParkingDecisionPoint: Tessng.IParkingDecisionPoint) -> None**

​	移除停车路径决策点。

参数：

​	[ in ] pIParkingDecisionPoint：停车路径决策点对象。

**def removeParkingDecisionPointByID(self, id: int) -> None**

​	通过停车路径决策点ID移除停车路径决策点。

参数：

​	[ in ] ID：停车路径决策点ID。

#### 3.3.2.42.停车路径

**def createParkingRouting(self, pDeciPoint: Tessng.IParkingDecisionPoint, pIParkingRegion: Tessng.IParkingRegion) -> Tessng.IParkingRouting**

​	创建停车路径。

参数：

​	[ in ] pDeciPoint：停车决策点。

​	[ in ] pIParkingRegion：停车区域。

**def removeParkingRouting(self, pIParkingRouting: Tessng.IParkingRouting) -> None**

​	移除停车路径。

参数：

​	[ in ] pIParkingRouting：停车决策点对象。

**def removeParkingRoutingByID(self, id: int) -> None**

​	通过停车路径ID移除停车路径。

参数：

​	[ in ] ID：停车决策点ID。

#### 3.3.2.43.收费站停车时距分布

**def tollParkingTimeDis(self) -> list[Online.TollStation.DynaTollParkingTimeDis]**

​	获取收费站停车时距分布序列。

**def createTollParkingTimeDis(self, param: Online.TollStation.DynaTollParkingTimeDis) -> Online.TollStation.DynaTollParkingTimeDis**

​	创建收费站停车时距分布。

参数：

​	[ in ] param：停车时距分布参数。

**def removeTollParkingTimeDis(self, id: int) -> None**

​	移除收费站停车时距分布。

参数：

​	[ in ] ID：停车时距分布ID。

**def updateTollParkingTimeDis(self, param: Online.TollStation.DynaTollParkingTimeDis) -> Online.TollStation.DynaTollParkingTimeDis**

​	更新收费站停车时距分布。

参数：

​	[ in ] param：停车时距分布参数。

#### 3.3.2.44.收费车道

**def tollLanes(self) -> list[Tessng.ITollLane]**

​	获取所有收费车道对象序列。

**def findTollLane(self, id: int) -> Tessng.ITollLane**

​	通过收费车道ID获取收费车道对象。

**def createTollLane(self, param: Online.TollStation.DynaTollLane) -> Tessng.ITollLane**

​	创建收费车道。

参数：

​	[ in ] param：动态收费车道信息。

**def removeTollLane(self, pITollLane: Tessng.ITollLane) -> None**

​	移除收费车道。

参数：

​	[ in ] pITollLane：收费车道对象。

**def removeTollLaneByID(self, id: int) -> None**

​	通过收费车道ID移除收费车道。

参数：

​	[ in ] ID：收费车道ID。

**def updateTollLane(self, param: Online.TollStation.DynaTollLane) -> Tessng.ITollLane**

​	更新收费车道。

参数：

​	[ in ] param：动态收费车道信息。

#### 3.3.2.45.收费路径决策点

**def tollDecisionPoints(self) -> list[Tessng.ITollDecisionPoint]**

​	获取所有收费路径决策点列表。

**def findTollDecisionPoint(self, id: int) -> Tessng.ITollDecisionPoint**

​	通过ID获取收费路径决策点。

**def createTollDecisionPoint(self, pLink: Tessng.ILink, distance: float, name: str = "") -> Tessng.ITollDecisionPoint**

​	创建收费路径决策点。

参数：

​	[ in ] pLink：决策点所在路段。

​	[ in ] distance：决策点距离路段起点的距离。单位：像素。

​	[ in ] name：决策点名称。

**def removeTollDecisionPoint(self, pITollDecisionPoint: Tessng.ITollDecisionPoint) -> None**

​	移除收费路径决策点。

参数：

​	[ in ] pITollLane：收费路径决策点对象。

**def removeTollDecisionPointByID(self, id: int) -> None**

​	通过收费路径决策点ID移除收费路径决策点。

参数：

​	[ in ] ID：收费路径决策点ID。

#### 3.3.2.46.收费路径

**def createTollRouting(self, pDeciPoint: Tessng.ITollDecisionPoint, pITollLane: Tessng.ITollLane) -> Tessng.ITollRouting**

​	创建收费路径。

参数：

​	[ in ] pDeciPoint：收费决策点。

​	[ in ] pITollLane：收费车道。

**def removeTollRouting(self, pITollRouting: Tessng.ITollRouting) -> None**

​	移除收费路径。

参数：

​	[ in ] pITollRouting：收费路径对象。

**def removeTollRoutingByID(self, id: int) -> None**

​	通过ID移除收费路径。

参数：

​	[ in ] ID：收费路径ID。

#### 3.3.2.47.节点

**def getAllJunctions(self) -> dict[int, Tessng.IJunction]**

​	获取所有节点对象序列。

**def findJunction(self, junctionId: int) -> Tessng.IJunction**

​	通过ID获取节点对象。

**def createJunction(self, startPoint: PySide2.QtCore.QPointF, endPoint: PySide2.QtCore.QPointF, name: str) -> Tessng.IJunction**

​	创建节点。

参数：

​	[ in ] startPoint：左上角起始点坐标。

​	[ in ] endPoint：右下角终点坐标。

​	[ in ] name：节点名称。

返回：

​	节点对象。

**def removeJunction(self, junctionId: int) -> bool**

​	删除节点。

参数：

​	[ in ] junctionID：节点ID。

返回：

​	是否移除成功。

**def updateJunctionName(self, junctionId: int, name: str) -> bool**

​	更新节点名称。

参数：

​	[ in ] junctionID：节点ID。

​	[ in ] name：新的节点名称。

**def getJunctionFlows(self, junctionId: int) -> dict[int, dict[int, Online.Junction.FlowTurning]]**

​	获取节点流向信息。

参数：

​	[ in ] junctionID：节点ID。

返回：

​	节点流向信息映射表。

**def updateFlow(self, timeId: int, junctionId: int, turningId: int, inputFlowValue: int) -> bool**

​	更新流向流量。

参数：

​	[ in ] timeID：时间段ID。

​	[ in ] junctionID：节点ID。

​	[ in ] turningID：转向ID。

​	[ in ] inputFlowValue：输入流量值(veh/h)。

返回：

​	是否更新成功。

**def updateFlowAlgorithmParams(self, theta: float, bpra: float, bprb: float, maxIterateNum: int, useNewPath: bool) -> bool**

​	更新流量算法参数。

参数：

​	[ in ] theta：参数θ(0.01-1)。

​	[ in ] bpra：BPR路阻参数A(0.05-0.5)。

​	[ in ] bprb：BPR路阻参数B(1-10)。

​	[ in ] maxIterateNum：最大迭代次数(1-5000)。

​	[ in ] useNewPath：是否重新构建静态路径。

返回：

​	是否更新成功。

**def updatePathBuildParams(self, deciPointPosFlag: bool, laneConnectorFlag: bool, minPathNum: int = 3) -> bool**

​	更新路径构建参数。

参数：

​	[ in ] deciPointPosFlag：是否考虑决策点位置。

​	[ in ] laneConnectorFlag：是否考虑车道连接。

​	[ in ] minPathNum：最小路径数量(默认3)。

返回：

​	是否更新成功。

**def buildAndApplyPaths(self) -> dict[tuple[int, int], list[list[Tessng.ILink]]]**

​	构建并应用路径。

返回：

​	路径结果信息映射表。

**def calculateFlows(self) -> dict[int, list[Online.Junction.FlowTurning]]**

​	计算并应用流量结果。

返回：

​	时间段ID到流量计算结果的映射表。

#### 3.3.2.48.节点时间段

**def getFlowTimeIntervals(self) -> list[Online.Junction.FlowTimeInterval]**

​	获取所有节点时间段。

**def addFlowTimeInterval(self) -> Online.Junction.FlowTimeInterval**

​	添加节点时间段。

返回：

​	节点时间段信息。

**def deleteFlowTimeInterval(self, timeId: int) -> bool**

​	删除节点时间段。

参数：

​	[ in ] timeID：节点时间段ID。

返回：

​	是否删除成功。

**def updateFlowTimeInterval(self, timeId: int, startTime: int, endTime: int) -> Online.Junction.FlowTimeInterval**

​	更新时间段。

参数：

​	[ in ] timeID：节点时间段ID。

​	[ in ] startTime：开始时间。单位：s。

​	[ in ] endTime：结束时间。单位：s。

### 3.3.3.仿真接口（SimuInterface）

​	SimuInterface是TessInterface的子接口，通过此接口可以启动、暂停、停止仿真，可以设置仿真精度，获取仿真过程中的车辆对象、车辆状态，获取几种检测器检测到的样本数据和集计数据等。

#### 3.3.3.1.仿真配置

**def simuIntervalScheming(self) -> int**

​	获取仿真时长。单位：s。

**def setSimuIntervalScheming(self, interval: int) -> None**

​	设置仿真时长。设置值为0时表示不限时长。单位：s。

**def simuAccuracy(self) -> int**

​	获取仿真精度。

**def setSimuAccuracy(self, accuracy: int) -> None**

​	设置仿真精度，即每秒计算次数。

**def acceMultiples(self) -> int**

​	获取仿真加速倍数。

**def setAcceMultiples(self, multiples: int) -> None**

​	设置仿真加速倍数。


**def byCpuTime(self) -> bool**

​	仿真时间是否由现实时间确定。一个计算周期存在两种时间，一种是现实经历的时间，另一种是由仿真精度决定的仿真时间，如果仿真精度为每秒20次，仿真一次相当于仿真了50毫秒。默认情况下，一个计算周期的仿真时间是由仿真精度决定的。在线仿真时如果算力不够，按仿真精度确定的仿真时间会与现实时间存在时差。

**def setByCpuTime(self, bByCpuTime: bool) -> None**

​	设置是否由现实时间确定仿真时间，如果设为True，每个仿真周期现实经历的时间作为仿真时间，这样仿真时间与现实时间相吻合。

**def isRecordTrace(self) -> bool**

​	获取是否记录车辆轨迹。

**def setIsRecordTrace(self, bRecord: bool) -> None**

​	设置是否记录车辆轨迹。

**def setThreadCount(self, count: int) -> None**

​	设置工作线程数。

**def batchNumber(self) -> int**

​	获取当前仿真批次。

**def batchIntervalReally(self) -> float**

​	获取当前批次实际时间。单位：ms。

**def simuTimeIntervalWithAcceMutiples(self) -> int**

​	获取获取当前已仿真时间。单位：ms。

**def startMSecsSinceEpoch(self) -> int**

​	获取仿真开始的现实时间。单位：ms。

**def stopMSecsSinceEpoch(self) -> int**

​	仿真结束的现实时间。单位：ms。

#### 3.3.3.2.仿真状态

**def isRunning(self) -> bool**

​	获取仿真是否在运行状态。

**def isPausing(self) -> bool**

​	获取仿真是否在暂停状态。

**def startSimu(self) -> None**

​	启动仿真。

**def pauseSimu(self) -> None**

​	暂停仿真。

**def stopSimu(self) -> None**

​	停止仿真。

**def pauseSimuOrNot(self) -> None**

​	暂停或恢复仿真。如果当前处于仿真运行状态，此方法暂停仿真，如果当前处于暂停状态，此方法继续仿真。

#### 3.3.3.3.车辆

**def vehiCountTotal(self) -> int**

​	获取车辆总数，包括已创建尚未进入路网的车辆、正在运行的车辆、已驶出路网的车辆。

**def vehiCountRunning(self) -> int**

​	获取当前时间正在运行的车辆数。

**def getVehicle(self, vehiId: int) -> Tessng.IVehicle**

​	通过车辆ID获取车辆对象。

**def allVehicle(self) -> list[Tessng.IVehicle]**

​	获取所有车辆对象序列。

**def allVehiStarted(self) -> list[Tessng.IVehicle]**

​	获取当前时间所有正在运行的车辆对象序列。

示例：

```python
from tessng import UnitOfMeasure

# 获取当前正在运行的车辆列表
all_vehicles = self.simuiface.allVehiStarted()
for vehicle in all_vehicles:
    print(f"车辆ID：{vehicle.id()}")
    print(f"车辆名称：{vehicle.name()}")
    print(f"车辆类型编码：{vehicle.vehicleTypeCode()}")
    print(f"车辆类型名称：{vehicle.vehicleTypeName()}")
    print(f"车辆长度：{vehicle.length(UnitOfMeasure.Metric)} m")

    print(f"车辆当前横坐标：{vehicle.pos(UnitOfMeasure.Metric).x()} m")
    print(f"车辆当前纵坐标：{vehicle.pos(UnitOfMeasure.Metric).y()} m")
    print(f"车辆当前高程：{vehicle.v3z()()} m")
    print(f"车辆当前所在道路ID：{vehicle.roadId()}")
    print(f"车辆当前所在道路名称：{vehicle.roadName()}")
    print(f"车辆当前是否在路段：{vehicle.roadIsLink()}")
    print(f"车辆当前所在车道ID：{vehicle.laneId()}")
    if vehicle.roadIsLink():
        print(f"车辆当前所在车道序号：{vehicle.vehicleDriving().laneNumber()}")
    print(f"车辆当前与车道起点的间距：{vehicle.vehicleDriving().distToStartPoint(True, True, UnitOfMeasure.Metric)} m")

    print(f"车辆当前当前速度：{vehicle.currSpeed(UnitOfMeasure.Metric) * 3.6} km/h")
    print(f"车辆当前期望速度：{vehicle.vehicleDriving().desirSpeed(UnitOfMeasure.Metric) * 3.6} km/h")
    print(f"车辆当前加速度：{vehicle.acce(UnitOfMeasure.Metric)} m/s²")
    print(f"车辆当前朝向角：{vehicle.angle()} °")
```

**def vehisInLink(self, linkId: int) -> list[Tessng.IVehicle]**

​	获取当前时间指定ID的路段上的车辆对象序列。

**def vehisInLane(self, laneId: int) -> list[Tessng.IVehicle]**

​	获取当前时间指定ID的车道上的车辆对象序列。

**def vehisInConnector(self, connectorId: int) -> list[Tessng.IVehicle]**

​	获取当前时间指定ID的连接段上的车辆对象序列。

**def vehisInLaneConnector(self, connectorId: int, fromLaneId: int, toLaneId: int) -> list[Tessng.IVehicle]**

​	获取当前时间指定连接段ID、上游车道ID和下游车道ID的车道连接上的车辆对象序列。

参数：

​	[ in ] connectorID：连接段ID。

​	[ in ] fromLaneID：上游车道ID。

​	[ in ] toLaneID：下游车道ID。

返回：

​	车辆对象序列。

**def getVehisStatus(self, batchNumber: int = 0, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[Online.VehicleStatus]**

​	获取当前时间所有正在运行的车辆状态。

参数：

​	[ in ] batchNumber：批次号。

返回：

​	车辆状态序列。

**def getVehiTrace(self, vehiId: int, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[Online.VehiclePosition]**

​	获取指定车辆的运行轨迹。单位：像素。

参数：

​	[ in ] vehiID：车辆ID。

返回：

​	车辆轨迹点位序列。

**def createGVehicle(self, dynaVehi: Online.DynaVehiParam) -> Tessng.IVehicle**

​	创建车辆。

参数：

​	[ in ] dynaVehi：动态车辆信息。

返回：

​	车辆对象。

```python
from tessng import Online, m2p

# 在路段上创建车辆
# 构建参数
dvp1 = Online.DynaVehiParam()
# 车型ID
dvp1.vehiTypeCode = 1
# 路段ID
dvp1.roadId = 4
# 车道序号
dvp1.laneNumber = 0
# 位置，单位：m
dvp1.dist = m2p(50)
# 速度，单位：m/s
dvp1.speed = m2p(20)
# 颜色
dvp1.color = "#00AFF0"
# 动态创建车辆
vehicle1 = self.simuiface.createGVehicle(dvp)
if vehicle1:
    print(f"在路段上创建了车辆，其ID为：{vehicle1.id()}"")

# 在连接段上创建车辆
# 构建参数
dvp2 = Online.DynaVehiParam()
# 车型ID
dvp2.vehiTypeCode = 1
# 连接段ID
dvp2.roadId = 4
# 上游路段的车道序号
dvp2.laneNumber = 0
# 下游路段的车道序号
dvp2.toLaneNumber = 0
# 位置，单位：m
dvp2.dist = m2p(10)
# 速度，单位：m/s
dvp2.speed = m2p(20)
# 颜色
dvp2.color = "#00AFF0"
# 动态创建车辆
vehicle2 = self.simuiface.createGVehicle(dvp2)
if vehicle2:
    print(f"在连接段上创建了车辆，其ID为：{vehicle2.id()}"")
```

**def createBus(self, pBusLine: Tessng.IBusLine, startSimuDateTime: float) -> Tessng.IVehicle**

​	创建公交车。

参数：

​	[ in ] pBusLine：公交线路对象。

​	[ in ] startSimuDateTime：发车时间。单位：ms。

#### 3.3.3.4.行人

**def allPedestrianStarted(self) -> list[Tessng.IPedestrian]**

​	获取所有正在运行的行人对象序列。

**def getPedestriansStatusByRegionID(self, regionId: int) -> list[Online.Pedestrian.PedestrianStatus]**

​	通过行人面域ID获取当前时间面域上所有行人的状态信息。

参数：

​	[ in ] regionID：面域ID。

返回：

​	行人状态信息序列。

#### 3.3.3.5.信号灯

**def getSignalPhasesColor(self) -> list[Online.SignalPhaseColor]**

​	获取当前时间所有信号控制相位的颜色。

返回：

​	相位颜色序列。

示例：

```python
all_signal_phase_color = self.simuiface.getSignalPhasesColor()
for signal_phase_color in all_signal_phase_color:
    print(f"信号机ID：{signal_phase_color.signalGroupId}")
    print(f"信控相位ID：{signal_phase_color.phaseId}")
    print(f"信控相位序号：{signal_phase_color.phaseNumber}")
    print(f"当前颜色：{signal_phase_color.color}")
    print(f"当前颜色的设置时间(ms)：{signal_phase_color.mrIntervalSetted}")
    print(f"当前颜色的已持续时间(ms)：{signal_phase_color.mrIntervalByNow}")
```

#### 3.3.3.6.数据采集器

**def getVehisInfoCollected(self) -> list[Online.VehiInfoCollected]**

​	获取当前时间完成穿越数据采集器的所有车辆信息。

示例：

```python
all_vehi_info_collected = self.simuiface.getVehisInfoCollected()
for vehi_info in all_vehi_info_collected:
    print(f"采集器ID：{vehi_info.collectorId}")
    print(f"仿真时间(s)：{vehi_info.simuInterval}")
    print(f"车辆ID：{vehi_info.vehiId}")
```

**def getVehisInfoAggregated(self) -> list[Online.VehiInfoAggregated]**

​	获取最近集计时间段内数据采集器采集的集计数据。

示例：

```python
all_vehi_info_aggregated = self.simuiface.getVehisInfoAggregated()
for vehi_info_agg in all_vehi_info_aggregated:
    print(f"采集器ID：{vehi_info_agg.collectorId}")
    print(f"时间段ID：{vehi_info_agg.timeId}")
    print(f"起始时间(s)：{vehi_info_agg.fromTime}")
    print(f"结束时间(s)：{vehi_info_agg.toTime}")
    print(f"车辆数(veh)：{vehi_info_agg.vehiCount}")
    print(f"平均速度(km/h)：{vehi_info_agg.avgSpeed}")
    print(f"平均占有率：{vehi_info_agg.occupancy}")
```

#### 3.3.3.7.排队计数器

**def getVehisQueueCounted(self) -> list[Online.VehiQueueCounted]**

​	获取当前时间排队计数器计数的车辆排队信息。

示例：

```python
all_vehi_queue_counted = self.simuiface.getVehisQueueCounted()
for vehi_queue in all_vehi_queue_counted:
    print(f"计数器ID：{vehi_queue.counterId}")
    print(f"仿真时间(s)：{vehi_queue.simuTime}")
    print(f"排队车辆数(veh)：{vehi_queue.vehiCount}")
    print(f"排队长度(m)：{vehi_queue.queueLength}")
```

**def getVehisQueueAggregated(self) -> list[Online.VehiQueueAggregated]**

​	获取最近集计时间段内排队计数器采集的集计数据。

示例：

```python
all_vehi_queue_aggregated = self.simuiface.getVehisQueueAggregated()
for vehi_queue_agg in all_vehi_queue_aggregated:
    print(f"计数器ID：{vehi_queue_agg.counterId}")
    print(f"时间段ID：{vehi_queue_agg.timeId}")
    print(f"起始时间(s)：{vehi_queue_agg.fromTime}")
    print(f"结束时间(s)：{vehi_queue_agg.toTime}")
    print(f"平均排队车辆数(veh)：{vehi_queue_agg.avgVehiCount}")
    print(f"平均排队长度(m)：{vehi_queue_agg.avgQueueLength}")
    print(f"最大排队长度(m)：{vehi_queue_agg.maxQueueLength}")
    print(f"最小排队长度(m)：{vehi_queue_agg.minQueueLength}")
```

**def queueRecently(self, queueCounterId: int, queueLength: float, vehiCount: int, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

​	指定排队计算器最近一次排队长度和排队车辆数。

参数：

​	[ in ] queueCounterID：排队计数器ID。

​	[ out ] queueLength：排队长度。

​	[ out ] vehiCount：排队车辆数。

返回：

​	是否获取成功。

#### 3.3.3.8.行程时间检测器

**def getVehisTravelDetected(self) -> list[Online.VehiTravelDetected]**

​	获取当前时间行程时间检测器完成的行程时间检测信息。

示例：

```python
all_vehi_travel_detected = self.simuiface.getVehisTravelDetected()
for vehi_travel in all_vehi_travel_detected:
    print(f"检测器ID：{vehi_travel.detectedId}")
    print(f"车辆ID：{vehi_travel.vehiId}")
    print(f"行驶时间(s)：{vehi_travel.travelTime}")
    print(f"行驶距离(m)：{vehi_travel.travelDistance}")
    print(f"延误(s)：{vehi_travel.delay}")
```

**def getVehisTravelAggregated(self) -> list[Online.VehiTravelAggregated]**

​	获取最近集计时间段内行程时间检测器采集的集计数据。

示例：

```python
all_vehi_travel_aggregated = self.simuiface.getVehisTravelAggregated()
for vehi_travel_agg in all_vehi_travel_aggregated:
    print(f"检测器ID：{vehi_travel_agg.detectedId}")
    print(f"时间段ID：{vehi_travel_agg.timeId}")
    print(f"起始时间(s)：{vehi_travel_agg.fromTime}")
    print(f"结束时间(s)：{vehi_travel_agg.toTime}")
    print(f"车辆数：{vehi_travel_agg.vehiCount}")
    print(f"平均行程时间(s)：{vehi_travel_agg.avgTravelTime}")
    print(f"平均行程距离(m)：{vehi_travel_agg.avgTravelDistance}")
    print(f"平均延误(s)：{vehi_travel_agg.avgDelay}")
```

### 3.3.4.界面接口（GuiInterface）

​	GuiInterface是TessInterface的子接口，通过此接口可以访问控制TESSNG的主窗体、菜单栏、工具栏和状态栏等，使用户可以在主窗体上创建菜单、自定义窗体等。

#### 3.3.4.1.窗体

**def mainWindow(self) -> PySide2.QtWidgets.QMainWindow**

​	获取TESSNG的主窗体。

#### 3.3.4.2.菜单栏

**def menuBar(self) -> PySide2.QtWidgets.QMenuBar**

​	获取TESSNG的菜单栏容器。


#### 3.3.4.3.工具栏

**def addToolBar(self, name: str) -> PySide2.QtWidgets.QToolBar**

​	新增自定义工具栏。

参数：

​	[ in ] name：工具栏名称。

返回：

​	工具栏对象。

**def insertToolBar(self, before: PySide2.QtWidgets.QToolBar, name: str) -> PySide2.QtWidgets.QToolBar**

​	在指定工具栏前插入新工具栏。

参数：

​	[ in ] before：要在其前插入新工具栏的已有工具栏。

​	[ in ] name：工具栏名称。

返回：

​	工具栏对象。



## 3.4.对象

​	TESS NG中的对象可分为**路网对象**和**仿真对象**，其中，路网对象包括：路段、连接段等，仿真对象包括：车辆和行人。

### 3.4.1.路网

#### 3.4.1.1.路网（IRoadNet）

​	路网基本信息接口，设计此接口的目的是为了TESS NG在导入外源路网时能够保存这些路网的属性，如路网中心点坐标、路网大地坐标等。

**def id(self) -> int**

​	获取路网ID，即路网编辑弹窗中的编号。

**def netName(self) -> str**

​	获取路网名称。

**def url(self) -> str**

​	源数据路径，可以是本地文件，可以是网络地址。

**def type(self) -> str**

​	来源分类: "TESSNG"表示TESSNG自建；"OpenDrive"表示由OpenDrive数据导入；"GeoJson"表示由geojson数据导入。

**def bkgUrl(self) -> str**

​	获取背景路径。

**def explain(self) -> str**

​	获取路网说明。

**def otherAttrs(self) -> dict**

​	其它属性json数据。

**def centerPoint(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	获取路网中心点位置。单位：像素。

#### 3.4.1.2.道路基类（ISection）

​	道路基类是路段和连接段的基类。

**def gtype(self) -> int**

​	类型，GLinkType 或 GConnectorType。GLinkType代表路段、GConnectorType代表连接段。

**def isLink(self) -> bool**

​	是否是路段。

**def id(self) -> int**

​	获取ID，如果是Link，id是Link的ID，如果是连接段，id是连接段ID。

**def sectionId(self) -> int**

​	获取ID，如果是Link，id是Link的ID，如果是连接段，id是连接段ID+10000000，从而区分路段与连接段。

**def name(self) -> str**

​	获取Section名称，路段名或连接段名。

**def setName(self, name: str) -> None**

​	设置Section名称。

**def v3z(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取Section高程。单位：像素。

**def length(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取Section长度。单位：像素。

**def laneObjects(self) -> list[Tessng.ILaneObject]**

​	车道与车道连接的父类接口列表。

**def fromSection(self, id: int) -> Tessng.ISection**

​	通过ID获取上游Section。如果当前是路段，id 为 0 返回None，否则返回上游指定ID的连接段；如果当前是连接段，id 为 0 返回上游路段，否则返回None。

**def toSection(self, id: int) -> Tessng.ISection**

​	通过ID获取下游 Sction。如果当前是路段，id 为 0 返回None，否则返回下游指定ID的连接段；如果当前是连接段，id 为 0 返回下游路段，否则None。

**def setOtherAttr(self, otherAttr: dict) -> None**

​	设置路段或连接段其它属性。

**def castToLink(self) -> Tessng.ILink**

​	转换成ILink，如果当前为连接段则None。

**def castToConnector(self) -> Tessng.IConnector**

​	转换成IConnector，如果当前为路段则返回None。

**def polygon(self) -> PySide2.QtGui.QPolygonF**

​	获取Section的多边型轮廓顶点构成的多边形。

#### 3.4.1.3.路段（ILink）

**def gtype(self) -> int**

​	类型，返回GLinkType。

**def id(self) -> int**

​	获取路段ID。

**def length(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取路段长度。单位：像素。

**def width(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取路段宽度。单位：像素。

**def z(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取路段高程。单位：像素。

**def v3z(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取路段高程，过载ISection的方法。单位：像素。

**def name(self) -> str**

​	获取路段名称。

**def setName(self, name: str) -> None**

​	设置路段名称。

**def linkType(self) -> str**

​	获取路段类型，如: 城市主干道、城市次干道、人行道等。

**def setType(self, type: str) -> None**

​	设置路段类型，路段类型有10种，分别为: 高速路、城市快速路、匝道、城市主要干道、次要干道、地方街道、非机动车道、人行道、公交专用道和机非共享。

**def laneCount(self) -> int**

​	获取车道数。

**def limitSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取路段最高限速。单位: km/h。

**def setLimitSpeed(self, speed: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置路段最高限速。单位: km/h。

参数: 

​	[ in ] speed: 限速值。

**def minSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取路段最低限速。单位: km/h。

**def lanes(self) -> list[Tessng.ILane]**

​	车道接口列表。

**def laneObjects(self) -> list[Tessng.ILaneObject]**

​	车道及车道连接的接口列表。

**def centerBreakPoints(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

​	获取路段中心线断点集。单位：像素。

**def leftBreakPoints(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

​	获取路段左侧线断点集。单位：像素。

**def rightBreakPoints(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

​	获取路段右侧线断点集。单位：像素。

**def centerBreakPoint3Ds(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

​	获取路段中心线三维断点集。单位：像素。

**def leftBreakPoint3Ds(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

​	获取路段左侧线三维断点集。单位：像素。

**def rightBreakPoint3Ds(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

​	获取路段右侧线三维断点集。单位：像素。

**def fromConnectors(self) -> list[Tessng.IConnector]**

​	获取上游连接段列表。

**def toConnectors(self) -> list[Tessng.IConnector]**

​	获取下游连接段列表。

**def setOtherAttr(self, otherAttr: dict) -> None**

​	设置路段其它属性。

**def otherAttr(self) -> dict**

​	获取路段其它属性。

**def setLaneTypes(self, lType: list[str]) -> None**

​	设置车道属性，属性类型包括: "机动车道"、"机非共享"、"非机动车道"、"公交专用道"，车道顺序从右到左。

**def setLaneOtherAtrrs(self, lAttrs: list[dict]) -> None**

​	设置车道其它属性。

**def distToStartPoint(self, p: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	中心线上一点到起点距离。单位：像素。

参数: 

​	[ in ] p: 当前点坐标。

**def getPointByDist(self, dist: float, outPoint: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

​	求中心线起点向前延伸dist距离后所在点，如果目标点不在中心线上返回False，否则返回True。单位：像素。

参数: 

​	[ in ] dist: 中心线起点向前延伸的距离。

​	[ out ] outPoint: 中心线起点向前延伸dist距离后所在点。

示例:

```python
from tessng import UnitOfMeasure

# 获取距离路段起点一定距离的点位坐标
out_point = QPointF()
result = link.getPointByDist(50, out_point, UnitOfMeasure.Metric)
if result:
    x = out_point.x()
    y = out_point.y()
```

**def getPointAndIndexByDist(self, dist: float, outPoint: PySide2.QtCore.QPointF, outIndex: int, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

​	求中心线起点向前延伸dist距离后所在点及分段序号，如果目标点不在中心线上返回False，否则返回True。单位：像素。

参数: 

​	[ in ] dist: 中心线起点向前延伸的距离。

​	[ out ] outPoint: 中心线起点向前延伸dist距离后所在点。

​	[ out ] outIndex: 中心线起点向前延伸dist距离后所在分段序号。

**def polygon(self) -> PySide2.QtGui.QPolygonF**

​	获取路段的多边型轮廓顶点。

#### 3.4.1.4.连接段（IConnector）

**def gtype(self) -> int**

​	类型，连接段类型为GConnectorType。

**def id(self) -> int**

​	获取连接段ID。

**def length(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取连接段长度。单位：像素。

**def z(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取连接段高程。单位：像素。

**def v3z(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取连接段高程。单位：像素。

**def name(self) -> str**

​	获取连接段名称。

**def setName(self, name: str) -> None**

​	设置连接段名称。

**def fromLink(self) -> Tessng.ILink**

​	获取起始路段。

**def toLink(self) -> Tessng.ILink**

​	获取目标路段。

**def limitSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取连接段最高限速。单位: km/h。

**def minSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取连接段最低限速。单位: km/h。

**def laneConnectors(self) -> list[Tessng.ILaneConnector]**

​	获取车道连接列表。

**def laneObjects(self) -> list[Tessng.ILaneObject]**

​	车道及车道连接的接口列表。

**def setLaneConnectorOtherAtrrs(self, lAttrs: list[dict]) -> None**

​	设置包含的车道连接其它属性。

**def setOtherAttr(self, otherAttr: dict) -> None**

​	设置连接段其它属性。

**def polygon(self) -> PySide2.QtGui.QPolygonF**

​	获取连接段的多边型轮廓顶点。

#### 3.4.1.5.车道基类（ILaneObject）

​	车道基类是车道和车道连接的父类。

**def gtype(self) -> int**

​	类型，GLaneType或GLaneConnectorType。

**def isLane(self) -> bool**

​	是否是车道。

**def id(self) -> int**

​	获取ID，如果是Lane，id是Lane的ID，如果是车道连接，id是车道连接ID。

**def length(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取长度。单位：像素。

**def section(self) -> Tessng.ISection**

​	获取所属的ISection。

**def fromLaneObject(self, id: int) -> Tessng.ILaneObject**

​	通过ID获取上游 LaneObject。如果当前是车道，id 为 0 返回None，否则返回上游指定ID的车道连接；如果当前是连接段，id 为 0 返回上游车道，否则返回None。

**def toLaneObject(self, id: int) -> Tessng.ILaneObject**

​	通过ID获取下游 LaneObject。如果当前是车道，id 为 0 返回None，否则返回下游指定ID的车道连接；如果当前是连接段，id 为 0 返回下游车道，否则返回None。

**def centerBreakPoints(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

​	获取中心线断点集。单位：像素。

**def leftBreakPoints(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

​	获取左侧线断点集。单位：像素。

**def rightBreakPoints(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

​	获取右侧线断点集。单位：像素。

**def centerBreakPoint3Ds(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

​	获取中心线三维断点集。单位：像素。

**def leftBreakPoint3Ds(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

​	获取左侧线三维断点集。单位：像素。

**def rightBreakPoint3Ds(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

​	获取右侧线三维断点集。单位：像素。

**def leftBreak3DsPartly(self, fromPoint: PySide2.QtCore.QPointF, toPoint: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

​	获取左侧部分三维断点集。单位：像素。

参数: 

​	[ in ] fromPoint: 中心线上某一点作为起点。

​	[ in ] toPoint: 中心线上某一点作为终点。

**def rightBreak3DsPartly(self, fromPoint: PySide2.QtCore.QPointF, toPoint: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

​	获取右侧部分三维断点集。单位：像素。

参数: 

​	[ in ] fromPoint: 中心线上某一点作为起点。

​	[ in ] toPoint: 中心线上某一点作为终点。

**def distToStartPoint(self, p: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	中心线上一点到起点距离。单位：像素。

参数: 

​	[ in ] p: 当前点坐标。

**def distToStartPointWithSegmIndex(self, p: PySide2.QtCore.QPointF, segmIndex: int = 0, bOnCentLine: bool = True, unit: UnitOfMeasure = UnitOfMeasure: : Default) -> float**

​	中心线上一点到起点距离，附加条件是该点所在车道上的分段序号。单位：像素。

参数: 

​	[ in ] p: 当前点坐标。

​	[ in ] segmIndex: 该点所在车道上的分段序号。

​	[ in ] bOnCentLine: 是否在中心线上。

**def getPointAndIndexByDist(self, dist: float, outPoint: PySide2.QtCore.QPointF, outIndex: int, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

​	求中心线起点向前延伸dist距离后所在点及分段序号，如果目标点不在中心线上返回False，否则返回True。单位：像素。

参数: 

​	[ in ] dist: 中心线起点向前延伸的距离。

​	[ out ] outPoint: 中心线起点向前延伸dist距离后所在点。

​	[ out ] outIndex: 中心线起点向前延伸dist距离后所在分段序号。

**def getPointByDist(self, dist: float, outPoint: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

​	求中心线起点向前延伸dist距离后所在点，如果目标点不在中心线上返回False，否则返回True。单位：像素。

参数: 

​	[ in ] dist: 中心线起点向前延伸的距离。

​	[ out ] outPoint: 中心线起点向前延伸dist距离后所在点。

**def setOtherAttr(self, attr: dict) -> None**

​	设置车道或车道连接其它属性。

**def castToLane(self) -> Tessng.ILane**

​	将ILaneObject转换为ILane，如果当前ILaneObject是车道连接则返回None。

**def castToLaneConnector(self) -> Tessng.ILaneConnector**

​	将ILaneObject转换为ILaneConnector，如果当前ILaneObject是车道则返回None。

#### 3.4.1.6.车道（ILane）

**def gtype(self) -> int**

​	类型，车道类型为GLaneType。

**def id(self) -> int**

​	获取车道ID。

**def link(self) -> Tessng.ILink**

​	获取车道所在路段。

**def section(self) -> Tessng.ISection**

​	获取车道所属Section。

**def length(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取车道长度。单位：像素。

**def width(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取车道宽度。单位：像素。

**def number(self) -> int**

​	获取车道序号，从0开始（自外侧往内侧，即自右向左依次编号）。

**def actionType(self) -> str**

​	获取车道的行为类型。

**def fromLaneConnectors(self) -> list[Tessng.ILaneConnector]**

​	获取上游车道连接列表。

**def toLaneConnectors(self) -> list[Tessng.ILaneConnector]**

​	获取下游车道连接列表。

**def centerBreakPoints(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

​	获取车道中心线断点集。单位：像素。

**def leftBreakPoints(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

​	获取车道左侧线断点集。单位：像素。

**def rightBreakPoints(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

​	获取车道右侧线断点集。单位：像素。

**def centerBreakPoint3Ds(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

​	获取车道中心线三维断点集。单位：像素。

**def leftBreakPoint3Ds(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

​	获取车道左侧线三维断点集。单位：像素。

**def rightBreakPoint3Ds(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

​	获取车道右侧线三维断点集。单位：像素。

**def leftBreak3DsPartly(self, fromPoint: PySide2.QtCore.QPointF, toPoint: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

​	获取左侧部分三维断点集。单位：像素。

参数: 

​	[ in ] fromPoint: 中心线上某一点作为起点。

​	[ in ] toPoint: 中心线上某一点作为终点。

**def rightBreak3DsPartly(self, fromPoint: PySide2.QtCore.QPointF, toPoint: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

​	获取右侧部分三维断点集。单位：像素。

参数: 

​	[ in ] fromPoint: 中心线上某一点作为起点。

​	[ in ] toPoint: 中心线上某一点作为终点。

**def distToStartPoint(self, p: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	中心线上一点到起点距离。单位：像素。

参数: 

​	[ in ] p: 当前点坐标。

**def distToStartPointWithSegmIndex(self, p: PySide2.QtCore.QPointF, segmIndex: int = 0, bOnCentLine: bool = True, unit: UnitOfMeasure = UnitOfMeasure: : Default) -> float**

​	中心线上一点到起点距离，附加条件是该点所在车道上的分段序号。单位：像素。

参数: 

​	[ in ] p: 当前中心线上该点坐标。

​	[ in ] segmIndex: 该点所在车道上的分段序号。

​	[ in ] bOnCentLine: 是否在中心线上。

**def getPointAndIndexByDist(self, dist: float, outPoint: PySide2.QtCore.QPointF, outIndex: int, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

​	求中心线起点向前延伸dist距离后所在点及分段序号，如果目标点不在中心线上返回False，否则返回True。单位：像素。

参数: 

​	[ in ] dist: 中心线起点向前延伸的距离。

​	[ out ] outPoint: 中心线起点向前延伸dist距离后所在点。

​	[ out ] outIndex: 中心线起点向前延伸dist距离后所在分段序号。

**def getPointByDist(self, dist: float, outPoint: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

​	求中心线起点向前延伸dist距离后所在点，如果目标点不在中心线上返回False，否则返回True。单位：像素。

参数: 

​	[ in ] dist: 中心线起点向前延伸的距离。

​	[ out ] outPoint: 中心线起点向前延伸dist距离后所在点。

示例:

```python
from tessng import UnitOfMeasure

# 获取距离车道起点一定距离的点位坐标
out_point = QPointF()
result = lane_obj.getPointByDist(50, out_point, UnitOfMeasure.Metric)
if result:
    x = out_point.x()
    y = out_point.y()
```

**def setOtherAttr(self, attr: dict) -> None**

​	设置车道其它属性。

**def setLaneType(self, type: str) -> None**

​	设置车道类型。

参数: 

​	[ in ] type: 车道类型，选下列几种类型其中一种: "机动车道"、"机非共享"、"非机动车道"、"公交专用道"。

示例:

```python
# 设置车道类型
lane.setLaneType("机动车道")
```

**def polygon(self) -> PySide2.QtGui.QPolygonF**

​	获取车道的多边型轮廓顶点。

#### 3.4.1.7.车道连接（ILaneConnector）

**def gtype(self) -> int**

​	类型，GLaneType或GLaneConnectorType，车道连接段为GLaneConnectorType。

**def id(self) -> int**

​	获取车道连接ID。

**def connector(self) -> Tessng.IConnector**

​	获取车道连接所在连接段。

**def section(self) -> Tessng.ISection**

​	获取车道所属Section。

**def fromLane(self) -> Tessng.ILane**

​	上游车道。

**def toLane(self) -> Tessng.ILane**

​	下游车道。

**def length(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取车道连接长度。单位：像素。

**def centerBreakPoints(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

​	获取车道连接中心线断点集。单位：像素。

**def leftBreakPoints(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

​	获取车道连接左侧线断点集。单位：像素。

**def rightBreakPoints(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

​	获取车道连接右侧线断点集。单位：像素。

**def centerBreakPoint3Ds(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

​	获取车道连接中心线三维断点集。单位：像素。

**def leftBreakPoint3Ds(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

​	获取车道连接左侧线三维断点集。单位：像素。

**def rightBreakPoint3Ds(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

​	获取车道连接右侧线三维断点集。单位：像素。

**def leftBreak3DsPartly(self, fromPoint: PySide2.QtCore.QPointF, toPoint: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

​	获取车道连接左侧部分三维断点集。单位：像素。

参数: 

​	[ in ] fromPoint: 中心线上某一点作为起点。

​	[ in ] toPoint: 中心线上某一点作为终点。

**def rightBreak3DsPartly(self, fromPoint: PySide2.QtCore.QPointF, toPoint: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

​	获取车道连接右侧部分三维断点集。单位：像素。

参数: 

​	[ in ] fromPoint: 中心线上某一点作为起点。

​	[ in ] toPoint: 中心线上某一点作为终点。

**def distToStartPoint(self, p: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	中心线上一点到起点距离。单位：像素。

参数: 

​	[ in ] p: 当前点坐标。

**def distToStartPointWithSegmIndex(self, p: PySide2.QtCore.QPointF, segmIndex: int, bOnCentLine: bool, unit: UnitOfMeasure = UnitOfMeasure: : Default) -> float**

​	中心线上一点到起点距离，附加条件是该点所在车道上的分段序号。单位：像素。

参数: 

​	[ in ] p: 当前点坐标。

​	[ in ] segmIndex: 分段序号。

​	[ in ] bOnCentLine: 是否在中心线上。

**def getPointAndIndexByDist(self, dist: float, outPoint: PySide2.QtCore.QPointF, outIndex: int, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

​	求中心线起点向前延伸dist距离后所在点及分段序号，如果目标点不在中心线上返回False，否则返回True。单位：像素。

参数: 

​	[ in ] dist: 中心线起点向前延伸的距离。

​	[ out ] outPoint: 中心线起点向前延伸dist距离后所在点。

​	[ out ] outIndex: 中心线起点向前延伸dist距离后所在分段序号。

**def getPointByDist(self, dist: float, outPoint: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

​	求中心线起点向前延伸dist距离后所在点，如果目标点不在中心线上返回False，否则返回True。单位：像素。

参数: 

​	[ in ] dist: 中心线起点向前延伸的距离。

​	[ out ] outPoint: 中心线起点向前延伸dist距离后所在点。

**def setOtherAttr(self, attr: dict) -> None**

​	设置车道连接其它属性。

#### 3.4.1.8.连接段面域（IConnectorArea）

**def id(self) -> int**

​	面域ID，面域是指若干Connector重叠形成的区域。

**def allConnector(self) -> list[Tessng.IConnector]**

​	面域相关所有连接段。

**def centerPoint(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	获取面域中心点位置。单位：像素。

### 3.4.2.发车点

#### 3.4.2.1.发车点（IDispatchPoint）

**def id(self) -> int**

​	获取发车点ID。

**def name(self) -> str**

​	获取发车名称。

**def link(self) -> Tessng.ILink**

​	获取发车点所在路段。

**def addDispatchInterval(self, vehiCompId: int, interval: int, vehiCount: int) -> int**

​	为发车点增加发点间隔。

参数: 

​	[ in ] vehiCompId: 车型组成ID。

​	[ in ] interval: 时间段。单位: s。

​	[ in ] vehiCount: 发车数。

返回值: 

​	发车间隔ID。

**def setDynaModified(self, bModified: bool) -> None**

​	设置是否被动态修改，默认情况下发车信息被动态修改后，整个文件不能保存，以免破坏原有发车设置。

**def polygon(self) -> PySide2.QtGui.QPolygonF**

​	获取发车点多边型轮廓的顶点。

### 3.4.3.决策点和车辆路径

#### 3.4.3.1.决策点（IDecisionPoint）

**def id(self) -> int**

​	决策点ID。

**def name(self) -> str**

​	决策点名称。

**def link(self) -> Tessng.ILink**

​	决策点所在路段。

**def distance(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取距路段起点距离。单位：像素。

**def routings(self) -> list[Tessng.IRouting]**

​	相关决策路径。

**def setDynaModified(self, bModified: bool) -> None**

​	设置是否被动态修改，默认情况下发车信息被动态修改后，整个文件不能保存，以免破坏原有发车设置。

参数: 

​	[ in ] bModified: 是否被动态修改，True为被动态修改，False为未被动态修改。

**def polygon(self) -> PySide2.QtGui.QPolygonF**

​	决策点多边型轮廓的顶点。

#### 3.4.3.2.车辆路径（IRouting）

**def id(self) -> int**

​	路径ID。

**def calcuLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	计算路径长度。单位：像素。

**def getLinks(self) -> list[Tessng.ILink]**

​	获取路段序列。

**def deciPointId(self) -> int**

​	所属决策点ID。

**def contain(self, pRoad: Tessng.ISection) -> bool**

​	通过所给道路判断是否在当前路径上。

参数: 

​	[ in ] pRoad: 路段或连接段。

**def nextRoad(self, pRoad: Tessng.ISection) -> Tessng.ISection**

​	通过所给道路求下一条道路。

参数: 

​	[ in ] pRoad: 路段或连接段。

### 3.4.4.信号控制

#### 3.4.4.1.信号机（ISignalController）

**def id(self) -> int**

​	获取信号机ID。

**def name(self) -> str**

​	获取信号机名称。

**def setName(self, name: str) -> None**

​	设置信号机名称。

参数: 

​	[ in ] name: 新名称。

**def addPlan(self, plan: Tessng.ISignalPlan) -> None**

​	添加信控方案。

参数: 

​	[ in ] plan: 信控方案。

**def removePlan(self, plan: Tessng.ISignalPlan) -> None**

​	移除信控方案。

参数: 

​	[ in ] plan: 要移除的信控方案。

**def plans(self) -> list[Tessng.ISignalPlan]**

​	获取所有信控方案。

**def isValid(self) -> bool**

​	检查信号机的有效性。

#### 3.4.4.2.信号控制方案（ISignalPlan）

**def id(self) -> int**

​	获取ID。

**def Name(self) -> str**

​	获取灯组名。

**def trafficName(self) -> str**

​	获取信控方案名称。

**def cycleTime(self) -> int**

​	获取信号周期。单位: s。

**def fromTime(self) -> int**

​	获取起始时间。单位: s。

**def toTime(self) -> int**

​	获取结束时间。单位: s。

**def phases(self) -> list[Tessng.ISignalPhase]**

​	获取相位列表。

**def setName(self, name: str) -> None**

​	设置信控方案名称。

参数: 

​	[ in ] name: 新名称。

**def setcycleTime(self, period: int) -> None**

​	设置信号周期。单位: s。

参数: 

​	[ in ] period: 信号周期。单位: s。

**def setFromTime(self, time: int) -> None**

​	设置起始时间。单位: s。

参数: 

​	[ in ] time: 起始时间。单位: s。

**def setToTime(self, time: int) -> None**

​	设置结束时间。单位: s。

参数: 

​	[ in ] time: 结束时间。单位: s。

#### 3.4.4.3.信号灯相位（ISignalPhase）

**def id(self) -> int**

​	相位ID。

**def phaseName(self) -> str**

​	相位名称。

**def listColor(self) -> list[Online.ColorInterval]**

​	获取相位灯色列表。

**def setColorList(self, lColor: list[Online.ColorInterval]) -> None**

​	设置信号灯列表。

参数: 

​	[ in ] lColor: 灯色时长信息，包含信号灯颜色和信号灯时长。

示例:

```python
# 构建灯色和时长对象列表
color_obj_list = [
    Online.ColorInterval("R", 10),   # 红色，时长10
    Online.ColorInterval("G", 60),   # 绿色，时长60
    Online.ColorInterval("Y", 3),    # 黄色，时长3
    Online.ColorInterval("R", 17)    # 红色，时长17
]
# 查找ID为7的信号灯相位
signal_phase = netiface.findSignalPhase(7)
if signal_phase:
    # 设置灯色列表
	signal_phase.setColorList(color_list)
```

**def cycleTime(self) -> int**

​	获取相位周期。单位: s。

**def phaseColor(self) -> Online.SignalPhaseColor**

​	获取当前相位灯色。

**def signalPlan(self) -> Tessng.ISignalPlan**

​	获取相位所在信控方案。

**def signalLamps(self) -> list[Tessng.ISignalLamp]**

​	获取相关信号灯列表。

**def setPhaseName(self, name: str) -> None**

​	设置相位名称。

参数: 

​	[ in ] name: 新名称。

#### 3.4.4.4.信号灯灯头（ISignalLamp）

**def id(self) -> int**

​	获取信号灯ID。

**def setSignalPhase(self, pPhase: Tessng.ISignalPhase) -> None**

​	设置相位，所设相位可以是其它信号灯组的相位。

参数: 

​	[ in ] pPhase: 相位。

**def setPhaseNumber(self, num: int) -> None**

​	设置相位序号，序号从1开始，如果num序号大于相位总数不进行设置。

**def setLampColor(self, colorStr: str) -> None**

​	设置信号灯颜色。

参数: 

​	[ in ] colorStr: 字符串表达的颜色，有四种可选，分别是"红"、"绿"、"黄"、"灰"，或者是"R"、"G"、"Y"、"grey"。 

**def color(self) -> str**

​	获取信号灯色，"R"、“G”、“Y”、“gray”分别表示"红"、"绿"、"黄"、"灰"。

**def name(self) -> str**

​	获取信号灯名称。

**def setName(self, name: str) -> None**

​	设置信号灯名称。

**def setDistToStart(self, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置信号灯距路段起点距离。单位：像素。

参数: 

​	[ in ] dist: 距离值。

**def signalPlan(self) -> Tessng.ISignalPlan**

​	获取信控方案。

**def signalPhase(self) -> Tessng.ISignalPhase**

​	获取相位。

**def laneObject(self) -> Tessng.ILaneObject**

​	获取所在车道或车道连接。

**def polygon(self) -> PySide2.QtGui.QPolygonF**

​	获取信号灯多边型轮廓的顶点。

**def angle(self) -> float**

​	获取信号灯角度。

### 3.4.5.采集设备

#### 3.4.5.1.数据采集器（IVehicleDrivInfoCollector）

**def id(self) -> int**

​	获取采集器ID。

**def collName(self) -> str**

​	获取采集器名称。

**def onLink(self) -> bool**

​	是否在路段上，如果True则connector()返回None。

**def link(self) -> Tessng.ILink**

​	采集器所在路段。

**def connector(self) -> Tessng.IConnector**

​	采集器所在连接段。

**def lane(self) -> Tessng.ILane**

​	如果采集器在路段上返回所在车道，否则返回None。

**def laneConnector(self) -> Tessng.ILaneConnector**

​	如果采集器在连接段上则返回车道连接，否则返回None。

**def distToStart(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取采集器距路段起点距离。单位：像素。

**def point(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	获取采集器位置坐标。单位：像素。

**def fromTime(self) -> int**

​	采集器工作起始时间。单位: s。

**def toTime(self) -> int**

​	采集器工作停止时间。单位: s。

**def aggregateInterval(self) -> int**

​	集计数据时间间隔。单位: s。

**def setName(self, name: str) -> None**

​	设置采集器名称。

**def setDistToStart(self, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置采集器距路段起点距离。单位：像素。

参数: 

​	[ in ] dist: 距离值。

**def setFromTime(self, time: int) -> None**

​	设置采集器工作起始时间。单位: s。

参数: 

​	[ in ] time: 工作起始时间。单位: s。

**def setToTime(self, time: int) -> None**

​	设置采集器工作结束时间。单位: s。

参数: 

​	[ in ] time: 工作结束时间。单位: s。

**def setAggregateInterval(self, interval: int) -> None**

​	设置采集器集计数据时间间隔。单位: s。

**def polygon(self) -> PySide2.QtGui.QPolygonF**

​	获取采集器的多边型轮廓顶点。

#### 3.4.5.2.排队计数器（IVehicleQueueCounter）

**def id(self) -> int**

​	获取计数器ID。

**def counterName(self) -> str**

​	获取计数器名称。

**def onLink(self) -> bool**

​	是否在路段上，如果True则connector()返回None。

**def link(self) -> Tessng.ILink**

​	计数器所在路段。

**def connector(self) -> Tessng.IConnector**

​	计数器所在连接段。

**def lane(self) -> Tessng.ILane**

​	如果计数器在路段上返回所在车道，否则返回None。

**def laneConnector(self) -> Tessng.ILaneConnector**

​	如果计数器在连接段上返回车道连接，否则返回None。

**def distToStart(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取计数器距路段起点距离。单位：像素。

**def point(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	获取计数器位置坐标。单位：像素。

**def fromTime(self) -> int**

​	计数器工作起始时间。单位: s。

**def toTime(self) -> int**

​	计数器工作停止时间。单位: s。

**def aggregateInterval(self) -> int**

​	计数集计数据时间间隔。单位: s。

**def setName(self, name: str) -> None**

​	设置计数器名称。

参数: 

​	[ in ] name: 计数器名称。

**def setDistToStart(self, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置计数器距路段起点距离。单位：像素。

参数: 

​	[ in ] dist: 距离值。

**def setFromTime(self, time: int) -> None**

​	设置工作起始时间。单位: s。

**def setToTime(self, time: int) -> None**

​	设置工作结束时间。单位: s。

**def setAggregateInterval(self, interval: int) -> None**

​	设置集计数据时间间隔。单位: s。

**def polygon(self) -> PySide2.QtGui.QPolygonF**

​	获取计数器的多边型轮廓顶点。

#### 3.4.5.3.行程时间检测器（IVehicleTravelDetector）

**def id(self) -> int**

​	获取检测器ID。

**def detectorName(self) -> str**

​	获取检测器名称。

**def isStartDetector(self) -> bool**

​	是否检测器起始点。

**def isOnLink_startDetector(self) -> bool**

​	检测器起点是否在路段上，如果否，则起点在连接段上。

**def isOnLink_endDetector(self) -> bool**

​	检测器终点是否在路段上，如果否，则终点在连接段上。

**def link_startDetector(self) -> Tessng.ILink**

​	如果检测器起点在路段上则返回起点所在路段，否则返回None。

**def laneConnector_startDetector(self) -> Tessng.ILaneConnector**

​	如果检测器起点在连接段上返回起点车道连接，否则返回None。

**def link_endDetector(self) -> Tessng.ILink**

​	如果检测器终点在路段上返回终点所在路段，否则返回None。

**def laneConnector_endDetector(self) -> Tessng.ILaneConnector**

​	如果检测器终点在连接段上返回终点车道连接，否则返回None。

**def distance_startDetector(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取起点检测器距路段起点距离。单位：像素。

**def distance_endDetector(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取终点检测器距路段起点距离。单位：像素。

**def point_startDetector(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	获取起点检测器位置坐标。单位：像素。

**def point_endDetector(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	获取终点检测器位置坐标。单位：像素。

**def fromTime(self) -> int**

​	检测器工作起始时间。单位: s。

**def toTime(self) -> int**

​	检测器工作停止时间。单位: s。

**def aggregateInterval(self) -> int**

​	集计数据时间间隔。单位: s。

**def setName(self, name: str) -> None**

​	设置检测器名称。

**def setDistance_startDetector(self, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置起点检测器距路段起点距离。单位：像素。

参数: 

​	[ in ] dist: 距离值。

**def setDistance_endDetector(self, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置终点检测器距路段起点距离。单位：像素。

参数: 

​	[ in ] dist: 距离值。

**def setFromTime(self, time: int) -> None**

​	设置检测器工作起始时间。单位: s。

参数: 

​	[ in ] time: 工作起始时间。单位: s。

**def setToTime(self, time: int) -> None**

​	设置检测器工作结束时间。单位: s。

参数: 

​	[ in ] time: 工作结束时间。单位: s。

**def setAggregateInterval(self, interval: int) -> None**

​	设置检测器集计数据时间间隔。单位: s。

参数: 

​	[ in ] interval: 集计数据时间间隔。单位: s。

**def polygon_startDetector(self) -> PySide2.QtGui.QPolygonF**

​	获取行程时间检测器起始点多边型轮廓的顶点。

**def polygon_endDetector(self) -> PySide2.QtGui.QPolygonF**

​	获取行程时间检测器终止点多边型轮廓的顶点。

### 3.4.6.导向箭头

#### 3.4.6.1.导向箭头（IGuIDArrow）

**def id(self) -> int**

​	获取导向箭头ID。

**def lane(self) -> Tessng.ILane**

​	获取导向箭头所在的车道。

**def length(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取导向箭头长度。单位：像素。

**def distToTerminal(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取导向箭头到终点距离。单位：像素。

**def arrowType(self) -> Online.GuideArrowType**

​	获取导向箭头的类型，导向箭头的类型分为: 直行、左转、右转、直行或左转、直行或右转、直行左转或右转、左转或右转、掉头、直行或掉头和左转或掉头。

**def polygon(self) -> PySide2.QtGui.QPolygonF**

​	获取导向箭头的多边型轮廓的顶点。

### 3.4.7.公交系统

#### 3.4.7.1.公交线路（IBusLine）

**def id(self) -> int**

​	获取公交线路ID。

**def name(self) -> str**

​	线路名称。

**def length(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取公交线路长度。单位：像素。

**def dispatchFreq(self) -> int**

​	发车间隔。单位: s。

**def dispatchStartTime(self) -> int**

​	发车开始时间。单位: s。

**def dispatchEndTime(self) -> int**

​	发车结束时间。单位: s。

**def desirSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取公交线路期望速度。单位: 像素/s。

**def passCountAtStartTime(self) -> int**

​	起始载客人数。

**def links(self) -> list[Tessng.ILink]**

​	公交线路经过的路段。

**def stations(self) -> list[Tessng.IBusStation]**

​	线路所有站点。

**def stationLines(self) -> list[Tessng.IBusStationLine]**

​	公交站点线路，当前线路相关站点的上下客等参数。

**def setName(self, name: str) -> None**

​	设置线路名称。

**def setDispatchFreq(self, freq: int) -> None**

​	设置当前公交线路的发车间隔。单位: s。

参数: 

​	[ in ] freq: 发车间隔。单位: s。

**def setDispatchStartTime(self, startTime: int) -> None**

​	设置当前公交线路上的公交首班车辆的开始发车时间。单位: s。

参数: 

​	[ in ] startTime: 开始发车时间。单位: s。

**def setDispatchEndTime(self, endTime: int) -> None**

​	设置当前公交线路上的公交末班车辆的结束发车时间。单位: s。

参数: 

​	[ in ] endTime: 结束发车时间。单位: s。

**def setDesirSpeed(self, speed: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置当前公交线路的期望速度。单位: 像素/s。

参数: 

​	[ in ] speed: 速度值。

**def setPassCountAtStartTime(self, count: int) -> None**

​	设置起始载客人数。

#### 3.4.7.2.公交站点（IBusStation）

**def id(self) -> int**

​	获取公交站点ID。

**def name(self) -> str**

​	获取公交站点名称。

**def laneNumber(self) -> int**

​	获取公交站点所在车道序号。

**def x(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取站点X坐标。单位：像素。

**def y(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取站点Y坐标。单位：像素。

**def length(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取站点长度。单位：像素。

**def stationType(self) -> int**

​	站点类型，1: 路边式、2: 港湾式。

**def link(self) -> Tessng.ILink**

​	公交站点所在路段。

**def lane(self) -> Tessng.ILane**

​	公交站点所在车道。

**def distance(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取站点距路段起点距离。单位：像素。

**def setName(self, name: str) -> None**

​	设置站点名称。

参数: 

​	[ in ] name: 新名称。

**def setDistToStart(self, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置站点距路段起点距离。单位：像素。

参数: 

​	[ in ] dist: 距离值。

**def setLength(self, length: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置站点长度。单位：像素。

参数: 

​	[ in ] length: 长度值。

**def setType(self, type: int) -> None**

​	设置站点类型。

参数: 

​	[ in ] type: 站点类型，1 路侧式、2 港湾式。

**def polygon(self) -> PySide2.QtGui.QPolygonF**

​	公交站点多边型轮廓的顶点。

#### 3.4.7.3.公交站点-线路（IBusStationLine）

**def id(self) -> int**

​	获取公交"站点-线路"ID。

**def stationId(self) -> int**

​	公交站点ID。

**def lineId(self) -> int**

​	公交线路ID。

**def busParkingTime(self) -> int**

​	车辆停靠时间。单位: s。

**def getOutPercent(self) -> float**

​	下客百分比。

**def getOnTimePerPerson(self) -> float**

​	平均每位乘客上车时间。单位: s。

**def getOutTimePerPerson(self) -> float**

​	平均每位乘客下车时间。单位: s。

**def setBusParkingTime(self, time: int) -> None**

​	设置车辆停靠时间。

参数: 

​	[ in ] time: 车辆停靠时间。单位: s。

**def setGetOutPercent(self, percent: float) -> None**

​	设置下客百分比。

参数: 

​	[ in ] percent: 下客百分比。

**def setGetOnTimePerPerson(self, time: float) -> None**

​	设置平均每位乘客上车时间。

参数: 

​	[ in ] time: 平均每位乘客上车时间。单位: s。

**def setGetOutTimePerPerson(self, time: float) -> None**

​	设置平均每位乘客下车时间。

参数: 

​	[ in ] time: 平均每位乘客下车时间。单位: s。

### 3.4.8.事件区域

#### 3.4.8.1.事故区（IAccidentZone）

**def id(self) -> int**

​	获取事故区ID。

**def name(self) -> str**

​	获取事故区名称。

**def location(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取事故区当前时段距所在路段起点的距离。单位：像素。

**def zoneLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取事故区当前时段长度。单位：像素。

**def limitedSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取事故区当前时段限速。单位：像素(km/h)。

**def section(self) -> Tessng.ISection**

​	获取事故区所在的路段或连接段。

**def roadId(self) -> int**

​	获取事故区所在路段的ID。

**def roadType(self) -> str**

​	获取事故区所在的道路类型(路段或连接段)。

**def laneObjects(self) -> list[Tessng.ILaneObject]**

​	获取事故区当前时段占用的车道列表。

**def controlLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取事故区当前时段控制距离（车辆距离事故区起点该距离内，强制变道）。单位：像素。

**def addAccidentZoneInterval(self, param: Online.DynaAccidentZoneIntervalParam) -> Tessng.IAccidentZoneInterval**

​	添加事故时段。

参数: 

​	[ in ] param: 事故时段参数。

**def removeAccidentZoneInterval(self, accidentZoneIntervalId: int) -> None**

​	移除事故时段。

参数: 

​	[ in ] accidentZoneIntervalId: 事故时段ID。

**def updateAccidentZoneInterval(self, param: Online.DynaAccidentZoneIntervalParam) -> bool**

​	更新事故时段。

参数: 

​	[ in ] param: 事故时段参数。

**def accidentZoneIntervals(self) -> list[Tessng.IAccidentZoneInterval]**

​	获取所有事故时段。

**def findAccidentZoneIntervalById(self, accidentZoneIntervalId: int) -> Tessng.IAccidentZoneInterval**

​	通过ID查询事故时段。

参数: 

​	[ in ] accidentZoneIntervalId: 事故时段ID。

**def findAccidentZoneIntervalByStartTime(self, startTime: int) -> Tessng.IAccidentZoneInterval**

​	通过开始时间查询事故时段。

参数: 

​	[ in ] startTime: 事故时段开始时间。

#### 3.4.8.2.事故区时段（IAccidentZoneInterval）

**def intervalId(self) -> int**

​	获取事故时段ID。

**def accidentZoneId(self) -> int**

​	获取所属事故区ID。

**def startTime(self) -> int**

​	获取事故时段开始时间。

**def endTime(self) -> int**

​	获取事故时段结束时间。

**def length(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取事故区在该时段的长度。单位：像素。

**def location(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取事故区在该时段的距起点距离。单位：像素。

**def limitedSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取事故区在该时段的限速。单位: 像素(km/h)。

**def controlLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取事故区在该时段的控制距离（车辆距离事故区起点该距离内，强制变道）。单位：像素。

**def laneNumbers(self) -> list[int]**

​	获取事故区在该时段的占用车道序号。

#### 3.4.8.3.施工区（IRoadWorkZone）

**def id(self) -> int**

​	获取施工区ID。

**def name(self) -> str**

​	获取施工区名称。

**def location(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取施工区距所在路段起点的距离。单位：像素。

**def zoneLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取施工区长度。单位：像素。

**def limitSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取施工区限速。单位: 像素（km/h）。

**def sectionId(self) -> int**

​	获取施工区所在路段或连接段的ID。

**def sectionName(self) -> str**

​	获取施工区所在路段或连接段的名称。

**def sectionType(self) -> str**

​	获取施工区所在道路的道路类型，link: 路段，connector: 连接段。

**def laneObjects(self) -> list[Tessng.ILaneObject]**

​	获取施工区所占的车道列表。

**def laneObjectIds(self) -> list[int]**

​	获取施工区所占的车道ID列表。

**def upCautionLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取施工区上游警示区长度。单位：像素。

**def upTransitionLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取施工区上游过渡区长度。单位：像素。

**def upBufferLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取施工区上游缓冲区长度。单位：像素。

**def downTransitionLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取施工区下游过渡区长度。单位：像素。

**def downTerminationLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取施工区下游终止区长度。单位：像素。

**def duration(self) -> int**

​	施工持续时间，自仿真过程创建后，持续时间大于此值，则移除。单位: s。

**def isBorrowed(self) -> bool**

​	获取施工区是否被借道。

#### 3.4.8.4.限行区（ILimitedZone）

**def id(self) -> int**

​	获取限行区ID。

**def name(self) -> str**

​	获取限行区名称。

**def location(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取限行区距所在路段起点的距离。单位：像素。

**def zoneLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取限行区长度。单位：像素。

**def limitSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取限行区限速，单位: 像素(km/h)。

**def sectionId(self) -> int**

​	获取路段或连接段ID。

**def sectionName(self) -> str**

​	获取Section名称。

**def sectionType(self) -> str**

​	获取道路类型，"link"表示路段，"connector"表示连接段。

**def laneObjects(self) -> list[Tessng.ILaneObject]**

​	获取相关车道对象列表。

**def duration(self) -> int**

​	获取限行持续时间，自仿真过程创建后，持续时间大于此值则删除。单位: s。

#### 3.4.8.5.改扩建借道（IReconstruction）

**def id(self) -> int**

​	获取改扩建ID。

**def roadWorkZoneId(self) -> int**

​	获取改扩建起始施工区ID。

**def limitedZoneId(self) -> int**

​	获取被借道限行区ID。

**def passagewayLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取保通长度。单位：像素。

**def duration(self) -> int**

​	获取改扩建持续时间。

**def borrowedNum(self) -> int**

​	获取借道数量。

**def passagewayLimitedSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取保通开口限速。单位: 像素（km/h）。

**def dynaReconstructionParam(self) -> Online.DynaReconstructionParam**

​	获取改扩建动态参数。

#### 3.4.8.6.限速区（IReduceSpeedArea）

**def id(self) -> int**

​	获取限速区ID。

**def name(self) -> str**

​	获取限速区名称。

**def location(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取距起点距离。单位：像素。

**def areaLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取限速区长度。单位：像素。

**def sectionId(self) -> int**

​	获取路段或连接段ID。

**def laneNumber(self) -> int**

​	获取车道序号。

**def toLaneNumber(self) -> int**

​	获取目标车道序号。

**def addReduceSpeedInterval(self, param: Online.DynaReduceSpeedIntervalParam) -> Tessng.IReduceSpeedInterval**

​	添加限速时段。

参数: 

​	[ in ] param: 限速时段参数。

**def removeReduceSpeedInterval(self, id: int) -> None**

​	移除限速时段。

参数: 

​	[ in ] id: 限速时段ID。

**def updateReduceSpeedInterval(self, param: Online.DynaReduceSpeedIntervalParam) -> bool**

​	更新限速时段。

参数: 

​	[ in ] param: 限速时段参数。

**def reduceSpeedIntervals(self) -> list[Tessng.IReduceSpeedInterval]**

​	获取限速时段列表。

**def findReduceSpeedIntervalById(self, id: int) -> Tessng.IReduceSpeedInterval**

​	通过ID获取限速时段。

参数: 

​	[ in ] id: 限速时段ID。

**def findReduceSpeedIntervalByStartTime(self, startTime: int) -> Tessng.IReduceSpeedInterval**

​	通过起始时间获取限速时段。

参数: 

​	[ in ] startTime: 起始时间。

**def polygon(self) -> PySide2.QtGui.QPolygonF**

​	获取多边型轮廓。

#### 3.4.8.7.限速时段（IReduceSpeedInterval）

**def id(self) -> int**

​	获取限速时段ID。

**def reduceSpeedAreaId(self) -> int**

​	获取所属限速区ID。

**def intervalStartTime(self) -> int**

​	获取开始时间。

**def intervalEndTime(self) -> int**

​	获取结束时间。

**def addReduceSpeedVehiType(self, param: Online.DynaReduceSpeedVehiTypeParam) -> Tessng.IReduceSpeedVehiType**

​	添加限速车型。

参数: 

​	[ in ] param: 限速车型参数。

**def removeReduceSpeedVehiType(self, id: int) -> None**

​	移除限速车型。

参数: 

​	[ in ] id: 限速车型ID。

**def updateReduceSpeedVehiType(self, param: Online.DynaReduceSpeedVehiTypeParam) -> bool**

​	更新限速车型。

参数: 

​	[ in ] param: 限速车型参数。

**def reduceSpeedVehiTypes(self) -> list[Tessng.IReduceSpeedVehiType]**

​	获取本时段限速车型及限速参数列表。

**def findReduceSpeedVehiTypeById(self, id: int) -> Tessng.IReduceSpeedVehiType**

​	通过id获取限速车型。

参数: 

​	[ in ] id: 限速车型ID。

**def findReduceSpeedVehiTypeByCode(self, vehicleTypeCode: int) -> Tessng.IReduceSpeedVehiType**

​	通过车型代码获取限速车型。

参数: 

​	[ in ] vehicleTypeCode: 车型代码。

#### 3.4.8.8.限速车型（IReduceSpeedVehiType）

**def id(self) -> int**

​	获取限速车型ID。

**def intervalId(self) -> int**

​	获取所属限速时段ID。

**def reduceSpeedAreaId(self) -> int**

​	获取所属限速区ID。

**def vehiTypeCode(self) -> int**

​	获取车型编码。

**def averageSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取平均车速。单位: 像素/s。

**def speedStandardDeviation(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取车速标准差。单位: 像素/s。

### 3.4.9.行人模块

#### 3.4.9.1.障碍物面域（IObstacleRegion）

**def isObstacle(self) -> bool**

​	获取面域是否为障碍物。

**def setObstacle(self, b: bool) -> None**

​	设置面域是否为障碍物。

参数: 

​	[ in ] b: 是否为障碍物。

#### 3.4.9.2.乘客面域（IPassengerRegion）

**def isBoardingArea(self) -> bool**

​	获取面域是否为上客区域。

**def setIsBoardingArea(self, b: bool) -> None**

​	设置面域是否为上客区域。

**def isAlightingArea(self) -> bool**

​	获取面域是否为下客区域。

**def setIsAlightingArea(self, b: bool) -> None**

​	设置面域是否为下客区域。

#### 3.4.9.3.行人路径面域基类（IPedestrianPathRegionBase）

**def getId(self) -> int**

​	获取面域ID。

**def getName(self) -> str**

​	获取面域名称。

**def setName(self, name: str) -> None**

​	设置面域名称。

**def getRegionColor(self) -> PySide2.QtGui.QColor**

​	获取面域颜色。

**def setRegionColor(self, color: PySide2.QtGui.QColor) -> None**

​	设置面域颜色。

**def getPosition(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	获取面域位置。单位：像素。

**def setPosition(self, scenePos: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**def getGType(self) -> int**

​	获取面域类型。

#### 3.4.9.4.行人面域（IPedestrianRegion）

**def getId(self) -> int**

​	获取面域ID。

**def getName(self) -> str**

​	获取面域名称。

**def setName(self, name: str) -> None**

​	设置面域名称。

**def getRegionColor(self) -> PySide2.QtGui.QColor**

​	获取面域颜色。

**def setRegionColor(self, color: PySide2.QtGui.QColor) -> None**

​	设置面域颜色。

**def getPosition(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	获取面域位置。单位：像素。

**def setPosition(self, scenePos: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**def getGType(self) -> int**

​	获取面域类型。

**def getExpectSpeedFactor(self) -> float**

​	获取期望速度系数。

**def setExpectSpeedFactor(self, val: float) -> None**

​	设置期望速度系数。

参数: 

​	[ in ] val: 期望速度系数。

**def getElevation(self) -> float**

​	获取面域高程。

**def setElevation(self, elevation: float) -> None**

​	设置面域高程。

参数: 

​	[ in ] elevation: 高程。

**def getPolygon(self) -> PySide2.QtGui.QPolygonF**

​	获取面域多边形。

**def getLayerId(self) -> int**

​	获取面域所在图层ID。

**def setLayerId(self, id: int) -> None**

​	设置面域所在图层，如果图层ID非法，则不做任何改变。

参数: 

​	[ in ] id: 图层ID。

#### 3.4.9.5.矩形行人面域（IPedestrianRectRegion）

**def getId(self) -> int**

​	获取面域ID。

**def getName(self) -> str**

​	获取面域名称。

**def setName(self, name: str) -> None**

​	设置面域名称。

**def getRegionColor(self) -> PySide2.QtGui.QColor**

​	获取面域颜色。

**def setRegionColor(self, color: PySide2.QtGui.QColor) -> None**

​	设置面域颜色。

**def getPosition(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	获取面域位置。单位：像素。

**def setPosition(self, scenePos: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**def getGType(self) -> int**

​	获取面域类型。

**def getExpectSpeedFactor(self) -> float**

​	获取期望速度系数。

**def setExpectSpeedFactor(self, val: float) -> None**

​	设置期望速度系数。

**def getElevation(self) -> float**

​	获取面域高程。

**def setElevation(self, elevation: float) -> None**

​	设置面域高程。

**def getPolygon(self) -> PySide2.QtGui.QPolygonF**

​	获取面域多边形。

**def getLayerId(self) -> int**

​	获取面域所在图层ID。

**def setLayerId(self, id: int) -> None**

​	设置面域所在图层，如果图层ID非法，则不做任何改变。

**def isObstacle(self) -> bool**

​	获取面域是否为障碍物。

**def setObstacle(self, b: bool) -> None**

​	设置面域是否为障碍物。

**def isBoardingArea(self) -> bool**

​	获取面域是否为上客区域。

**def setIsBoardingArea(self, b: bool) -> None**

​	设置面域是否为上客区域。

**def isAlightingArea(self) -> bool**

​	获取面域是否为下客区域。

**def setIsAlightingArea(self, b: bool) -> None**

​	设置面域是否为下客区域。

#### 3.4.9.6.三角形行人面域（IPedestrianTriangleRegion）

**def getId(self) -> int**

​	获取面域ID。

**def getName(self) -> str**

​	获取面域名称。

**def setName(self, name: str) -> None**

​	设置面域名称。

**def getRegionColor(self) -> PySide2.QtGui.QColor**

​	获取面域颜色。

**def setRegionColor(self, color: PySide2.QtGui.QColor) -> None**

​	设置面域颜色。

**def getPosition(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	获取面域位置。单位：像素。

**def setPosition(self, scenePos: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**def getGType(self) -> int**

​	获取面域类型。

**def getExpectSpeedFactor(self) -> float**

​	获取期望速度系数。

**def setExpectSpeedFactor(self, val: float) -> None**

​	设置期望速度系数。

**def getElevation(self) -> float**

​	获取面域高程。

**def setElevation(self, elevation: float) -> None**

​	设置面域高程。

**def getPolygon(self) -> PySide2.QtGui.QPolygonF**

​	获取面域多边形。

**def getLayerId(self) -> int**

​	获取面域所在图层ID。

**def setLayerId(self, id: int) -> None**

​	设置面域所在图层，如果图层ID非法，则不做任何改变。

**def isObstacle(self) -> bool**

​	获取面域是否为障碍物。

**def setObstacle(self, b: bool) -> None**

​	设置面域是否为障碍物。

**def isBoardingArea(self) -> bool**

​	获取面域是否为上客区域。

**def setIsBoardingArea(self, b: bool) -> None**

​	设置面域是否为上客区域。

**def isAlightingArea(self) -> bool**

​	获取面域是否为下客区域。

**def setIsAlightingArea(self, b: bool) -> None**

​	设置面域是否为下客区域。

#### 3.4.9.7.椭圆形行人面域（IPedestrianEllipseRegion）

**def getId(self) -> int**

​	获取面域ID。

**def getName(self) -> str**

​	获取面域名称。

**def setName(self, name: str) -> None**

​	设置面域名称。

**def getRegionColor(self) -> PySide2.QtGui.QColor**

​	获取面域颜色。

**def setRegionColor(self, color: PySide2.QtGui.QColor) -> None**

​	设置面域颜色。

**def getPosition(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	获取面域位置。单位：像素。

**def setPosition(self, scenePos: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**def getGType(self) -> int**

​	获取面域类型。

**def getExpectSpeedFactor(self) -> float**

​	获取期望速度系数。

**def setExpectSpeedFactor(self, val: float) -> None**

​	设置期望速度系数。

**def getElevation(self) -> float**

​	获取面域高程。

**def setElevation(self, elevation: float) -> None**

​	设置面域高程。

**def getPolygon(self) -> PySide2.QtGui.QPolygonF**

​	获取面域多边形。

**def getLayerId(self) -> int**

​	获取面域所在图层ID。

**def setLayerId(self, id: int) -> None**

​	设置面域所在图层，如果图层ID非法，则不做任何改变。

**def isObstacle(self) -> bool**

​	获取面域是否为障碍物。

**def setObstacle(self, b: bool) -> None**

​	设置面域是否为障碍物。

**def isBoardingArea(self) -> bool**

​	获取面域是否为上客区域。

**def setIsBoardingArea(self, b: bool) -> None**

​	设置面域是否为上客区域。

**def isAlightingArea(self) -> bool**

​	获取面域是否为下客区域。

**def setIsAlightingArea(self, b: bool) -> None**

​	设置面域是否为下客区域。

#### 3.4.9.8.扇形行人面域（IPedestrianFanShapeRegion）

**def getId(self) -> int**

​	获取面域ID。

**def getName(self) -> str**

​	获取面域名称。

**def setName(self, name: str) -> None**

​	设置面域名称。

**def getRegionColor(self) -> PySide2.QtGui.QColor**

​	获取面域颜色。

**def setRegionColor(self, color: PySide2.QtGui.QColor) -> None**

​	设置面域颜色。

**def getPosition(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	获取面域位置。单位：像素。

**def setPosition(self, scenePos: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**def getGType(self) -> int**

​	获取面域类型。

**def getExpectSpeedFactor(self) -> float**

​	获取期望速度系数。

**def setExpectSpeedFactor(self, val: float) -> None**

​	设置期望速度系数。

**def getElevation(self) -> float**

​	获取面域高程。

**def setElevation(self, elevation: float) -> None**

​	设置面域高程。

**def getPolygon(self) -> PySide2.QtGui.QPolygonF**

​	获取面域多边形。

**def getLayerId(self) -> int**

​	获取面域所在图层ID。

**def setLayerId(self, id: int) -> None**

​	设置面域所在图层，如果图层ID非法，则不做任何改变。

**def isObstacle(self) -> bool**

​	获取面域是否为障碍物。

**def setObstacle(self, b: bool) -> None**

​	设置面域是否为障碍物。

**def isBoardingArea(self) -> bool**

​	获取面域是否为上客区域。

**def setIsBoardingArea(self, b: bool) -> None**

​	设置面域是否为上客区域。

**def isAlightingArea(self) -> bool**

​	获取面域是否为下客区域。

**def setIsAlightingArea(self, b: bool) -> None**

​	设置面域是否为下客区域。

**def getInnerRadius(self) -> float**

​	获取内半径，单位: 米。

**def getOuterRadius(self) -> float**

​	获取外半径，单位: 米。

**def getStartAngle(self) -> float**

​	获取起始角度，单位: 度。

**def getSweepAngle(self) -> float**

​	获取扫过角度，单位: 度。

#### 3.4.9.9.多边形行人面域（IPedestrianPolygonRegion）

**def getId(self) -> int**

​	获取面域ID。

**def getName(self) -> str**

​	获取面域名称。

**def setName(self, name: str) -> None**

​	设置面域名称。

**def getRegionColor(self) -> PySide2.QtGui.QColor**

​	获取面域颜色。

**def setRegionColor(self, color: PySide2.QtGui.QColor) -> None**

​	设置面域颜色。

**def getPosition(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	获取面域位置。单位：像素。

**def setPosition(self, scenePos: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**def getGType(self) -> int**

​	获取面域类型。

**def getExpectSpeedFactor(self) -> float**

​	获取期望速度系数。

**def setExpectSpeedFactor(self, val: float) -> None**

​	设置期望速度系数。

**def getElevation(self) -> float**

​	获取面域高程。

**def setElevation(self, elevation: float) -> None**

​	设置面域高程。

**def getPolygon(self) -> PySide2.QtGui.QPolygonF**

​	获取面域多边形。

**def getLayerId(self) -> int**

​	获取面域所在图层ID。

**def setLayerId(self, id: int) -> None**

​	设置面域所在图层，如果图层ID非法，则不做任何改变。

**def isObstacle(self) -> bool**

​	获取面域是否为障碍物。

**def setObstacle(self, b: bool) -> None**

​	设置面域是否为障碍物。

**def isBoardingArea(self) -> bool**

​	获取面域是否为上客区域。

**def setIsBoardingArea(self, b: bool) -> None**

​	设置面域是否为上客区域。

**def isAlightingArea(self) -> bool**

​	获取面域是否为下客区域。

**def setIsAlightingArea(self, b: bool) -> None**

​	设置面域是否为下客区域。

#### 3.4.9.10.人行道行人面域（IPedestrianSIDeWalkRegion）

**def getId(self) -> int**

​	获取面域ID。

**def getName(self) -> str**

​	获取面域名称。

**def setName(self, name: str) -> None**

​	设置面域名称。

参数: 

​	[ in ] name: 新名称。

**def getRegionColor(self) -> PySide2.QtGui.QColor**

​	获取面域颜色。

**def setRegionColor(self, color: PySide2.QtGui.QColor) -> None**

​	设置面域颜色。

参数: 

​	[ in ] color: 面域颜色。

**def getPosition(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	获取面域位置。单位：像素。

**def setPosition(self, scenePos: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**def getGType(self) -> int**

​	获取面域类型。

**def getExpectSpeedFactor(self) -> float**

​	获取期望速度系数。

**def setExpectSpeedFactor(self, val: float) -> None**

​	设置期望速度系数。

**def getElevation(self) -> float**

​	获取面域高程。

**def setElevation(self, elevation: float) -> None**

​	设置面域高程。

**def getPolygon(self) -> PySide2.QtGui.QPolygonF**

​	获取面域多边形。

**def getLayerId(self) -> int**

​	获取面域所在图层ID。

**def setLayerId(self, id: int) -> None**

​	设置面域所在图层，如果图层ID非法，则不做任何改变。

参数: 

​	[ in ] id: 图层ID。

**def getWidth(self) -> float**

​	获取人行道宽度。

**def setWidth(self, width: float) -> None**

​	设置人行道宽度。

参数: 

​	[ in ] width: 人行道宽度，单位: m。

**def getVetexs(self) -> list[PySide2.QtWidgets.QGraphicsEllipseItem]**

​	获取人行道顶点，即初始折线顶点。

**def getControl1Vetexs(self) -> list[PySide2.QtWidgets.QGraphicsEllipseItem]**

​	获取人行道贝塞尔曲线控制点P1。

**def getControl2Vetexs(self) -> list[PySide2.QtWidgets.QGraphicsEllipseItem]**

​	获取人行道贝塞尔曲线控制点P2。

**def getCandidateVetexs(self) -> list[PySide2.QtWidgets.QGraphicsEllipseItem]**

​	获取候选顶点。

**def removeVetex(self, index: int) -> None**

​	删除第index个顶点。

参数: 

​	[ in ] index: 顶点索引。

**def insertVetex(self, pos: PySide2.QtCore.QPointF, index: int) -> None**

​	在第index个位置插入顶点，初始位置为pos。

参数: 

​	[ in ] pos: 顶点位置。

​	[ in ] index: 插入位置。

#### 3.4.9.11.人行横道行人面域（IPedestrianCrossWalkRegion）

**def getId(self) -> int**

​	获取面域ID。

**def getName(self) -> str**

​	获取面域名称。

**def setName(self, name: str) -> None**

​	设置面域名称。

参数: 

​	[ in ] name: 新名称。

**def getRegionColor(self) -> PySide2.QtGui.QColor**

​	获取面域颜色。

**def setRegionColor(self, color: PySide2.QtGui.QColor) -> None**

​	设置面域颜色。

参数: 

​	[ in ] color: 面域颜色。

**def getPosition(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	获取面域位置。单位：像素。

**def setPosition(self, scenePos: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**def getGType(self) -> int**

​	获取面域类型。

**def getExpectSpeedFactor(self) -> float**

​	获取期望速度系数。

**def setExpectSpeedFactor(self, val: float) -> None**

​	设置期望速度系数。

**def getElevation(self) -> float**

​	获取面域高程。

**def setElevation(self, elevation: float) -> None**

​	设置面域高程。

**def getPolygon(self) -> PySide2.QtGui.QPolygonF**

​	获取面域多边形。

**def getLayerId(self) -> int**

​	获取面域所在图层ID。

**def setLayerId(self, id: int) -> None**

​	设置面域所在图层，如果图层ID非法，则不做任何改变。

**def getWidth(self) -> float**

​	获取人行横道宽度，单位: 米。

**def setWidth(self, width: float) -> None**

​	设置人行横道宽度，单位: 米。

**def getSceneLine(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QLineF**

​	获取人行横道起点到终点的线段，场景坐标系下。单位：像素。

**def getAngle(self) -> float**

​	获取人行横道倾斜角度。

**def setAngle(self, angle: float) -> None**

​	设置人行横道倾斜角度。

**def getRedLightSpeedFactor(self) -> float**

​	获取红灯清尾速度系数。

**def setRedLightSpeedFactor(self, factor: float) -> None**

​	设置红灯清尾速度系数。

**def getUnitDirectionFromStartToEnd(self) -> PySide2.QtGui.QVector2D**

​	获取场景坐标系下从起点到终点的单位方向向量。

**def getLocalUnitDirectionFromStartToEnd(self) -> PySide2.QtGui.QVector2D**

​	获取人行横道本身坐标系下从起点到终点的单位方向。

**def getStartControlPoint(self) -> PySide2.QtWidgets.QGraphicsEllipseItem**

​	获取起点控制点。

**def getEndControlPoint(self) -> PySide2.QtWidgets.QGraphicsEllipseItem**

​	获取终点控制点。

**def getLeftControlPoint(self) -> PySide2.QtWidgets.QGraphicsEllipseItem**

​	获取左侧控制点。

**def getRightControlPoint(self) -> PySide2.QtWidgets.QGraphicsEllipseItem**

​	获取右侧控制点。

**def getPositiveDirectionSignalLamp(self) -> Tessng.ICrosswalkSignalLamp**

​	获取管控正向通行的信号灯。

**def getNegativeDirectionSignalLamp(self) -> Tessng.ICrosswalkSignalLamp**

​	获取管控反向通行的信号灯。

**def isPositiveTrafficLightAdded(self) -> bool**

​	判断是否添加了管控正向通行的信号灯。

**def isReverseTrafficLightAdded(self) -> bool**

​	判断是否添加了管控反向通行的信号灯。

#### 3.4.9.12.楼梯行人面域（IPedestrianStairRegion）

**def getId(self) -> int**

​	获取面域ID。

**def getName(self) -> str**

​	获取面域名称。

**def setName(self, name: str) -> None**

​	设置面域名称。

**def getRegionColor(self) -> PySide2.QtGui.QColor**

​	获取面域颜色。

**def setRegionColor(self, color: PySide2.QtGui.QColor) -> None**

​	设置面域颜色。

**def getPosition(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	获取面域位置。单位：像素。

**def setPosition(self, scenePos: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**def getGType(self) -> int**

​	获取面域类型。

**def getWidth(self) -> float**

​	获取楼梯宽度，单位: m。

**def setWidth(self, width: float) -> None**

​	设置楼梯宽度，单位: m。

**def getStartPoint(self) -> PySide2.QtCore.QPointF**

​	获取起始点，场景坐标系下。

**def getEndPoint(self) -> PySide2.QtCore.QPointF**

​	获取终止点，场景坐标系下。

**def getStartConnectionAreaLength(self) -> float**

​	获取起始衔接区域长度，单位: m。

**def getEndConnectionAreaLength(self) -> float**

​	获取终止衔接区域长度，单位: m。

**def getStartRegionCenterPoint(self) -> PySide2.QtCore.QPointF**

​	获取起始衔接区域中心，场景坐标系下。

**def getEndRegionCenterPoint(self) -> PySide2.QtCore.QPointF**

​	获取终止衔接区域中心，场景坐标系下。

**def getStartSceneRegion(self) -> PySide2.QtGui.QPainterPath**

​	获取起始衔接区域形状，场景坐标系下。

**def getEndSceneRegion(self) -> PySide2.QtGui.QPainterPath**

​	获取终止衔接区域形状，场景坐标系下。

**def getMainQueueRegion(self) -> PySide2.QtGui.QPainterPath**

​	获取楼梯主体形状，场景坐标系下。

**def getFullQueueregion(self) -> PySide2.QtGui.QPainterPath**

​	获取楼梯整体形状，场景坐标系下。

**def getMainQueuePolygon(self) -> PySide2.QtGui.QPolygonF**

​	获取楼梯主体多边形，场景坐标系下。

**def getStairType(self) -> Tessng.StairType**

​	获取楼梯类型。

**def setStairType(self, type: Tessng.StairType) -> None**

​	设置楼梯类型。

**def getStartLayerId(self) -> int**

​	获取起始层级。

**def setStartLayerId(self, id: int) -> None**

​	设置起始层级。

**def getEndLayerId(self) -> int**

​	获取终止层级。

**def setEndLayerId(self, id: int) -> None**

​	设置终止层级。

**def getTransmissionSpeed(self) -> float**

​	获取传送速度，单位: m/s。

**def setTransmissionSpeed(self, speed: float) -> None**

​	设置传送速度，单位: m/s。

**def getHeadroom(self) -> float**

​	获取楼梯净高。

**def setHeadroom(self, headroom: float) -> None**

​	设置楼梯净高。

**def getStartControlPoint(self) -> PySide2.QtWidgets.QGraphicsEllipseItem**

​	获取起点控制点。

**def getEndControlPoint(self) -> PySide2.QtWidgets.QGraphicsEllipseItem**

​	获取终点控制点。

**def getLeftControlPoint(self) -> PySide2.QtWidgets.QGraphicsEllipseItem**

​	获取左侧控制点。

**def getRightControlPoint(self) -> PySide2.QtWidgets.QGraphicsEllipseItem**

​	获取右侧控制点。

**def getStartConnectionAreaControlPoint(self) -> PySide2.QtWidgets.QGraphicsEllipseItem**

​	获取起始衔接区域长度控制点。

**def getEndConnectionAreaControlPoint(self) -> PySide2.QtWidgets.QGraphicsEllipseItem**

​	获取终止衔接区域长度控制点。

#### 3.4.9.13.行人路径（IPedestrianPath）

**def getId(self) -> int**

​	获取行人路径ID。

**def getPathStartPoint(self) -> Tessng.IPedestrianPathPoint**

​	获取行人路径起始点。

**def getPathEndPoint(self) -> Tessng.IPedestrianPathPoint**

​	获取行人路径终点。

**def getPathMiddlePoints(self) -> list[Tessng.IPedestrianPathPoint]**

​	获取行人路径中间点。

**def isLocalPath(self) -> bool**

​	判断是否是局部路径。

#### 3.4.9.14.行人路径点（IPedestrianPathPoint）

**def getId(self) -> int**

​	获取行人路径点ID。

**def getScenePos(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	获取行人路径点场景坐标系下的位置。单位：像素。

**def getRadius(self) -> float**

​	获取行人路径点的半径，单位: m。

#### 3.4.9.15.人行横道信号灯（ICrosswalkSignalLamp）

**def id(self) -> int**

​	获取信号灯ID。

**def setSignalPhase(self, pPhase: Tessng.ISignalPhase) -> None**

​	设置相位，所设相位可以是其它信号灯组的相位。

**def setPhaseNumber(self, num: int) -> None**

​	设置相位序号，序号从1开始，如果num序号大于相位总数不进行设置。

**def setLampColor(self, colorStr: str) -> None**

​	设置信号灯颜色。

参数: 

​	[ in ] colorStr: 字符串表达的颜色，有四种可选，分别是"红"、"绿"、"黄"、"灰"，，或者是"R"、"G"、"Y"、"gray"。 

**def color(self) -> str**

​	获取信号灯色，"R"、“G”、“Y”、“gray”分别表示"红"、"绿"、"黄"、"灰"。

**def name(self) -> str**

​	获取信号灯名称。

**def setName(self, name: str) -> None**

​	设置信号灯名称。

**def setDistToStart(self, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置信号灯距路段起点距离。单位：像素。

参数: 

​	[ in ] dist: 距离值。

**def signalPlan(self) -> Tessng.ISignalPlan**

​	获取信控方案。

**def signalPhase(self) -> Tessng.ISignalPhase**

​	获取相位。

**def laneObject(self) -> Tessng.ILaneObject**

​	获取所在车道或车道连接。

**def polygon(self) -> PySide2.QtGui.QPolygonF**

​	获取信号灯多边型轮廓的顶点。

**def angle(self) -> float**

​	获取信号灯角度。

**def getICrossWalk(self) -> Tessng.IPedestrianCrossWalkRegion**

​	获取所属人行横道。

### 3.4.10.停车场模块

#### 3.4.10.1.停车位（IParkingStall）

**def id(self) -> int**

​	获取停车位ID。

**def parkingRegionId(self) -> int**

​	获取所属停车区域ID。

**def parkingRegion(self) -> Tessng.IParkingRegion**

​	获取所属停车区域。

**def distance(self) -> float**

​	获取距路段起始位置，单位: m。

**def stallType(self) -> int**

​	获取车位类型，与车辆类型编码一致。

#### 3.4.10.2.停车区域（IParkingRegion）

**def id(self) -> int**

​	获取停车区域ID。

**def name(self) -> str**

​	获取停车区域名称。

**def setName(self, name: str) -> None**

​	设置停车区域名称。

参数: 

​	[ in ] name: 新名称。

**def parkingStalls(self) -> list[Tessng.IParkingStall]**

​	获取所有停车位。

**def dynaParkingRegion(self) -> Online.ParkingLot.DynaParkingRegion**

​	获取动态停车区域信息。

#### 3.4.10.3.停车路径决策点（IParkingDecisionPoint）

**def id(self) -> int**

​	获取停车决策点ID。

**def name(self) -> str**

​	获取停车决策点名称。

**def link(self) -> Tessng.ILink**

​	获取停车决策点所在路段。

**def distance(self) -> float**

​	获取停车决策点距路段起点距离，单位: m。

**def routings(self) -> list[Tessng.IParkingRouting]**

​	获取相关停车路径。

**def updateParkDisInfo(self, tollDisInfoList: list[Online.ParkingLot.DynaParkDisInfo]) -> bool**

​	更新停车分配信息。

参数: 

​	[ in ] tollDisInfoList: 停车分配信息列表。

**def parkDisInfoList(self) -> list[Online.ParkingLot.DynaParkDisInfo]**

​	获取停车分配信息列表。

**def polygon(self) -> PySide2.QtGui.QPolygonF**

​	获取停车决策点多边型轮廓。

#### 3.4.10.4.停车路径（IParkingRouting）

**def id(self) -> int**

​	获取路径ID。

**def parkingDeciPointId(self) -> int**

​	获取所属决策点ID。

**def parkingRegionId(self) -> int**

​	路径到达的停车区域id。

**def calcuLength(self) -> float**

​	计算路径长度。

**def contain(self, pRoad: Tessng.ISection) -> bool**

​	通过所给道路判断是否在当前路径上。

参数: 

​	[ in ] pRoad: 路段或连接段。

**def nextRoad(self, pRoad: Tessng.ISection) -> Tessng.ISection**

​	通过所给道路求下一条道路。

参数: 

​	[ in ] pRoad: 路段或连接段。

**def getLinks(self) -> list[Tessng.ILink]**

​	获取路段序列。

### 3.4.11.收费站模块

#### 3.4.11.1.收费点（ITollPoint）

**def id(self) -> int**

​	获取收费点ID。

**def distance(self) -> float**

​	获取距路段起始位置，单位: m。

**def tollLaneId(self) -> int**

​	获取所属收费车道ID。

**def tollLane(self) -> Tessng.ITollLane**

​	获取所属收费车道。

**def isEnabled(self) -> bool**

​	获取是否启用。

**def setEnabled(self, enabled: bool) -> bool**

​	设置启用状态。

参数: 

​	[ in ] enabled: 是否启用。

**def tollType(self) -> int**

​	获取收费类型。

**def setTollType(self, tollType: int) -> bool**

​	设置收费类型。

参数: 

​	[ in ] tollType: 收费类型。

**def timeDisId(self) -> int**

​	获取停车时间分布ID。

**def setTimeDisId(self, timeDisId: int) -> bool**

​	设置停车时间分布ID。

参数: 

​	[ in ] timeDisId: 时间分布ID。

#### 3.4.11.2.收费车道（ITollLane）

**def id(self) -> int**

​	获取收费车道ID。

**def name(self) -> str**

​	获取收费车道名称。

**def distance(self) -> float**

​	获取距路段起始位置，单位: m。

**def setName(self, name: str) -> None**

​	设置收费车道名称。

参数: 

​	[ in ] name: 收费车道新名称。

**def setWorkTime(self, startTime: int, endTime: int) -> None**

​	设置工作时间，工作时间与仿真时间对应。

参数: 

​	[ in ] startTime: 开始时间。单位：s。

​	[ in ] endTime: 结束时间。单位：s。

**def dynaTollLane(self) -> Online.TollStation.DynaTollLane**

​	获取动态收费车道信息。

**def tollPoints(self) -> list[Tessng.ITollPoint]**

​	获取收费车道所有收费点。

#### 3.4.11.3.收费决策点（ITollDecisionPoint）

**def id(self) -> int**

​	获取收费决策点ID。

**def name(self) -> str**

​	获取收费决策点名称。

**def link(self) -> Tessng.ILink**

​	获取收费决策点所在路段。

**def distance(self) -> float**

​	获取距路段起点距离，单位: m。

**def routings(self) -> list[Tessng.ITollRouting]**

​	获取相关收费路径。

**def tollDisInfoList(self) -> list[Online.TollStation.DynaTollDisInfo]**

​	获取收费分配信息列表。

**def updateTollDisInfoList(self, tollDisInfoList: list[Online.TollStation.DynaTollDisInfo]) -> None**

​	更新收费分配信息列表。

参数: 

​	[ in ] tollDisInfoList: 收费分配信息列表。

**def polygon(self) -> PySide2.QtGui.QPolygonF**

​	获取收费决策点多边型轮廓。

#### 3.4.11.4.收费路径（ITollRouting）

**def id(self) -> int**

​	获取路径ID。

**def tollDeciPointId(self) -> int**

​	获取所属收费决策点ID。

**def tollLaneId(self) -> int**

​	路径到达的收费区域id。

**def calcuLength(self) -> float**

​	计算路径长度。

**def contain(self, pRoad: Tessng.ISection) -> bool**

​	通过所给道路判断是否在当前路径上。

参数: 

​	[ in ] pRoad: 路段或连接段。

**def nextRoad(self, pRoad: Tessng.ISection) -> Tessng.ISection**

​	通过所给道路求下一条道路。

参数: 

​	[ in ] pRoad: 路段或连接段。

**def getLinks(self) -> list[Tessng.ILink]**

​	获取路段序列。

### 3.4.12.节点模块

#### 3.4.12.1.节点（IJunction）

**def getId(self) -> int**

​	获取节点ID。

**def name(self) -> str**

​	获取节点名称。

**def setName(self, strName: str) -> None**

​	设置节点名称。

参数: 

​	[ in ] strName: 新名称。

**def getJunctionLinks(self) -> list[Tessng.ILink]**

​	获取节点内的路段。

**def getJunctionConnectors(self) -> list[Tessng.IConnector]**

​	获取节点内的连接段。

**def getAllTurnningInfo(self) -> list[Online.Junction.TurnningBaseInfo]**

​	获取节点内所有流向信息。

**def getTurnningInfo(self, turningId: int) -> Online.Junction.TurnningBaseInfo**

​	获取节点内指定流向信息。

### 3.4.13.车辆与行人

#### 3.4.13.1.车辆（IVehicle）

​	车辆接口，用于访问、控制车辆。通过此接口可以读取车辆属性，设置车辆部分属性，仿真过程读取当前道路情况、车辆前后左右相邻车辆及与它们的距离等。

**def id(self) -> int**

​	车辆ID，车辆ID的组成方式为 x * 100000 + y，每个发车点的x值不一样，从1开始递增，y是每个发车点所发车辆序号，从1开始递增。第一个发车点所发车辆ID从100001开始递增，第二个发车点所发车辆ID从200001开始递增。

**def startLink(self) -> Tessng.ILink**

​	车辆进入路网时起始路段。

**def startSimuTime(self) -> int**

​	车辆进入路网时起始时间。

**def roadId(self) -> int**

​	车辆所在路段或连接段ID。

**def road(self) -> None**

​	道路，如果在路段上返回ILink，如果在连接段上返回IConnector。

**def section(self) -> Tessng.ISection**

​	车辆所在的Section，即路段或连接段。

**def laneObj(self) -> Tessng.ILaneObject**

​	车辆所在的车道或车道连接。

**def segmIndex(self) -> int**

​	车辆在当前LaneObject上分段序号。

**def roadIsLink(self) -> bool**

​	车辆所在道路是否路段。

**def roadName(self) -> str**

​	道路名。

**def initSpeed(self, speed: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	初始化车速。

参数: 

​	[ in ] speed: 初始速度值。单位: 像素/s。

**def initLane(self, laneNumber: int, dist: float = -1, speed: float = -1, unit: UnitOfMeasure = UnitOfMeasure: : Default) -> None**

​	在路段上初始化车辆。

参数: 

​	[ in ] laneNumber: 车道序号。

​	[ in ] dist: 距起点距离，单位: 像素。

​	[ in ] speed: 初始速度，单位: 像素/s。

**def initLaneConnector(self, laneNumber: int, toLaneNumber: int, dist: float = -1, speed: float = -1, unit: UnitOfMeasure = UnitOfMeasure: : Default) -> None**

​	在连接段上初始化车辆。单位：像素。

参数: 

​	[ in ] laneNumber: 起始车道序号。

​	[ in ] toLaneNumber: 目标车道序号。

​	[ in ] dist: 距起点距离，单位: 像素。

​	[ in ] speed: 初始速度，单位: 像素/s。

**def setVehiType(self, code: int) -> None**

​	设置车辆类型，车辆被创建时已确定了类型，通过此方法可以改变车辆类型。

参数: 

​	[ in ] code: 车辆类型编码。

**def setColor(self, color: str) -> None**

​	设置车辆颜色。

参数: 

​	[ in ] color: 颜色RGB，如: "#EE0000"。

示例：

```python
# 设置车辆颜色为蓝色
vehicle.setColor("#00AFF0")
```

**def length(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取车辆长度。单位：像素。

**def setLength(self, len: float, bRestWidth: bool, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置车辆长度。单位：像素。

参数: 

​	[ in ] len: 长度值，单位: 像素或米(取决于unit参数)。

​	[ in ] bRestWidth: 是否同比例约束宽度。

**def laneId(self) -> int**

​	如果toLaneId() 小于等于0，那么laneId()获取的是当前所在车道ID，如果toLaneId()大于0，则车辆在车道连接上，laneId()获取的是上游车道ID。

**def toLaneId(self) -> int**

​	下游车道ID。如果小于等于0，车辆在路段的车道上，否则车辆在连接段的车道连接上。

**def lane(self) -> Tessng.ILane**

​	获取当前车道，如果车辆在车道连接上，获取的是车道连接的上游车道。

**def toLane(self) -> Tessng.ILane**

​	如果车辆在车道连接上，返回车道连接的下游车道，如果当前不在车道连接上，返回None。

**def laneConnector(self) -> Tessng.ILaneConnector**

​	获取当前车道连接，如果在车道上，返回None。

**def currBatchNumber(self) -> int**

​	当前仿真计算批次。

**def roadType(self) -> int**

​	车辆所在道路类型。GLinkType代表路段、GConnectorType代表连接段。

**def limitMaxSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取最大限速，单位: 像素/s。

**def limitMinSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取最小限速，单位: 像素/s。

**def vehicleTypeCode(self) -> int**

​	车辆类型编码。

**def vehicleTypeName(self) -> str**

​	获取车辆类型名，如"小客车"。

**def name(self) -> str**

​	获取车辆名称。

**def vehicleDriving(self) -> Tessng.IVehicleDriving**

​	获取车辆驾驶行为接口。

**def driving(self) -> None**

​	驱动车辆。在每个运算周期，每个在运行的车辆被调用一次该方法。

**def pos(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	获取当前位置。单位：像素。

**def zValue(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取当前高程。单位：像素。

**def acce(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取当前加速度。单位：像素。

**def currSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取当前速度，单位: 像素/s。

**def angle(self) -> float**

​	当前角度，北向0度顺时针。

**def isStarted(self) -> bool**

​	是否在运行，如果返回False，表明车辆已驰出路网或尚未上路。

**def vehicleFront(self) -> Tessng.IVehicle**

​	前车对象。

**def vehicleRear(self) -> Tessng.IVehicle**

​	后车对象。

**def vehicleLFront(self) -> Tessng.IVehicle**

​	左前车对象。

**def vehicleLRear(self) -> Tessng.IVehicle**

​	左后车对象。

**def vehicleRFront(self) -> Tessng.IVehicle**

​	右前车对象。

**def vehicleRRear(self) -> Tessng.IVehicle**

​	右后车对象。

**def vehiDistFront(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取与前车距离。单位：像素。

**def vehiSpeedFront(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取前车速度，单位: 像素/s。

**def vehiHeadwayFront(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取与前车时距，单位: 秒。

**def vehiDistRear(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取与后车距离。单位：像素。

**def vehiSpeedRear(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取后车速度，单位: 像素/s。

**def vehiHeadwaytoRear(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取与后车时距，单位: 秒。

**def vehiDistLLaneFront(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取与左前车距离。单位：像素。

**def vehiSpeedLLaneFront(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取左前车速度。单位：像素。

**def vehiDistLLaneRear(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取与左后车距离。单位：像素。

**def vehiSpeedLLaneRear(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取左后车速度。单位：像素。

**def vehiDistRLaneFront(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取与右前车距离。单位：像素。

**def vehiSpeedRLaneFront(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取右前车速度。单位：像素。

**def vehiDistRLaneRear(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取与右后车距离。单位：像素。

**def vehiSpeedRLaneRear(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取右后车速度。单位：像素。

**def setDynaInfo(self, pDynaInfo: None) -> None**

​	设置动态信息。

**def dynaInfo(self) -> None**

​	获取动态信息。

**def lLaneObjectVertex(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

​	获取车道或车道连接中心线内点集。单位：像素。

**def routing(self) -> Tessng.IRouting**

​	当前路径。

**def picture(self) -> PySide2.QtGui.QPicture**

​	获取车辆图片。

**def boundingPolygon(self) -> PySide2.QtGui.QPolygonF**

​	获取车辆由方向和长度决定的四个拐角构成的多边型。

**def setTag(self, tag: int) -> None**

​	设置标签表示的状态。

**def tag(self) -> int**

​	获取标签表示的状态。

**def setTextTag(self, text: str) -> None**

​	设置文本信息，用于在运行过程保存临时信息，方便开发。

**def textTag(self) -> str**

​	文本信息，运行过程临时保存的信息，方便开发。

**def setJsonInfo(self, info: dict) -> None**

​	设置json格式数据。

**def jsonInfo(self) -> dict**

​	返回json格式数据。

**def jsonProperty(self, propName: str) -> any**

​	返回json字段值。

**def setJsonProperty(self, key: str, value: any) -> None**

​	设置json数据属性。

#### 3.4.13.2.车辆驾驶行为（IVehicleDriving）

​	车辆驾驶行为接口，通过此接口可以控制车辆的左右变道、设置车辆角度，对车辆速度、坐标位置等进行控制等。**在获取车辆对象 `vehicle` 后，通过`vehicle.vehicleDriving().xxx()` 的方式调用。**

**def vehicle(self) -> Tessng.IVehicle**

​	当前驾驶车辆。

**def getRandomNumber(self) -> int**

​	获取随机数。

**def nextPoint(self) -> bool**

​	计算下一点位置，过程包括计算车辆邻车关系、公交车是否进站是否出站、是否变道、加速度、车速、移动距离、跟驰类型、轨迹类型等。

**def zeroSpeedInterval(self) -> int**

​	当前车速为零持续时间。单位：ms。

**def isHavingDeciPointOnLink(self) -> bool**

​	当前是否在路段上且有决策点。

**def followingType(self) -> int**

​	跟驰车辆的类型，即当前车辆前车的类型，分为: 0: 停车，1: 正常，5: 急减速，6: 急加速，7: 汇入，8: 穿越，9: 协作减速，10: 协作加速，11: 减速待转，12: 加速待转。

**def isOnRouting(self) -> bool**

​	当前是否在路径上。

**def stopVehicle(self) -> None**

​	停止运行，将车辆移出路网。

**def angle(self) -> float**

​	旋转角。单位：角度。北向0度，顺时针。

**def setAngle(self, angle: float) -> None**

​	设置车辆旋转角。

参数: 

​	[ in ] angle: 旋转角，一周360度。

**def euler(self, bPositive: bool = False) -> PySide2.QtGui.QVector3D**

​	返回车辆欧拉角。

参数: 

​	[ in ] bPositive: 车头方向是否正向计算，如果bPosiDire为False则反向计算。

**def desirSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取期望速度，单位: 像素/s。

**def getCurrRoad(self) -> Tessng.ISection**

​	返回当前所在路段或连接段。

**def getNextRoad(self) -> Tessng.ISection**

​	下一路段或连接段。

**def differToTargetLaneNumber(self) -> int**

​	与目标车道序号的差值，不等于0表示有强制变道意图，大于0有左变道意图，小于0有右变道意图，绝对值大于0表示需要强制变道次数。

**def toLeftLane(self, bFource: bool = False) -> None**

​	左变道。

参数: 

​	[ in ] bFource: 是否强制変道，默认为False。

示例：

```python
# 控制车辆向左变道
vehicle.vehicleDriving().toLeftLane()
```

**def toRightLane(self, bFource: bool = False) -> None**

​	右变道。

参数: 

​	[ in ] bFource: 是否强制変道，默认为False。

示例：

```python
# 控制车辆向右变道
vehicle.vehicleDriving().toRightLane()
```

**def laneNumber(self) -> int**

​	当前车道序号，最右侧序号为0。

**def initTrace(self) -> None**

​	初始化轨迹。

**def setTrace(self, lPoint: list[PySide2.QtCore.QPointF], unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置轨迹点集。单位：像素。

参数: 

​	[ in ] lPoint: 轨迹点坐标集合。

**def calcTraceLength(self) -> None**

​	计算轨迹长度。

**def tracingType(self) -> int**

​	返回轨迹类型，分为: 0: 跟驰，1: 左变道，2: 右变道，3: 左虚拟変道，4: 右虚拟变道，5: 左转待转，6: 右转待转，7: 入湾，8: 出湾。

**def setTracingType(self, type: int) -> None**

​	设置轨迹类型。

**def setLaneNumber(self, number: int) -> None**

​	设置当前车道序号。

参数: 

​	[ in ] number: 车道序号。

**def currDistanceInRoad(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取当前路段或连接段已行驶距离。单位：像素。

**def setCurrDistanceInRoad(self, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置当前路段或连接段已行驶距离。单位：像素。

参数: 

​	[ in ] dist: 距离。

**def setVehiDrivDistance(self, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置已行驶总里程。单位：像素。

参数: 

​	[ in ] dist: 总里程。

**def getVehiDrivDistance(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取已行驶总里程。单位：像素。

**def currDistanceInSegment(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取当前分段已行驶距离。单位：像素。

**def setCurrDistanceInSegment(self, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置当前分段已行驶距离。单位：像素。

参数: 

​	[ in ] dist: 距离。

**def setSegmentIndex(self, index: int) -> None**

​	设置分段序号。

**def setCurrDistanceInTrace(self, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置曲化轨迹上行驶的距离。单位：像素。

参数: 

​	[ in ] dist: 距离。

**def setX(self, posX: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置横坐标。单位：像素。

参数: 

​	[ in ] posX: 横坐标。

**def setY(self, posY: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置纵坐标。单位：像素。

参数: 

​	[ in ] posY: 纵坐标。

**def setV3z(self, v3z: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	设置高程坐标。单位：像素。

参数: 

​	[ in ] v3z: 高程坐标。

**def changingTrace(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

​	获取变轨点集。单位：像素。

**def changingTraceLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	获取变轨长度。单位：像素。

**def distToStartPoint(self, fromVehiHead: bool = False, bOnCentLine: bool = True, unit: UnitOfMeasure = UnitOfMeasure: : Default) -> float**

​	获取在车道或车道连接上到起点距离。单位：像素。

参数: 

​	[ in ] fromVehiHead: 是否从车头计算。

​	[ in ] bOnCentLine: 当前是否在中心线上。

**def distToEndpoint(self, fromVehiHead: bool = False, bOnCentLine: bool = True, unit: UnitOfMeasure = UnitOfMeasure: : Default) -> float**

​	获取在车道或车道连接上到终端距离。单位：像素。

参数: 

​	[ in ] fromVehiHead: 是否从车头计算。

​	[ in ] bOnCentLine: 当前是否在中心线上。

**def setRouting(self, pRouting: Tessng.IRouting) -> bool**

​	设置路径，外界设置的路径不一定有决策点，可能是临时创建的，如果车辆不在此路径上则设置不成功并返回False。

示例：

```python
# 1. 使用现有的决策点的车辆路径
routing1 = self.netiface.findRouting(1)
vehicle.vehicleDriving().setRouting(routing1)

# 2. 创建不与决策点绑定的车辆路径
link_id_list = [8, 16, 25]
link_list = [self.netiface.findLink(link_id) for link_id in link_id_list]
routing2 = self.netiface.createRouting(link_list)
vehicle.vehicleDriving().setRouting(routing2)
```

**def routing(self) -> Tessng.IRouting**

​	当前路径。

**def moveToLane(self, pLane: Tessng.ILane, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

​	将车辆移到另一条车道上。单位：像素。

参数: 

​	[ in ] pLane: 目标车道。

​	[ in ] dist: 到目标车道起点距离。

**def moveToLaneConnector(self, pLaneConnector: Tessng.ILaneConnector, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

​	将车辆移到另一条车道连接上。单位：像素。

参数: 

​	[ in ] pLaneConnector: 目标车道连接。

​	[ in ] dist: 到目标车道连接起点距离。

**def move(self, pILaneObject: Tessng.ILaneObject, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

​	移动车辆到另一条车道或车道连接上。单位：像素。

参数: 

​	[ in ] pILaneObject: 目标车道或车道连接。

​	[ in ] dist: 到目标起点距离。

示例：

```python
from tessng import UnitOfMeasure

# 获取车道对象
lane = self.netiface.findLane(6)
# 位置，单位：m
dist = 50
# 移动车辆到指定车道和位置上，实现车辆位置的瞬移
vehicle.vehicleDriving().move(lane, dist, UnitOfMeasure.Metric)
```

#### 3.4.13.3.行人（IPedestrian）

**def getId(self) -> int**

​	获取行人ID。

**def getRadius(self) -> float**

​	获取行人半径，单位: m。

**def getWeight(self) -> float**

​	获取行人质量，单位: kg。

**def getColor(self) -> str**

​	获取行人颜色，RGB格式，如: "#EE0000"。

**def getPos(self) -> PySide2.QtCore.QPointF**

​	获取行人当前位置，单位: m。

**def getAngle(self) -> float**

​	获取行人当前角度，Qt坐标系下，x轴正方向为0，逆时针为正。

**def getDirection(self) -> PySide2.QtGui.QVector2D**

​	获取行人当前二维方向向量。

**def getElevation(self) -> float**

​	获取行人当前高程，单位: m。

**def getSpeed(self) -> PySide2.QtGui.QVector2D**

​	获取行人当前速度，单位: m/s。

**def getDesiredSpeed(self) -> float**

​	获取行人期望速度，单位: m/s。

**def getMaxSpeed(self) -> float**

​	获取行人最大速度限制，单位: m/s。

**def getAcce(self) -> PySide2.QtGui.QVector2D**

​	获取行人当前加速度，单位: m/s²。

**def getMaxAcce(self) -> float**

​	获取行人最大加速度限制，单位: m/s²。

**def getEuler(self) -> PySide2.QtGui.QVector3D**

​	获取行人欧拉角。

**def getSpeedEuler(self) -> PySide2.QtGui.QVector3D**

​	获取行人速度欧拉角。

**def getWallFDirection(self) -> PySide2.QtGui.QVector2D**

​	获取墙壁方向单位向量。

**def getRegion(self) -> Tessng.IPedestrianRegion**

​	获取行人当前所在面域。

**def getPedestrianTypeId(self) -> int**

​	获取行人类型ID。

**def stop(self) -> None**

​	停止仿真，会在下一个仿真批次移除当前行人，释放资源。

<div style="page-break-after: always;"></div>

# 4.高频接口

​	本节提供 TESS NG 二次开发经常使用的接口代码案例。



## 4.1.路网建模

### 4.1.1.创建路段和连接段

​	创建路段和连接段的代码如下。**此外，开源路网编辑工具 pytessng （使用TESS NG Python 二次开发实现）支持支持导入 OpenDrive、shape、OpenStreetMap 等格式的数据来创建路网，具体使用方法可参考 [pytessng · PyPI](https://pypi.org/project/pytessng/)。**

```python
from PySide2.QtCore import QPointF
from tessng import UnitOfMeasure

# ==================== 创建路段 ====================
# 创建第一条路段：曹安公路
start_point = QPointF(-300, 0)
end_point = QPointF(300, 0)
link_points = [start_point, end_point]
link1 = self.netiface.createLink(link_points, 7, "曹安公路", True, UnitOfMeasure.Metric)
if link1 is not None:
    # 车道列表
    lanes = link1.lanes()
    # 打印该路段所有车道ID
    print("曹安公路车道ID列表：", [lane.id() for lane in lanes])
    # 在当前路段创建发车点
    dp = self.netiface.createDispatchPoint(link1)
    if dp is not None:
        # 设置发车间隔，含车型组成、时间间隔、发车数
        dp.addDispatchInterval(1, 2, 28)

# 创建第二条路段
start_point = QPointF(-300, -25)
end_point = QPointF(300, -25)
link_points = [start_point, end_point]
link2 = self.netiface.createLink(link_points, 7, "次干道", True, UnitOfMeasure.Metric)
if link2 is not None:
    # 在当前路段创建发车点
    dp = self.netiface.createDispatchPoint(link2)
    if dp is not None:
        # 设置发车间隔，含车型组成、时间间隔、发车数
        dp.addDispatchInterval(1, 3600, 3600)
    # 将外侧车道设为公交专用道
    lanes = link2.lanes()
    lane = lanes[0]
    lane.setLaneType("公交专用道")

# 创建第三条路段
start_point = QPointF(-300, 25)
end_point = QPointF(-150, 25)
link_points = [start_point, end_point]
link3 = self.netiface.createLink(link_points, 3, "link3", True, UnitOfMeasure.Metric)
if link3 is not None:
    # 在当前路段创建发车点
    dp = self.netiface.createDispatchPoint(link3)
    if dp is not None:
        # 设置发车间隔，含车型组成、时间间隔、发车数
        dp.addDispatchInterval(1, 3600, 3600)

# 创建第四条路段
start_point = QPointF(-50, 25)
end_point = QPointF(50, 25)
link_points = [start_point, end_point]
link4 = self.netiface.createLink(link_points, 3, "link4", True, UnitOfMeasure.Metric)

# 创建第五条路段
start_point = QPointF(150, 25)
end_point = QPointF(300, 25)
link_points = [start_point, end_point]
link5 = self.netiface.createLink(link_points, 3, "自定义限速路段", True, UnitOfMeasure.Metric)
if link5 is not None:
    # 设置路段限速，单位：km/h
    link5.setLimitSpeed(30)

# 创建第六条路段
start_point = QPointF(-300, 50)
end_point = QPointF(300, 50)
link_points = [start_point, end_point]
link6 = self.netiface.createLink(link_points, 3, "动态发车路段", True, UnitOfMeasure.Metric)
if link6 is not None:
    # 设置路段限速，单位：km/h
    link6.setLimitSpeed(80)

# 创建第七条路段
start_point = QPointF(-300, 75)
end_point = QPointF(-250, 75)
link_points = [start_point, end_point]
link7 = self.netiface.createLink(link_points, 3, "link7", True, UnitOfMeasure.Metric)
if link7 is not None:
    # 设置路段限速，单位：km/h
    link7.setLimitSpeed(80)

# 创建第八条路段
start_point = QPointF(-50, 75)
end_point = QPointF(300, 75)
link_points = [start_point, end_point]
link8 = self.netiface.createLink(link_points, 3, "link8", True, UnitOfMeasure.Metric)
if link8 is not None:
    # 设置路段限速，单位：km/h
    link8.setLimitSpeed(80)

# ==================== 创建连接段 ====================
# 创建第一条连接段，连接link3和link4
if link3 is not None and link4 is not None:
    from_lane_numbers = [1, 2, 3]
    to_lane_numbers = [1, 2, 3]
    connector1 = self.netiface.createConnector(link3.id(), link4.id(), from_lane_numbers, to_lane_numbers, "连接段1", True)

# 创建第二条连接段，连接link4和link5
if link4 is not None and link5 is not None:
    from_lane_numbers = [1, 2, 3]
    to_lane_numbers = [1, 2, 3]
    connector2 = self.netiface.createConnector(link4.id(), link5.id(), from_lane_numbers, to_lane_numbers, "连接段2", True)

# 创建第三条连接段，连接link7和link8
if link7 is not None and link8 is not None:
    from_lane_numbers = [1, 2, 3]
    to_lane_numbers = [1, 2, 3]
    connector3 = self.netiface.createConnector(link7.id(), link8.id(), from_lane_numbers, to_lane_numbers, "动态发车连接段", True)
```

### 4.1.2.创建各类采集设备

​	各类采集设备包括：数据采集器、排队计数器和行程时间检测器。创建它们的代码如下。

```python
# ==================== 创建数据采集器 ====================
# 获取车道对象
lane = self.netiface.findLane(1)
# 位置，单位：m
dist = 50
# 在路段上创建数据采集器
collector = self.netiface.createVehiCollectorOnLink(lane, dist, UnitOfMeasure.Metric)

# 获取车道连接对象
lane_connector = self.netiface.findLaneConnector(1, 4)
# 位置，单位：m
dist = 50
# 在连接段上创建数据采集器
collector = self.netiface.createVehiCollectorOnConnector(lane_connector, dist, UnitOfMeasure.Metric)

# ==================== 创建排队计数器 ====================
# 获取车道对象
lane = self.netiface.findLane(1)
# 位置，单位：m
dist = 80
# 在路段上创建排队计数器
counter = self.netiface.createVehiQueueCounterOnLink(lane, dist, UnitOfMeasure.Metric)

# 获取车道连接对象
lane_connector = self.netiface.findLaneConnector(1, 4)
# 位置，单位：m
dist = 80
# 在连接段上创建排队计数器
counter = self.netiface.createVehiQueueCounterOnConnector(lane_connector, dist, UnitOfMeasure.Metric)

# ==================== 创建排队时间检测器 ====================
# 获取起始路段对象
start_link = self.netiface.findLink(1)
# 获取终止路段对象
end_link = self.netiface.findLink(2)
# 检测器起点在起始路段的位置，单位：m
start_dist = 10
# 检测器终点在终止路段的位置，单位：m
end_dist = 90
# 创建起点在路段、终点也在路段的行程时间检测器
detectors = self.netiface.createVehicleTravelDetector_link2link(start_link, end_link, start_dist, end_dist, UnitOfMeasure.Metric)

# 获取起始路段对象
start_link = self.netiface.findLink(1)
# 获取终止车道连接对象
end_lane_connector = self.netiface.findLaneConnector(1, 4)
# 检测器起点在起始路段的位置，单位：m
start_dist = 10
# 检测器终点在终止车道连接的位置，单位：m
end_dist = 10
# 创建起点在路段、终点在连接段的行程时间检测器
detectors = self.netiface.createVehicleTravelDetector_link2conn(start_link, end_lane_connector, start_dist, end_dist, UnitOfMeasure.Metric)

# 获取起始车道连接对象
start_lane_connector = self.netiface.findLaneConnector(1, 4)
# 获取终止路段对象
end_link = self.netiface.findLink(2)
# 检测器起点在起始车道连接的位置，单位：m
start_dist = 10
# 检测器终点在终止路段的位置，单位：m
end_dist = 90
# 创建起点在连接段、终点在路段的行程时间检测器
detectors = self.netiface.createVehicleTravelDetector_conn2link(start_lane_connector, end_link, start_dist, end_dist, UnitOfMeasure.Metric)

# 获取起始车道连接对象
start_lane_connector = self.netiface.findLaneConnector(1, 4)
# 获取终止路段对象
end_lane_connector = self.netiface.findLaneConnector(4, 7)
# 检测器起点在起始车道连接的位置，单位：m
start_dist = 10
# 检测器终点在终止车道连接的位置，单位：m
end_dist = 90
# 创建起点在连接段、终点也在连接段的行程时间检测器
detectors = self.netiface.createVehicleTravelDetector_conn2conn(start_lane_connector, end_lane_connector, start_dist, end_dist, UnitOfMeasure.Metric)
```

### 4.1.3.创建导向箭头

​	创建导向箭头的代码如下。

```python
from tessng import Online, UnitOfMeasure

lane = self.netiface.findLane(4)
if lane is not None:
    length = 4
    dist_to_terminal = 10
    arrow_type = Online.GuideArrowType.StraightRight
    guid_arrow = self.netiface.createGuidArrow(lane, length, dist_to_terminal, arrow_type, UnitOfMeasure.Metric)
```

### 4.1.4.创建公交站点和线路

​	创建公交站点和公交线路的代码如下。

```python
# 创建公交站点
lane = self.netiface.findLane(1)
bus_station = self.netiface.createBusStation(lane, 30, 50, "公交站1", UnitOfMeasure.Metric)
# 设置站点类型 1：路边式、2：港湾式
bus_station.setType(1)

# 创建公交线路
link1 = self.netiface.findLink(1)
link2 = self.netiface.findLink(2)
bus_line = self.netiface.createBusLine([link1, link2])

# 关联公交线路和公交站点
result = self.netiface.addBusStationToLine(bus_line, bus_station)
# 关联成功
if result:
    # 获取公交线路上的所有公交站点
    station_line_list = bus_line.stationLines()
    # 获取第一个公交站点
    station_line = station_line_list[0]
    # 设置车辆停靠时间，单位：s
    station_line.setBusParkingTime(20)
```

### 4.1.5.创建各类事件区域

​	各类事件区域包括：事故区、施工区、限行区和改扩建借道。创建它们的代码如下。

```python
from tessng import Online, UnitOfMeasure

# ==================== 创建事故区 ====================
# 构建参数
param = Online.DynaAccidentZoneParam()
# 事故区名称
param.name = "事故区"
# 道路ID
param.roadId = 1
# 位置, 距离路段或连接段起点距离, 单位：m
param.location = 100
# 长度, 单位：m
param.length = 50
# 车道序号列表，从0开始，连续有序
param.mlFromLaneNumber = [0]
# 开始时间，单位：s
param.startTime= 10
# 持续时间，单位：s
param.duration = 600
# 相邻车道限速，单位：km/h
param.limitSpeed = 40
# 创建事故区
accident_zone = self.netiface.createAccidentZone(param, UnitOfMeasure.Metric)

# ==================== 创建施工区 ====================
# 构建参数
param = Online.DynaRoadWorkZoneParam()
# 施工区名称
param.name= "施工区"
# 道路ID
param.roadId = 1
# 位置, 距离路段或连接段起点距离, 单位：m
param.location = 200
# 长度, 单位：m
param.length = 50  # 长度
param.upCautionLength = 70  # 提前警示长度
param.upTransitionLength = 50  # 过渡区长度
param.upBufferLength = 50  # 缓冲区长度
param.downTransitionLength = 40  # 下游过渡区长度
param.downTerminationLength = 40  # 终止区长度
# 车道序号列表，从0开始，连续有序
param.mlFromLaneNumber = [0]
# 开始时间，单位：s
param.startTime = 0
# 持续时间，单位：s
param.duration = 3600
# 相邻车道限速，单位：km/h
param.limitSpeed = 40
# 创建施工区
road_work_zone = self.netiface.createRoadWorkZone(param, UnitOfMeasure.Metric)

# ==================== 创建限行区 ====================
# 构建参数
param = Online.DynaLimitedZoneParam()
# 限行区名称
param.name = "限行区"
# 道路ID
param.roadId = 1
# 位置, 距离路段或连接段起点距离, 单位：m
param.location = 100
# 长度, 单位：m
param.length = 50
# 车道序号列表，从0开始，连续有序
param.mlFromLaneNumber = [0]
# 开始时间，单位：s
param.startTime = 0
# 持续时间，单位：s
param.duration = 600
# 相邻车道限速，单位：km/h
param.limitSpeed = 40
# 创建限行区
limited_zone = self.netiface.createLimitedZone(param, UnitOfMeasure.Metric)

# ==================== 创建改扩建借道 ====================
# 构建参数
param = Online.DynaReconstructionParam()
# 施工区ID
param.roadWorkZoneId = rwz_id
# 被借道的路段ID
param.beBorrowedLinkId = 2
# 被借道的车道数量
param.borrowedNum = 1
# 保通开口长度，单位：m
param.passagewayLength = 80
# 保通开口限速，单位：m/s
param.passagewayLimitedSpeed = 40 / 3.6
# 创建改扩建借道
reconstruction = self.netiface.createReconstruction(param, UnitOfMeasure.Metric)
```



## 4.2.需求建模

### 4.2.1.设置发车

​	设置发车可在**仿真前通过发车点批量配置**，也可在**仿真过程中动态创建单车**。

​	（1）在仿真开启前，创建车型、车辆组成和发车点及发车流量的代码如下。

```python
from tessng import _VehicleType

# ==================== 创建车型 ====================
# 构建参数
vehicle_type = _VehicleType()
vehicle_type.vehicleTypeName = "新建车型1"  # 车型名称
vehicle_type.Length = 4.5  # 长度，单位：m
vehicle_type.lengthSD = 0.5  # 长度标准差，单位：m
vehicle_type.width = 2  # 宽度，单位：m
vehicle_type.widthSD = 0.2  # 宽度标准差，单位：m
vehicle_type.avgSpeed = 60  # 期望速度，单位：km/h
vehicle_type.speedSD = 10  # 期望速度标准差，单位：km/h
vehicle_type.avgAcce = 4  # 期望加速度，单位：m/s²
vehicle_type.acceSD = 0.5  # 期望加速度标准差，单位：m/s²
vehicle_type.avgDece = 6  # 期望减速度，单位：m/s²
vehicle_type.deceSD = 0.5  # 期望减速度标准差，单位：m/s²
vehicle_type.maxAcce = 5.5  # 最大加速度，单位：m/s²
vehicle_type.maxDece = 7.5  # 最大减速度，单位：m/s²
vehicle_type.maxSpeed = 80  # 最大速度，单位：km/h
vehicle_type.commercialVehicle = False  # 是否是营运车辆
vehicle_type.maxPassengerCapacity = 1  # 核载人数，单位：人
# 创建车型
result = self.netiface.createVehicleType(vehicle_type)
print(f"创建车型是否成功：{result}")

# ==================== 创建车辆组成 ====================
# 构建车辆类型比例列表
vehi_type_proportion_list = [
    Online.VehiComposition(1, 0.3),  # 小客车，占比0.3
    Online.VehiComposition(2, 0.2),  # 大客车，占比0.2
    Online.VehiComposition(3, 0.1),  # 公交车，占比0.1
    Online.VehiComposition(4, 0.4)   # 货车，占比0.4
]
# 创建车辆组成
vehi_composition_id = self.netiface.createVehicleComposition("动态创建车型组成", vehi_type_proportion_list)

# ==================== 创建发车点 ====================
# 获取路段对象
link = self.netiface.findLink(1)
# 创建发车点
dp = self.netiface.createDispatchPoint(link)
if dp is not None:
    # 添加发车间隔，含车型组成、时间间隔、发车数
    dp.addDispatchInterval(1, 600, 300)
    dp.addDispatchInterval(1, 600, 400)
```

​	（2）在仿真过程中，不使用发车点，在指定位置创建单车的代码如下。

```python
from tessng import m2p

# ==================== 在路段上创建车辆 ====================
# 构建参数
dvp1 = Online.DynaVehiParam()
# 车型ID
dvp1.vehiTypeCode = 1
# 路段ID
dvp1.roadId = 4
# 车道序号
dvp1.laneNumber = 0
# 位置，单位：m
dvp1.dist = m2p(50)
# 速度，单位：m/s
dvp1.speed = m2p(20)
# 颜色
dvp1.color = "#00AFF0"
# 动态创建车辆
vehicle1 = self.simuiface.createGVehicle(dvp)
if vehicle1:
    print(f"在路段上创建了车辆，其ID为：{vehicle1.id()}"")

# ==================== 在连接段上创建车辆 ====================
# 构建参数
dvp2 = Online.DynaVehiParam()
# 车型ID
dvp2.vehiTypeCode = 1
# 连接段ID
dvp2.roadId = 4
# 上游路段的车道序号
dvp2.laneNumber = 0
# 下游路段的车道序号
dvp2.toLaneNumber = 0
# 位置，单位：m
dvp2.dist = m2p(10)
# 速度，单位：m/s
dvp2.speed = m2p(20)
# 颜色
dvp2.color = "#00AFF0"
# 动态创建车辆
vehicle2 = self.simuiface.createGVehicle(dvp2)
if vehicle2:
    print(f"在连接段上创建了车辆，其ID为：{vehicle2.id()}"")
```

### 4.2.2.设置路径

​	设置路径可在**仿真开启前或仿真过程中基于决策点进行流量比例分配**，也可**直接为单个车辆指定行驶路线**。	

​	（1）在仿真开启前，创建决策点，并更新其路径和路径流量比例的代码如下。

```python
from tessng import _RoutingFLowRatio, _DecisionPoint

# ============================== 创建决策点 ==============================
link = self.netiface.findLink(1)
location = 50
decision_point_name = "新建决策点"
decision_point = self.netiface.createDecisionPoint(link, location, decision_point_name, UnitOfMeasure.Metric)

# ==================== 创建决策点的车辆路径 ====================
# 路段ID列表
link_id_list_1 = [1, 2]
link_id_list_2 = [1, 3]
link_id_list_3 = [1, 4]

# 构建路段对象列表
link_list_1 = [self.netiface.findLink(link_id) for link_id in link_id_list_1]
link_list_2 = [self.netiface.findLink(link_id) for link_id in link_id_list_2]
link_list_3 = [self.netiface.findLink(link_id) for link_id in link_id_list_3]

# 创建决策点的车辆路径
routing1 = self.netiface.createDeciRouting(decision_point, link_list_1)
routing2 = self.netiface.createDeciRouting(decision_point, link_list_2)
routing3 = self.netiface.createDeciRouting(decision_point, link_list_3)

# ==================== 更新决策点路径流量比配置 ====================
# 初始化左、直、右流量比对象
flowRatio_left = _RoutingFLowRatio()
flowRatio_left.RoutingFLowRatioID = 1
flowRatio_left.routingID = decisionRouting1.id()
flowRatio_left.startDateTime = 0
flowRatio_left.endDateTime = 999999
flowRatio_left.ratio = 2.0

flowRatio_straight = _RoutingFLowRatio()
flowRatio_straight.RoutingFLowRatioID = 2
flowRatio_straight.routingID = decisionRouting2.id()
flowRatio_straight.startDateTime = 0
flowRatio_straight.endDateTime = 999999
flowRatio_straight.ratio = 3.0

flowRatio_right = _RoutingFLowRatio()
flowRatio_right.RoutingFLowRatioID = 3
flowRatio_right.routingID = decisionRouting3.id()
flowRatio_right.startDateTime = 0
flowRatio_right.endDateTime = 999999
flowRatio_right.ratio = 1.0

# 初始化决策点数据
decision_point_data = _DecisionPoint()
decision_point_data.deciPointID = decision_point.id()
decision_point_data.deciPointName = decision_point.name()
decisionPoint_pos = QPointF()
if decisionPoint.link().getPointByDist(decision_point.distance(), decisionPoint_pos): 
    decision_point_data.X = decisionPoint_pos.x()
    decision_point_data.Y = decisionPoint_pos.y()
    decision_point_data.Z = decision_point.link().z()

# 构造流量比列表
flow_ratio_list = [flowRatio_left, flowRatio_straight, flowRatio_right]
# 更新决策点路径流量比配置
updated_decision_point = self.netiface.updateDecipointPoint(decision_point_data, flow_ratio_list)
```

​	（2）在仿真过程中，动态修改已有决策点的路径流量比例代码如下。

```python
# MySimulator.py

def calcDynaFlowRatioParameters(self) -> list:
    # 当前仿真计算批次
    batch_number = self.simuiface.batchNumber()
    # 在计算第20批次时修改某决策点各路径流量比
    if batch_number == 20:
        # 一个决策点某个时段各路径车辆分配比
        dfi = Online.DecipointFlowRatioByInterval()
        # 决策点编号
        dfi.deciPointID = 5
        # 起始时间 单位：秒
        dfi.startDateTime = 1
        # 结束时间 单位：秒
        dfi.endDateTime = 999999
        # 路径流量比
        rfr1 = Online.RoutingFlowRatio(1, 3)
        rfr2 = Online.RoutingFlowRatio(2, 4)
        rfr3 = Online.RoutingFlowRatio(3, 3)
        dfi.mlRoutingFlowRatio = [rfr1, rfr2, rfr3]
        return [dfi]
    return []
```

​	（3）在仿真过程中，给车辆设置路径的代码如下。

```python
# 1. 使用现有的决策点的车辆路径
routing1 = self.netiface.findRouting(1)
vehicle.vehicleDriving().setRouting(routing1)

# 2. 创建不与决策点绑定的车辆路径
link_id_list = [8, 16, 25]
link_list = [self.netiface.findLink(link_id) for link_id in link_id_list]
routing2 = self.netiface.createRouting(link_list)
vehicle.vehicleDriving().setRouting(routing2)
```




## 4.3.信号控制

### 4.3.1.创建信号机、信控方案、信号灯相位和信号灯

​	在仿真开启前，可以依次创建信号机、信控方案、信号灯相位、信号灯，创建过程中同步建立了绑定关系：**信号灯→信号灯相位→信控方案→信号机**，代码如下。

```python
from tessng import Online

# ==================== 创建信号机（通常一个交叉口对应一个信号机） ====================
# 信号机名称
signal_controller_name = "双龙大道-吉印大道交叉口"
# 创建信号机
signal_controller = self.netiface.createSignalController(signal_controller_name)

# ==================== 创建信控方案（一个信号机在不同时段可配置多个信控方案） ====================
# 获取信号机对象
signal_controller = self.netiface.findSignalControllerById(1)
# 信控方案名称
signal_plan_name = "平峰方案"
# 周期时长，单位：s
cycle_time = 120
# 相位差，单位：s
phase_difference = 0
# 起始时间，单位：s
start_time = 0
# 结束时间，单位：s
end_time = 3600
# 创建信控方案
signal_plan = self.netiface.createSignalPlan(signal_controller, signal_plan_name, cycle_time, phase_difference, start_time, end_time)

# ==================== 创建信号灯相位（一个信控方案需为不同方向/转向分配相位） ====================
# 获取信控相位对象
signal_plan = self.netiface.findSignalPlanById(1)
# 相位名称
signal_phase_name = "东西直行"
# 构建灯色对象列表
color = ["R", "G", "Y", "R"]
intervals = [30, 26, 3, 61]
color_interval_list = [
    Online.ColorInterval(color, duration)
    for color, duration in zip(colors, durations)
]
# 创建信号灯相位
signal_phase = self.netiface.createSignalPlanSignalPhase(signal_plan, signal_phase_name, color_interval_list)

# ==================== 创建信号灯（一个相位控制多条车道的信号灯） ====================
# 获取相位对象
signal_phase = self.netiface.findSignalPhase(1)
# 信号灯名称
signal_lamp_name = "东直1"
# 车道ID
lane_id = 1
# 下游车道ID
to_lane_id = -1
# 位置，单位：m
distance = m2p(50)
# 创建信号灯
signal_lamp = self.netiface.createSignalLamp(signal_plan, signal_lamp_name, lane_id, to_lane_id, distance)
```

### 4.3.2.控制信号灯灯色

​	可以按**信控相位**或**单个信号灯**两种粒度修改灯色设置。

​	（1）在仿真开启前或仿真过程中，按信控相位修改灯色与时长的代码如下。

```python
from tessng import Online

# 构建灯色和时长对象列表
color_obj_list = [
    Online.ColorInterval("R", 10),  # 红色，时长10
    Online.ColorInterval("G", 60),  # 绿色，时长60
    Online.ColorInterval("Y", 3),  # 黄色，时长3
    Online.ColorInterval("R", 17)  # 红色，时长17
]
# 查找ID为7的信号灯相位
signal_phase = netiface.findSignalPhase(7)
if signal_phase:
    # 设置灯色列表
	signal_phase.setColorList(color_list)
```

​	在路网中已完成信号机、信控方案、信号灯相位及信号灯的创建后，若需在仿真过程中修改单个交叉口的信控方案，可参考以下示例代码。使用前，需预先记录各相位对应的相位ID。

```python
from tessng import Online

def afterOneStep(self) -> None:
    # 获取当前仿真时间，单位：ms
    simu_time = self.simuiface.simuIntervalScheming()
    
    # 到达指定时刻
    if simu_time == 60 * 1000:
        # 单个交叉口的一个信控方案的不同信控相位对应的信控相位ID和灯色时长列表
        signal_interval_mapping = {
            "东西直行": {
                "signalPhaseId": 1,  # 对应的信控相位ID
                "instervals": [0, 31, 3, 86],  # 对应灯色（红、绿、黄、红）的时长列表
            },
            "东西左转": {
                "signalPhaseId": 2,
                "instervals": [35, 21, 3, 61],
            },
            "南北直行": {
                "signalPhaseId": 3,
                "instervals": [60, 31, 3, 26],
            },
            "南北左转": {
                "signalPhaseId": 4,
                "instervals": [95, 21, 3, 1],
            },
        }
    
        # 按信控相位设置
        for signal_phase_name, signal_phase_data in signal_interval_mapping.items():
            # 获取信控相位ID
            signal_phase_id = signal_phase_data["signalPhaseId"]
            # 获取信控相位对象
            signal_phase = self.netiface.findSignalPhase(signal_phase_id)
            if signal_phase is None:
                continue
            # 时长列表
            instervals = signal_phase_data["instervals"]
            # 构建灯色和时长对象列表
            color_obj_list = [
                Online.ColorInterval("R", instervals[0]),  # 红色
                Online.ColorInterval("G", instervals[1]),  # 绿色
                Online.ColorInterval("Y", instervals[2]),  # 黄色
                Online.ColorInterval("R", instervals[3]),  # 红色
            ]
            # 给信控相位设置新的时长方案
            signal_phase.setColorList(color_list)
```

​	（2）在仿真过程中，按单个信号灯直接修改灯色的代码如下。由于这种操作本质上是对 TESS NG 已计算结果的修正或覆盖，因此这类调整**仅在当前帧内生效**。这意味着，**不能仅在满足条件的某个时刻进行一次设置，而需要在整个符合条件的时间区间内持续执行设置操作**。

```python
# MySimulator.py
from tessng import ISignalLamp

def calcLampColor(self, pSignalLamp: ISignalLamp) -> bool:
    # 获取当前仿真时间，单位：ms
    simu_time = self.simuiface.simuIntervalScheming()
    # 若信号灯ID为1，且在指定时间范围内，则设为绿色
	if pSignalLamp.id() == 1 && (60 * 1000 <= simu_time <= 90 * 1000): 
		pSignalLamp.setLampColor("G")
		return True
	return False
```



## 4.4.车辆控制

### 4.4.1.设置车辆期望速度

​	在仿真过程中，设置车辆期望速度的代码如下。

```python
# 设置车辆的期望速度，单位：像素/s
vehicle.setDesirSpeed(m2p(80 / 3.6))
```

### 4.4.2.设置车辆速度

​	在仿真过程中，设置车辆速度的代码如下。

```python
# MySimulator.py
from tessng import IVehicle, objreal, objUnitOfMeasure

# 单位：m/s
def ref_reSetSpeed_unit(self, vehicle: IVehicle, ref_inOutSpeed: objreal, ref_unit: objUnitOfMeasure) -> bool:
    if vehicle.id() == 100001:
        # 直接指定车辆的速度
        ref_inOutSpeed.value = 80 / 3.6;
        return True
    return False
```

### 4.4.3.设置车辆加速度

​	设置车辆加速度的代码如下。

```python
# MySimulator.py
from tessng import IVehicle, objreal, objUnitOfMeasure

# 该函数在 TESS NG 计算加速度之前计算，单位：m/s²
def ref_calcAcce_unit(self, pIVehicle: IVehicle, ref_acce: objreal, ref_unit: objUnitOfMeasure) -> bool:
    if pIVehicle.roadName() == "曹安公路":
        # 根据速度不同，直接计算加速度
        if pIVehicle.currSpeed() > 20/3.6:
            ref_acce.value = -3
            return True;
        elif pIVehicle.currSpeed() > 10/3.6:
            ref_acce.value = -1
          	return True
	return False

# 该函数在 TESS NG 计算加速度之后计算单位：m/s²
def ref_reSetAcce_unit(self, pIVehicle: IVehicle, ref_inOutAcce: objreal, ref_unit: objUnitOfMeasure) -> bool:
    if pIVehicle.roadName() == "曹安公路":
        # 根据速度不同，对已计算出的加速度进行修正
        if pIVehicle.currSpeed() > 20/3.6:
            acce.value += -3
            return True
        elif pIVehicle.currSpeed() > 10/3.6:
            acce.value += -1
          	return True
	return False
```

### 4.4.4.设置车辆变道

​	控制车辆向左或向右变道的代码如下。

```python
# 控制车辆向左变道
vehicle.vehicleDriving().toLeftLane()

# 控制车辆向右变道
vehicle.vehicleDriving().toRightLane()
```

​	撤销车辆变道的代码如下。

```python
# MySimulator.py
from tessng import IVehicle

def reCalcDismissChangeLane(self, pIVehicle: IVehicle) -> bool:
    # 距离路段终点小于50m时撤销一切自由变道，达到禁止自由变道的效果
	if pIVehicle.vehicleDriving().distToEndpoint(True, True, UnitOfMeasure.Metric) < 50:
        return True
    return False
```

### 4.4.5.设置车辆车道限行

​	设置车辆车道限行的代码如下。

```python
# MySimulator.py
from tessng import IVehicle

def calcLimitedLaneNumber(self, pIVehicle: IVehicle) -> list[int]:
    # 如果车辆在路段上且车辆长度大于8m，则禁止驶入最内侧车道
    if pIVehicle.roadIsLink() and pIVehicle.length(UnitOfMeasure.Metric) > 8:
       limit_lane_number = pIVehicle.lane().link().laneCount()
       return [limit_lane_number]
    return []
```

### 4.4.6.设置车辆路径

​	设置车辆路径的代码如下。

```python
# 1. 使用现有的决策点的车辆路径
routing1 = self.netiface.findRouting(1)
vehicle.vehicleDriving().setRouting(routing1)

# 2. 创建不与决策点绑定的车辆路径
link_id_list = [8, 16, 25]
link_list = [self.netiface.findLink(link_id) for link_id in link_id_list]
routing2 = self.netiface.createRouting(link_list)
vehicle.vehicleDriving().setRouting(routing2)
```

### 4.4.7.设置车辆跟驰参数

​	设置车辆跟驰参数的代码如下。**当前仅支持修改 IDM 跟驰模型的参数**。

```python
from tessng import m2p

# 设置车辆的期望加速度单位：像素/s²
vehicle.setDesirAcce(m2p(5.5))

# 设置车辆最大减速度，单位：像素/s²
vehicle.setMaxDece(m2p(7.5))

# 设置车辆的安全时距，单位：s
vehicle.vehicleDriving().setSafeTimeInterval(1.5)

# 设置车辆的停车距离，单位：像素
vehicle.vehicleDriving().setStoppingDistance(m2p(2))
```

### 4.4.8.设置车辆跳跃

​	设置车辆跳跃的代码如下。

```python
from PySide2.QtCore import QPointF
from tessng import UnitOfMeasure

# 目标点
target_point = QPointF(50, 50);
# 将目标点投影到附近一定范围内的车道上，获取定位信息序列
locations = self.netiface.locateOnCrid(target_point, 9, UnitOfMeasure.Metric);  # 使用前需要先执行netiface.buildNetGrid(10)
# 如果定位到了车道对象
if locations:
    location = locations[0]
    # 车道对象
    lane_obj = location.pLaneObject
    # 位置，单位：m
    dist = location.distToStart

    # 移动车辆到指定车道和位置上，实现车辆位置的瞬移
    vehicle.vehicleDriving().move(lane_obj, dist, UnitOfMeasure.Metric)
```

### 4.4.9.设置车辆信息和可视化

​	设置车辆信息的代码如下。

```python
# MySimulator.py
from tessng import IVehicle

def vehiRunInfo(self, pIVehicle: IVehicle) -> str:
	return f"车辆当前在ID={pIVehicle.roadId()}的道路上"
```

​	设置车辆颜色的代码如下。

```python
# 设置车辆颜色为蓝色
vehicle.setColor("#00AFF0")
```

​	设置车辆可视化的代码如下。

```python
# MySimulator.py
from PySide2.QtCore import QPointF
from PySide2.QtGui import QPainter, QFont, QPainterPath, QFontMetrics, QColor
from tessng import IVehicle

def rePaintVehicle(self, pIVehicle: IVehicle, painter: QPainter) -> None:
    # 在车身上添加车辆名称标签
    label: str = vehicle.name()

    # 创建QFont对象，设置字体和字号
    font = QFont('Arial', 1)
    # 设置字体为非粗体
    font.setBold(False)

    # 创建QFontMetrics对象，获取字体度量信息
    fontMetrics = QFontMetrics(font)
    # 获取文本的边界矩形
    boundingRect = fontMetrics.boundingRect(label)
    # 计算文本位置
    new_x = -boundingRect.center().x() - vehicle.width() * 0.5
    new_y = -boundingRect.center().y()
    position = QPointF(new_x, new_y)

    # 创建QPainterPath对象绘制文本
    textPath = QPainterPath()
    # 将文本添加到路径中
    textPath.addText(position, font, label)
    
    # 设置画笔的缩放比例
    painter.scale(1, 1)
    # 填充路径绘制文本
    painter.fillPath(textPath, QColor("#c94f4f"))
```



## 4.5.仿真控制

### 4.5.1.设置仿真参数

​	在仿真开启前，设置仿真参数的代码如下。

```python
# MySimulator.py

# 在仿真开启前设置以下参数
def beforeStart(self, keep_on: bool) -> None:
    # 设置仿真倍速
    self.simuiface.setAcceMultiples(5)
    # 设置仿真时长，单位：s
    self.simuiface.setSimuIntervalScheming(3600)
    # 设置仿真精度
    self.simuiface.setSimuAccuracy(10)
    # 设置随机种子
    self.simuiface.setRandSeed(42)
    # 设置是否记录车辆轨迹
    self.simuiface.setIsRecordTrace(True)
    # 设置是否记录行人轨迹
    self.simuiface.setIsRecordPedestrianTrace(True)
```

### 4.5.2.启动、暂停和停止仿真

​	启动、暂停和停止仿真的代码如下。

```python
# 开启仿真，一般写在 afterLoadNet 或 afterStop
if not self.simuiface.isRunning() or self.simuiface.isPausing():
    self.simuiface.startSimu()

# 暂停仿真，一般写在 afterOneStep
if self.simuiface.isRunning():
    self.simuiface.pauseSimu()

# 停止仿真，一般写在 afterOneStep
if self.simuiface.isRunning():
    self.simuiface.stopSimu()
```

### 4.5.3.连续多次仿真

​	连续多次仿真的代码如下。

```python
# MySimulator.py

class MySimulator(PyCustomerSimulator):
    def __init__(self):
        super().__init__()
        # 代表TESS NG的接口
        self.iface = tessngIFace()
        # 代表TESS NG 的仿真子接口
        self.simuiface: SimuInterface = self.iface.simuInterface()
        
        # 当前仿真次数
        self.current_simu_count = 0
        # 最大仿真次数
        self.max_simu_count = 10

    def afterStart(self) -> None:
        # 仿真次数加一
        self.current_simu_count += 1
    
    def afterOneStep(self) -> None:
        # 当前仿真时间，单位：ms
        simu_time = self.simuiface.simuTimeIntervalWithAcceMutiples()
        if simu_time > 600 * 1000:
            # 停止仿真
            self.simuiface.stopSimu()
    
    def afterStop(self) -> None:
        # 还没到最大仿真次数
        if self.current_simu_count < self.max_simu_count:
            # 开启仿真
            self.simuiface.startSimu()
```



## 4.6.数据输出

### 4.6.1.输出路网几何线性数据

​	路网由路段和连接段组成，其中路段由车道构成，连接段由车道连接构成。路段、车道和车道连接均包含中心线、左边线和右边线的断点序列，车辆正是在这些由断点构成的线上行驶。获取路段、车道和车道连接断点数据的代码如下。

```python
# 获取某一路段的中心线、左边线和右边线的断点坐标
link = self.netiface.findLink(1)
link_center_points = link.centerBreakPoint3Ds(UnitOfMeasure.Metric)
link_left_points = link.leftBreakPoint3Ds(UnitOfMeasure.Metric)
link_right_points = link.rightBreakPoint3Ds(UnitOfMeasure.Metric)

# 获取某一车道的中心线、左边线和右边线的断点坐标
lane = self.netiface.findLane(1)
lane_center_points = lane.centerBreakPoint3Ds(UnitOfMeasure.Metric)
lane_left_points = lane.leftBreakPoint3Ds(UnitOfMeasure.Metric)
lane_right_points = lane.rightBreakPoint3Ds(UnitOfMeasure.Metric)
        
# 获取某一车道连接的中心线、左边线和右边线的断点坐标
lane_connector = self.netiface.findLaneConnector(1, 4)
lane_connector_center_points = lane_connector.centerBreakPoint3Ds(UnitOfMeasure.Metric)
lane_connector_left_points = lane_connector.leftBreakPoint3Ds(UnitOfMeasure.Metric)
lane_connector_right_points = lane_connector.rightBreakPoint3Ds(UnitOfMeasure.Metric)
```

### 4.6.2.输出车辆轨迹数据

​	在仿真过程中，获取某一帧仿真的车辆数据的代码如下。

```python
# 获取当前正在运行的车辆列表
all_vehicles = self.simuiface.allVehiStarted()
for vehicle in all_vehicles:
    print(f"车辆ID：{vehicle.id()}")
    print(f"车辆名称：{vehicle.name()}")
    print(f"车辆类型编码：{vehicle.vehicleTypeCode()}")
    print(f"车辆类型名称：{vehicle.vehicleTypeName()}")
    print(f"车辆长度：{vehicle.length(UnitOfMeasure.Metric)} m")

    print(f"车辆当前横坐标：{vehicle.pos(UnitOfMeasure.Metric).x()} m")
    print(f"车辆当前纵坐标：{vehicle.pos(UnitOfMeasure.Metric).y()} m")
    print(f"车辆当前高程：{vehicle.v3z()()} m")
    print(f"车辆当前所在道路ID：{vehicle.roadId()}")
    print(f"车辆当前所在道路名称：{vehicle.roadName()}")
    print(f"车辆当前是否在路段：{vehicle.roadIsLink()}")
    print(f"车辆当前所在车道ID：{vehicle.laneId()}")
    if vehicle.roadIsLink():
        print(f"车辆当前所在车道序号：{vehicle.laneNumber()}")
    print(f"车辆当前与车道起点的间距：{vehicle.vehicleDriving().distToStartPoint(True, True, UnitOfMeasure.Metric)} m")

    print(f"车辆当前当前速度：{vehicle.currSpeed(UnitOfMeasure.Metric) * 3.6} km/h")
    print(f"车辆当前期望速度：{vehicle.vehicleDriving().desirSpeed(UnitOfMeasure.Metric) * 3.6} km/h")
    print(f"车辆当前加速度：{vehicle.acce(UnitOfMeasure.Metric)} m/s²")
    print(f"车辆当前朝向角：{vehicle.angle()} °")
```

### 4.6.3.输出信号灯数据

​	在仿真过程中，获取某一帧仿真的信号灯数据的代码如下。

```python
all_signal_phase_color = self.simuiface.getSignalPhasesColor()
for signal_phase_color in all_signal_phase_color:
    print(f"信号机ID：{signal_phase_color.signalGroupId}")
    print(f"信控相位ID：{signal_phase_color.phaseId}")
    print(f"信控相位序号：{signal_phase_color.phaseNumber}")
    print(f"当前颜色：{signal_phase_color.color}")
    print(f"当前颜色的设置时间(ms)：{signal_phase_color.mrIntervalSetted}")
    print(f"当前颜色的已持续时间(ms)：{signal_phase_color.mrIntervalByNow}")
```

### 4.6.4.输出各类采集设备数据

​	各类采集设备包括：数据采集器、排队计数器和行程时间检测器。在仿真过程中，获取它们的样本数据和集计数据的代码如下。其中，**集计数据仅能在集计时间段结束的那一帧仿真中获取**。

```python
# ==================== 数据采集器的样本数据 ====================
all_vehi_info_collected = self.simuiface.getVehisInfoCollected()
for vehi_info in all_vehi_info_collected:
    print(f"采集器ID：{vehi_info.collectorId}")
    print(f"仿真时间(s)：{vehi_info.simuInterval}")
    print(f"车辆ID：{vehi_info.vehiId}")

# ==================== 数据采集器的集计数据 ====================
all_vehi_info_aggregated = self.simuiface.getVehisInfoAggregated()
for vehi_info_agg in all_vehi_info_aggregated:
    print(f"采集器ID：{vehi_info_agg.collectorId}")
    print(f"时间段ID：{vehi_info_agg.timeId}")
    print(f"起始时间(s)：{vehi_info_agg.fromTime}")
    print(f"结束时间(s)：{vehi_info_agg.toTime}")
    print(f"车辆数(veh)：{vehi_info_agg.vehiCount}")
    print(f"平均速度(km/h)：{vehi_info_agg.avgSpeed}")
    print(f"平均占有率：{vehi_info_agg.occupancy}")

# ==================== 排队计数器的样本数据 ====================
all_vehi_queue_counted = self.simuiface.getVehisQueueCounted()
for vehi_queue in all_vehi_queue_counted:
    print(f"计数器ID：{vehi_queue.counterId}")
    print(f"仿真时间(s)：{vehi_queue.simuTime}")
    print(f"排队车辆数(veh)：{vehi_queue.vehiCount}")
    print(f"排队长度(m)：{vehi_queue.queueLength}")

# ==================== 排队计数器的集计数据 ====================
all_vehi_queue_aggregated = self.simuiface.getVehisQueueAggregated()
for vehi_queue_agg in all_vehi_queue_aggregated:
    print(f"计数器ID：{vehi_queue_agg.counterId}")
    print(f"时间段ID：{vehi_queue_agg.timeId}")
    print(f"起始时间(s)：{vehi_queue_agg.fromTime}")
    print(f"结束时间(s)：{vehi_queue_agg.toTime}")
    print(f"平均排队车辆数(veh)：{vehi_queue_agg.avgVehiCount}")
    print(f"平均排队长度(m)：{vehi_queue_agg.avgQueueLength}")
    print(f"最大排队长度(m)：{vehi_queue_agg.maxQueueLength}")
    print(f"最小排队长度(m)：{vehi_queue_agg.minQueueLength}")

# ==================== 行程时间检测器的样本数据 ====================
all_vehi_travel_detected = self.simuiface.getVehisTravelDetected()
for vehi_travel in all_vehi_travel_detected:
    print(f"检测器ID：{vehi_travel.detectedId}")
    print(f"车辆ID：{vehi_travel.vehiId}")
    print(f"行驶时间(s)：{vehi_travel.travelTime}")
    print(f"行驶距离(m)：{vehi_travel.travelDistance}")
    print(f"延误(s)：{vehi_travel.delay}")

# ==================== 行程时间检测器的集计数据 ====================
all_vehi_travel_aggregated = self.simuiface.getVehisTravelAggregated()
for vehi_travel_agg in all_vehi_travel_aggregated:
    print(f"检测器ID：{vehi_travel_agg.detectedId}")
    print(f"时间段ID：{vehi_travel_agg.timeId}")
    print(f"起始时间(s)：{vehi_travel_agg.fromTime}")
    print(f"结束时间(s)：{vehi_travel_agg.toTime}")
    print(f"车辆数：{vehi_travel_agg.vehiCount}")
    print(f"平均行程时间(s)：{vehi_travel_agg.avgTravelTime}")
    print(f"平均行程距离(m)：{vehi_travel_agg.avgTravelDistance}")
    print(f"平均延误(s)：{vehi_travel_agg.avgDelay}")
```
<div style="page-break-after: always;"></div>

# 5.行业案例

​	基于 TESS NG 二次开发实现的行业案例如下表所示，完整代码请参见 [Github](https://github.com/jIDa-traffic/TESSNG_SecondaryDev) 仓库或 [Gitee](https://gitee.com/jidatraffic/tessng-secondary-doc) 仓库。

|       大类       | 功能项                           |
| :--------------: | :------------------------------- |
|       高速       | 施工区仿真                       |
|                  | 事故，事件仿真                   |
|                  | 车道限速管控                     |
|                  | 车道关闭仿真                     |
|                  | 硬路肩，应急车道开放             |
|                  | 匝道信号控制                     |
|                  | 拥堵预警                         |
|                  | 高速管控预评价系统               |
|                  | 高快速路参数标定                 |
|       城市       | 单点信控自适应                   |
|                  | 交叉口车道车道渠化变更，可变车道 |
|                  | 干线协调                         |
|                  | 车辆路径诱导                     |
|                  | 拥堵预警                         |
|                  | 车道管控仿真                     |
|                  | 车辆事故仿真                     |
|                  | 车辆速度引导（VMS信息板）        |
|                  | 城市道路参数标定                 |
|                  | 公交信号优先                     |
|   V2X 自动驾驶   | v2x交叉口                        |
|                  | 速度引导                         |
|                  | 车辆编队行驶                     |
| 自动驾驶联合仿真 | Carla对接                        |
|                  | prescan对接                      |
|                  | scanner对接                      |
|                  | 交通数字孪生：与UE5，unity结合   |
|                  | 自动驾驶测试场景设计             |

<div style="page-break-after: always;"></div>

# 6.注意事项

## 6.1.软件激活

​	用户在首次使用 TESS NG 二次开发时也需要激活，试用版用户与首次激活软件流程相同，采用安装包的 Cert 文件夹下的 JIDaTraffic_key 激活即可。

​	软件的试用期为30天，试用期结束后，二次开发的接口（Interface）仍可用，但自定义插件（Plugin）将无法使用。商业版用户使用不受限制。

​	另外，还可以**修改 `config` 中的 `__workspace` 参数**，将其指定为 TESS NG 的安装目录。这样设置后，所有输出文件将统一生成至该目录，同时能实现激活文件共享（避免重复激活）与 3D 模型文件共享（防止 3D 转换时找不到模型文件）。



## 6.2.度量单位

​	由于 TESS NG 基于 Qt 框架开发，而 Qt 的图形系统以像素为基础单位，其坐标体系与现实世界的物理单位（如米）存在天然差异。Qt 的绘图操作、界面布局及交互响应均均围绕像素维度展开，默认以屏幕像素作为渲染和定位的基准，并不直接对应现实空间的物理尺度。	

​	因此，在 TESS NG 二次开发中，无论是路网元素的尺寸定义、车辆位置的计算映射，还是自定义图形的绘制、交互操作的坐标解析，都需要特别关注**像素与米制单位**的转换逻辑。默认情况下，1像素对应1m，但若因为导入底图等操作更改了像素比例，则可通过以下方法实现单位转换：

- 米制转换像素：def m2p(value: float) -> float
- 像素转换米制：def p2m(value: float) -> float

​	此外，插件与接口中部分方法包含 **UnitOfMeasure unit** 参数，其默认值为`UnitOfMeasure.Default`（即像素单位），若传入`UnitOfMeasure.Metric`（**需通过`from tessng import UnitOfMeasure`导入**）则表示采用米制单位（支持读写操作）。例如，`vehicle.currSpeed()`会返回车辆的像素单位速度，而`vehicle.currSpeed(UnitOfMeasure.Metric)`则返回车辆的米制单位速度。 需要注意的是，由于`unit`参数通常位于方法参数列表的末尾，**若需显式指定该参数，则其之前所有带默认值的参数也必须显式传入对应值**。相关规则在此统一说明，接口详情中不再赘述。



## 6.3.坐标系

​	由于 TESS NG 基于 Qt 框架开发，其坐标系设计直接沿用了 Qt 的核心规则 ——Qt 为适配屏幕显示与图形渲染逻辑（屏幕像素通常以左上角为原点，向下为 y 轴正方向），采用 **y轴朝下**的坐标系（原点一般位于画布 / 窗口左上角，x 轴水平向右，y 轴垂直向下）。

​	因此，在 TESS NG 二次开发过程中，所有涉及坐标计算、图形绘制（如路网元素定位、车辆位置标注、自定义图形渲染）、鼠标交互定位等场景，均需遵循这一 **y轴朝下**的坐标系规则。尤其在与现实地理坐标系（通常 y 轴朝上）或自定义坐标体系进行数据转换、位置映射时，需特别注意坐标轴方向的差异，避免因坐标系理解偏差导致图形错位、位置计算错误等问题。



## 6.4.依赖模块导入

​	通常需要在文件开头导入所需的依赖模块，可一次性导入整个模块或只导入需要的对象。示例如下。

```python
# 导入整个模块
from tessng import *

# 导入指定对象
from tessng import tessngIFace, Online
```



## 6.5.子插件作用规则

​	在仿真插件中，对车辆加速度、期望速度、行驶速度、转向角度等参数的调整，以及对信号灯灯色的设置，实质上都是对 TESS NG 已计算结果的修正或覆盖，因此这类调整**仅在当前帧内生效**。这意味着像信号灯灯色设置这类操作，**不能仅在满足条件的某个时刻进行一次设置，而需要在整个符合条件的时间区间内持续设置**。



## 6.6.子插件修改传入值函数的使用规则

​	由于 TESS NG 底层基于 C++ 实现，而 C++ 支持通过引用传递修改整数、浮点数、布尔值等基础类型，Python 却不支持对这些类型进行引用修改。为解决这一差异，对于需要修改传入值的函数，我们会在其名称前添加 "ref_" 前缀，并特别构建了`objint`、`objreal`、`objbool`等类型。

​	例如，原函数`def reSetSpeed(self, vehicle, inOutSpeed) -> bool`会新增对应的`def ref_reSetSpeed(self, vehicle, ref_inOutSpeed) -> bool`。其中，`ref_inOutSpeed`的类型为`Tessng.objreal`，可通过`ref_inOutSpeed.value = 1`的方式进行赋值操作。

​	这类函数主要集中在 PyCustomerSimulator 和 PyCustomerNet 中，接口详情中会同时列出不带`ref_`前缀和带`ref_`前缀的函数：

- 若有修改传入值的需求，需使用带`ref_`前缀的函数；
- 若无修改传入值的需求，如`def beforeStart(self, keepOn:bool) -> None`，使用不带`ref_`前缀和带`ref_`前缀的函数都可。



## 6.7.接口方法调用规则

​	所有函数仅支持通过**位置参数**调用，例如：`self.netiface.findLane(1)`，不支持通过**关键字参数**调用，例如：`self.netiface.findLane(laneId=1)`。

<div style="page-break-after: always;"></div>

# 7.问答列表

### 1. 为什么我在 MySimulator 自带函数中编写的二次开发代码没有生效？

**答：** 可能是由于试用期已结束，导致系统没有权限加载插件，从而使自定义代码无法执行。

