# Microscopic Traffic Simulation Software TESS NG Secondary Development Interface Documentation (Java Version)

[TOC]

<div style="page-break-after: always;"></div>

# 1. Introduction

## 1.1. Related Links

* [Official Website of Shanghai Jida Traffic Technology](https://jidatraffic.com/#/home)
* [TESS NG Secondary Development Official Documentation](http://jidatraffic.com:82/)
* [TESS NG Secondary Development GitHub Repository](https://github.com/jIDa-traffic/TESSNG_SecondaryDev)
* [TESS NG Secondary Development Gitee Repository](https://gitee.com/jidatraffic/tessng-secondary-doc)



## 1.2. Development Background

**The domestically developed microscopic traffic simulation software TESS NG** integrates the latest technological advancements from interdisciplinary fields including traffic engineering, software engineering, and system simulation. It features fully independent intellectual property rights, efficient and convenient modeling capabilities, open external interface modules, and customizable user services.

　　During function extension and project development, TESS NG strengthens its design by highly abstracting the implementation of numerous functions and deeply integrating these abstractions with the core functionalities. These abstractions are further refined into interface methods, while the specific implementations of the interfaces are completed by users based on actual application scenarios. Under this architectural design, TESS NG has successfully developed plugin modules such as vehicle-road coordination, online simulation, and integrated micro-macro simulation, with the design and application of related interfaces reaching a high level of maturity.

　　TESS NG’s secondary development capability is realized through user-written code interacting with the software, thereby extending functionality and customizing scenarios. Users can not only realize highly automated and personalized simulation operations but also construct traffic digital twins and scientific research experimental environments tailored to specific requirements. This constitutes a key approach for conducting traffic research and applications.

　　Currently, TESS NG supports secondary development in three programming languages: **C++**, **Python**, and **Java**, with interface names fully consistent across all three.



## 1.3. Application Scenarios

The secondary development features of TESS NG enable the construction of diverse simulation scenarios. The applicable scenarios are extensive and include, but are not limited to, those listed in the table below.

| Serial Number |     Category     |       Scenario       |                             Application                             |
| :--: | :----------: | :--------------: | :----------------------------------------------------------: |
|  1   |   Urban Simulation   |     Signal Control     |                     Single-Point Webster Signal Control Algorithm                      |
|  2   |              |     Bus Priority     |                         Mainline Green Wave Algorithm                         |
|  3   |              |   Vehicle Route Guidance   | Inducing by adjusting the proportion of traffic flow at decision points<br/>Evaluation and analysis of queue length on downstream roads at induction points |
|  4   |   Highway Simulation   |     Ramp Signal Control     |                  On-Ramp ALINEA Signal Control Algorithm Application                  |
|  5   |              |   Lane Speed Limit Management   |                  Dynamic Highway Lane Speed Limit Management                  |
|  6   |              |   Emergency Incident Handling   |                    Vehicle Accident and Incident Simulation                    |
|  7   |              |     Road Construction     |                        Simulation of Three Types of Construction Zones                        |
|  8   |     Teaching     | Continuous Intersection Speed Guidance |                     Application of Green Wave Speed Guidance Strategy                     |
|  9   |              |    Traffic Flow Reconstruction    |                 Parameter Calibration of Car-Following and Lane-Changing Models on Expressways                 |
|  10  |              |   Preliminary Research on AI Algorithms    |             Research on Variable Speed Limit Optimization for Expressways Based on Reinforcement Learning             |
|  11  |   Road Network Construction   |     Road Network Editing     |          CRUD Operations on Simulation Elements Including Road Network, Road Segment, and Connection Segment          |
|  12  |              |     Signal Control Editing     |         CRUD Operations on Traffic Signals and Signal Groups, Supporting Dual-Loop Structure Signal Control Loading         |
|  13  |              |     Demand Editing     | Departure point traffic loading configuration<br/>Single vehicle designated location loading settings<br/>Vehicle composition customization<br/>Addition, deletion, modification, and query of decision points and path ratios |
|  14  | Simulation |     Process Control     | Start, pause, resume, and close operations of simulation<br/>Application of simulation snapshot function<br/>Acquisition of simulation information, road network information, and vehicle information<br/>Conversion of vehicle trajectory plane coordinates and geographic coordinates<br/>Parameter settings such as acceleration, simulation accuracy, and random seeds |
|  15  |              |     Action Control     | Setting of speed limit zone, accident zone, and construction zone<br/>Vehicle movement, information modification, lane change, and heading angle adjustment<br/>Update of signal light color, path, and phase information<br/>Lane opening and closing, road scheme, and path information management<br/>Parameter modification of car following model and lane changing model |
|  16  |              |     Simulation Output     | Settings of detectors and collectors<br/>Output data at specified time and frequency<br/>Obtain binding relationship between detectors, collectors and simulated road network<br/>Vehicle trajectory output<br/>Output structured data of simulated road network |
|  17  | Interactive Interface Development |      Menu Bar      |      Supports User-Added Custom Menus to Facilitate Interaction with TESS NG Software       |
|  18  |              |      Toolbar      |     Supports users in adding custom toolbars to enable interaction with TESS NG software      |



## 1.4. Interface Architecture

TESS NG exposes its core functionalities to users by implementing TessInterface and its three sub-interfaces. Upon launching TESS NG, users can acquire the top-level interface, then access the three sub-interfaces through it and invoke their respective methods. After loading plugins, TESS NG can invoke interface methods implemented by the plugins. Users can control the simulation execution—including vehicle driving behavior, traffic signal states, route vehicle allocation, and more—during the simulation process via TessInterface and its sub-interfaces within plugin methods.

The overall architecture for secondary development is illustrated in the following figure.

<img src="http://129.211.28.237:5566/document/images/0_interface_architecture" alt="Secondary Development Overall Architecture Diagram" style="zoom: 50%;" />



## 1.5. Update Log

**【 2025-01-21 】**

- The TESS NG kernel has been upgraded from V3.1 to V4.0. The secondary development version supports the basic features of the V4.0 Professional Edition.

- [New] ISignalPlan Signal Control Plan Interface, supporting multi-period signal control plans and replacing the original ISignalGroup interface.

- [New] ISignalLamp Traffic Signal Interface, supporting the creation of traffic signals and their association with signal controllers.

- [New] ICrosswalkSignalLamp Pedestrian Signal Interface, supporting the creation of pedestrian signals and their association with signal controllers.

- [New] IRoadWorkZone Road Occupancy Construction Interface, supporting the creation of construction zones.

- [New] IAccIDentZone Accident Zone interface upgrade, including IAccIDentZoneInterval accident time periods, enabling the creation of accident zones with different parameters across multiple time intervals.

- [New] ILimitedZone Restricted Zone, which is part of detour construction, may not be used directly; however, users can employ it to define custom restricted-area types.

- [New] IReconstruction Detour Construction (Reconstruction and Expansion), enabling fine-grained generation and control of reconstructed and expanded road networks.

- [New] IReduceSpeedArea New Speed Limit Zone interface, supporting lane speed limits by time intervals through IReduceSpeedInterval and by vehicle types through IReduceSpeedVehiType.

- [New] Newly added toll station series interfaces, including toll lane ITollLane, toll decision point ITollDecisionPoint, toll routing ITollRouting, and toll station parking point ITollPoint.

- [New] Parking-related interfaces, including Parking Stall IParkingStall, Parking Region IParkingRegion, Parking Decision Point IParkingDecisionPoint, and Parking Routing IParkingRouting.

- [New] Junction construction and route reconstruction interface IJunction, featuring automatic calculation of junction traffic flows and route reconstruction based on input observations.

- [New] Pedestrian surface area interfaces include: Pedestrian base class IPedestrian, Obstacle Region IObstacleRegion, Passenger loading/unloading region IPassengerRegion, and Elliptical Region. IPedestrianEllipseRegion, Fan-shaped Region IPedestrianFanShapeRegion, Polygonal Region IPedestrianPolygonRegion, Rectangular Region IPedestrianRectRegion, and Triangular Region IPedestrianTriangleRegion.

- [Added] IPedestrianSideWalkRegion interface for pedestrian sidewalk surface areas.

- [Added] IPedestrianCrossWalkRegion interface for pedestrian crosswalks (zebra crossings).

- [Added] IPedestrianStairRegion interface for pedestrian stair surface areas.

- [Added] ICrosswalkSignalLamp interface for pedestrian crosswalk traffic signals.

- [Added] A series of pedestrian path interfaces, including: IPedestrianPath and IPedestrianPathPoint.

- [Added] Under the NetInterface class, CRUD operations for IJunction node objects; CRUD operations for pedestrian surface areas and routes; CRUD operations for accident zones, construction zones, reconstruction and expansion zones, speed limit zones, traffic signals, signal controllers, signal control plans, and star phases; CRUD operations for parking lots and toll stations.

- [New] Added interfaces under the SimuInterface class to obtain pedestrian status and moving pedestrian information, and introduced an interface for single-step simulation.

- [Optimization] Standardized interface units: the V3 series defaults to pixel units, while commonly used concepts such as speed and length in V4 have been converted to metric units (meters). Additionally, the unitOfMeasure parameter is provided to explicitly specify the unit type, thereby eliminating cumbersome m2p and p2m conversions.

  

**【 2025-09-30 】**

- [New] Interfaces introduced to set vehicle safe time interval and stopping distance: setSafeTimeInterval and setStoppingDistance.
- [New] Interfaces to read and configure whether to output traffic signal head data: isRecordSignalLampStatus and setIsRecordSignalLampStatus.
- [Removed] Deprecated plugin functions related to lane changing: reSetChangeLaneFreelyParam and isPassbyEventZone.

<div style="page-break-after: always;"></div>

# 2. Quick Start Guide

This section provides a quick start guide. Through installation and execution, example explanations, and important notes, readers can quickly understand how to build and run TESS NG Java API examples in a local environment. These contents establish a practical foundation for subsequent plugin development and interface invocation, assisting developers in completing the workflow initially, then progressively exploring functional extensions.



## 2.1. Installation and Execution (Windows)

#### <span style="color: green;">Step 1: Download the Example Code Package</span>

1. Download the latest version of TESS NG from the [Jida Traffic Official Website](https://www.jidatraffic.com/#/simulation) ;

   <img src="http://129.211.28.237:5566/document/images/java_2_1_01" alt="Figure 1" style="zoom: 60%;" />

2. After installation, the Java example code package named **`TESS_JavaAPI_EXAMPLE`** can be found in the **`SecondDev`** folder within the software directory.

   <img src="http://129.211.28.237:5566/document/images/java_2_1_02" alt="Figure 2" style="zoom: 60%;" />

#### <span style="color: green;">Step 2: Configure the Development Environment</span>

1. **Install JDK**:

   - Visit the [Java Official Download Page](https://www.oracle.com/java/technologies/downloads/) and select **JDK version 8 or later** for download;
   - Using JDK 21 as an example, select the Windows x64 Installer and click to download the `jdk-21_windows-x64_bin.exe` file;
   - Double-click the downloaded `jdk-21_windows-x64_bin.exe` file to launch the installer;
   - Follow the Installation Wizard by clicking "Next" sequentially. You may choose a custom installation directory as needed;
   - Click "Next" again and wait for the installation to complete.

   <img src="http://129.211.28.237:5566/document/images/java_2_1_03" alt="Figure 3" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/java_2_1_04" alt="Figure 4" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/java_2_1_05" alt="Figure 5" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/java_2_1_06" alt="Figure 6" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/java_2_1_07" alt="Figure 7" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/java_2_1_08" alt="Figure 8" style="zoom: 60%;" />

2. **Verify Installation Results**:

   - After installation, press `Win + R` and enter `cmd` to open the system terminal;

   - Run the commands `java -version` and `javac -version` respectively. If the output shows version information similar to `java version "21.0.8" 2025-07-15 LTS` and `javac 21.0.8`, the installation has been successful.

   <img src="http://129.211.28.237:5566/document/images/java_2_1_09" alt="Figure 9" style="zoom: 60%;" />

#### <span style="color: green;">Step 3: Select and Configure IDE</span>

- It is recommended to use **JetBrains IntelliJ IDEA** (Community or Ultimate Edition). The operation procedure is as follows:

1. **Install IDEA**:
   - Visit the [IntelliJ IDEA official website](https://www.jetbrains.com/idea/) and download the installation package suitable for the Windows operating system;
   - Double-click the downloaded `ideaIU-x.x.x.exe` file to launch the installer;
   - Follow the Installation Wizard and click “Next.” You may select a custom installation route as needed;
   - Click “Install” and wait for the installation process to complete.
   
   <img src="http://129.211.28.237:5566/document/images/java_2_1_10" alt="Figure 10" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/java_2_1_11" alt="Figure 11" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/java_2_1_12" alt="Figure 12" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/java_2_1_13" alt="Figure 13" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/java_2_1_14" alt="Figure 14" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/java_2_1_15" alt="Figure 15" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/java_2_1_16" alt="Figure 16" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/java_2_1_17" alt="Figure 17" style="zoom: 60%;" />
   
2. **Configure JDK:**

   - Launch IDEA, click the 'Open' button, and select the `TESS_JavaAPI_EXAMPLE` folder to open it;

   - Click sequentially on the top menu bar 'File > Project Structure' to open the 'Project Structure' configuration window;

   - In the left navigation pane, select 'Project Settings > Project'; then, in the right 'SDK' dropdown, select the installed JDK directory. After clicking 'OK', IDEA will automatically detect the JDK version and related dependencies, completing the project SDK configuration.

   <img src="http://129.211.28.237:5566/document/images/java_2_1_18" alt="Figure 18" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/java_2_1_19" alt="Figure 19" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/java_2_1_20" alt="Figure 20" style="zoom: 60%;" />

#### <span style="color: green;">Step 4: Run the Sample Project</span>

1. **Startup Code**:

   - Click “Current File > Edit Configurations” in the top menu bar of IDEA to open the “Run/Debug Configurations” window;
   - Click the “+” icon in the top left corner and select “Application”;
   - In the configuration interface:
     - You may rename the “Name” field to a custom name (e.g., “Main”);
     - In the “Build and Run” section’s “Main class” input box, click the browse button on the right (or directly enter the full class name) to select the preset main class `Main` from the project class hierarchy;
     -  In the “Environment Variables” option, click the “Browse .env files and scripts” button on the right, then in the file selection dialog, select the `.env` file located in the project root directory to complete the import;
     - Click the 'OK' button.

   - Click the 'Run' button above (green triangle icon), or press the shortcut `Shift + F10` to launch the program.

   <img src="http://129.211.28.237:5566/document/images/java_2_1_21" alt="Figure 21" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/java_2_1_22" alt="Figure 22" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/java_2_1_23" alt="Figure 23" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/java_2_1_24" alt="Figure 24" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/java_2_1_25" alt="Figure 25" style="zoom: 60%;" />

2. **Software Activation:**

   - Upon first launch, the TESS NG software activation window will appear. Follow the instructions to complete the activation (a valid license is required);
   - After successful activation, close the window and click the “Run” button again to normally start the example project.

   <img src="http://129.211.28.237:5566/document/images/java_2_1_26" alt="Figure 26" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/java_2_1_27" alt="Figure 27" style="zoom: 60%;" />



## 2.2. Example Explanation

#### <span style="color: dodgerblue;">Note 1: Project Directory</span>

​	`TESS_JavaAPI_EXAMPLE` adheres to the Maven standard project directory structure (convention over configuration), separating source code, dependency libraries, and compilation output directories. It is aligned with the Java engineering development workflow. The descriptions of each directory and file are as follows:

- **lib**: Directory for project dependency Jar packages, including TESSNG.jar, referenced during project compilation and runtime
- **out**: TESS NG output directory
- **src**: Root directory of the project source code
  - **main**: Main source code directory
    - **java**: Java source code directory
      - **Main.java**: Main entry class of the project, responsible for initializing the TESS NG instance and launching the program
      - **MyPlugin.java**: Custom plugin implementation class, responsible for initializing the plugin
      - **MyNet.java**: Custom road network plugin implementation class, capable of executing custom operations before and after road network loading, and controlling the rendering of road network elements
      - **MySimulator.java**: Custom simulation plugin implementation class, capable of executing custom operations before, during, and after the simulation, allowing global control over simulation start/stop logic as well as fine-grained intervention in the driving behavior of individual vehicles
    - **native**
      - **win-x64**: Native resource directory for the Windows x64 platform, containing project-dependent DLL files (Dynamic Link Libraries) and QT plugins, ensuring that the Java layer can properly invoke native functionalities.

- **target**: Default output directory for the Maven build tool, storing project packaging artifacts (such as Jar packages), compiled bytecode files, and dependency libraries; this is the core directory for project deployment artifacts.
- **pom.xml**: Core configuration file for the Maven project, defining basic project information (such as coordinates and version), dependency libraries (managed via the `<dependencies>` node), and build rules (including compilation plugins and output configurations).

#### <span style="color: dodgerblue;">Note 2: Plugin Registration Mechanism and Simulation Control Logic</span>

Many TESS NG beginners often wonder: how is the custom plugin code they write invoked by TESS NG? By examining the implementation logic of the project’s main entry file `main.cpp`, this process can be clearly understood. At the same time, it is necessary to clarify the core development approach for the simulation scenario, as detailed below:

1. First, to answer the core question: **How is the custom code invoked by TESS NG?** The key lies in the line `tessngFactory.build(myPlugin, workspacePath)` in `Main.java`. This acts as a “bridge” connecting the user-defined plugin to the TESS NG simulation core. The `build` method of `tessngFactory` (a factory class provided by TESS NG) registers the user-created plugin instance, instantiated via `MyPlugin myPlugin = new MyPlugin()` (`MyPlugin` being the user-defined plugin class encapsulating all custom logic), with the simulation core through TESS NG’s underlying interfaces. After registration is completed, TESS NG automatically calls the user-overridden hook methods in `MyPlugin` and its sub-plugins `MyNet` and `MySimulator` at key points during simulation execution (such as simulation start, each simulation step, simulation end, etc.) without requiring manual invocation code, thereby enabling functional extension.

2. To clarify the core concept of simulation scenario development: beginners often mistakenly focus on 'how to embed TESS NG simulation into their own computational code'; the correct approach is to **embed custom computational code within the TESS NG simulation process**. TESS NG provides a mature simulation framework (including basic capabilities such as road network loading, simulation progression, and interface interaction), and the core role of `Main.java` is to configure and launch this framework. Users are not required to build the simulation framework themselves. They only need to encapsulate computational code (such as custom vehicle behaviors, data collection, special scenario trigger logic, etc.) within specific methods of `MyPlugin` and its sub-plugins `MyNet` and `MySimulator` (for example, TESS NG provides per-step simulation trigger methods like `afterOneStep` and simulation start trigger methods like `afterStart`). After plugin registration is completed via `tessngFactory.build`, these logics will be automatically integrated into the simulation process by TESS NG and executed as the simulation advances.

   The main entry class of the project is Main.java, with the code as follows:

```java
package com.example;

import javax.json.Json;
import javax.json.JsonObject;
import com.jidatraffic.tessng.TessngFactory;

public class Main {
    // Load library files
    static {
        try {
            System.loadLibrary("TESS_WIN_Java");
        } catch (UnsatisfiedLinkError e) {
            System.err.println("Native code library failed to load. See the chapter on Dynamic Linking Problems in the SWIG Java documentation for help.\n" + e);
            System.exit(1);
        }
    }

    public static void main(String[] args) {
        // Building a workspace path
        String workspacePath = System.getProperty("user.dir") + "\\out";
        // Build configuration parameters
        JsonObject jsonObject = Json.createObjectBuilder()
                .add("__secdevlang", "java")
                .add("__workspace", workspacePath)
                .add("__netfilepath", "")
                .add("__simuafterload", true)
                .build();

        // Create an instance of the custom plugin class
        MyPlugin myPlugin = new MyPlugin();
        // Create an instance of the TESS NG factory class
        TessngFactory tessngFactory = new TessngFactory();
        // Construct the TESS NG simulation core object via the factory class
        tessngFactory.build(myPlugin, jsonObject);
        // Exirt
        System.exit(0);
    }
}
```

#### <span style="color: dodgerblue;">Note 3: Modifying the startup road network</span>

​	Modify the `jsonObject` configuration properties in `Main.java` as follows:

- `"__netfilepath"`: Specifies the path to the road network file that TESS NG loads by default at startup;

- `"__simuafterload"`: Specifies whether TESS NG immediately starts the simulation after loading the road network file.

  For example:


```java
JsonObject jsonObject = Json.createObjectBuilder()
                .add("__language", "java")
                .add("__workspace", workspacePath)
                .add("__netfilepath", "C:/TESSNG_4.1.0/Examles/Wulinmen.tess")
                .add("__simuafterload", true)
                .build();
```

#### <span style="color: dodgerblue;">Note 4: Add, Delete, Query, and Modify Operations of Road Network Elements</span>

​	The `netiface` interface enables **adding, deleting, querying, and modifying** road network elements (such as road segments, connection segments, etc.). Additionally, after obtaining the road network element objects, it supports **querying** and **modifying** their attributes.

- The following example illustrates: adding, deleting, querying, and modifying road network elements (via the `netiface` interface).

```java
// 1. Query all links: Retrieve a list of all links currently in the road network
ArrayList<ILink> links = netiface.links();

// 2. Query a specific road segment by ID: Retrieve the link with ID = 1 (returns None if not found)
ILink link = netiface.findLink(1);

// 3. Create link: Enter the vertex coordinates (link_points), number of lanes (7), and name ("Cao'an Highway") of the link, create and return a new link object
Point startPoint1 = new Point(m2p(-300), 0);
Point endPoint1 = new Point(m2p(300), 0);
ArrayList<Point> linkPoints1 = new ArrayList<>(Arrays.asList(startPoint1, endPoint1));
ILink link1 = netiface.createLink(linkPoints1, 7, "Caoan", true, UnitOfMeasure.Metric);

// 4. Delete a link: Pass the link object to be deleted (link1) to remove it from the road network
netiface.removeLink(link1);
```

- The following example illustrates: querying and modifying attributes of road network elements (via element objects).


```java
// 1. Attribute query: Retrieve relevant attributes of road segment link1
int laneCount = link1.laneCount();  // Query the number of lanes of the road segment (returns an integer, e.g., 3)
qreal laneLength = link1.length();  // Query the length of the road segment (returns a floating-point number, unit: meters)

// 2. Attribute modification: Modify the name and speed limit of road segment link1
link1.setName("Caoan Highway");  // Set the road segment name to "Cao'an Highway"
link1.setLimitSpeed(80);  // Set the speed limit of the road segment to 80 km/h
```

#### <span style="color: dodgerblue;">Note 5: Custom Operations Before and After Road Network Loading</span>

​	In a custom road network plugin (class `MyNet`), overriding the `beforeLoadNet` and `afterLoadNet` methods enables implementation of **preprocessing before road network loading** and **post-processing after road network loading**.

- The following example demonstrates: after the road network is loaded, first check whether the current road network contains any road segments; If none exist, call the custom method `createNet()` to create the basic road network (including road segments, connection segments, dispatch points, etc.).

```java
// MyNet.java：Implementation file for the Custom Road Network Plugin
@Override
public void afterLoadNet() {
    // 1. Retrieve the number of road segments
    int linkCount = netiface.linkCount();

    // 2. If there are no road segments in the road network, invoke the custom method to create the road network
    if (linkCount == 0) {
        // Custom method: Internal implementation logic for creating road segments, connector segments, and departure points
        createNetwork();
    }
}
```

#### <span style="color: dodgerblue;">Note 6: Display Control of Road Network Elements</span>

​	In a custom road network plugin (class `MyNet`), overriding the `labelNameAndFont` method allows fine control over the labeling of road network elements (such as road segments and connection segments)—including label content (display name / ID / no display) and font size customization, to satisfy visualization requirements under different scenarios.

- The following example illustrates: for the road segment named 'Cao'an Highway', labels display the segment name; labels of other road segments show the ID; connection segment labels all display the name.

```java
// MyNet.java：Implementation file for the Custom Road Network Plugin
@Override
    public void ref_labelNameAndFont(int itemType, long itemId, ObjInt ref_outPropName, ObjReal ref_outFontSize) {
        // 1. When the simulation is running (not paused): Labels on Road Segments and Lanes are not displayed to avoid interfering with simulation observation
        if (simuiface.isRunning()) {
            ref_outPropName.setValue(GraphicsItemPropName.None.swigValue());  // Do not display any labels
            return;  // Return immediately, no need to execute subsequent logic
        }

        // 2. Default configuration: Labels display element ID, with a font size of 6 meters
        ref_outPropName.setValue(GraphicsItemPropName.Id.swigValue());
        ref_outFontSize.setValue(6);

        // 3. Connector Segment special configuration: All display the Name (regardless of ID, uniformly identified by Name)
        if (itemType == NetItemType.getGConnectorType()) {
            ref_outPropName.setValue(GraphicsItemPropName.Name.swigValue());
        }
        // 4. Road Segment special configuration: Only Road Segments with IDs 1, 5, and 6 display the Name; others display the ID
        else if (itemType == NetItemType.getGLinkType()) {
            if (itemId == 1 || itemId == 5 || itemId == 6) {
                ref_outPropName.setValue(GraphicsItemPropName.Name.swigValue());
            }
        }
    }
```

#### <span style="color: dodgerblue;">Note 7: Querying and Modifying Simulation Information</span>

​	The `simuiface` interface allows querying and modifying **core simulation parameters**, including simulation duration, precision, speed multiplier, and others.

```java
// 1. Simulation Information Query: Retrieve Key Parameters of the Current Simulation
long simuInterval = simuiface.simuIntervalScheming();  // Query the preset total simulation duration (Unit: s)
int simuAccuracy = simuiface.simuAccuracy();  // Query simulation accuracy
int simuMultiples = simuiface.acceMultiples();  // Query simulation speed multiplier
long simuTime = simuiface.simuTimeIntervalWithAcceMutiples();  // Query the currently elapsed simulation time (Unit: ms)

// 2. Simulation Information Modification: Set Key Parameters of the Simulation
simuiface.setSimuIntervalScheming(3600);  // Set the total simulation duration to 3600 s
simuiface.setSimuAccuracy(1);  // Set the simulation accuracy to 1
simuiface.setAcceMultiples(5);  // Set the simulation speed multiplier to 5
```

#### <span style="color: dodgerblue;">Note 8: Adding, Deleting, Querying, and Operating on Simulation Vehicles</span>

​	Via the `simuiface` interface, it is possible to add, delete, and query **simulation vehicles**. Upon obtaining a vehicle object, all its properties can be queried, and **static properties** (those that remain constant during simulation, such as length and maximum speed) can be modified.

- The following example demonstrates: adding, deleting, querying, and modifying simulated vehicles (via the `simuiface` interface).

```java
// 1. Query Vehicles: Retrieve the list of vehicles within a specified range
ArrayList<IVehicle> allVehicles = simuiface.allVehiStarted();  // Retrieve all active vehicles currently in the simulation
ArrayList<IVehicle> vehicles = simuiface.vehisInLink(1);  // Retrieve vehicles currently traveling on the road segment with ID 1

// 2. Add Vehicle: Dynamically create a vehicle on a specified road segment (vehicle parameters must be configured first via DynaVehiParam)
DynaVehiParam dvp = new DynaVehiParam();  // Vehicle dynamic parameter object
dvp.setVehiTypeCode(randomInt(0, 4) + 1);  // Randomly set the vehicle type code (1-4, corresponding to different vehicle types)
dvp.setRoadId(6);  // Specify the vehicle's initial road segment ID (here, 6)
dvp.setLaneNumber(randomInt(0, 3));  // Randomly set the initial lane number (0-2, corresponding to lanes 1-3 of the road segment)
dvp.setDist(50);  // Vehicle's initial distance along the road segment (50 m from the start of the road segment)
dvp.setSpeed(20);  // Initial vehicle speed (Unit: m/s)
dvp.setColor("#00AFF0");  // Vehicle display color
// Invoke interface to create vehicle, returns new vehicle object (returns null if creation fails)
IVehicle vehicle1 = simuiface.createGVehicle(dvp);
// Verify if the vehicle was created successfully
if (vehicle1 != null){
    System.out.println("Created vehicle " + vehicle1.id() + " on the link.");
}

// 3. Delete vehicle: stop the specified vehicle (vehicle1) and remove it from the simulation
simuiface.stopVehicleDriving(vehicle1);
```

- The following example demonstrates: querying and static modification of vehicle attributes (via the vehicle object).


```java
// 1. Attribute query: retrieve relevant attributes of the vehicle object
String roadName = vehicle.roadName();  // Name of the road segment or connector segment where the vehicle is located
double speed = vehicle.currSpeed();  // Get the vehicle's current speed (Unit: m/s)

// 2. Attribute modification: modify the vehicle's length and speed limit
vehicle.setLength(5);  // Modify the vehicle's length (Unit: m)
vehicle.setMaxSpeed(80/3.6);  // Modify the vehicle's maximum speed (Unit: m/s)
```

#### <span style="color: dodgerblue;">Note 9: Dynamic attribute modification of simulated vehicles</span>

​	The **dynamic attributes** of vehicles (such as real-time speed and acceleration, which vary dynamically during the simulation process) cannot be directly modified through the vehicle object. They must be implemented by overriding specific methods within the **custom simulation plugin (`MySimulator` class)**—essentially correcting or overriding the dynamically computed values of TESS NG in real time.

- The following example demonstrates: within the `reSetSpeed` method, forcibly setting the real-time speed of certain vehicles based on their vehicle ID and the road segment they occupy (making vehicles with IDs 2 to N follow the speed of the vehicle with ID 1).

```java
// MySimulator.java: Implementation file of the Custom Simulation Plugin
@Override
public boolean ref_reSetSpeed(IVehicle vehicle, ObjReal refInOutSpeed) {
    // 1. Process Vehicle ID (apply modulus to avoid overly long IDs, retaining only the last 5 digits)
    long tmpVehicleId = vehicle.id() % 100000;

    // 2. Retrieve the current Road segment name where the Vehicle is located
    String roadName = vehicle.roadName();

    // 3. Apply speed control logic exclusively to vehicles on "Cao'an Highway"
    if (roadName.equals("Caoan Highway")) {
        // For Vehicle with ID=1: record its current speed as the base speed
        if (tmpVehicleId == 1) {
            planeSpeed = vehicle.currSpeed();
        } 
        // For Vehicles with IDs from 2 to self.squareVehiCount: forcibly set their speed to the base speed
        else if (tmpVehicleId >= 2 && tmpVehicleId <= squareVehiCount) {
            // Override the speed value calculated by TESS NG
            refInOutSpeed.setValue(planeSpeed);
            // Return True to indicate that the speed modification has taken effect
            return true;
        }
    }
    // Return False to indicate that speed is unmodified; use TESS NG's default computed value
    return false;
}
```

#### <span style="color: dodgerblue;">Note 10: Custom Operations at Specific Simulation Timing</span>

​	In a custom simulation plugin (the `MySimulator` class), by overriding specific methods provided by TESS NG, custom logic can be triggered at **various simulation nodes**: supporting operations at **global simulation timings** (such as before simulation start and after simulation end) as well as at **vehicle-specific behavior timings** (such as vehicle creation, vehicle removal, and before vehicle lane change), thereby fulfilling detailed simulation customization requirements.

- By overriding the `beforeStart` (before simulation start) and `afterStop` (after simulation end) methods, global preprocessing and postprocessing of the simulation can be implemented, such as initializing simulation parameters, repeatedly starting the simulation, and exporting simulation results. The following example demonstrates that after the simulation ends, if the cumulative number of simulations is ≤ 3, the simulation will automatically restart, enabling looped simulation.

```java
// MySimulator.java: Implementation file of the Custom Simulation Plugin
@Override
public void afterStop() {
    // 1. simuCount is a user-defined variable used to count the cumulative simulation count.
    if (this.simuCount <= 3) {
        // 2. Call the interface to restart the simulation
        simuiface.startSimu();
    }
}
```

- By overriding methods associated with vehicle behavior, logic can be triggered when vehicles meet specific conditions, such as initializing vehicle properties after creation or recording data after vehicle removal. The following example shows that after a vehicle is created in the simulation, its type, position, and length are set based on the vehicle ID.

```java
// MySimulator.java: Implementation file of the Custom Simulation Plugin
@Override
public void initVehicle(IVehicle vehicle) {
    // 1. Obtain basic information of the current vehicle (Road segment name, Road Segment ID)
    String roadName = vehicle.roadName();  // Name of the road segment or connector segment where the vehicle is currently located
    long roadId = vehicle.roadId();  // ID of the road segment or connector segment where the vehicle is currently located

    // 2. Execute special customized logic only for vehicles on 'Cao'an Highway'
    if (roadName.equals("Caoan Highway")) {
        // Process Vehicle ID: modulo 100000, remove the leading digit (the leading digit usually corresponds to the vehicle source, such as the departure point or bus route)
        int tmpVehicleId = (int) (vehicle.id() % 100000);

        // 3. For vehicles with specific IDs, set dedicated vehicle types and initial positions
        if (tmpVehicleId == 1) {
            // Set the vehicle with ID=1 to 'Vehicle Type 12'
            vehicle.setVehiType(12);
            // Initialize the vehicle’s initial lane, position, and speed
            vehicle.initLane(3, m2p(105), 0);
        }
        // Additional customization logic for other vehicle IDs can be added here, such as tmp_vehicle_id=2, 3, etc.

        // 4. Set specific length for vehicles with IDs 23 to 28
        if (tmpVehicleId >= 23 && tmpVehicleId <= 28) {
            vehicle.setLength(m2p(4.5), true);
        }
    }
}
```

<div style="page-break-after: always;"></div>

# 3. Interface Details

This section first introduces the **Global Configuration Parameters (config.json)**, followed by an explanation of the three hierarchical components: **Plugin**, **Interface**, and **Object**, to help readers progressively understand the secondary development model of TESS NG from a general overview to detailed specifics.



## 3.1. Global Configuration Parameters

The global configuration parameters recognized by TESS NG in config.json are as follows: 

```json
{
	"__netfilepath": "xxx.tess", 		
	"__simuafterload": false, 
	"__timebycpu": false, 
	"__writesimuresult": true, 
	"__custsimubysteps": false,
    "__allowspopup": false
}
```

**__netfilepath**

Specifies the road network file path loaded by TESS NG at startup, supporting both absolute and relative paths. If the file does not exist, a blank road network will be opened by default.

**__simuafterload**

Specifies whether TESS NG automatically starts the simulation after loading the road network file; the default value is false. 

**__timebycpu**

Specifies the time basis for simulation cycle calculations: either real time based on the CPU clock or simulation time based on simulation precision; the default is false. When running online simulation under limited computational resources, this property can be set to true.

**__writesimuresult**

​	Controls whether Simulation Results are output; the default value is true. If set to false, result files will not be written after simulation ends, and during the simulation process, vehicles that have exited the Road network for some time will be recycled into the available queue to reduce memory usage.

**__custsimubysteps**

​	Sets the frequency basis for TESSNG to invoke plugin methods; the default is false. If set to false, methods are invoked once per calculation cycle (regardless of the frequency set on the plugin side); If set to true, methods are invoked according to the frequency specified by the plugin.

**__allowspopup**

​	Controls whether popup prompt windows are allowed to avoid blocking program execution; the default is true.



## 3.2. Plugin

Typically, software functionality is extended by defining plugin interfaces that users implement to create plugins. TESS NG also adopts this model, including the top-level plugin interface TessPlugin, as well as two sub-plugin interfaces: JCustomerNet and JCustomerSimulator. Unlike the TessInterface, which only permits calling interface methods without modifying internal runtime logic, users can implement the methods of TessPlugin and its sub-interfaces to access TESS NG’s internal runtime process deeply, influencing stages such as road network loading and the simulation process. This enables modification of the runtime logic to achieve more advanced functional extensions. All methods of these two sub-plugins provide default implementations, allowing users to selectively implement some or all methods according to their needs.

Due to differences in invocation scenarios and objectives of plugin interface methods, to standardize the understanding of these methods, most employ the following structural pattern:

```java
boolean method(type &outParam) 
{
    outParam.setValue(1);
	return true;
}
```

When TESS NG calls these methods, it follows this logic: **if the return value is false, it is regarded as no user response, and the call will be ignored; if the return value is true, it signifies that the user has responded, and subsequent processing will proceed using the value of the outParam parameter**. For example, in the given scenario: when vehicles queue on Cao'an Highway, it is necessary to reset the speed of vehicles behind an airplane to match that of the airplane. In this case, a subclass of JCustomerSimulator, MySimulator, can fulfill this requirement by implementing the `ref_reSetSpeed` method.

```java
@Override
public boolean ref_reSetSpeed(IVehicle vehicle, ObjReal refInOutSpeed) {
    long tmpVehicleId = vehicle.id() % 100000;
    String roadName = vehicle.roadName();
    if (roadName.equals("Caoan Highway")) {
        if (tmpVehicleId == 1) {
            planeSpeed = vehicle.currSpeed();
        } else if (tmpVehicleId >= 2 && tmpVehicleId <= squareVehiCount) {
            refInOutSpeed.setValue(planeSpeed);
            return true;
        }
    }
    return false;
}
```

After TESS NG calculates the vehicle speed, it invokes the plugin's reSetSpeed method. If this method returns true, it indicates that the plugin has responded to this call, and the original calculated speed is replaced with the outSpeed value. The procedure by which TESS NG calls the plugin's `reSetSpeed` method (C++ code) is as follows:

```cpp
if (gpTessPlugin && gpTessPlugin->customerSimulator())
{
   qreal outSpeed = mrCurrSpeed；
   if (gpTessPlugin->customerSimulator()->reSetSpeed(mpGVehicle，outSpeed))
   {
       mrCurrSpeed = outSpeed；
   }
}
```

### 3.2.1. Top-Level Plugin (TessPlugin)

TessPlugin is the top-level plugin interface developed by users. It includes two sub-plugin interfaces: JCustomerNet and JCustomerSimulator. By implementing these sub-plugins, users interact with TESS NG in the domains of the road network and the simulation process, respectively.

**public void init()**

During plugin initialization, subclasses of JCustomerNet and JCustomerSimulator can be instantiated within this method.

**public CustomerNet customerNet()**

Returns the customerNet object.

**public CustomerSimulator customerSimulator()**

Returns the CustomerSimulator object.


### 3.2.2. Road Network Plugin (JCustomerNet)

JCustomerNet is a sub-plugin interface of TessPlugin. By implementing this plugin, users can execute custom operations before and after road network loading and control the rendering of road network elements.

#### 3.2.2.1. Road Network Loading

**public void beforeLoadNet()**

Called before loading the road network; users can perform necessary initialization tasks through this method.

**public void afterLoadNet()**

Called after loading the road network.

Example:

```java
@Override
public void afterLoadNet() {
    // Retrieve the number of road segments
    int linkCount = netiface.linkCount();
    // If there are no road segments in the road network, invoke the custom method to create the road network
    if (linkCount == 0) {
        createNetwork();
    }
}
```

#### 3.2.2.2. Road Network Element Rendering

**public boolean isPermitForCustDraw()**

Indicates whether customer rendering invocation is allowed. This method aims to reduce unnecessary code calls and eliminate adverse effects on runtime efficiency.

Return:

Whether to render; true indicates rendering, false indicates no rendering. Default is true.

**public boolean isDrawLinkCenterLine(long linkId)**

Whether to render the centerline of the road segment.

Parameters:

[ in ] linkID: Road Segment ID.

Return:

Whether to render; true indicates rendering, false indicates no rendering. Default is true.

Example:

```java
@Override
public boolean isDrawLinkCenterLine(long linkId) {
    // Do not draw the centerline for the road segment with ID 1
    return linkId != 1;
}
```

**public boolean isDrawLinkCorner(long linkId)**

Whether to render circular and square markers at the four corners of the road segment.

Parameters:

[ in ] linkID: Road Segment ID.

Return:

Whether to render; true indicates rendering, false indicates no rendering. Default is true.

**public boolean isDrawLaneCenterLine(long laneId)**

Whether to render the lane centerline.

Parameters:

[ in ] laneID: Lane ID.

Return:

Whether to render; true indicates rendering, false indicates no rendering. Default is false.

**public boolean linkType(ArrayList\<String\> lType)**

Road segment type.

Parameters:

[ in ] lType: User-defined list of road segment types.

Return:

Whether customized.

**public boolean laneType(ArrayList\<String\> lType)**

Lane type.

Parameters:

[ in ] lType: User-defined list of lane types.

Return:

Whether customized.

**public boolean paint(int itemType, long itemID, Painter painter)**

Render the road network element.

Parameters:

[ in ] itemType: Road network element type.

[ in ] itemID: Road network element ID.

[ in ] painter: QPainter object.

Return:

If true is returned, TESSNG considers the plugin to have completed the drawing and will not draw further; otherwise, TESSNG will perform the drawing.

**public boolean paintLaneObject(ILaneObject pILaneObj, Painter painter)**

Draw a lane or lane connection.

Parameters:

[ in ] pILaneObj: Lane or lane connection.

[ in ] painter: QPainter object.

Return:

If true is returned, TESSNG considers the plugin to have completed the drawing and will not draw further; otherwise, TESSNG will perform the drawing.

**public boolean linkBuildGLanes(ILink pILink)**

Create a lane.

Parameters:

[ in ] pILink: Road segment object.

Return:

If true is returned, TESSNG considers the plugin to have created the lane and will not create it again.

**public boolean linkBrushColor(long linkID, Color color)**

Road segment brush color.

Parameters:

[ in ] linkID: Road Segment ID.

[ out ] color: QColor object.

Return:

True indicates the road segment is drawn using the specified color.

Example:

```java
@Override
public boolean linkBrushColor(long linkID, Color color) {
	// Set the specified road segment to red
	Set<Long> targetLinkIds = new HashSet<>();
    targetLinkIds.add(1L);
    targetLinkIds.add(2L);
    targetLinkIds.add(3L);
    if (targetLinkIds.contains(linkID)) {
        color[0] = new Color(255, 0, 0);
        return true;
    }
    return false;
}
```

~~**public boolean laneBrushAndPen(long laneID, QBrush brush, QPen pen)**~~

~~Set the brush for drawing the lane by specifying the Lane ID.~~

~~Parameters:~~

~~[ in ] laneID: Lane ID.~~

~~[ out ] brush: QBrush object.~~

~~[ out ] pen: QPen object.~~

~~Return:~~

~~true indicates that the lane with the ID equal to laneID is drawn using the brush and pen parameters.~~

**public boolean connectorAreaBrushColor(long connAreaID, Color color)**

Brush color of the area.

Parameters:

[ in ] connAreaID: Area ID.

[ out ] color: Brush color.

Return:

true indicates that TESSNG draws the area using the color.

**public void labelNameAndFont(int itemType, long itemId, ObjInt outPropName, ObjReal outFontSize)**

**public void ref_labelNameAndFont(int itemType, long itemId, ObjInt ref_outPropName, ObjReal ref_outFontSize)**

Determine whether to use the ID or name as the drawing content based on the road network element type and ID.

Parameters:

[ in ] itemType: Road segment element type.

[ in ] itemID: Road network element ID.

[ out ] outPropName: Enumerated value. If assigned GraphicsItemPropName.Id.swigValue(), the ID is used as the drawing content; if assigned GraphicsItemPropName.Name.swigValue(), the road network element name is used as the drawing content.

[out] outFontSize: Font Size. Unit: m.

Return:	

True indicates that the label is drawn using either the ID or name according to the set outPropName value and rendered at the specified size.

Example:

```java
@Override
public void ref_labelNameAndFont(int itemType, long itemId, ObjInt ref_outPropName, ObjReal ref_outFontSize) {
    // If the simulation is running, labels for both Road Segments and Lanes will not be drawn.
    if (simuiface.isRunning()) {
        ref_outPropName.setValue(GraphicsItemPropName.None.swigValue());
        return;
    }

    // Default is to display the ID.
    ref_outPropName.setValue(GraphicsItemPropName.Id.swigValue());
    // Label size is 6 m.
    ref_outFontSize.setValue(6);

    // For Connector Segments, always display the Name.
    if (itemType == NetItemType.getGConnectorType()) {
        ref_outPropName.setValue(GraphicsItemPropName.Name.swigValue());
    }
    // For Road Segments, whether to display the Name is determined based on the ID.
    else if (itemType == NetItemType.getGLinkType()) {
        if (itemId == 1 || itemId == 5 || itemId == 6) {
            ref_outPropName.setValue(GraphicsItemPropName.Name.swigValue());
        }
    }
}
```

### 3.2.3. Simulation Plugin (JCustomerSimulator)

JCustomerSimulator is a TessPlugin sub-plugin interface. By implementing this plugin, users can perform custom operations before, during, and after the simulation process, allowing both global control of simulation start and stop logic and fine-grained intervention in individual vehicle driving behavior.

#### 3.2.3.1. Simulation Start and Stop

**public void beforeStart(ObjBool keepOn)**

**public void ref_beforeStart(ObjBool ref_keepOn)**

Used to implement custom operations before starting the simulation. If necessary, users can abandon the simulation by setting keepOn to false.

Parameters:

[ out ] keepOn: whether to continue; the default is true.

**public void afterStart()**

Used to implement custom operations after the simulation starts.

**public void afterStop()**

Used to implement custom operations after the simulation ends.

Example:

```java
@Override
public void afterStop() {
    // Restart the simulation if the number of runs is less than 3
    if (this.simuCount <= 3) {
        simuiface.startSimu();
    }
}
```

**public void afterOneStep()**

Used to implement custom operations after completing a simulation frame. At this point, all vehicles have completed the same batch of calculations. Typically, this method is used to obtain vehicle trajectories, detector data, and perform necessary subtotals. Calculations performed in this method generally do not affect the consistency of simulation results, but the efficiency is low. A large computational load can impact simulation performance.

**public void duringOneStep()**

This method is called during the calculation of the same batch across multiple worker threads. At this time, some vehicles have completed their calculations while others are still processing. Calculations performed in this method are less safe but more efficient.

**public boolean calcSimuConfig(SimuConfig config)**

Calculate simulation parameters.

Parameters:

[ out ] config: Simulation parameter information.

Return:

true indicates updating simulation parameters with those in config. Once the simulation has started, simulation accuracy and thread count cannot be updated; however, simulation duration and acceleration factor can be modified.

#### 3.2.3.2. Vehicle Control

**public void initVehicle(IVehicle pIVehicle)**

Used to implement custom operations after vehicle creation. Users can initialize the vehicle's lane index, starting position, and size within this method.

Parameters:

[ in ] pIVehicle: Vehicle object.

Example:

```java
@Override
public void initVehicle(IVehicle pIVehicle) {
    // Set to blue if it is a passenger car
    if (pIVehicle.vehicleTypeCode() == 1) {
        pIVehicle.setColor("#00AFF0");
    }
}
```

**public boolean isStopDriving(IVehicle pIVehicle)**

Used to determine whether to stop the vehicle's operation.

Parameters:

[ in ] pIVehicle: Vehicle object.

Return:

true indicates stopping the vehicle's operation and removing it from the road network.

Example:

```java
@Override
public boolean isStopDriving(IVehicle pIVehicle) {
    // Remove the vehicle if it enters Road Segment 12.
    if (pIVehicle.roadIsLink() && pIVehicle.roadId() == 12) {
        return true;
    }
    return false;
}
```

**public void beforeStopVehicle(IVehicle pIVehicle)**

Used to implement custom operations before vehicle removal.

Parameters:

[ in ] pIVehicle: Vehicle object. 

**public void afterStopVehicle(IVehicle pIVehicle)**

Used to implement custom operations after a vehicle is removed.

Parameters:

[ in ] pIVehicle: Vehicle object.

**public void afterStep(IVehicle pIVehicle)**

Used to implement custom operations after a vehicle completes one simulation frame. Vehicle current information can be obtained here, such as the current road, position, heading angle, speed, desired speed, and surrounding vehicles (front, rear, left, right).

Parameters:

[ in ] pIVehicle: Vehicle object.

**public boolean calcAcce(IVehicle pIVehicle, ObjReal acce)**

**public boolean calcAcce(IVehicle pIVehicle, ObjReal acce, ObjUnitOfMeasure unit)**

**public boolean ref_calcAcce(IVehicle pIVehicle, ObjReal acce)**

**public boolean ref_calcAcce_unit(IVehicle pIVehicle, ObjReal ref_acce, ObjUnitOfMeasure ref_unit)**

Calculates the vehicle’s acceleration.

Parameters:

[ in ] pIVehicle: Vehicle object.

[ out ] acce: vehicle acceleration. Unit: pixel/s².

Return:	

If true is returned, acce will be set as the current acceleration.

Example:

```java
@Override
public boolean ref_calcAcce_unit(IVehicle pIVehicle, ObjReal acce, ObjUnitOfMeasure ref_unit) {
    if (pIVehicle.roadName() == "Caoan Highway") {
        // Calculate acceleration directly based on speed differences.
        if (pIVehicle.currSpeed() > 20/3.6) {
            acce.setValue(-3);
            return true;
        }
        else if (pIVehicle.currSpeed() > 10/3.6) {
            acce.setValue(-1);
            return true;
        }
    }
    return false;
}
```

**public boolean reSetAcce(IVehicle pIVehicle, ObjReal inOutAcce)**

**public boolean reSetAcce(IVehicle pIVehicle, ObjReal inOutAcce, ObjUnitOfMeasure unit)**

**public boolean ref_reSetAcce(IVehicle pIVehicle, ObjReal ref_inOutAcce)**

**public boolean ref_reSetAcce_unit(IVehicle pIVehicle, ObjReal ref_inOutAcce, ObjUnitOfMeasure ref_unit)**

Recalculates the vehicle’s acceleration.

Parameters:

[ in ] pIVehicle: Vehicle object.

[ in, out ] inOutAcce: vehicle acceleration. Unit: pixel/s².

Return:

If true is returned, inOutAcce will be set as the current acceleration.

Example:

```java
@Override
public boolean ref_reSetAcce_unit(IVehicle pIVehicle, ObjReal inOutAcce, ObjUnitOfMeasure ref_unit) {
    if (pIVehicle.roadName() == "Caoan Highway") {
        // Adjust the calculated acceleration based on the speed
        if (pIVehicle.currSpeed() > 20/3.6) {
            acce.setValue(acce.getValue() + (-3));
            return true;
        }
        else if (pIVehicle.currSpeed() > 10/3.6) {
            acce.setValue(acce.getValue() + (-1));
            return true;
        }
    }
    return false;
}
```

**public boolean reCalcdesirSpeed(IVehicle pIVehicle, ObjReal inOutDesirSpeed)**

**public boolean reCalcdesirSpeed(IVehicle pIVehicle, ObjReal inOutDesirSpeed, ObjUnitOfMeasure unit)**

**public boolean ref_reCalcdesirSpeed(IVehicle pIVehicle, ObjReal ref_desirSpeed)**

**public boolean ref_reCalcdesirSpeed_unit(IVehicle pIVehicle, ObjReal ref_inOutDesirSpeed, ObjUnitOfMeasure ref_unit)**

Recalculates the vehicle’s desired speed.

Parameters:

[ in ] pIVehicle: Vehicle object.

[ in, out ] inOutDesirSpeed: Vehicle desired speed. Unit: pixels/s².

Return:

If true is returned, inOutDesirSpeed will be used as the desired speed.

**public boolean calcMaxLimitedSpeed(IVehicle pIVehicle, ObjReal inOutLimitedSpeed)**

**public boolean calcMaxLimitedSpeed(IVehicle pIVehicle, ObjReal inOutLimitedSpeed, ObjUnitOfMeasure unit)**

**public boolean ref_calcMaxLimitedSpeed(IVehicle pIVehicle, ObjReal ref_inOutLimitedSpeed)**

**public boolean ref_calcMaxLimitedSpeed_unit(IVehicle pIVehicle, ObjReal ref_inOutLimitedSpeed, ObjUnitOfMeasure ref_unit)**

Recalculate the vehicle's current maximum speed limit. Without plugin intervention, when the vehicle speed exceeds the road limit, the vehicle travels at the road's maximum speed limit. Under the intervention of this method, the limit can be raised to allow the vehicle to exceed the road speed limit.

Parameters:

[ in ] pIVehicle: Vehicle object.

[ in, out ] inOutLimitedSpeed: Vehicle maximum speed limit. Unit: pixels/second.

Return:

If true is returned, inOutLimitedSpeed will be used as the current road maximum speed limit.

**public boolean calcSpeedLimitByLane(ILink pILink, int laneNumber, ObjReal outSpeed)**

**public boolean calcSpeedLimitByLane(ILink pILink, int laneNumber, ObjReal outSpeed, ObjUnitOfMeasure unit)**

**public boolean ref_calcSpeedLimitByLane(ILink pILink, int laneNumber, ObjReal ref_outSpeed)**

**public boolean ref_calcSpeedLimitByLane_unit(ILink pILink, int laneNumber, ObjReal ref_outSpeed, ObjUnitOfMeasure ref_unit)**

Speed limit determined by the lane.

Parameters:

[ in ] pILink: Road segment object.

[ in ] laneNumber: Lane index, with 0 as the rightmost lane.

​	[ in, out ] outSpeed: Vehicle speed limit. Unit: km/h.

Return:	

​	If true is returned, outSpeed is applied as the lane speed limit.

**public boolean reSetSpeed(IVehicle pIVehicle, ObjReal inOutSpeed)**

**public boolean reSetSpeed(IVehicle pIVehicle, ObjReal inOutSpeed, ObjUnitOfMeasure unit)**

**public boolean ref_reSetSpeed(IVehicle pIVehicle, ObjReal ref_inOutSpeed)**

**public boolean ref_reSetSpeed_unit(IVehicle pIVehicle, ObjReal ref_inOutSpeed, ObjUnitOfMeasure ref_unit)**

​	Recalculate the vehicle’s speed.

Parameters:

[ in ] pIVehicle: Vehicle object.

​	[ in, out ] inOutSpeed: Vehicle speed. Unit: pixel/s.

Return:

​	If true is returned, inOutSpeed is applied as the current vehicle speed.

Example:

```java
@Override
public boolean ref_reSetSpeed_unit(IVehicle pIVehicle, ObjReal ref_inOutSpeed, ObjUnitOfMeasure ref_unit) {
    if (pIVehicle.id() == 100001) {
        // Directly specify the vehicle’s speed
        ref_inOutSpeed.setValue(80 / 3.6);
        return true;
    }
    return false;
}
```

**public boolean reCalcAngle(IVehicle pIVehicle, ObjReal outAngle)**

**public boolean ref_reCalcAngle(IVehicle pIVehicle, ObjReal ref_outAngle)**

​	Recalculate the vehicle’s angle. North is 0 degrees, clockwise direction.

Parameters:

[ in ] pIVehicle: Vehicle object.

​	[ in, out ] inOutAngle: Vehicle angle. Unit: degrees.

Return:

​	If true is returned, inOutAngle is applied as the current vehicle angle.

**public boolean reSetFollowingType(IVehicle pIVehicle, ObjInt outTypeValue)**

**public boolean ref_reSetFollowingType(IVehicle pIVehicle, ObjInt ref_outTypeValue)**

​	Reset the vehicle’s car-following type.

Parameters:

[ in ] pIVehicle: Vehicle object.

​	[ out ] outTypeValue: Car-following type. 0: stop, 1: normal, 5: rapid deceleration, 6: rapid acceleration, 7: merging, 8: crossing, 9: cooperative deceleration, 10: cooperative acceleration, 11: deceleration pending turn, 12: acceleration pending turn.

Return:	

If it returns true, outTypeValue will be used as the vehicle's Car-Following Type.

**public boolean reSetFollowingParam(IVehicle pIVehicle, ObjReal inOutSafeInterval, ObjReal inOutSafeDistance)**

**public boolean reSetFollowingParam(IVehicle pIVehicle, ObjReal inOutSafeInterval, ObjReal inOutSafeDistance, ObjUnitOfMeasure unit)**

**public boolean ref_reSetFollowingParam(IVehicle pIVehicle, ObjReal ref_inOutSafeInterval, ObjReal ref_inOutSafeDistance)**

**public boolean ref_reSetFollowingParam_unit(IVehicle pIVehicle, ObjReal ref_inOutSafeInterval, ObjReal ref_inOutSafeDistance, ObjUnitOfMeasure ref_unit)**

Reset the safety distance and safety time headway in the vehicle's Car-Following Model.

Parameters:

[ in ] pIVehicle: Vehicle object.

[ in, out ] inOutSafeInterval: Safety time headway, unit: seconds.

[ in, out ] inOutSafeDistance: Safety distance, unit: Pixel.

Return:

If it returns true, inOutSafeInterval will be used as the vehicle's safety time headway and inOutSafeDistance as the vehicle's safety distance.

**public ArrayList\<FollowingModelParam\> reSetFollowingParams()**

Reset the parameters of the vehicle's Car-Following Model, replacing the current model used in the simulation with the obtained Car-Following Model data, affecting all vehicles.

Return:

List of Car-Following parameters, allowing reset of parameters for motor vehicles and non-motor vehicles. **Once set, these parameters will be continuously applied** until replaced by new ones.

**public boolean reSetDistanceFront(IVehicle pIVehicle, ObjReal distance, ObjReal s0)**

**public boolean reSetDistanceFront(IVehicle pIVehicle, ObjReal distance, ObjReal s0, ObjUnitOfMeasure unit)**

**public boolean ref_reSetDistanceFront(IVehicle pIVehicle, ObjReal distance, ObjReal s0)**

**public boolean ref_reSetDistanceFront_unit(IVehicle pIVehicle, ObjReal ref_distance, ObjReal ref_s0, ObjUnitOfMeasure ref_unit)**

Reset the vehicle’s front vehicle spacing and stopping distance.

Parameters:

[ in ] pIVehicle: Vehicle object.

[ in, out ] distance: The distance between the current vehicle and the preceding vehicle. Unit: Pixel.

[ in, out ] s0: Stopping Distance. Unit: Pixel.

Return:

If true is returned, distance will be assigned as the vehicle’s front vehicle spacing, and s0 as the vehicle’s stopping distance.

**public boolean calcChangeLaneSafeDist(IVehicle pIVehicle, ObjReal dist)**

**public boolean calcChangeLaneSafeDist(IVehicle pIVehicle, ObjReal dist, ObjUnitOfMeasure unit)**

**public boolean ref_calcChangeLaneSafeDist(IVehicle pIVehicle, ObjReal ref_dist)**

**public boolean ref_calcChangeLaneSafeDist_unit(IVehicle pIVehicle, ObjReal ref_dist, ObjUnitOfMeasure ref_unit)**

Calculate the safe lane change distance for the vehicle.

Parameters:

[ in ] pIVehicle: Vehicle for which the safe lane change distance is calculated.

[ in, out ] dist: Safe lane change distance. Unit: Pixel.

Return:

If true is returned, dist will be assigned as the vehicle’s safe lane change distance.

**public boolean reCalcToLeftLane(IVehicle pIVehicle)**

Calculate whether to perform a mandatory left lane change. This applies only when TESSNG determines no mandatory left lane change is needed and cannot override TESSNG's control over the vehicle's mandatory left lane change.

Parameters:

[ in ] pIVehicle: Vehicle object.

Return:

If true is returned, the vehicle will be controlled to perform a mandatory left lane change.

**public boolean reCalcToRightLane(IVehicle pIVehicle)**

Calculate whether to perform a mandatory right lane change. This applies only when TESSNG determines no mandatory right lane change is needed and cannot override TESSNG's control over the vehicle's mandatory right lane change.

Parameters:

[ in ] pIVehicle: Vehicle object.

Return:

If true is returned, the vehicle will be controlled to perform a mandatory right lane change.

**public void beforeToLeftFreely(IVehicle pIVehicle, ObjBool bKeepOn)**

**public void ref_beforeToLeftFreely(IVehicle pIVehicle, ObjBool ref_keepOn)**

Pre-processing before TESSNG calculates free left lane changes.

Parameters:

[ in ] pIVehicle: Vehicle object.

[ in, out ] bKeepOn: Whether to continue. If assigned false, TESSNG will no longer evaluate the possibility of a free left lane change.

**public void beforeToRightFreely(IVehicle pIVehicle, ObjBool bKeepOn)**

**public void ref_beforeToRightFreely(IVehicle pIVehicle, ObjBool ref_keepOn)**

TESSNG processing before calculating whether to perform a free lane change to the right.

[ in ] pIVehicle: Vehicle object.

[ in, out ] bKeepOn: whether to continue; if set to false, TESSNG will no longer calculate the possibility of a free lane change to the right.

**public boolean reCalcToLeftFreely(IVehicle pIVehicle)**

Recalculate whether the vehicle intends to perform a free lane change to the left. This is effective only if TESSNG determines that a free lane change to the left is unnecessary and does not override TESSNG’s control over the vehicle’s free lane change to the left.

Parameters:

[ in ] pIVehicle: Vehicle object.

Return:

If true is returned, control the vehicle to perform a free lane change to the left.

**public boolean reCalcToRightFreely(IVehicle pIVehicle)**

Recalculate whether the vehicle intends to perform a free lane change to the right. This is effective only if TESSNG determines that a free lane change to the right is unnecessary and does not override TESSNG’s control over the vehicle’s free lane change to the right.

Parameters:

[ in ] pIVehicle: Vehicle object.

Return:

If true is returned, the vehicle is permitted to freely change lanes to the right.

**public boolean reCalcDismissChangeLane(IVehicle pIVehicle)**

Recalculate whether the vehicle should cancel the lane change.

Parameters:

[ in ] pIVehicle: Vehicle object.

Return:

If true is returned and the current lane change progress does not exceed one-third, cancel the current lane change action.

Example:

```java
@Override
public boolean reCalcDismissChangeLane(IVehicle pIVehicle) {
	// Cancel all free lane changing when the distance to the end of the road segment is less than 50 m, thereby prohibiting free lane changing
    if (pIVehicle.vehicleDriving().distToEndpoint(true, true, UnitOfMeasure.Metric) < 50) {
        return true;
    }
    return false;
}
```

**public ArrayList\<Int\> calcLimitedLaneNumber(IVehicle pIVehicle)**

Calculate restricted Lane Indexes, such as controlled or hazardous lanes, with the rightmost lane indexed as 0.

Parameters:

[ in ] pVehicle: Vehicle object.

Return:

Sequence of Lane Indexes representing lanes that the vehicle is prohibited from entering.

Example:

```java
@Override
public ArrayList<Int> calcLimitedLaneNumber(IVehicle pIVehicle) {
    // If the vehicle is on the road segment and its length exceeds 8 m, entering the innermost lane is prohibited
    if (pIVehicle.roadIsLink() && pIVehicle.length(UnitOfMeasure.Metric) > 8) {
        int limitLaneNumber = pIVehicle.lane().link().laneCount();
        List<Integer> restrictedLanes = new ArrayList<>();
        restrictedLanes.add(limitLaneNumber);
        return restrictedLanes;
    }
    return new ArrayList<>();
}
```

**public ArrayList\<ILaneConnector\> candIDateLaneConnectors(IVehicle pIVehicle, ArrayList\<ILaneConnector\> lInLC)**

Calculate the subsequent traversable lane connections when the vehicle leaves the road segment; users may filter or recalculate from the traversable lane connection sequence. This is ignored if the vehicle has a defined route.

Parameters:

[ in ] pVehicle: Vehicle object.

[ in ] lInLC: All previously calculated lane connections reachable from the current lane.

Return:

Subsequent reachable lane connection sequence.

**public ILaneConnector candIDateLaneConnector(IVehicle pIVehicle, ILaneConnector pCurrLaneConnector)**

Calculate the lane connections the vehicle will follow next; at this time, the vehicle is leaving the current road segment and will move to pCurrLaneConnector. This method can modify the subsequent lane connections. If the returned lane connection is null, TESSNG will ignore this method call. If the returned lane connection is not on the original route, or if this method sets a new route and the new route does not include the returned lane connection, TESSNG will set the route to null after calling this method.

Parameters:

[ in ] pVehicle: Vehicle object.

[ in ] pCurrLaneConnector: the currently calculated lane connection that the current lane will follow.

Return:

The lane connection to be reset.

**public void beforeNextPoint(IVehicle pIVehicle, ObjBool keepOn)**

**public void ref_beforeNextPoint(IVehicle pIVehicle, ObjBool ref_keepOn)**

Operations performed before the vehicle moves to the next point. Users can use this method to instruct TESSNG to skip the calculation of the specified vehicle’s movement to the next point.

Parameters:

[ in ] pIVehicle: Vehicle object.

[ out ] keepOn: Whether to continue; if keepOn is set to false, TESS NG abandons the calculation of moving to the next point but does not remove the vehicle from the road network.

**public void beforeMergingToLane(IVehicle pIVehicle, ObjBool keepOn)**

**public void ref_beforeMergingToLane(IVehicle pIVehicle, ObjBool ref_keepOn)**

The calculation before merging on a Lane Connection allows TESS NG to skip the merging calculation so that users can implement their own merging logic.

Parameters:

[ in ] pIVehicle: Vehicle object.

[ out ] keepOn: Whether to abandon; if keepOn is set to false, TESS NG abandons the merging.

**public void beforeNextRoad(IVehicle pIVehicle, SWIGTYPE_p_p_QGraphicsItem pRoad, ObjBool keepOn)**

**public void ref_beforeNextRoad(IVehicle pIVehicle, SWIGTYPE_p_QGraphicsItem pRoad, ObjBool ref_keepOn)**

Processing before calculating the next road.

Parameters:

[ in ] pIVehicle: Vehicle object.

[ in ] pRoad: Parameter currently unused.

[ in, out ] keepOn: Whether to continue calculation; if keepOn is set to false, TESS NG will not calculate subsequent roads.

**public void afterCalcTracingType(IVehicle pIVehicle)**

Processing after calculation of Car-Following Type.

Parameters:

[ in ] pIVehicle: Vehicle object.

**public void busArriving(IVehicle pIVehicle, IBusStationLine pStationLine, int alightingCount, int alightingTime, int boardingCount, int boardingTime)**

Processing after bus arrival at the station.

Parameters:

[ in ] pIVehicle: Vehicle object.

[ in ] pStationLine: Station route.

[ in ] alightingCount: Number of alighting passengers. Unit: persons.

[ in ] alightingTime: Total time required for alighting. Unit: s.

[ in ] boardingCount: Number of boarding passengers. Unit: persons.

[ in ] boardingTime: Total time required for boarding. Unit: s.

**public void leaveForNextLaneObj(IVehicle pIVehicle, ILaneObject pCurrLaneObj, ILaneObject pNextLaneObj)**

Called when a vehicle is about to cross a road.

Parameters:

[ in ] pIVehicle: Vehicle object.

[ in ] pCurrLaneObj: Current Lane Object.

[ in ] pNextLaneObj: Lane Object to be entered.

**public boolean travelOnChangingTrace(IVehicle pIVehicle)**

Called when a vehicle is traveling on a lane-changing trajectory.

Parameters:

[ in ] pIVehicle: Vehicle object.

**public boolean leaveOffChangingTrace(IVehicle pIVehicle, double differ, ObjReal s)**

Called when a vehicle leaves a lane-changing trajectory.

Parameters:

[ in ] pIVehicle: Vehicle object.

**public boolean isCalcVehicleVector3D()**

Whether to calculate the vehicle's 3D attributes, such as Euler angles.

Return:

If it returns true, it indicates that the vehicle's 3D attributes need to be calculated.

**public Vector3D calcVehicleEuler(IVehicle pIVehicle, boolean bPosIDire)**

Calculate the vehicle's Euler angles.

Parameters:

[ in ] pIVehicle: Vehicle object.

[ in ] bPosIDire: Whether the vehicle's front direction is calculated in the forward direction; if bPosIDire is false, it is calculated in the reverse direction.

Return:

Vehicle's Euler angles.

**public String vehiRunInfo(IVehicle pIVehicle)**

Control the text content of the textbox in the vehicle operation status popup. During the simulation process, selecting a vehicle and pressing Ctrl+i will display the vehicle operation status popup.

Return:

The text content displayed in the textbox of the vehicle operation status popup.

Example:

```java
@Override
public String vehiRunInfo(IVehicle pIVehicle) {
    return String.format("The vehicle is currently on the road with ID=%d", pIVehicle.roadId());
}
```

**public boolean boundingRect(IVehicle pIVehicle, RectF outRect)**

Get the vehicle bounding rectangle.

Parameters:

[ in ] pIVehicle: Vehicle object.

[ out ] outRect: Vehicle bounding rectangle.

**public boolean shape(IVehicle pIVehicle, QPainterPath outShape)**

Obtain the vehicle graphic route.

Parameters:

[ in ] pIVehicle: Vehicle object.

[ out ] outShape: Vehicle shape route.

~~**public boolean paintVehicle(IVehicle pIVehicle, Painter painter)**~~

~~Draw vehicle.~~

~~Parameters:~~

~~[ in ] pIVehicle: Vehicle object.~~

~~[ in ] painter: QPainter object.~~

~~Return:~~	

~~If true is returned, TESSNG considers the user to have already drawn the vehicle and will not draw it again.~~

~~**public boolean paintVehicleWithRotation(IVehicle pIVehicle, Painter painter, double inOutRotation)**~~

~~Draw the vehicle, rotating the vehicle object by the specified angle prior to drawing.~~

~~Parameters:~~

~~[ in ] pIVehicle: Vehicle object.~~

~~[ in ] painter: QPainter object.~~

~~[ in ] inOutRotation: Rotation angle. Unit: degrees.~~

~~Return:~~

~~If true is returned, TESSNG considers the user to have already drawn the vehicle and will not draw it again.~~

~~**public void rePaintVehicle(IVehicle pIVehicle, Painter painter)**~~

~~Add custom drawing content after TESSNG has drawn the vehicle.~~

~~Parameters:~~

~~[ in ] pIVehicle: Vehicle object.~~

~~[ in ] painter: QPainter object.~~

#### 3.2.3.3. Traffic Signal Control

**public boolean beforeCalcLampColor(ObjBool keepOn)**

**public boolean ref_beforeCalcLampColor(ObjBool ref_keepOn)**

Used to implement custom operations prior to calculating the traffic signal color.

Parameters:

[ in, out ] Indicates whether to continue the calculation.

Return:	

If true is returned and keepOn is set to false, TESS NG will cease calculating the traffic signal color.

**public boolean calcLampColor(ISignalLamp pSignalLamp)**

Calculate the traffic signal color.

Parameters:

[ in ] pSignalLamp: Traffic Signal Object.

Return:

If true is returned, this indicates that the user has modified the traffic signal color, and TESS NG will no longer calculate it.

Example:

```java
@Override
public boolean calcLampColor(ISignalLamp pSignalLamp) {
    // If the traffic signal ID is 1, set it to green.
	if (pSignalLamp.id() == 1) {
		pSignalLamp.setLampColor("G");
		return true;
	}
	return false;
}
```

#### 3.2.3.4. Others

**public void beforeCreateGVehiclesForBusLine(IBusLine pBusLine, ObjBool keepOn)**

**public void ref_beforeCreateGVehiclesForBusLine(IBusLine pBusLine, ObjBool ref_keepOn)**

Used to implement custom operations prior to creating bus vehicles.

Parameters:

[ in ] pBusLine: Bus Route.

[ in, out ] keepOn: Indicates whether to continue creating bus vehicles.

Return:

If it returns true and keepOn is set to false, TESSNG will no longer create transit vehicles.

**public ArrayList\<DecipointFlowRatioByInterval\> calcDynaFlowRatioParameters()**

Calculate dynamic traffic assignment information.

Return:

Sequence of traffic assignment information at the decision points.

Example:

```java
@Override
public ArrayList<DecipointFlowRatioByInterval> calcDynaFlowRatioParameters() {
    ArrayList<DecipointFlowRatioByInterval> result = new ArrayList<>();
    // Current simulation calculation batch.
    long batchNumber = simuiface.batchNumber();
    // Modify the flow ratio of each route at a decision point during the 20th calculation batch.
    if (batchNumber == 20) {
        // Vehicle allocation ratio for each route at a decision point during a specific time period.
        DecipointFlowRatioByInterval dfi = new DecipointFlowRatioByInterval();
        // Decision Point ID
        dfi.setDeciPointID(5);
        // Start Time (Unit: seconds)
        dfi.setStartDateTime(1);
        // End Time (Unit: seconds)
        dfi.setEndDateTime(999999);
        // Route Flow Ratio
        ArrayList<RoutingFlowRatio> ratios = new ArrayList<>();
        ratios.add(new RoutingFlowRatio(1, 3));
        ratios.add(new RoutingFlowRatio(2, 4));
        ratios.add(new RoutingFlowRatio(3, 3));
        dfi.setRoutingFlowRatios(ratios);
        result.add(dfi);
    }
    return result;
}
```

**public ArrayList\<DispatchInterval\> calcDynaDispatchParameters()**

Calculate dynamic vehicle dispatch information.

Return:

Sequence of dynamic vehicle dispatch information.

Example:

```java
@Override
public ArrayList<DispatchInterval> calcDynaDispatchParameters() {
    DispatchInterval di = new DispatchInterval();
    // Departure Point ID
    di.setDispatchId(1);
    // Start Time (Unit: s)
    di.setFromTime(0);
    // End Time (Unit: s)
    di.setToTime(300);
    // Number of Vehicles
    di.setVehiCount(300);
    // Vehicle Composition List
    ArrayList<VehiComposition> composition = new ArrayList<>();
    composition.add(new VehiComposition(1, 60));
    composition.add(new VehiComposition(2, 40));
    di.setVehicleConsDetails(composition);
    ArrayList<DecipointFlowRatioByInterval> result = new ArrayList<>();
    result.add(di);
    return result;
}
```



## 3.3. Interface

Unlike plugins that emphasize **'process extension and logic intervention'**, the interface focuses on **'data interaction and state control'**. It includes the top-level interface TessInterface and two sub-interfaces, NetInterface and SimuInterface, providing users with capabilities to access and modify core information related to the road network and simulation. Users can directly retrieve the road network topology and real-time simulation parameters (such as time step and total number of vehicles), as well as actively modify this information to adjust the system's fundamental state.

​	The top-level interface object has the characteristics of global variables and can be instantiated at any location within the code. However, from the perspectives of code maintainability and ease of use, we recommend initializing each interface within the **constructor**, for example:

```java
// MySimulator.java
public class MySimulator extends JCustomerSimulator {
    // Represents the TESS NG interface
    private TessInterface iface;
    // Represents the TESS NG road network sub-interface
    private NetInterface netiface;
    // Represents the TESS NG simulation sub-interface
    private SimuInterface simuiface;

    public MySimulator() {
        super();
        iface = TESSNG.tessngIFace();
        netiface = iface.netInterface();
        simuiface = iface.simuInterface();
    }
```

### 3.3.1. Top-level Interface (TessInterface)

​	TessInterface is the top-level interface exposed by TESS NG, containing two sub-interfaces: NetInterface and SimuInterface, which are used to access or control the road network and the simulation process, respectively.

**public JsonObject config()**

​	Retrieve a JSON object containing information from the config.json configuration file; this configuration is reloaded each time the road network is loaded.

**public void setConfigProperty(String key, QVariant value)**

​	Set configuration properties.

**public boolean loadPluginFromMem()**

​	Load a plugin.

**public void releasePlugins()**

​	Unload a plugin.

**public NetInterface netInterface()**

​	Returns the NetInterface used to access and control the road network.

Example:

```java
netiface = iface.netInterface();
```

**public SimuInterface simuInterface()**

​	Returns the SimuInterface used to control the simulation process.

Example:

```java
simuiface = iface.simuInterface();
```

### 3.3.2. Road Network Interface (NetInterface)

​	NetInterface is a sub-interface of TessInterface designed for accessing and controlling road network elements. This interface enables querying, creating, deleting, and modifying road network elements such as road segments and connection segments.

#### 3.3.2.1. Road Network

**public String netFilePath()**

​	Retrieves the full path name of the road network file. If the road network is saved as professional data, the method returns the road network ID.

Example:

```java
String netFilePath = netiface.netFilePath();
```

**public void saveRoadNet()**

​	Saves the current road network file.

**public void openNetFle(String filePath)**

​	Opens a road network file.

Parameters:

​	[ in ] filePath: full path name of the road network file.

**public boolean createEmptyNetFile(String filePath, long dbver)**

​	Creates a blank road network.

Parameters:

​	[ in ] filePath: full path name of the blank road network.

[ in ] dbver: Database version.

**public void openNetByNetId(long netId)**

Load road network from a professional database.

**public IRoadNet netAttrs()**

Retrieve road network attribute Object.

**public IRoadNet roadNet()**

Retrieve road network attribute Object. Same as netAttrs.

**public IRoadNet setNetAttrs(String name, String sourceType, Point centerPoint, String backgroundUrl, JsonObject otherAttrsJson)**

Set the basic information of the road network.

Parameters:

[ in ] name: Name of the road network.

[ in ] sourceType: Data source category, default is "TESSNG", indicating the road network is directly created by the TESSNG software. Value "OPENDRIVE" indicates the road network is imported through OpenDRIVE.

[ in ] centerPoint: Coordinates of the center point within the road network, default is (0, 0). Users may also save the center point coordinates in the otherAttrsJson field.

[ in ] backgroundUrl: Path to the base map.

[ in ] otherAttrsJson: Additional attributes stored in a JSON object, such as geodetic coordinate information.

Return:

Road network attribute object.

**public QGraphicsScene graphicsScene()**

Get scenario object.

**public QGraphicsView graphicsView()**

Get view object.

**public double sceneScale()**

Obtain the pixel ratio in the scene. Unit: m/pixel.

**public double sceneWidth(UnitOfMeasure unit)**

Get scenario width. Unit: Pixel.

**public double sceneHeigth(UnitOfMeasure unit)**

Get scenario height. Unit: Pixel.

**public byte[] backgroundMap()**

Get background image bytes.

**public RectF boundingRect()**

Get road network boundary.

**public long getIDByItemName(String name)**

Get auto-increment ID by road network element name.

Parameters:

[ in ] name: Road network element name.

**public boolean initSequence(String schemaName)**

Initialize database sequence for professional database sequences saving road networks; currently supports PostgreSQL.

Parameters:

[ in ] schemaName: Database schema name.

#### 3.3.2.2. Road

**public ArrayList\<ISection\> sections()**

Get all roads.

#### 3.3.2.3. Road Segment

**public int linkCount()**

Get number of road segments.

**public ArrayList\<Long\> linkIds()**

Get sequence of road segment IDs.

**public ArrayList\<ILink\> links()**

Get sequence of road segment objects.

Example:

```java
for (Link link : netiface.links()) {
    System.out.println(link.id());
}
```

**public ILink findLink(long id)**

Obtain the segment object by Road Segment ID.

**public ArrayList\<Point\> linkCenterPoints(long linkID, UnitOfMeasure unit)**

Retrieve the specified segment centerline breakpoint sequence. Unit: Pixel.

Parameters:

[ in ] linkID: Specified Road Segment ID.

**public ILink createLink(ArrayList\<Point\> lCenterPoint, int laneCount, String linkName, boolean bAddToScene, UnitOfMeasure unit)**

Create a road segment. Unit: Pixel.

Parameters:

[ in ] lCenterPoint: Segment centerline breakpoint sequence.

[ in ] laneCount: Number of lanes.

[ in ] linkName: Segment name.

[ in ] bAddToScene: Whether to add to the scenario.

Return:

Segment object.

Example:

```java
List<Point> linkPoints2D = new ArrayList<>();
linkPoints2D.add(new Point(-300, 0));
linkPoints2D.add(new Point(300, 0));
ILink link = netiface.createLink(linkPoints2D, 7, "Caoan Highway", true, UnitOfMeasure.Metric);
```

**public ILink createLink3D(ArrayList\<Vector3D\> lCenterV3, int laneCount, String linkName, boolean bAddToScene, UnitOfMeasure unit)**

Create a 3D road segment. Unit: Pixel.

Parameters:

[ in ] lCenterV3: Segment centerline 3D breakpoint set.

[ in ] laneCount: Number of lanes.

[ in ] linkName: Segment name.

[ in ] bAddToScene: Whether to add to the scenario.

[ in ] unit: Unit parameter; default is Default, Metric indicates meter units, Default indicates no unit restriction.

Return:

Segment object.

Example:

```java
List<Vector3D> linkPoints3D = new ArrayList<>();
linkPoints3D.add(new Vector3D(-300, 0, 10));
linkPoints3D.add(new Vector3D(300, 0, 20));
link = netiface.createLink3D(linkPoints3D, 7, "Caoan Highway", true, UnitOfMeasure.Metric);
```

**public ILink createLinkWithLaneWidth(ArrayList\<Point\> lCenterPoint, ArrayList\<Double\> lLaneWidth, String linkName, boolean bAddToScene, UnitOfMeasure unit)**

Create a road segment with specified lane widths. Unit: Pixel.

Parameters:

[ in ] lCenterPoint: Segment centerline breakpoint sequence.

​	[ in ] lLaneWidth: List of lane widths.

[ in ] linkName: Segment name.

[ in ] bAddToScene: Whether to add to the scenario.

Return:

Segment object.

Example:

```java
List<Point> linkPointsWithWidth = new ArrayList<>();
linkPointsWithWidth.add(new Point(-300, 0));
linkPointsWithWidth.add(new Point(300, 0));

List<Double> laneWidthList = new ArrayList<>();
laneWidthList.add(1.0);
laneWidthList.add(3.5);
laneWidthList.add(3.5);
laneWidthList.add(3.5);

link = netiface.createLinkWithLaneWidth(linkPointsWithWidth, laneWidthList, "Caoan Highway", true, UnitOfMeasure.Metric);
       
```

**public ILink createLink3DWithLaneWidth(ArrayList\<Vector3D\> lCenterV3, ArrayList\<Double\> lLaneWidth, String linkName, boolean bAddToScene, UnitOfMeasure unit)**

​	Create a 3D road segment with specified lane widths. Unit: pixel.

Parameters:

​	[ in ] lCenterV3: Road segment centerline 3D breakpoint sequence.

​	[ in ] lLaneWidth: List of lane widths.

[ in ] linkName: Segment name.

[ in ] bAddToScene: Whether to add to the scenario.

Return:

Segment object.

Example:

```java
List<Vector3D> linkPoints3DWithWidth = new ArrayList<>();
linkPoints3DWithWidth.add(new Vector3D(-300, 0, 10));
linkPoints3DWithWidth.add(new Vector3D(300, 0, 20));

List<Double> laneWidthList = new ArrayList<>();
laneWidthList.add(1.0);
laneWidthList.add(3.5);
laneWidthList.add(3.5);
laneWidthList.add(3.5);

link = netiface.createLink3DWithLaneWidth(linkPoints3DWithWidth, laneWidthList, "Caoan Highway", true, UnitOfMeasure.Metric);    
```

**public ILink createLink3DWithLanePoints(ArrayList\<Vector3D\> lCenterLineV3, ArrayList\<HashMap\<String, ArrayList\<Vector3D\>\>\> lanesWithPoints, String linkName, boolean bAddToScene, UnitOfMeasure unit)**

​	Create a 3D road segment with specified lane breakpoints. Unit: pixel.

Parameters:

​	[ in ] lCenterLineV3: Road segment centerline 3D breakpoint sequence.

​	[ in ] lanesWithPoints: Collection of lane point sets.

[ in ] linkName: Segment name.

[ in ] bAddToScene: Whether to add to the scenario.

Return:

Segment object.

Example:

```java
// Road Segment Centerline
List<Vector3D> linkPoints = new ArrayList<>();
linkPoints.add(new Vector3D(-300, 0, 10));
linkPoints.add(new Vector3D(300, 0, 20));

// Build lane break points list
List<Map<String, List<Vector3D>>> lanesPoints = new ArrayList<>();

// Frist lane group
Map<String, List<Vector3D>> firstLaneGroup = new HashMap<>();

List<Vector3D> leftLane1 = new ArrayList<>();
leftLane1.add(new Vector3D(-300, 0, 10));
leftLane1.add(new Vector3D(300, 0, 20));
firstLaneGroup.put("left", leftLane1);

List<Vector3D> centerLane1 = new ArrayList<>();
centerLane1.add(new Vector3D(-300, 1.75, 10));
centerLane1.add(new Vector3D(300, 1.75, 20));
firstLaneGroup.put("center", centerLane1);

List<Vector3D> rightLane1 = new ArrayList<>();
rightLane1.add(new Vector3D(-300, 3.5, 10));
rightLane1.add(new Vector3D(300, 3.5, 20));
firstLaneGroup.put("right", rightLane1);

lanesPoints.add(firstLaneGroup);

// Second lane group
Map<String, List<Vector3D>> secondLaneGroup = new HashMap<>();

List<Vector3D> leftLane2 = new ArrayList<>();
leftLane2.add(new Vector3D(-300, -3.5, 10));
leftLane2.add(new Vector3D(300, -3.5, 20));
secondLaneGroup.put("left", leftLane2);

List<Vector3D> centerLane2 = new ArrayList<>();
centerLane2.add(new Vector3D(-300, -1.75, 10));
centerLane2.add(new Vector3D(300, -1.75, 20));
secondLaneGroup.put("center", centerLane2);

List<Vector3D> rightLane2 = new ArrayList<>();
rightLane2.add(new Vector3D(-300, 0, 10));
rightLane2.add(new Vector3D(300, 0, 20));
secondLaneGroup.put("right", rightLane2);

lanesPoints.add(secondLaneGroup);

link = netiface.createLink3DWithLanePoints(linkPoints, lanesPoints, "Caoan Highway", true, UnitOfMeasure.Metric);
```

**public ILink createLink3DWithLanePointsAndAttrs(ArrayList\<Vector3D\> lCenterLineV3, ArrayList\<HashMap\<String, ArrayList\<Vector3D\>\>\> lanesWithPoints, ArrayList\<String\> lLaneType, ArrayList\<JsonObject\> lAttr, String linkName, boolean bAddToScene, UnitOfMeasure unit)**

​	Create a 3D road segment with specified lane breakpoints and attributes. Unit: pixel.

Parameters:

​	[ in ] lCenterLineV3: Road segment centerline 3D breakpoint sequence.

​	[ in ] lanesWithPoints: Collection of lane point sets.

​	[ in ] lLaneType: Sequence of lane types.

​	[ in ] lAttr: Sequence of lane additional attributes.

[ in ] linkName: Segment name.

[ in ] bAddToScene: Whether to add to the scenario.

Return:

Segment object.

**public void removeLink(ILink pLink)**

​	Remove the road segment.

Parameters:

​	[ in ] pLink: Segment object.

Example:

```java
// Remove the road segment with ID = 1
ILink link = netiface.findLink(1);
netiface.removeLink(link);
```

**public ILink updateLink(_Link link, ArrayList\<_Lane\> lLane, ArrayList\<Point\> lPoint, UnitOfMeasure unit)**

Update road segment. Unit: Pixel.

Parameters:

[ in ] link: Basic road segment information.

[ in ] lLane: Lane list.

[ in ] lPoint: Breakpoint list.

Return:

Updated road segment object.

**public void moveLinks(ArrayList\<ILink\> lLink, Point offset, UnitOfMeasure unit)**

Move road segment and related connection segments. Unit: Pixel.

Parameters:

[ in ] lLink: Sequence of road segment objects.

[ in ] offset: Offset value.

Example:

```java
// Retrieve all road segments
ArrayList<ILink> links = netiface.links();
// Move all road segments
netiface.moveLinks(links, Point(100, 100));
```

**public boolean judgeLinkToCross(long linkId)**

Determine whether the downstream of the road segment enters an intersection based on the presence of multiple connection segments within the area and the angle between the current road segment and the subsequent road segment.

Parameters:

[ in ] linkID: Road Segment ID.

Return:

Whether the downstream of the road segment enters an intersection.

#### 3.3.2.4. Lane

**public ILane findLane(long id)**

Obtain lane object by Lane ID.

**public ArrayList\<Point\> laneCenterPoints(long laneID, UnitOfMeasure unit)**

Get the sequence of centerline breakpoints for the lane with the specified ID. Unit: Pixel.

Parameters:

[ in ] laneID: Lane ID.

Return:

The sequence of centerline breakpoints for the specified lane.

#### 3.3.2.5. Connection Segment

**public int connectorCount()**

Retrieve the number of connection segments.

**public ArrayList\<Long\> connectorIds()**

Retrieve the sequence of connection segment IDs.

**public ArrayList\<IConnector\> connectors()**

Retrieve the sequence of connection segment objects.

**public IConnector findConnector(long id)**

Retrieve the connection segment object by connection segment ID.

**public IConnector findConnectorByLinkIds(long fromLinkID, long toLinkId)**

Retrieve the connection segment object by upstream road segment ID and downstream road segment ID.

**public IConnector createConnector(long fromLinkID, long toLinkID, ArrayList\<Int\> lFromLaneNumber, ArrayList\<Int\> lToLaneNumber, String connName, boolean bAddToScene)**

Create a connection segment.

Parameters:

[ in ] fromLinkID: Upstream road segment ID.

[ in ] toLinkID: Downstream road segment ID.

[ in ] lFromLaneNumber: Sequence of lane indexes on the upstream road segment.

[ in ] LToLaneNumber: Sequence of lane indexes on the downstream road segment.

[ in ] connName: Connection segment name; if empty, the name defaults to the concatenation of the two road segment IDs.

[ in ] bAddToScene: Whether to add the connection segment to the road network scenario upon creation; default is true.

Return:

Connection Segment Object.

Example:

```java
// Create a connector segment linking Road Segment 1 and Road Segment 2
ArrayList<Integer> fromLaneNumbers = new ArrayList<>(Arrays.asList(1, 2, 3));
ArrayList<Integer> toLaneNumbers = new ArrayList<>(Arrays.asList(1, 2, 3));
connector = netiface.createConnector(1, 2, fromLaneNumbers, toLaneNumbers, "Connector1");
}
```

**public IConnector createConnector3DWithPoints(long fromLinkID, long toLinkID, ArrayList\<Int\> lFromLaneNumber, ArrayList\<Int\> lToLaneNumber, ArrayList\<HashMap\<String, ArrayList\<Vector3D\>\>\> laneConnectorWithPoints, String connName, boolean bAddToScene, UnitOfMeasure unit)**

Create a 3D connection segment at the specified breakpoints. Unit: Pixel.

Parameters:

[ in ] fromLinkID: Upstream road segment ID.

[ in ] toLinkID: Downstream road segment ID.

[ in ] lFromLaneNumber: List of lane indices in the upstream road segment.

[ in ] lToLaneNumber: List of lane indices in the downstream road segment.

[ in ] laneConnectorWithPoints: Collection of lane connection point sets.

[ in ] connName: Name of the connection segment.

[ in ] bAddToScene: Whether to add to the scenario.

Return:

Connection Segment Object.

**public void removeConnector(IConnector pConnector)**

Remove the connection segment.

Parameters:

[ in ] pConnector: Connection segment object.

**public IConnector updateConnector(_Connector connector)**

Update the connection segment. Unit: Pixel.

Parameters:

[ in ] connector: Basic information of the connection segment.

Return:

Connection Segment Object.

#### 3.3.2.6. Lane Connection

**public ILaneConnector findLaneConnector(long id)**

Retrieve the lane connection object by lane connection ID.

**public ILaneConnector findLaneConnector(long fromLaneID, long toLaneId)**

Retrieve the lane connection object by upstream lane ID and downstream lane ID.

**public ArrayList\<CrossPoint\> crossPoints(ILaneConnector pLaneConnector)**

Sequence of intersection points formed by the current lane connection crossing other lane connections.

Parameters:

[ in ] pLaneConnector: Lane Connection Object.

Return:

Sequence of intersections.

#### 3.3.2.7. Connection Segment Area

**public ArrayList\<IConnectorArea\> allConnectorArea()**

Retrieve the complete sequence of connection segment area objects.

**public IConnectorArea findConnectorArea(long id)**

Retrieve the area object by Area ID.

#### 3.3.2.8. Road Network Grid

**public void buildNetGrid(double width, UnitOfMeasure unit)**

Road network gridding.

Parameters:

[ in ] width: Cell width. Unit: Pixel.

**public ArrayList\<ISection\> findSectionOn1Cell(Point point, UnitOfMeasure unit)**

Retrieve all roads within the cell containing the point.

Parameters:

[ in ] point: Coordinates of the point. Unit: Pixel.

Return:

Sequence of road objects.

**public ArrayList\<ISection\> findSectionOn4Cell(Point point, UnitOfMeasure unit)**

Retrieve all roads in the nearest 4 cells based on the point.

Parameters:

[ in ] point: Coordinates of the point. Unit: Pixel.

Return:

Sequence of road objects.

**public ArrayList\<ISection\> findSectionOn9Cell(Point point, UnitOfMeasure unit)**

Retrieve all roads in the nearest 9 cells based on the point.

Parameters:

[ in ] point: Coordinates of the point. Unit: Pixel.

Return:

Sequence of road objects.

**public ArrayList\<Location\> locateOnCrid(Point point, int cellCount, UnitOfMeasure unit)**

Retrieve lane base class objects from multiple cells surrounding the point.

Parameters:

[ in ] point: Coordinates of the point. Unit: Pixel.

[ in ] cellCount: Number of cells. Defaults to 1 if less than 1, defaults to 4 if between 1 and 4, and defaults to 9 if greater than 4.

Return:	

Sequence of positioning data, sorted by shortest distance in ascending order.

Example:

```java
// Target Point
Point targetPoint = new Point(50, 50);
// Project the target point onto lanes within a specified nearby range to obtain the position information sequence.
ArrayList<Location> locations = netiface.locateOnCrid(targetPoint, 9, UnitOfMeasure.Metric);  // Execute netiface.buildNetGrid(10) before use.
for (Location location: locations) {
    System.out.println("The lane/lane connector ID is: " + location.getpLaneObject().id());
    System.out.println("The projection point is: (" + location.getPoint().getX() + ", " + location.getPoint().getY() + ")");
    System.out.println("The distance between the target point and the projection point is: " + location.getLeastDist() + " m");
    System.out.println("The distance between the projection point and the starting point of the lane is: " + location.getDistToStart() + " m");
    System.out.println("The segment number of the projection point in the lane is: " + location.getSegmIndex());
}
```

**public ArrayList\<Location\> locateOnSections(Point point, ArrayList\<ISection\> lSection, double referDistance, UnitOfMeasure unit)**

Calculate the shortest distance from the point to every lane of each road in the road list.

Parameters:

[ in ] point: Coordinates of the point. Unit: Pixel.

[ in ] lSection: Road list.

[ in ] referDistance: Distance from the point on LaneObject nearest to the given point to the start of LaneObject; used solely to improve computational efficiency. Default is 0.

Return:

Sequence of positioning data, sorted by shortest distance in ascending order.

#### 3.3.2.9. Vehicle Type

**public boolean createVehicleType(_VehicleType _vt)**

Create a vehicle type.

Parameters:

[ in ] vt: Vehicle type data. A vehicle type name different from existing types must be specified, otherwise creation will fail. The code of the newly created vehicle type will be automatically set to the current maximum code plus one.

Return:

Indicates whether creation was successful.

Example:

```java
// Construction Parameters
_VehicleType vehicleType = new _VehicleType();
vehicleType.setVehicleTypeName("New type 1");  // Vehicle Type Name
vehicleType.setLength(4.5);  // Length, Unit: m
vehicleType.setLengthSD(0.5);  // Length Standard Deviation, Unit: m
vehicleType.setWidth(2);  // Width, Unit: m
vehicleType.setWidthSD(0.2);  // Width Standard Deviation, Unit: m
vehicleType.setAvgSpeed(60);  // Desired Speed, Unit: km/h
vehicleType.setSpeedSD(10);  // Desired Speed Standard Deviation, Unit: km/h
vehicleType.setAvgAcce(4);  // Desired Acceleration, Unit: m/s²
vehicleType.setAcceSD(0.5);  // Desired Acceleration Standard Deviation, Unit: m/s²
vehicleType.setAvgDece(6);  // Desired Deceleration, Unit: m/s²
vehicleType.setDeceSD(0.5);  // Desired Deceleration Standard Deviation, Unit: m/s²
vehicleType.setMaxAcce(5.5);  // Maximum Acceleration, Unit: m/s²
vehicleType.setMaxDece(7.5);  // Maximum Deceleration, Unit: m/s²
vehicleType.setMaxSpeed(80);  // Maximum speed, Unit: km/h
vehicleType.setCommercialVehicle(false);  // Whether it is a commercial vehicle
vehicleType.setMaxPassengerCapacity(1);  // Rated passenger capacity, Unit: persons
// Create vehicle type
boolean result = netiface.createVehicleType(vehicleType);
System.out.println("Is the creation of the vehicle type successful: " + result);
```

#### 3.3.2.10. Vehicle Composition

**public long createVehicleComposition(String name, ArrayList\<VehicleComposition\> lVehiComp)**

Create a vehicle composition.

Parameters:

[ in ] name: Vehicle type composition name.

[ in ] lVehiComp: Sequence of proportions for different vehicle types.

Return:

Vehicle type composition ID. Returns -1 if the vehicle type composition name already exists, if the related vehicle type code does not exist, or if the related vehicle type proportion is less than 0.

Example:

```java
// Construct vehicle type proportion list
List<VehiComposition> vehiTypeProportionList = new ArrayList<>(Arrays.asList(
    new VehiComposition(1, 0.3),  // Passenger car, proportion 0.3
    new VehiComposition(2, 0.2),  // Large bus, proportion 0.2
    new VehiComposition(3, 0.1),  // Bus, proportion 0.1
    new VehiComposition(4, 0.4)   // Truck, proportion 0.4
));

// Create vehicle composition
int vehiCompositionId = netiface.createVehicleComposition("new vehicle composition", vehiTypeProportionList);
```

**public boolean removeVehicleComposition(long vehiCompId)**

Remove a vehicle composition.

Parameters:

[ in ] vehiCompID: Vehicle type composition ID.

#### 3.3.2.11. Dispatch Point

**public ArrayList\<IDispatchPoint\> dispatchPoints()**

Retrieve the sequence of all dispatch points.

**public IDispatchPoint findDispatchPoint(long id)**

Retrieve a dispatch point by its dispatch point ID.

**public IDispatchPoint createDispatchPoint(ILink pLink, String dpName, boolean bAddToScene)**

Create a dispatch point.

Parameters:

[ in ] pLink: Road segment on which to create the dispatch point.

[ in ] dpName: Dispatch point name; defaults to empty, in which case the dispatch point ID will be used as the name.

[ in ] bAddToScene: Whether to add the connection segment to the road network scenario upon creation; default is true.

Example:

```java
// Retrieve road segment object
ILink link = netiface.findLink(1);
// Create departure point
IDispatchPoint dp = netiface.createDispatchPoint(link);
if (dp != null) {
    // Add departure interval, including vehicle type composition, time interval, and departure count
    dp.addDispatchInterval(1, 600, 300);
    dp.addDispatchInterval(1, 600, 300);
}
```

**public boolean removeDispatchPoint(IDispatchPoint pDispPoint)**

Remove the Dispatch Point.

Parameters:

[ in ] pDispPoint: Dispatch Point object.

#### 3.3.2.12. Decision Point

**public ArrayList\<IDecisionPoint\> decisionPoints()**

Retrieve the sequence of all Decision Points.

**public IDecisionPoint findDecisionPoint(long id)**

Retrieve a Decision Point by its ID.

**public IDecisionPoint createDecisionPoint(ILink pLink, double distance, String name, UnitOfMeasure unit)**

Create a Decision Point.

Parameters:

[ in ] pLink: Road Segment where the Decision Point is located.

[ in ] distance: Distance from the start of the Road Segment to the Decision Point. Unit: Pixel.

[ in ] name: Name of the Decision Point.

Return:

Decision Point object.

Example:

```java
ILink link = netiface.findLink(1);
double location = 50;
String decisionPointName = "new decision point";
IDecisionPoint decisionPoint = netiface.createDecisionPoint(link, location, decisionPointName, UnitOfMeasure.Metric);
```

**public IDecisionPoint updateDecipointPoint(\_DecisionPoint deciPoint, ArrayList\<_RoutingFLowRatio\> lFlowRatio)**

Update the Decision Point and flow ratios of its Routes across different time intervals.

Parameters:

[ in ] deciPoint: Decision Point data.

[ in ] lFlowRatio: Data collection of flow ratios for each Route by time interval.


Return:

Decision Point object.

Example:

```java
// Initialize left, straight, and right flow ratio objects
RoutingFlowRatio flowRatioLeft = new RoutingFlowRatio();
flowRatioLeft.routingFlowRatioID = 1;
flowRatioLeft.routingID = decisionRouting1.id();
flowRatioLeft.startDateTime = 0;
flowRatioLeft.endDateTime = 999999;
flowRatioLeft.ratio = 2.0;

RoutingFlowRatio flowRatioStraight = new RoutingFlowRatio();
flowRatioStraight.routingFlowRatioID = 2;
flowRatioStraight.routingID = decisionRouting2.id();
flowRatioStraight.startDateTime = 0;
flowRatioStraight.endDateTime = 999999;
flowRatioStraight.ratio = 3.0;

RoutingFlowRatio flowRatioRight = new RoutingFlowRatio();
flowRatioRight.routingFlowRatioID = 3;
flowRatioRight.routingID = decisionRouting3.id();
flowRatioRight.startDateTime = 0;
flowRatioRight.endDateTime = 999999;
flowRatioRight.ratio = 1.0;

// Initialize Decision Point data
_DecisionPoint decisionPointData = new DecisionPointData();
_DecisionPoint.deciPointID = decisionPoint.id();
_DecisionPoint.deciPointName = decisionPoint.name();
Point decisionPointPos = new Point();
if (decisionPoint.link().getPointByDist(decisionPoint.distance(), decisionPointPos)) {
    decisionPointData.X = decisionPointPos.getX();
    decisionPointData.Y = decisionPointPos.getY();
    decisionPointData.Z = decisionPoint.link().z();
}

// Construct flow ratio list
List<RoutingFlowRatio> flowRatioList = new ArrayList<>();
flowRatioList.add(flowRatioLeft);
flowRatioList.add(flowRatioStraight);
flowRatioList.add(flowRatioRight);

// Update the flow ratio configuration of routes in the Decision Point
IDecisionPoint updatedDecisionPoint = netiface.updateDecipointPoint(decisionPointData, flowRatioList);
```

#### 3.3.2.13. Vehicle Path

**public IRouting findRouting(long id)**

Retrieve the route object by route ID.

**public IRouting createRouting(ArrayList\<ILink\> lILink)**

Create a route without binding it to a decision point.

Parameters:

[ in ] lILink: Sequence of segment objects that must be continuous.

Return:

Route object.

Example:

```java
// List of Road Segment IDs
List<Integer> linkIdList = new ArrayList<>(Arrays.asList(1, 2, 3, 4));
// Construct the list of road segment objects
ArrayList<Link> linkList = new ArrayList<>();
for (int linkId : linkIdList) {
    linkList.add(netiface.findLink(linkId));
}
// Create vehicle route
IRouting routing = netiface.createRouting(linkList);
```

**public IRouting createDeciRouting(IDecisionPoint pDeciPoint, ArrayList\<ILink\> lILink)**

Add a vehicle path to a decision point.

Parameters:

[ in ] pDeciPoint: Decision point object.

[ in ] lILink: Sequence of segment objects that must start from the road segment of the decision point and be continuous.

Return:

Route object.

**public boolean removeDeciRouting(IDecisionPoint pDeciPoint, IRouting pRouting)**

Remove a vehicle path from a decision point.

Parameters:

[ in ] pDeciPoint: Decision point object.

[ in ] pRouting: Route object.

Return:

Indicates whether the removal was successful.

**public IRouting shortestRouting(ILink pFromLink, ILink pToLink)**

Calculate the shortest path between two road segments.

Parameters:

[ in ] pFromLink: Starting road segment.

[ in ] pToLink: Target Road Segment.

Return:	

Route object.

#### 3.3.2.14. Signal Controller

**public int signalControllerCount()**

Obtain the number of Signal Controllers.

**public ArrayList\<Long\> signalControllerIds()**

Obtain the sequence of Signal Controller IDs.

**public ArrayList\<ISignalController\> signalControllers()**

Obtain the sequence of all Signal Controller Objects.

**public ISignalController findSignalControllerById(long id)**

Obtain a Signal Controller Object by ID.

**public ISignalController findSignalControllerByName(String name)**

Obtain a Signal Controller Object by name; returns the first if duplicates exist.

**public ISignalController createSignalController(String name)**

Create a Signal Controller.

Parameters:

[ in ] name: Signal Controller name.

Return:

Signal Controller Object.

Example:

```java
// Signal Controller Name
String signalControllerName = "Shuanglong Avenue - Jiyin Avenue Intersection";
// Create Signal Controller
ISignalController signalController = netiface.createSignalController(signalControllerName);
```

#### 3.3.2.15. Signal Control Scheme

**public int signalPlanCount()**

Obtain the number of Signal Control Scheme groups.

**public ArrayList\<Long\> signalPlanIds()**

Obtain the sequence of Signal Control Scheme IDs.

**public ArrayList\<ISignalPlan\> signalPlans()**

Obtain the sequence of Signal Control Scheme Objects.

**public ISignalPlan findSignalPlanById(long id)**

Obtain a Signal Control Scheme Object by ID.

**public ISignalPlan findSignalPlanByName(String name)**

Obtain a Signal Control Scheme Object by name.

**public ISignalPlan createSignalPlan(ISignalController pITrafficLight, String name, int cycle, int phasedifference, int startTime, int endTime)**

Create a Signal Control Scheme.

Parameters:

[ in ] pITrafficLight: Signal Controller Object.

[ in ] name: Scheme name.

[ in ] cycle: Cycle duration.

[ in ] phasedifference: Phase difference.

[ in ] startTime: Start time.

[ in ] endTime: End time.

Return:

Signal Control Scheme Object.

Example:

```java
// Get the signal controller object
ISignalController signalController = netiface.findSignalControllerByID(1);
// Traffic signal control scheme name
String signalPlanName = "Off-peak Signal Plan";
// Cycle duration, Unit: s
int cycleTime = 120;
// Phase difference, Unit: s
int phaseDifference = 0;
// Start time, Unit: s
int startTime = 0;
// End Time (Unit: s)
int endTime = 3600;
// Create traffic signal control scheme
ISignalPlan signalPlan = netiface.createSignalPlan(signalController, signalPlanName, cycleTime, phaseDifference, startTime, endTime);
```

#### 3.3.2.16. Traffic Signal Phase

**public ISignalPhase findSignalPhase(long id)**

Retrieve the traffic signal phase object by traffic signal phase ID.

**public ISignalPhase createSignalPlanSignalPhase(ISignalPlan SignalPlan, String name, ArrayList\<ColorInterval\> lColor)**

Create a traffic signal phase.

Parameters:

[ in ] SignalPlan: Signal Control Scheme Object.

[ in ] name: Phase name.

[ in ] lColor: List of light color objects.

Return:

Traffic Signal Phase Object.

Example:

```java
// Retrieve traffic signal control phase object
ISignalPlan signalPlan = netiface.findSignalPlanById(1);
// Phase Name
String signalPhaseName = "East-West Through";
// Build list of light color objects
String[] colors = {"R", "G", "Y", "R"};
int[] intervals = {30, 26, 3, 61};
ArrayList<ColorInterval> colorIntervalList = new ArrayList<>();
for (int i = 0; i < colors.length; i++) {
    colorIntervalList.add(new ColorInterval(colors[i], intervals[i]));
}
// Create traffic signal phase
ISignalPhase signalPhase = netiface.createSignalPlanSignalPhase(signalPlan, signalPhaseName, colorIntervalList);
```

**public void removeSignalPhase(ISignalPlan pPlan, long phaseId)**

Remove an existing traffic signal phase; after removal, the original phase sequence is automatically reordered.

Parameters:

[ in ] pPlan: Signal Control Scheme Object.

[ in ] phaseID: Phase ID to be removed.

#### 3.3.2.17. Traffic Signal Head

**public int signalLampCount()**

Retrieve the number of traffic signals.

**public ArrayList\<Long\> signalLampIds()**

Retrieve the sequence of traffic signal IDs.

**public ArrayList\<ISignalLamp\> signalLamps()**

Retrieve the sequence of traffic signal objects.

**public ISignalLamp findSignalLamp(long id)**

Retrieve a traffic signal object by traffic signal ID.

**public ISignalLamp createSignalLamp(ISignalPhase pPhase, String name, long laneID, long toLaneID, double distance)**

Create a traffic signal.

Parameters:

[ in ] pPhase: Phase object.

[ in ] name: Traffic Signal Name.

[ in ] laneID: Lane ID where the traffic signal is located, or upstream Lane ID of the lane connection.

[ in ] toLaneID: Downstream Lane ID of the lane connection where the traffic signal is located.

[ in ] distance: Distance from the traffic signal to the start of the lane or lane connection. Unit: Pixel.

Return:

Traffic Signal Object.

Example:

```java
// Get phase object
ISignalPhase signalPhase = netiface.findSignalPhase(1);
// Traffic signal name
String signalLampName = "East Through";
// Lane ID
long laneId = 1;
// Downstream Lane ID
long toLaneId = -1;
// Position, Unit: m
double distance = m2p(50);
// Create traffic signal
ISignalLamp signalLamp = netiface.createSignalLamp(signalPhase, signalLampName, laneId, toLaneId, distance);
```

**public ISignalLamp createTrafficSignalLamp(ISignalController pTrafficLight, String name, long laneID, long toLaneID, double distance)**

Create a traffic signal.

Parameters:

[ in ] pTrafficLight: Signal Controller.

[ in ] name: Traffic Signal Name.

[ in ] laneID: Lane ID where the traffic signal is located, or upstream Lane ID of the lane connection.

[ in ] toLaneID: Downstream Lane ID of the Lane Connection where the Traffic Signal is located.

[ in ] distance: Distance from the traffic signal to the start of the lane or lane connection. Unit: Pixel.

Return:

Traffic Signal Object.

**public void addSignalPhaseToLamp(int SignalPhaseID, ISignalLamp signalLamp)**

Add a bound phase to the Traffic Signal.

Parameters:

[ in ] SignalPhaseID: Signal Phase ID.

[ in ] signalLamp: Traffic Signal Object.

**public void removeSignalPhaseFromLamp(int SignalPhaseID, ISignalLamp signalLamp)**

Remove a bound phase from the Traffic Signal; if only one phase remains in the phase list, set the associated phase to null.

Parameters:

[ in ] SignalPhaseID: Signal Phase ID.

[ in ] signalLamp: Traffic Signal Object.

**public void transferSignalPhase(ISignalPhase pFromISignalPhase, ISignalPhase pToISignalPhase, ISignalLamp signalLamp)**

Replace the bound phase of the Traffic Signal without crossing the Signal Controller.

Parameters:

[ in ] pFromISignalPhase: Original phase.

[ in ] pToISignalPhase: Target phase.

[ in ] signalLamp: Traffic Signal Object.

#### 3.3.2.18. Data Collector

**public ArrayList\<IVehicleDrivInfoCollector\> vehiInfoCollectors()**

Retrieve the sequence of all Data Collector objects.

**public IVehicleDrivInfoCollector findVehiInfoCollector(long id)**

Obtain a Data Collector object by ID.

**public IVehicleDrivInfoCollector createVehiCollectorOnLink(ILane pLane, double dist, UnitOfMeasure unit)**

Create a Data Collector on a lane of a road segment.

Parameters:

[ in ] pLane: Lane Object.

[ in ] dist: Distance from the start of the lane. Unit: Pixel.

Return:

Data Collector object.

Example:

```java
// Get Lane object
ILane lane = netiface.findLane(1);
// Position, Unit: m
double dist = 50;
// Create data collector on Road Segment
IVehicleDrivInfoCollector collector = netiface.createVehiCollectorOnLink(lane, dist, UnitOfMeasure.Metric);
```

**public IVehicleDrivInfoCollector createVehiCollectorOnConnector(ILaneConnector pLaneConnector, double dist, UnitOfMeasure unit)**

Create a Data Collector on a lane connection of a connection segment.

Parameters:

[ in ] pLaneConnector: Lane Connection Object.

[ in ] dist: Distance from the start of the lane connection. Unit: Pixel.

Return:

Data Collector object.

Example:

```java
// Get Lane Connection object
ILaneConnector laneConnector = netiface.findLaneConnector(1, 4);
// Position, Unit: m
double dist = 50;
// Create data collector on Connector Segment
IVehicleDrivInfoCollector collector = netiface.createVehiCollectorOnConnector(laneConnector, dist, UnitOfMeasure.Metric);
```

**public boolean removeVehiCollector(IVehicleDrivInfoCollector pCollector)**

Remove the vehicle information collector.

Parameters:

[ in ] pCollector: Vehicle information collector object.

Return:

Indicates whether the removal was successful.

#### 3.3.2.19. Queue Counter

**public ArrayList\<IVehicleQueueCounter\> vehiQueueCounters()**

Retrieve the sequence of all Queue Counter objects.

**public IVehicleQueueCounter findVehiQueueCounter(long id)**

Obtain a Queue Counter object by ID.

**public IVehicleQueueCounter createVehiQueueCounterOnLink(ILane pLane, double dist, UnitOfMeasure unit)**

Create a vehicle queue counter on the lane of a road segment.

Parameters:

[ in ] pLane: Lane Object.

[ in ] dist: Distance from the start of the lane. Unit: Pixel.

Return:

Queue counter object.

Example:

```java
// Get Lane object
ILane lane = netiface.findLane(1);
// Position, Unit: m
double dist = 80;
// Create a queue counter on a road segment
IVehicleQueueCounter counter = netiface.createVehiQueueCounterOnLink(lane, dist, UnitOfMeasure.Metric);
```

**public IVehicleQueueCounter createVehiQueueCounterOnConnector(ILaneConnector pLaneConnector, double dist, UnitOfMeasure unit)**

Create a vehicle queue counter on the lane connection of a connection segment.

Parameters:

[ in ] pLaneConnector: Lane Connection Object.

[ in ] dist: Distance from the start of the lane connection. Unit: Pixel.

Return:

Queue counter object.

Example:

```java
// Get Lane Connection object
laneConnector = netiface.findLaneConnector(1, 4);
// Position, Unit: m
double dist = 80;
// Create a queue counter on a connector segment
IVehicleQueueCounter counter = netiface.createVehiQueueCounterOnConnector(laneConnector, dist, UnitOfMeasure.Metric);
```

#### 3.3.2.20. Travel Time Detector

**public ArrayList\<IVehicleTravelDetector\> vehiTravelDetectors()**

Retrieve the sequence of all vehicle travel time detector objects.

**public IVehicleTravelDetector findVehiTravelDetector(long id)**

Retrieve the vehicle travel time detector object by ID.

**public ArrayList\<IVehicleTravelDetector\> createVehicleTravelDetector_link2link(ILink pStartLink, ILink pEndLink, double dist1, double dist2, UnitOfMeasure unit)**

Create a travel time detector from one road segment to another.

Parameters:

[ in ] pStartLink: Origin road segment object.

[ in ] pEndLink: Destination road segment object.

[ in ] dist1: Distance from the detector start point to the start point of the road segment. Unit: Pixel.

[ in ] dist2: Distance from the detector endpoint to the start point of the road segment. Unit: Pixel.

Return:

Travel Time Detector Object.

Example:

```java
// Get the starting road segment object
ILink startLink = netiface.findLink(1);
// Get the ending road segment object
ILink endLink = netiface.findLink(2);
// Detector start position on the starting road segment, unit: m
double startDist = 10;
// Detector end position on the ending road segment, unit: m
double endDist = 90;
// Create a travel time detector with both start and end points on road segments
ArrayList<IVehicleTravelDetector> detectors = netiface.createVehicleTravelDetector_link2link(startLink, endLink, startDist, endDist, UnitOfMeasure.Metric);
```

**public ArrayList\<IVehicleTravelDetector\> createVehicleTravelDetector_link2conn(ILink pStartLink, ILaneConnector pEndLaneConnector, double dist1, double dist2, UnitOfMeasure unit)**

Create a travel time detector from a Road Segment to a Connection Segment.

Parameters:

[ in ] pStartLink: Origin road segment object.

[ in ] pEndLaneConnector: Ending Lane Connection Object.

[ in ] dist1: Distance from the detector start point to the start point of the road segment. Unit: Pixel.

[ in ] dist2: Distance from the detector endpoint to the start point of the Lane Connection. Unit: Pixel.

Return:

Travel Time Detector Object.

Example:

```java
// Get the starting road segment object
ILink startLink = netiface.findLink(1);
// Get the ending lane connection object
ILaneConnector endLaneConnector = netiface.findLaneConnector(1, 4);
// Detector start position on the starting road segment, unit: m
double startDist = 10;
// Detector end position on the ending lane connection, unit: m
double endDist = 10;
// Create a travel time detector with start on road segment and end on connector segment
ArrayList<IVehicleTravelDetector> detectors = netiface.createVehicleTravelDetector_link2conn(startLink, endLaneConnector, startDist, endDist, UnitOfMeasure.Metric);
```

**public ArrayList\<IVehicleTravelDetector\> createVehicleTravelDetector_conn2link(ILaneConnector pStartLaneConnector, ILink pEndLink, double dist1, double dist2, UnitOfMeasure unit)**

Create a travel time detector from a Connection Segment to a Road Segment.

Parameters:

[ in ] pStartLaneConnector: Starting Lane Connection Object.

[ in ] pEndLink: Destination road segment object.

[ in ] dist1: Distance from the detector start point to the start point of the Lane Connection. Unit: Pixel.

[ in ] dist2: Distance from the detector endpoint to the start point of the road segment. Unit: Pixel.

Return:

Travel Time Detector Object.

Example:

```java
// Get the starting Lane Connection object
ILink startLaneConnector = netiface.findLaneConnector(1, 4);
// Get the ending road segment object
ILaneConnector endLink = netiface.findLink(2);
// Position of the detector start point on the starting Lane Connection, unit: m
double startDist = 10;
// Detector end position on the ending road segment, unit: m
double endDist = 90;
// Create a travel time detector with start point on Connector Segment and end point on Road Segment
ArrayList<IVehicleTravelDetector> detectors = netiface.createVehicleTravelDetector_conn2link(startLaneConnector, endLink, startDist, endDist, UnitOfMeasure.Metric);
```

**public ArrayList\<IVehicleTravelDetector\> createVehicleTravelDetector_conn2conn(ILaneConnector pStartLaneConnector, ILaneConnector pEndLaneConnector, double dist1, double dist2, UnitOfMeasure unit)**

Create a travel time detector from a Connection Segment to another Connection Segment.

Parameters:

[ in ] pStartLaneConnector: Starting Lane Connection Object.

[ in ] pEndLaneConnector: Ending Lane Connection Object.

[ in ] dist1: Distance from the detector start point to the start point of the Lane Connection. Unit: Pixel.

[ in ] dist2: Distance from the detector endpoint to the start point of the Lane Connection. Unit: Pixel.

Return:

Travel Time Detector Object.

Example:

```java
// Get the starting Lane Connection object
ILaneConnector startLaneConnector = netiface.findLaneConnector(1, 4);
// Get the ending road segment object
ILaneConnector endLaneConnector = netiface.findLaneConnector(4, 7);
// Position of the detector start point on the starting Lane Connection, unit: m
double startDist = 10;
// Detector end position on the ending lane connection, unit: m
double endDist = 90;
// Create a travel time detector with both start and end points on Connector Segment
ArrayList<IVehicleTravelDetector> detectors = netiface.createVehicleTravelDetector_conn2conn(startLaneConnector, endLaneConnector, startDist, endDist, UnitOfMeasure.Metric);
```

#### 3.3.2.21. Guide Arrow

**public int guidArrowCount()**

Get the number of guide arrows.

**public ArrayList\<Long\> guidArrowIds()**

Get the sequence of guide arrow IDs.

**public ArrayList\<IGuidArrow\> guidArrows()**

Retrieve the sequence of guidance arrow objects.

**public IGuidArrow findGuidArrow(long id)**

Retrieve the guidance arrow object by guidance arrow ID.

**public IGuidArrow createGuidArrow(ILane pLane, double length, double distToTerminal, GuideArrowType arrowType, UnitOfMeasure unit)**

Create a guidance arrow.

Parameters:

[ in ] pLane: Lane Object.

[ in ] length: Length in pixels.

[ in ] distToTerminal: Distance to lane terminal in pixels.

[ in ] arrowType: Type of the arrow.

Return:

Guidance arrow object.

Example:

```java
ILane lane = netiface.findLane(4);
if (lane != null) {
    double length = 4;
    double distToTerminal = 10;
    GuideArrowType arrowType = GuideArrowType.StraightRight;
	IGuidArrow guidArrow = netiface.createGuidArrow(lane, length, distToTerminal, arrowType, UnitOfMeasure.Metric);
}
```

**public void removeGuidArrow(IGuidArrow pArrow)**

Remove a guidance arrow.

Parameters:

[ in ] pArrow: Guidance arrow object.

#### 3.3.2.22. Bus Route

**public ArrayList\<IBusLine\> buslines()**

Retrieve the sequence of bus route objects.

**public IBusLine findBusline(long buslineId)**

Retrieve the bus route by bus route ID.

**public IBusLine findBuslineByFirstLinkId(long linkId)**

Retrieve the bus route by starting road segment ID.

**public IBusLine createBusLine(ArrayList\<ILink\> lLink)**

Create a bus route. The adjacent road segments in the lLink list may be adjacent or non-adjacent in the road network. If non-adjacent, TESSNG will generate the shortest path between them. If adjacent segments in the lLink list are not contiguous in the road network and there is no shortest path between them, the second adjacent segment and all subsequent segments are considered invalid.

Parameters:
	[ in ] lLink: Sequence of segment objects traversed by the bus route.

Return:

Bus route object.

Example:

```java
ILink link1 = netiface.findLink(1);
ILink link2 = netiface.findLink(2);
ArrayList<ILink> links = new ArrayList<>(Arrays.asList(link1, link2));
IBusLine busLine = netiface.createBusLine(links);
```

**public boolean removeBusLine(IBusLine pBusLine)**

Remove the bus route.

Parameters:

[ in ] pBusLine: Bus route object.

#### 3.3.2.23. Bus Stop

**public ArrayList\<IBusStation\> busStations()**

Retrieve the sequence of bus stop objects.

**public IBusStation findBusStation(long stationId)**

Retrieve a bus stop object by the bus stop ID.

**public IBusStation createBusStation(ILane pLane, double length, double dist, String name, UnitOfMeasure unit)**

Create a bus stop.

Parameters:

[ in ] pLane: Lane Object.

[ in ] length: Length of the stop. Unit: Pixel.

[ in ] dist: Distance from the stop start point to the lane start point. Unit: Pixel.

​	[ in ] name: Station Name.	

Return:

​	Bus Station Object.

Example:

```java
ILane lane = netiface.findLane(1);
IBusStation busStation = netiface.createBusStation(lane1, 30, 50, "Bus station 1", UnitOfMeasure.Metric);
// Set station type 1: Curbside, 2: Bay
busStation.setType(1);
```

**public boolean removeBusStation(IBusStation pStation)**

​	Remove Bus Station.

Parameters:

​	[ in ] pStation: Bus Station Object.

#### 3.3.2.24. Bus Route - Station

**public ArrayList\<IBusStationLine\> findBusStationLineByStationId(long stationId)**

​	Retrieve Bus Route - Station Object by Bus Station ID.

**public boolean addBusStationToLine(IBusLine pBusLine, IBusStation pStation)**

​	Associate Bus Station with the Bus Route.

Parameters:

[ in ] pBusLine: Bus route object.

​	[ in ] pStation: Bus Station Object.

**public boolean removeBusStationFromLine(IBusLine pBusLine, IBusStation pStation)**

​	Disassociate Bus Station from the Bus Route.

Parameters:

[ in ] pBusLine: Bus route object.

​	[ in ] pStation: Bus Station Object.

#### 3.3.2.25. Accident Zone

**public ArrayList\<IAccidentZone\> accidentZones()**

​	Retrieve all Accident Zone Objects.

**public IAccidentZone findAccidentZone(long accidentZoneId)**

​	Retrieve Accident Zone Object by Accident Zone ID.

**public IAccidentZone createAccidentZone(DynaAccidentZoneParam param)**

​	Create Accident Zone.

Parameters:

​	[ in ] param: Dynamic Accident Zone Information.

Return:

​	Accident Zone Object.

Example:

```java
// Construction Parameters
DynaAccidentZoneParam param = new DynaAccidentZoneParam();
// Accident Area Name
param.setName("Accident Area");
// Road ID
param.setRoadId(1); 
// Position, distance from the start point of the road segment or connector segment, unit: m
param.setLocation(100);
// Length, unit: m
param.setLength(50);
// List of lane indices, starting from 0, continuous and sequential
ArrayList<Integer> fromLaneNumbers = new ArrayList<>(Arrays.asList(0));
accidentZoneParam.setMlFromLaneNumber(fromLaneNumbers);
// Start Time (Unit: s)
param.setStartTime(10); 
// Duration, unit: s
param.setDuration(600); 
// Speed limit of adjacent lanes, unit: km/h
param.setLimitedSpeed(40);
// Create accident area
IAccidentZoneInterval accidentZone = netiface.createAccidentZone(param, UnitOfMeasure.Metric);
```

**public void removeAccidentZone(IAccidentZone pIAccidentZone)**

​	Remove Accident Zone.

Parameters:

[ in ] pIAccidentZone: Accident Zone object.

#### 3.3.2.26. Construction Zone

**public ArrayList\<IRoadWorkZone\> roadWorkZones()**

Retrieve the sequence of all Construction Zone objects.

**public IRoadWorkZone findRoadWorkZone(long roadWorkZoneId)**

Retrieve a Construction Zone object by its ID.

**public IRoadWorkZone createRoadWorkZone(DynaRoadWorkZoneParam param, UnitOfMeasure unit)**

Create a Construction Zone.

Parameters:

[ in ] param: Construction Zone parameters. Unit: Pixel.

Return:

Construction Zone object.

Example:

```java
// Construction Parameters
DynaRoadWorkZoneParam param = new DynaRoadWorkZoneParam();
// Construction Zone Name
param.setName("Construction Zone");
// Road ID
param.setRoadId(1);
// Position, distance from the start point of the road segment or connector segment, unit: m
param.setLocation(200);
// Length, unit: m
param.setLength(50);  // Length
param.setUpCautionLength(70);  // Advance Warning Length
param.setUpTransitionLength(50);  // Transition Zone Length
param.setUpBufferLength(50);  // Buffer Zone Length
param.setDownTransitionLength(40);  // Downstream Transition Zone Length
param.setDownTerminationLength(40);  // Termination Zone Length
// List of lane indices, starting from 0, continuous and sequential
ArrayList<Integer> fromLaneNumbers = new ArrayList<>(Arrays.asList(0));
param.setMlFromLaneNumber(fromLaneNumbers);
// Start Time (Unit: s)
param.setStartTime(0);
// Duration, unit: s
param.setDuration(3600);
// Speed limit of adjacent lanes, unit: km/h
param.setLimitSpeed(40);
// Create Construction Zone
IRoadWorkZone roadWorkZone = netiface.createRoadWorkZone(param, UnitOfMeasure.Metric);
```

**public void removeRoadWorkZone(IRoadWorkZone pIRoadWorkZone)**

Remove a Construction Zone.

Parameters:

[ in ] pIRoadWorkZone: Construction Zone object.

**public boolean updateRoadWorkZone(DynaRoadWorkZoneParam param, UnitOfMeasure unit)**

Update a Construction Zone.

Parameters:

[ in ] param: Construction Zone parameters. Unit: Pixel.

#### 3.3.2.27. Restriction Zone

**public ArrayList\<ILimitedZone\> limitedZones()**

Retrieve the sequence of all Restriction Zone objects.

**public ILimitedZone findLimitedZone(long limitedZoneId)**

Retrieve a Restriction Zone object by its ID.

**public ILimitedZone createLimitedZone(DynaLimitedZoneParam param, UnitOfMeasure unit)**

Create a Restriction Zone.

Parameters:

[ in ] param: Restriction Zone parameters. Unit: Pixel.

Return:

Restriction Zone object.

Example:

```java
// Construction Parameters
DynaLimitedZoneParam param = new DynaLimitedZoneParam();
// Restricted Zone Name
param.setName("Restricted Zone");
// Road ID
param.setRoadId(1); 
// Position, distance from the start point of the road segment or connector segment, unit: m
param.setLocation(100);
// Length, unit: m
param.setLength(50);
// List of lane indices, starting from 0, continuous and sequential
ArrayList<Integer> fromLaneNumbers = new ArrayList<>(Arrays.asList(0));
accidentZoneParam.setMlFromLaneNumber(fromLaneNumbers);
// Start Time (Unit: s)
param.setStartTime(10); 
// Duration, unit: s
param.setDuration(600); 
// Speed limit of adjacent lanes, unit: km/h
param.setLimitedSpeed(40);
// Create Restricted Zone
ILimitedZone limitedZone = netiface.createLimitedZone(param, UnitOfMeasure.Metric);
```

**public void removeLimitedZone(ILimitedZone pILimitedZone)**

Remove the restricted driving zone.

Parameters:

[ in ] pILimitedZone: Restricted driving zone object.

**public boolean updateLimitedZone(DynaLimitedZoneParam param, UnitOfMeasure unit)**

Update the restricted driving zone.

Parameters:

[ in ] param: Restriction Zone parameters. Unit: Pixel.

#### 3.3.2.28. Reconstruction and Expansion Borrowed Lane

**public ArrayList\<IReconstruction\> reconstructions()**

Retrieve all reconstruction and expansion objects.

**public IReconstruction findReconstruction(long reconstructionId)**

Retrieve reconstruction and expansion object by reconstruction and expansion ID.

**public IReconstruction createReconstruction(DynaReconstructionParam param, UnitOfMeasure unit)**

Create reconstruction and expansion.

Parameters:

[ in ] param: Reconstruction and expansion parameters. Unit: Pixel.

Return:

Reconstruction and expansion object.

Example:

```java
// Construction Parameters
DynaReconstructionParam param = new DynaReconstructionParam();
// Construction Zone ID
param.setRoadWorkZoneId(rwzId);
// Borrowed Road Segment ID
param.setBeBorrowedLinkId(2);
// Number of Borrowed Lanes
param.setBorrowedNum(1);
// Traffic Maintenance Opening Length, Unit: m
param.setPassagewayLength(80);
// Traffic Maintenance Opening Speed Limit, Unit: m/s
param.setPassagewayLimitedSpeed(40 / 3.6);
// Create Reconstruction and Expansion Lane Borrowing
IReconstruction reconstruction = netiface.createReconstruction(param, UnitOfMeasure.Metric);
```

**public void removeReconstruction(IReconstruction pIReconstruction)**

Remove reconstruction and expansion.

Parameters:

[ in ] pIReconstruction: Reconstruction and expansion object.

**public boolean updateReconStruction(DynaReconstructionParam param, UnitOfMeasure unit)**

Update reconstruction and expansion.

Parameters:

[ in ] param: Reconstruction and expansion parameters. Unit: Pixel.

**public double reCalcPassagewayLength(DynaReconstructionParam param, UnitOfMeasure unit)**

Recalculate the traffic guarantee opening length; it can be derived from detailed traffic guarantee parameters.

Parameters:

[ in ] param: Reconstruction and expansion parameters. Unit: Pixel.

Return:

Traffic guarantee opening length.

#### 3.3.2.29. Speed Limit Zone

**public ArrayList\<IReduceSpeedArea\> reduceSpeedAreas()**

Retrieve all speed limit zone objects.

**public IReduceSpeedArea findReduceSpeedArea(long id)**

Retrieve the Speed Limit Zone object by Speed Limit Zone ID.

**public IReduceSpeedArea createReduceSpeedArea(DynaReduceSpeedAreaParam param)**

Create a Speed Limit Zone.

Parameters:

[ in ] param: Speed Limit Zone parameters. Unit: Pixel.

Return:

Speed Limit Zone object.

**public void removeReduceSpeedArea(IReduceSpeedArea pIReduceSpeedArea)**

Remove a Speed Limit Zone.

Parameters:

[ in ] pIReduceSpeedArea: Speed Limit Zone object.

**public boolean updateReduceSpeedArea(DynaReduceSpeedAreaParam param)**

Update a Speed Limit Zone.

Parameters:

[ in ] param: Speed Limit Zone parameters. Unit: Pixel.

#### 3.3.2.30. Pedestrian Type

**public ArrayList\<IPedestrianType\> pedestrianTypes()**

Retrieve the sequence of all Pedestrian Type objects.

#### 3.3.2.31. Pedestrian Composition

**public ArrayList\<PedestrianComposition\> pedestrianCompositions()**

Retrieve the sequence of all Pedestrian Composition information.

**public long createPedestrianComposition(String name, HashMap\<int, double\> mpCompositionRatio)**

Create Pedestrian Composition.

Parameters:

[ in ] name: composition name.

[ in ] mpCompositionRatio: composition details, where the key is the pedestrian type code and the value is the pedestrian type proportion.

Return:

Pedestrian Composition ID; returns -1 if creation fails.

**public boolean removePedestrianComposition(long compositionId)**

Remove pedestrian composition.

Parameters:

[ in ] compositionID: Pedestrian composition ID.

**public boolean updatePedestrianComposition(long compositionID, HashMap\<int, double\> mpCompositionRatio)**

Update pedestrian composition.

Parameters:

[ in ] compositionID: Pedestrian composition ID.

[ in ] mpCompositionRatio: composition details, where the key is the pedestrian type code and the value is the pedestrian type proportion.

Return:

Indicates whether the update was successful.

#### 3.3.2.32. Pedestrian Surface Area Hierarchy

**public ArrayList\<LayerInfo\> layerInfos()**

Retrieve all hierarchy information.

**public LayerInfo addLayerInfo(String name, double height, boolean visible, boolean locked)**

Add a new hierarchy and return the information of the newly added hierarchy.

Parameters:

[ in ] name: Hierarchy name.

[ in ] height: Hierarchy height.

[ in ] visible: Visibility.

[ in ] locked: Whether locked; when locked, the surface area cannot be modified.

**public void removeLayerInfo(long layerId)**

Delete a hierarchy, which will remove all elements within the hierarchy.

Parameters:

[ in ] layerID: Hierarchy ID.

**public boolean updateLayerInfo(long layerID, String name, double height, boolean visible, boolean locked)**

Update hierarchy information.

Parameters:

[ in ] layerID: Hierarchy ID.

[ in ] name: Hierarchy name.

[ in ] height: Hierarchy height.

[ in ] visible: Visibility.

[ in ] locked: Whether locked; when locked, the surface area cannot be modified.

Return:

Indicates whether the update was successful.

#### 3.3.2.33. Pedestrian Surface Area

**public ArrayList\<IPedestrianRegion\> pedestrianRegions()**

Retrieve the sequence of all Pedestrian Surface Area objects.

**public ArrayList\<IPedestrianRectRegion\> pedestrianRectRegions()**

Retrieve the sequence of all rectangular surface area objects.

**public ArrayList\<IPedestrianTriangleRegion\> pedestrianTriangleRegions()**

Retrieve the sequence of all triangular surface area objects.

**public ArrayList\<IPedestrianEllipseRegion\> pedestrianEllipseRegions()**

Retrieve the sequence of all elliptical surface area objects.

**public ArrayList\<IPedestrianFanShapeRegion\> pedestrianFanShapeRegions()**

Retrieve the sequence of all sector surface area objects.

**public ArrayList\<IPedestrianPolygonRegion\> pedestrianPolygonRegions()**

Retrieve the sequence of all polygonal surface area objects.

**public ArrayList\<IPedestrianSIDeWalkRegion\> pedestrianSIDeWalkRegions()**

Retrieve the sequence of all sidewalk objects.

**public ArrayList\<IPedestrianCrossWalkRegion\> pedestrianCrossWalkRegions()**

Retrieve the sequence of all pedestrian crossing objects.

**public IPedestrianRegion findPedestrianRegion(long id)**

Retrieve the Pedestrian Surface Area object by Area ID.

**public IPedestrianRectRegion findPedestrianRectRegion(long id)**

Retrieve the rectangular surface area object by Area ID.

**public IPedestrianEllipseRegion findPedestrianEllipseRegion(long id)**

Retrieve the elliptical surface area object by Area ID.

**public IPedestrianTriangleRegion findPedestrianTriangleRegion(long id)**

Retrieve the triangular surface area object by Area ID.

**public IPedestrianFanShapeRegion findPedestrianFanShapeRegion(long id)**

Retrieve the sector surface area object by Area ID.

**public IPedestrianPolygonRegion findPedestrianPolygonRegion(long id)**

Retrieve the polygon area object by Pedestrian Surface Area ID.

**public IPedestrianSIDeWalkRegion findPedestrianSIDeWalkRegion(long id)**

Retrieve the sidewalk object by Pedestrian Surface Area ID.

**public IPedestrianCrossWalkRegion findPedestrianCrossWalkRegion(long id)**

Retrieve the pedestrian crosswalk object by Pedestrian Surface Area ID.

**public IPedestrianRectRegion createPedestrianRectRegion(Point startPoint, Point endPoint)**

Create a rectangular pedestrian surface area.

Parameters:

[ in ] startPoint: Coordinates of the upper-left corner.

[ in ] endPoint: Coordinates of the lower-right corner.

Return	

Rectangular pedestrian surface area object.

**public IPedestrianTriangleRegion createPedestrianTriangleRegion(Point startPoint, Point endPoint)**

Create a triangular pedestrian surface area.

Parameters:

[ in ] startPoint: Coordinates of the upper-left corner.

[ in ] endPoint: Coordinates of the lower-right corner.

Return:

Triangular pedestrian surface area object.

**public IPedestrianEllipseRegion createPedestrianEllipseRegion(Point startPoint, Point endPoint)**

Create an elliptical pedestrian surface area.

Parameters:

[ in ] startPoint: Coordinates of the upper-left corner.

[ in ] endPoint: Coordinates of the lower-right corner.

Return:	

Elliptical pedestrian surface area object.

**public IPedestrianFanShapeRegion createPedestrianFanShapeRegion(Point startPoint, Point endPoint)**

Create a sector-shaped pedestrian surface area.

Parameters:

[ in ] startPoint: Coordinates of the center point.

[ in ] endPoint: Coordinates of the endpoint of the outer radius.

Return:

Fan-shaped pedestrian surface area object.

**public IPedestrianPolygonRegion createPedestrianPolygonRegion(Vector\<Point\> polygon)**

Create polygon pedestrian surface area.

Parameters:

[ in ] polygon: polygon vertices.

Return:

Polygon pedestrian surface area object.

**public IPedestrianSIDeWalkRegion createPedestrianSIDeWalkRegion(ArrayList\<Point\> vertexs)**

Create sidewalk.

Parameters:

[ in ] vertices: list of vertices.

Return:	

Sidewalk object.

**public IPedestrianCrossWalkRegion createPedestrianCrossWalkRegion(Point startPoint, Point endPoint)**

Create crosswalk.

Parameters:

[ in ] startPoint: Coordinates of the upper-left corner.

[ in ] endPoint: Coordinates of the lower-right corner.

Return:

Crosswalk object.

**public IPedestrianStairRegion createPedestrianStairRegion(Point startPoint, Point endPoint)**

Create stairs.

Parameters:

[ in ] startPoint: starting coordinate.

[ in ] endPoint: ending coordinate.

Return:	

Stairs object.

**public void removePedestrianRectRegion(IPedestrianRectRegion pIPedestrianRectRegion)**

Delete rectangular pedestrian surface area.

Parameters:

[ in ] pIPedestrianRectRegion: rectangular pedestrian surface area object.

**public void removePedestrianTriangleRegion(IPedestrianTriangleRegion pIPedestrianTriangleRegion)**

Delete triangular pedestrian surface area.

Parameters:

[ in ] pIPedestrianTriangleRegion: Triangular pedestrian surface area Object.

**public void removePedestrianEllipseRegion(IPedestrianEllipseRegion pIPedestrianEllipseRegion)**

Delete elliptical pedestrian surface area.

Parameters:

[ in ] pIPedestrianEllipseRegion: Elliptical pedestrian surface area Object.

**public void removePedestrianFanShapeRegion(IPedestrianFanShapeRegion pIPedestrianFanShapeRegion)**

Delete fan-shaped pedestrian surface area.

Parameters:

[ in ] pIPedestrianFanShapeRegion: Fan-shaped pedestrian surface area Object.

**public void removePedestrianPolygonRegion(IPedestrianPolygonRegion pIPedestrianPolygonRegion)**

Delete polygonal pedestrian surface area.

Parameters:

[ in ] pIPedestrianPolygonRegion: Polygonal pedestrian surface area Object.

**public void removePedestrianSIDeWalkRegion(IPedestrianSIDeWalkRegion pIPedestrianSIDeWalkRegion)**

Delete sidewalk.

Parameters:

[ in ] pIPedestrianSideWalkRegion: Sidewalk Object.

**public void removePedestrianCrossWalkRegion(IPedestrianCrossWalkRegion pIPedestrianCrossWalkRegion)**

Delete pedestrian crosswalk.

Parameters:

[ in ] pIPedestrianCrossWalkRegion: Pedestrian crosswalk Object.

**public void removePedestrianStairRegion(IPedestrianStairRegion pIPedestrianStairRegion)**

Delete the stair.

Parameters:

[ in ] pIPedestrianStairRegion: Stair object.

#### 3.3.2.34. Pedestrian Spawn Point

**public ArrayList\<IPedestrianPathPoint\> pedestrianPathStartPoints()**

Retrieve the sequence of all pedestrian spawn point objects.

**public IPedestrianPathPoint findPedestrianPathStartPoint(long id)**

Retrieve the pedestrian spawn point object by pedestrian spawn point ID.

**public Pedestrian.PedestrianPathStartPointConfigInfo findPedestrianStartPointConfigInfo(long id)**

Retrieve the pedestrian spawn point configuration information by pedestrian spawn point ID.

**public IPedestrianPathPoint createPedestrianPathStartPoint(Point scenePos)**

Create a pedestrian spawn point.

Parameters:

[ in ] scenePos: Scenario coordinate.

Return:	

Pedestrian spawn point object.

**public void removePedestrianPathStartPoint(IPedestrianPathPoint pIPedestrianPathStartPoint)**

Delete a pedestrian spawn point.

Parameters:

[ in ] pIPedestrianPathStartPoint: Pedestrian spawn point object.

**public boolean updatePedestrianStartPointConfigInfo(PedestrianPathStartPointConfigInfo info)**

Update pedestrian spawn point configuration information.

Parameters:

[ in ] info: Pedestrian spawn point configuration information.

Return:	

Indicates whether the update was successful.

#### 3.3.2.35. Pedestrian End Point

**public ArrayList\<IPedestrianPathPoint\> pedestrianPathEndPoints()**

Retrieve the sequence of all pedestrian end point objects.

**public IPedestrianPathPoint findPedestrianPathEndPoint(long id)**

Retrieve the pedestrian end point object by ID.

**public IPedestrianPathPoint createPedestrianPathEndPoint(Point scenePos)**

Create a pedestrian end point.

Parameters:

[ in ] scenePos: Scenario coordinate.

Return:

Pedestrian end point object.

**public void removePedestrianPathEndPoint(IPedestrianPathPoint pIPedestrianPathEndPoint)**

Delete a pedestrian end point.

Parameters:

[ in ] pIPedestrianPathEndPoint: Pedestrian end point object.

#### 3.3.2.36. Pedestrian Decision Point

**public ArrayList\<IPedestrianPathPoint\> pedestrianPathDecisionPoints()**

Retrieve the sequence of all pedestrian decision point objects.

**public IPedestrianPathPoint findPedestrianDecisionPoint(long id)**

Retrieve the pedestrian decision point object by pedestrian decision point ID.

**public PedestrianDecisionPointConfigInfo findPedestrianDecisionPointConfigInfo(long id)**

Retrieve pedestrian decision point configuration information by pedestrian decision point ID.

**public IPedestrianPathPoint createPedestrianDecisionPoint(Point scenePos)**

Create a pedestrian decision point.

Parameters:

[ in ] scenePos: Scenario coordinate.

Return:

Pedestrian decision point object.

**public void removePedestrianDecisionPoint(IPedestrianPathPoint pIPedestrianDecisionPoint)**

Delete a pedestrian decision point.

Parameters:

[ in ] pIPedestrianDecisionPoint: Pedestrian decision point object.

**public boolean updatePedestrianDecisionPointConfigInfo(PedestrianDecisionPointConfigInfo info)**

Update pedestrian Decision Point configuration information.

Parameters:

[ in ] info: Pedestrian Decision Point configuration information.

Return:	

Indicates whether the update was successful.

#### 3.3.2.37. Pedestrian Route

**public ArrayList\<IPedestrianPath\> pedestrianPaths()**

Get all pedestrian Route objects, including local routes.

**public IPedestrianPath findPedestrianPath(long id)**

Get pedestrian Route by pedestrian Route ID, including local routes.

**public IPedestrianPath createPedestrianPath(IPedestrianPathPoint pStartPoint, IPedestrianPathPoint pEndPoint, ArrayList\<Point\> mIDdlePoints)**

Create a pedestrian Route (or pedestrian local Route).

Parameters:

[ in ] pStartPoint: Pedestrian origin point (or pedestrian Decision Point).

[ in ] pEndPoint: Pedestrian destination point.

[ in ] mIDdlePoints: A set of intermediate mandatory points.

Return:	

Pedestrian Route object.

**public void removePedestrianPath(IPedestrianPath pIPedestrianPath)**

Delete pedestrian Route.

Parameters:

[ in ] pIPedestrianPath: Pedestrian Route object.

#### 3.3.2.38. Pedestrian Traffic Signal

**public ArrayList\<ICrosswalkSignalLamp\> crosswalkSignalLamps()**

Retrieve the sequence of all pedestrian crosswalk traffic signal objects.

**public ICrosswalkSignalLamp findCrosswalkSignalLamp(long id)**

Retrieve a pedestrian crosswalk traffic signal object by ID.

**public void addCrossWalkSignalPhaseToLamp(int SignalPhaseID, ISignalLamp signalLamp)**

Add a pedestrian pedestrian signal light.

Parameters:

[ in ] SignalPhaseID: Signal Phase ID.

[ in ] signalLamp: Traffic Signal Object.

**public ICrosswalkSignalLamp createCrossWalkSignalLamp(ISignalController pTrafficLight, String name, long crosswalkID, Point scenePos, boolean isPositive)**

Create a pedestrian crosswalk traffic signal.

Parameters:

[ in ] pTrafficLight: Signal Controller object.

[ in ] name: Traffic Signal Name.

[ in ] crosswalkID: Pedestrian crosswalk ID.

[ in ] scenePos: Scene coordinates located within the pedestrian crosswalk.

[ in ] isPositive: Indicates whether the traffic signal control direction is positive.

Return:

Pedestrian crosswalk traffic signal object.

**public void removeCrossWalkSignalLamp(ICrosswalkSignalLamp pICrosswalkSignalLamp)**

Delete the pedestrian crosswalk traffic signal.

Parameters:

[ in ] pICrosswalkSignalLamp: Pedestrian crosswalk traffic signal object.

#### 3.3.2.39. Parking Lot Parking Time Interval Distribution

**public ArrayList\<DynaParkingTimeDis\> parkingTimeDis()**

Retrieve the list of parking lot parking time interval distributions.

**public DynaParkingTimeDis createParkingTimeDis(DynaParkingTimeDis param)**

Create a parking lot parking time interval distribution.

Parameters:

[ in ] param: Parking time interval distribution parameters.

**public void removeParkingTimeDis(long id)**

Remove a parking lot parking time interval distribution.

Parameters:

[ in ] ID: Parking time interval distribution ID.

**public DynaParkingTimeDis updateParkingTimeDis(DynaParkingTimeDis param)**

Update a parking lot parking time interval distribution.

Parameters:

[ in ] param: Parking time interval distribution parameters.

#### 3.3.2.40. Parking Area

**public ArrayList\<IParkingRegion\> parkingRegions()**

Retrieve all parking area sequences.

**public IParkingRegion findParkingRegion(long id)**

Retrieve a parking area by its ID.

**public IParkingRegion createParkingRegion(DynaParkingRegion param)**

Create a parking area.

Parameters:

[ in ] param: Dynamic parking area information.

**public void removeParkingRegion(IParkingRegion pIParkingRegion)**

Remove a parking area.

Parameters:

[ in ] pIParkingRegion: Parking area Object.

**public void removeParkingRegionById(long id)**

Remove the parking area by its ID.

Parameters:

[ in ] ID: Parking area ID.

**public IParkingRegion updateParkingRegion(DynaParkingRegion param)**

Update the parking area.

Parameters:

[ in ] param: Dynamic parking area information.

#### 3.3.2.41. Parking Route Decision Point

**public ArrayList\<IParkingDecisionPoint\> parkingDecisionPoints()**

Retrieve the list of all parking route decision points.

**public IParkingDecisionPoint findParkingDecisionPoint(long id)**

Obtain the parking route decision point object by its ID.

**public IParkingDecisionPoint createParkingDecisionPoint(ILink pLink, double distance, String name)**

Create a parking route decision point.

Parameters:

[ in ] pLink: Road Segment where the Decision Point is located.

[ in ] distance: Distance from the start of the Road Segment to the Decision Point. Unit: Pixel.

[ in ] name: Decision point name.

**public void removeParkingDecisionPoint(IParkingDecisionPoint pIParkingDecisionPoint)**

Remove the parking route decision point.

Parameters:

[ in ] pIParkingDecisionPoint: Parking route decision point object.

**public void removeParkingDecisionPointById(long id)**

Remove the parking route decision point by its ID.

Parameters:

​	[ in ] ID: Parking Route Decision Point ID.

#### 3.3.2.42. Parking Route

**public IParkingRouting createParkingRouting(IParkingDecisionPoint pDeciPoint, IParkingRegion pIParkingRegion)**

​	Create Parking Route.

Parameters:

​	[ in ] pDeciPoint: Parking Decision Point.

​	[ in ] pIParkingRegion: Parking Area.

**public void removeParkingRouting(IParkingRouting pIParkingRouting)**

​	Remove Parking Route.

Parameters:

​	[ in ] pIParkingRouting: Parking Decision Point Object.

**public void removeParkingRoutingById(long id)**

​	Remove Parking Route by Parking Route ID.

Parameters:

​	[ in ] ID: Parking Decision Point ID.

#### 3.3.2.43. Toll Station Parking Time Gap Distribution

**public ArrayList\<DynaTollParkingTimeDis\> tollParkingTimeDis()**

​	Get Toll Station Parking Time Gap Distribution Sequence.

**public DynaTollParkingTimeDis createTollParkingTimeDis(DynaTollParkingTimeDis param)**

​	Create Toll Station Parking Time Gap Distribution.

Parameters:

[ in ] param: Parking time interval distribution parameters.

**public void removeTollParkingTimeDis(long id)**

​	Remove Toll Station Parking Time Gap Distribution.

Parameters:

[ in ] ID: Parking time interval distribution ID.

**public DynaTollParkingTimeDis updateTollParkingTimeDis(DynaTollParkingTimeDis param)**

Update the parking time gap distribution at the toll station.

Parameters:

[ in ] param: Parking time interval distribution parameters.

#### 3.3.2.44. Toll Lane

**public ArrayList\<ITollLane\> tollLanes()**

Retrieve the sequence of all toll lane objects.

**public ITollLane findTollLane(long id)**

Retrieve a toll lane object by Toll Lane ID.

**public ITollLane createTollLane(DynaTollLane param)**

Create a toll lane.

Parameters:

[ in ] param: Dynamic toll lane information.

**public void removeTollLane(ITollLane pITollLane)**

Remove a toll lane.

Parameters:

[ in ] pITollLane: Toll lane object.

**public void removeTollLaneById(long id)**

Remove a toll lane by Toll Lane ID.

Parameters:

[ in ] ID: Toll Lane ID.

**public ITollLane updateTollLane(DynaTollLane param)**

Update a toll lane.

Parameters:

[ in ] param: Dynamic toll lane information.

#### 3.3.2.45. Toll Route Decision Point

**public ArrayList\<ITollDecisionPoint\> tollDecisionPoints()**

Retrieve the list of all toll route decision points.

**public ITollDecisionPoint findTollDecisionPoint(long id)**

Retrieve a toll route decision point by ID.

**public ITollDecisionPoint createTollDecisionPoint(ILink pLink, double distance, String name)**

Create a toll route decision point.

Parameters:

[ in ] pLink: Road segment where the Decision Point is located.

[ in ] distance: Distance from the start of the Road Segment to the Decision Point. Unit: Pixel.

[ in ] name: Decision point name.

**public void removeTollDecisionPoint(ITollDecisionPoint pITollDecisionPoint)**

Remove toll route Decision Point.

Parameters:

[ in ] pITollLane: Toll route Decision Point object.

**public void removeTollDecisionPointById(long id)**

Remove toll route Decision Point by ID.

Parameters:

[ in ] ID: Toll route Decision Point ID.

#### 3.3.2.46. Toll Route

**public ITollRouting createTollRouting(ITollDecisionPoint pDeciPoint, ITollLane pITollLane)**

Create toll route.

Parameters:

[ in ] pDeciPoint: Toll Decision Point.

[ in ] pITollLane: Toll lane.

**public void removeTollRouting(ITollRouting pITollRouting)**

Remove toll route.

Parameters:

[ in ] pITollRouting: Toll route object.

**public void removeTollRoutingById(long id)**

Remove toll route by ID.

Parameters:

[ in ] ID: Toll route ID.

#### 3.3.2.47. Node

**public ArrayList\<IJunction\> getAllJunctions()**

Retrieve the sequence of all node Objects.

**public IJunction findJunction(long junctionId)**

Retrieve the node Object by ID.

**public IJunction createJunction(Point startPoint, Point endPoint, String name)**

Create a node.

Parameters:

[ in ] startPoint: Upper-left starting point coordinates.

[ in ] endPoint: Lower-right ending point coordinates.

[ in ] name: Node name.

Return:

Node Object.

**public boolean removeJunction(long junctionId)**

Delete a node.

Parameters:

[ in ] junctionID: Node ID.

Return:

Indicates whether the removal was successful.

**public boolean updateJunctionName(long junctionID, String name)**

Update node name.

Parameters:

[ in ] junctionID: Node ID.

[ in ] name: New node name.

**public ArrayList\<FlowTurning\> getJunctionFlows(long junctionId)**

Retrieve node turning movement information.

Parameters:

[ in ] junctionID: Node ID.

Return:

Mapping table of node turning movement information.

**public boolean updateFlow(long timeID, long junctionID, long turningID, long inputFlowValue)**

Update turning movement flow.

Parameters:

[ in ] timeID: Time period ID.

[ in ] junctionID: Node ID.

[ in ] turningID: Turning movement ID.

[ in ] inputFlowValue: Input flow value (veh/h).

Return:

Indicates whether the update was successful.

**public boolean updateFlowAlgorithmParams(double theta, double bpra, double bprb, long maxIterateNum, boolean useNewPath)**

Update flow algorithm parameters.

Parameters:

[ in ] theta: Parameter θ (0.01–1).

[ in ] bpra: BPR impedance parameter A (0.05–0.5).

[ in ] bprb: BPR impedance parameter B (1–10).

[ in ] maxIterateNum: Maximum number of iterations (1–5000).

[ in ] useNewPath: Whether to reconstruct static routes.

Return:

Indicates whether the update was successful.

**public boolean updatePathBuildParams(boolean deciPointPosFlag, boolean laneConnectorFlag, long minPathNum)**

Update path construction parameters.

Parameters:

[ in ] deciPointPosFlag: Whether to consider the decision point position.

[ in ] laneConnectorFlag: Whether to consider lane connections.

[ in ] minPathNum: Minimum number of paths (default 3).

Return:

Indicates whether the update was successful.

~~**public HashMap\<QPair<long, long>, ArrayList\<ArrayList\<ILink\>\>\> buildAndApplyPaths()**~~

~~Construct and apply routes.~~

~~Return:~~

~~Route result information mapping table.~~

~~**public HashMap\<long, ArrayList\<Junction.FlowTurning\>\> calculateFlows()**~~

~~Calculate and apply traffic flow results.~~

~~Return:~~

~~Mapping table from time period ID to traffic flow calculation results.~~

#### 3.3.2.48. Node Time Period

**public ArrayList\<FlowTimeInterval\> getFlowTimeIntervals()**

Retrieve all node time periods.

**public FlowTimeInterval addFlowTimeInterval()**

Add a node time period.

Return:

Node time period information.

**public boolean deleteFlowTimeInterval(long timeId)**

Delete a node time period.

Parameters:

[ in ] timeID: Node time period ID.

Return:

Indicates whether deletion was successful.

**public FlowTimeInterval updateFlowTimeInterval(long timeID, long startTime, long endTime)**

Update time period.

Parameters:

[ in ] timeID: Node time period ID.

[ in ] startTime: Start time, in seconds.

[ in ] endTime: End time, in seconds.

### 3.3.3. Simulation Interface (SimuInterface)

SimuInterface is a sub-interface of TessInterface. Through this interface, simulations can be started, paused, and stopped; simulation precision can be configured; vehicle objects and vehicle states during the simulation process can be retrieved; as well as sample data and aggregated data detected by various types of detectors.

#### 3.3.3.1. Simulation Configuration

**public long simuIntervalScheming()**

Get the simulation duration. Unit: seconds.

**public void setSimuIntervalScheming(long interval)**

Set the simulation duration. A value of 0 means unlimited duration. Unit: seconds.

**public int simuAccuracy()**

Get the simulation precision.

**public void setSimuAccuracy(int accuracy)**

Set the simulation precision, i.e., the number of calculations per second.

**public int acceMultiples()**

Get the simulation acceleration factor.

**public void setAcceMultiples(int multiples)**

Set the simulation acceleration factor.


**public boolean byCpuTime()**

Determine whether simulation time is governed by real time. There are two types of time within a calculation cycle: elapsed real time and simulation time determined by the simulation precision. For example, if the simulation precision is 20 calculations per second, one simulation step corresponds to 50 milliseconds of simulated time. By default, the simulation time of a calculation cycle is determined by the simulation precision. If computational resources are insufficient during online simulation, the simulation time determined by simulation accuracy will deviate from real time.

**public void setByCpuTime(boolean bByCpuTime)**

Set whether simulation time is determined by real time. If set to true, the actual elapsed time for each simulation cycle will be used as simulation time, thereby aligning simulation time with real time.

**public boolean isRecordTrace()**

Get whether vehicle trajectory recording is enabled.

**public void setIsRecordTrace(boolean bRecord)**

Set whether vehicle trajectory recording is enabled.

**public void setThreadCount(int count)**

Set the number of worker threads.

**public long batchNumber()**

Get the current simulation batch.

**public double batchIntervalReally()**

Get the actual time of the current batch. Unit: ms.

**public long simuTimeIntervalWithAcceMutiples()**

Get the current elapsed simulation time. Unit: ms.

**public long startMSecsSinceEpoch()**

Get the real start time of the simulation. Unit: ms.

**public long stopMSecsSinceEpoch()**

Get the real end time of the simulation. Unit: ms.

#### 3.3.3.2. Simulation Status

**public boolean isRunning()**

Retrieve whether the simulation is currently running.

**public boolean isPausing()**

Retrieve whether the simulation is currently paused.

**public void startSimu()**

Start the simulation.

**public void pauseSimu()**

Pause the simulation.

**public void stopSimu()**

Stop the simulation.

**public void pauseSimuOrNot()**

Pause or resume the simulation. If the simulation is currently running, this method pauses it; if it is paused, this method resumes it.

#### 3.3.3.3. Vehicle

**public long vehiCountTotal()**

Retrieve the total number of vehicles, including those created but not yet in the road network, those currently running, and those that have exited the road network.

**public long vehiCountRunning()**

Retrieve the number of vehicles currently running at the current time.

**public IVehicle getVehicle(long vehiId)**

Retrieve the vehicle object by vehicle ID.

**public ArrayList\<IVehicle\> allVehicle()**

Retrieve the sequence of all vehicle objects.

**public ArrayList\<IVehicle\> allVehiStarted()**

Retrieve the sequence of all vehicles currently running at the current simulation time.

Example:

```java
// Retrieve the list of vehicles currently running
ArrayList<IVehicle> allVehicles = simuiface.allVehiStarted();
for (IVehicle vehicle : allVehicles) {
    System.out.println("Vehicle ID: " + vehicle.id());
    System.out.println("Vehicle Name: " + vehicle.name());
    System.out.println("Vehicle Type Code: " + vehicle.vehicleTypeCode());
    System.out.println("Vehicle Type Name: " + vehicle.vehicleTypeName());
    System.out.println("Vehicle Length: " + vehicle.length(UnitOfMeasure.Metric) + " m");

    System.out.println("Vehicle Current Abscissa: " + vehicle.pos(UnitOfMeasure.Metric).getX() + " m");
    System.out.println("Vehicle Current Ordinate: " + vehicle.pos(UnitOfMeasure.Metric).getY() + " m");
    System.out.println("Vehicle Current Elevation: " + vehicle.v3z() + " m");
    System.out.println("Vehicle Current Road ID: " + vehicle.roadId());
    System.out.println("Vehicle Current Road Name: " + vehicle.roadName());
    System.out.println("Vehicle Is on Link: " + vehicle.roadIsLink());
    System.out.println("Vehicle Current Lane ID: " + vehicle.laneId());
    if (vehicle.roadIsLink()) {
        System.out.println("Vehicle Current Lane Number: " + vehicle.vehicleDriving().laneNumber());
    }
    System.out.println("Vehicle Distance to Lane Start Point: " + vehicle.vehicleDriving().distToStartPoint(true, true, UnitOfMeasure.Metric) + " m");
    
    System.out.println("Vehicle Current Speed: " + vehicle.currSpeed(UnitOfMeasure.Metric) * 3.6 + " km/h");
    System.out.println("Vehicle Current Desired Speed: " + vehicle.vehicleDriving().desirSpeed(UnitOfMeasure.Metric) * 3.6 + " km/h");
    System.out.println("Vehicle Current Acceleration: " + vehicle.acce(UnitOfMeasure.Metric) + " m/s²");
    System.out.println("Vehicle Current Heading Angle: " + vehicle.angle() + " °");
}
```

**public ArrayList\<IVehicle\> vehisInLink(long linkId)**

Retrieve the sequence of vehicle objects on the road segment with the specified ID at the current simulation time.

**public ArrayList\<IVehicle\> vehisInLane(long laneId)**

Retrieve the sequence of vehicle objects on the lane with the specified ID at the current simulation time.

**public ArrayList\<IVehicle\> vehisInConnector(long connectorId)**

Retrieve the sequence of vehicle objects on the connection segment with the specified ID at the current simulation time.

**public ArrayList\<IVehicle\> vehisInLaneConnector(long connectorID, long fromLaneID, long toLaneId)**

Retrieve the sequence of vehicle objects on the lane connection identified by the specified connection segment ID, upstream lane ID, and downstream lane ID at the current simulation time.

Parameters:

[ in ] connectorID: Connection segment ID.

[ in ] fromLaneID: Upstream lane ID.

[ in ] toLaneID: Downstream lane ID.

Return:

Sequence of vehicle objects.

**public ArrayList\<VehicleStatus\> getVehisStatus(long batchNumber, UnitOfMeasure unit)**

Retrieve the status of all vehicles currently running at the current simulation time.

Parameters:

[ in ] batchNumber: Batch number.

Return:

Vehicle status sequence.

**public ArrayList\<VehiclePosition\> getVehiTrace(long vehiID, UnitOfMeasure unit)**

Retrieve the operation trajectory of the specified vehicle. Unit: Pixel.

Parameters:

[ in ] vehiID: Vehicle ID.

Return:

Vehicle trajectory point sequence.

**public IVehicle createGVehicle(DynaVehiParam dynaVehi)**

Create vehicle.

Parameters:

[ in ] dynaVehi: Dynamic vehicle information.

Return:

Vehicle object.

```java
// Create vehicle on Road Segment
// Construction Parameters
DynaVehiParam dvp1 = new DynaVehiParam();
// Vehicle type ID
dvp1.setVehiTypeCode(1);
// Road Segment ID
dvp1.setRoadId(4);
// Lane Index
dvp1.setLaneNumber(0);
// Position, Unit: m
dvp1.setDist(m2p(50));
// Speed, Unit: m/s
dvp1.setSpeed(m2p(20));
// Color
dvp1.setColor("#00AFF0");
// Dynamically create vehicle
IVehicle vehicle1 = simuiface.createGVehicle(dvp1);
if (vehicle != null) {
    System.out.println("Vehicle created on link, ID: " + vehicle1.id());
}

// Create vehicle on connector segment
// Construction Parameters
DynaVehiParam dvp2 = new DynaVehiParam();
// Vehicle type ID
dvp2.setVehiTypeCode(1);
// Connector Segment ID
dvp2.setRoadId(4);
// Upstream road segment lane index
dvp2.setLaneNumber(0);
// Downstream road segment lane index
dvp2.setToLaneNumber(0);
// Position, Unit: m
dvp2.setDist(m2p(50));
// Speed, Unit: m/s
dvp2.setSpeed(m2p(20));
// Color
dvp2.setColor("#00AFF0");
// Dynamically create vehicle
IVehicle vehicle2 = simuiface.createGVehicle(dvp2);
if (vehicle2 != null) {
    System.out.println("Vehicle created on connector, ID: " + vehicle2.id());
}
```

**public IVehicle createBus(IBusLine pBusLine, double startSimuDateTime)**

Create bus.

Parameters:

[ in ] pBusLine: Bus route object.

[ in ] startSimuDateTime: Departure time. Unit: ms.

#### 3.3.3.4. Pedestrians

**public ArrayList\<IPedestrian\> allPedestrianStarted()**

Retrieve the sequence of all currently active pedestrian objects.

**public ArrayList\<PedestrianStatus\> getPedestriansStatusByRegionId(long regionId)**

Retrieve the status information of all pedestrians on the current Pedestrian Surface Area at the specified time using the Pedestrian Surface Area ID.

Parameters:

[ in ] regionID: Area ID.

Return:

Pedestrian status information sequence.

#### 3.3.3.5. Traffic Signals

**public ArrayList\<SignalPhaseColor\> getSignalPhasesColor()**

Retrieve the colors of all signal control phases at the current time.

Return:

Phase color sequence.

Example:

```java
ArrayList<SignalPhaseColor> allSignalPhaseColor = simuiface.getSignalPhasesColor();
for (SignalPhaseColor signalPhaseColor : allSignalPhaseColor) {
    System.out.println("Signal Group ID: " + signalPhaseColor.getSignalGroupId());
    System.out.println("Signal Phase ID: " + signalPhaseColor.getPhaseId());
    System.out.println("Signal Phase Number: " + signalPhaseColor.getPhaseNumber());
    System.out.println("Current Color: " + signalPhaseColor.getColor());
    System.out.println("Current Color Set Time (ms): " + signalPhaseColor.getMrIntervalSetted());
    System.out.println("Current Color Duration (ms): " + signalPhaseColor.getMrIntervalByNow());
}
```

#### 3.3.3.6. Data Collector

**public ArrayList\<VehiInfoCollected\> getVehisInfoCollected()**

Obtain all vehicle information that has completed traversal through the Data Collector at the current time.

Example:

```python
ArrayList<VehiInfoCollected> allVehiInfoCollected = simuiface.getVehisInfoCollected();
for (VehiInfoCollected vehiInfo : allVehiInfoCollected) {
    System.out.println("Collector ID: " + vehiInfo.getCollectorId());
    System.out.println("Simulation Time (s): " + vehiInfo.getSimuInterval());
    System.out.println("Vehicle ID: " + vehiInfo.getVehiId());
}
```

**public ArrayList\<VehiInfoAggregated\> getVehisInfoAggregated()**

Retrieve aggregated data collected by the Data Collector during the most recent aggregation interval.

Example:

```python
ArrayList<VehiInfoAggregated> allVehiInfoAggregated = simuiface.getVehisInfoAggregated();
for (VehiInfoAggregated vehiInfoAgg : allVehiInfoAggregated) {
    System.out.println("Collector ID: " + vehiInfoAgg.getCollectorId());
    System.out.println("Time Period ID: " + vehiInfoAgg.getTimeId());
    System.out.println("Start Time (s): " + vehiInfoAgg.getFromTime());
    System.out.println("End Time (s): " + vehiInfoAgg.getToTime());
    System.out.println("Vehicle Count (veh): " + vehiInfoAgg.getVehiCount());
    System.out.println("Average Speed (km/h): " + vehiInfoAgg.getAvgSpeed());
    System.out.println("Average Occupancy: " + vehiInfoAgg.getOccupancy());
}
```

#### 3.3.3.7. Queue Counter

**public ArrayList\<VehiQueueCounted\> getVehisQueueCounted()**

Obtain vehicle queue information counted by the Queue Counter at the current time.

Example:

```python
ArrayList<VehiQueueCounted> allVehiQueueCounted = simuiface.getVehisQueueCounted();
for (VehiQueueCounted vehiQueue : allVehiQueueCounted) {
    System.out.println("Counter ID: " + vehiQueue.getCounterId());
    System.out.println("Simulation Time (s): " + vehiQueue.getSimuTime());
    System.out.println("Queued Vehicle Count (veh): " + vehiQueue.getVehiCount());
    System.out.println("Queue Length (m): " + vehiQueue.getQueueLength());
}
```

**public ArrayList\<VehiQueueAggregated\> getVehisQueueAggregated()**

Retrieve aggregated data collected by the Queue Counter during the most recent aggregation interval.

Example:

```python
ArrayList<VehiQueueAggregated> allVehiQueueAggregated = simuiface.getVehisQueueAggregated();
for (VehiQueueAggregated vehiQueueAgg : allVehiQueueAggregated) {
    System.out.println("Counter ID: " + vehiQueueAgg.getCounterId());
    System.out.println("Time Period ID: " + vehiQueueAgg.getTimeId());
    System.out.println("Start Time (s): " + vehiQueueAgg.getFromTime());
    System.out.println("End Time (s): " + vehiQueueAgg.getToTime());
    System.out.println("Average Queued Vehicle Count (veh): " + vehiQueueAgg.getAvgVehiCount());
    System.out.println("Average Queue Length (m): " + vehiQueueAgg.getAvgQueueLength());
    System.out.println("Maximum Queue Length (m): " + vehiQueueAgg.getMaxQueueLength());
    System.out.println("Minimum Queue Length (m): " + vehiQueueAgg.getMinQueueLength());
}
```

**public boolean queueRecently(long queueCounterID, double queueLength, int vehiCount, UnitOfMeasure unit)**

Specify the most recent queue length and number of queued vehicles recorded by the Queue Counter.

Parameters:

[ in ] queueCounterID: Queue Counter ID.

[ out ] queueLength: Queue length.

[ out ] vehiCount: Number of queued vehicles.

Return:

Indicates whether the data was successfully obtained.

#### 3.3.3.8. Travel Time Detector

**public ArrayList\<VehiTravelDetected\> getVehisTravelDetected()**

Retrieve the travel time detection information completed by the travel time detector at the current time.

Example:

```python
ArrayList<VehiTravelDetected> allVehiTravelDetected = simuiface.getVehisTravelDetected();
for (VehiTravelDetected vehiTravel : allVehiTravelDetected) {
    System.out.println("Detector ID: " + vehiTravel.getDetectedId());
    System.out.println("Vehicle ID: " + vehiTravel.getVehiId());
    System.out.println("Travel Time (s): " + vehiTravel.getTravelTime());
    System.out.println("Travel Distance (m): " + vehiTravel.getTravelDistance());
    System.out.println("Delay (s): " + vehiTravel.getDelay());
}

```

**public ArrayList\<VehiTravelAggregated\> getVehisTravelAggregated()**

Retrieve the aggregated data collected by the travel time detector during the most recent aggregation period.

Example:

```python
ArrayList<VehiTravelAggregated> allVehiTravelAggregated = simuiface.getVehisTravelAggregated();
for (VehiTravelAggregated vehiTravelAgg : allVehiTravelAggregated) {
    System.out.println("Detector ID: " + vehiTravelAgg.getDetectedId());
    System.out.println("Time Period ID: " + vehiTravelAgg.getTimeId());
    System.out.println("Start Time (s): " + vehiTravelAgg.getFromTime());
    System.out.println("End Time (s): " + vehiTravelAgg.getToTime());
    System.out.println("Vehicle Count: " + vehiTravelAgg.getVehiCount());
    System.out.println("Average Travel Time (s): " + vehiTravelAgg.getAvgTravelTime());
    System.out.println("Average Travel Distance (m): " + vehiTravelAgg.getAvgTravelDistance());
    System.out.println("Average Delay (s): " + vehiTravelAgg.getAvgDelay());
}
```



## 3.4. Object

Objects in TESS NG are categorized into **Road Network Objects** and **Simulation Objects**. Road network objects include road segments, connection segments, etc., while simulation objects include vehicles and pedestrians.

### 3.4.1. Road Network

#### 3.4.1.1. Road Network (IRoadNet)

Basic interface for road network information, designed to enable TESS NG to preserve attributes of externally imported road networks, such as the road network's central coordinates and geodetic coordinates.

**public long id()**

Obtain the Road Network ID, corresponding to the identifier in the road network editing dialog.

**public String netName()**

Retrieve the Road Network name.

**public String url()**

Source data path, which may be a local file or a network address.

**public String type()**

Source classification: "TESSNG" indicates native creation by TESSNG; "OpenDrive" indicates data imported from OpenDrive; "GeoJson" indicates data imported from GeoJSON.

**public String bkgUrl()**

Obtain the background path.

**public String explain()**

Retrieve the Road Network description.

**public JsonObject otherAttrs()**

Other attribute JSON data.

**public Point centerPoint(UnitOfMeasure unit)**

Obtain the Road Network center coordinates. Unit: Pixel.

#### 3.4.1.2. Road Base Class (ISection)

The road base class serves as the superclass for Road Segment and Connection Segment.

**public int gtype()**

Type: GLinkType or GConnectorType. GLinkType represents a Road Segment; GConnectorType represents a Connection Segment.

**public boolean isLink()**

Indicates whether this is a Road Segment.

**public long id()**

Get ID. If it is a Link, the ID corresponds to the Link's ID; if it is a Connection Segment, the ID corresponds to the Connection Segment's ID.

**public long sectionId()**

Get ID. If it is a Link, the ID corresponds to the Link's ID; if it is a Connection Segment, the ID corresponds to the Connection Segment's ID plus 1. 0000000, thereby differentiating Road Segments from Connection Segments.

**public String name()**

Get Section name, either the Road Segment name or the Connection Segment name.

**public void setName(String name)**

Set Section name.

**public double v3z(UnitOfMeasure unit)**

Get Section elevation. Unit: Pixel.

**public double length(UnitOfMeasure unit)**

Get Section length. Unit: Pixel.

**public ArrayList\<ILaneObject\> laneObjects()**

Parent interface list for Lane and Lane Connection.

**public ISection fromSection(long id)**

Get upstream Section by ID. If the current object is a Road Segment, return null if id is 0; otherwise, return the upstream Connection Segment with the specified id. If the current object is a Connection Segment, return the upstream Road Segment if id is 0; otherwise, return null.

**public ISection toSection(long id)**

Get downstream Section by ID. If the current object is a Road Segment and the ID is 0, return null; otherwise, return the downstream Connection Segment with the specified ID. If the current object is a Connection Segment and the ID is 0, return the downstream Road Segment; otherwise, return null.

**public void setOtherAttr(JsonObject otherAttr)**

Set other attributes of the Road Segment or Connection Segment.

**public ILink castToLink()**

Convert to ILink; if the current object is a Connection Segment, return null.

**public IConnector castToConnector()**

Convert to IConnector; if the current object is a Road Segment, return null.

**public Vector\<Point\> polygon()**

Obtain the polygon formed by the vertices of the Section's polygonal contour.

#### 3.4.1.3. Road Segment (ILink)

**public int gtype()**

Type, returns GLinkType.

**public long id()**

Obtain the Road Segment ID.

**public double length(UnitOfMeasure unit)**

Obtain the Road Segment length. Unit: Pixel.

**public double width(UnitOfMeasure unit)**

Obtain the Road Segment width. Unit: Pixel.

**public double z(UnitOfMeasure unit)**

Obtain the Road Segment elevation. Unit: Pixel.

**public double v3z(UnitOfMeasure unit)**

Obtain the Road Segment elevation, an overridden method from ISection. Unit: Pixel.

**public String name()**

Get the segment name.

**public void setName(String name)**

Set the segment name.

**public String linkType()**

Get the segment type, such as: urban arterial, urban secondary road, sidewalk, etc.

**public void setType(String type)**

Set the segment type. There are 10 segment types: expressway, urban expressway, ramp, urban primary arterial, secondary arterial, local street, non-motorized lane, sidewalk, bus-only lane, and mixed motor and non-motorized lane.

**public int laneCount()**

Get the number of lanes.

**public double limitSpeed(UnitOfMeasure unit)**

Get the segment speed limit. Unit: km/h.

**public void setLimitSpeed(double speed, UnitOfMeasure unit)**

Set the segment speed limit. Unit: km/h.

Parameters: 

[ in ] speed: speed limit value.

**public double minSpeed(UnitOfMeasure unit)**

Get the segment minimum speed limit. Unit: km/h.

**public ArrayList\<ILane\> lanes()**

List of lane interfaces.

**public ArrayList\<ILaneObject\> laneObjects()**

List of interfaces for Lanes and Lane Connections.

**public ArrayList\<Point\> centerBreakPoints(UnitOfMeasure unit)**

Retrieve the set of centerline breakpoints of the Road Segment. Unit: Pixel.

**public ArrayList\<Point\> leftBreakPoints(UnitOfMeasure unit)**

Retrieve the set of left boundary line breakpoints of the Road Segment. Unit: Pixel.

**public ArrayList\<Point\> rightBreakPoints(UnitOfMeasure unit)**

Retrieve the set of right boundary line breakpoints of the Road Segment. Unit: Pixel.

**public ArrayList\<Vector3D\> centerBreakPoint3Ds(UnitOfMeasure unit)**

Retrieve the set of 3D centerline breakpoints of the Road Segment. Unit: Pixel.

**public ArrayList\<Vector3D\> leftBreakPoint3Ds(UnitOfMeasure unit)**

Retrieve the set of 3D left boundary line breakpoints of the Road Segment. Unit: Pixel.

**public ArrayList\<Vector3D\> rightBreakPoint3Ds(UnitOfMeasure unit)**

Retrieve the set of 3D right boundary line breakpoints of the Road Segment. Unit: Pixel.

**public ArrayList\<IConnector\> fromConnectors()**

Retrieve the list of upstream Connection Segments.

**public ArrayList\<IConnector\> toConnectors()**

Retrieve the list of downstream Connection Segments.

**public void setOtherAttr(JsonObject otherAttr)**

Set additional attributes of the Road Segment.

**public JsonObject otherAttr()**

Retrieve additional attributes of the Road Segment.

**public void setLaneTypes(ArrayList\<String\> lType)**

Set Lane attributes. Attribute types include: "Motor Vehicle Lane", "Mixed Motor and Non-motor Lane", "Non-motor Vehicle Lane", and "Bus-only Lane". Lane order is from right to left.

**public void setLaneOtherAtrrs(ArrayList\<JsonObject\> lAttrs)**

Set additional lane attributes.

**public double distToStartPoint(Point p, UnitOfMeasure unit)**

Distance from a point on the centerline to the start point. Unit: Pixel.

Parameters: 

[ in ] p: Coordinates of the current point.

**public boolean getPointByDist(double dist, Point outPoint, UnitOfMeasure unit)**

Calculate the point at a distance dist extended forward from the centerline start point; return false if the target point is not on the centerline, otherwise return true. Unit: Pixel.

Parameters: 

[ in ] dist: Distance extended forward from the centerline start point.

[ out ] outPoint: The point at a distance dist extended forward from the centerline start point.

Example:

```java
// Obtain the coordinates of a point at a specific distance from the start of the road segment
Point outPoint = new Point();
boolean result = link.getPointByDist(50, outPoint, UnitOfMeasure.Metric);
if (result) {
    double x = outPoint.x();
    double y = outPoint.y();
}
```

**public boolean getPointAndIndexByDist(double dist, Point outPoint, int outIndex, UnitOfMeasure unit)**

Calculate the point and segment index at a distance dist extended forward from the centerline start point; return false if the target point is not on the centerline, otherwise return true. Unit: Pixel.

Parameters: 

[ in ] dist: Distance extended forward from the centerline start point.

[ out ] outPoint: The point at a distance dist extended forward from the centerline start point.

[ out ] outIndex: Index of the segment located at a distance dist forward from the start point of the centerline.

**public Vector\<Point\> polygon()**

Retrieve the polygonal contour vertices of the road segment.

#### 3.4.1.4. Connection Segment (IConnector)

**public int gtype()**

Type, the connection segment type is GConnectorType.

**public long id()**

Get the connection segment ID.

**public double length(UnitOfMeasure unit)**

Get the connection segment length. Unit: pixel.

**public double z(UnitOfMeasure unit)**

Get the connection segment elevation. Unit: pixel.

**public double v3z(UnitOfMeasure unit)**

Get the connection segment elevation. Unit: pixel.

**public String name()**

Get the connection segment name.

**public void setName(String name)**

Set the connection segment name.

**public ILink fromLink()**

Get the starting road segment.

**public ILink toLink()**

Get the target road segment.

**public double limitSpeed(UnitOfMeasure unit)**

Get the maximum speed limit of the connection segment. Unit: km/h.

**public double minSpeed(UnitOfMeasure unit)**

Get the minimum speed limit of the connection segment. Unit: km/h.

**public ArrayList\<ILaneConnector\> laneConnectors()**

Get the list of lane connections.

**public ArrayList\<ILaneObject\> laneObjects()**

List of interfaces for Lanes and Lane Connections.

**public void setLaneConnectorOtherAtrrs(ArrayList\<JsonObject\> lAttrs)**

Set other properties included in the lane connections.

**public void setOtherAttr(JsonObject otherAttr)**

​	Set other properties of the Connection Segment.

**public Vector\<Point\> polygon()**

​	Retrieve the polygonal contour vertices of the Connection Segment.

#### 3.4.1.5. Base Class for Lane (ILaneObject)

​	The base class for Lane and Lane Connection.

**public int gtype()**

​	Type: GLaneType or GLaneConnectorType.

**public boolean isLane()**

​	Indicates whether it is a Lane.

**public long id()**

​	Get the ID. If it is a Lane, the id is the Lane's ID; if it is a Lane Connection, the id is the Lane Connection's ID.

**public double length(UnitOfMeasure unit)**

​	Get the length. Unit: pixel.

**public ISection section()**

​	Get the associated ISection.

**public ILaneObject fromLaneObject(long id)**

​	Retrieve the upstream LaneObject by ID. If currently a Lane, returns null when id is 0; otherwise, returns the upstream Lane Connection with the specified ID. If currently a Connection Segment, returns the upstream Lane when id is 0; otherwise, returns null.

**public ILaneObject toLaneObject(long id)**

Retrieve the downstream LaneObject by ID. If the current object is a lane, returns null when id is 0; otherwise, returns the downstream Lane Connection specified by the ID. If the current object is a Connection Segment, returns the downstream lane when id is 0; otherwise, returns null.

**public ArrayList\<Point\> centerBreakPoints(UnitOfMeasure unit)**

Retrieve the centerline breakpoint set. Unit: Pixel.

**public ArrayList\<Point\> leftBreakPoints(UnitOfMeasure unit)**

Retrieve the left boundary line breakpoint set. Unit: Pixel.

**public ArrayList\<Point\> rightBreakPoints(UnitOfMeasure unit)**

Retrieve the right boundary line breakpoint set. Unit: Pixel.

**public ArrayList\<Vector3D\> centerBreakPoint3Ds(UnitOfMeasure unit)**

Retrieve the three-dimensional centerline breakpoint set. Unit: Pixel.

**public ArrayList\<Vector3D\> leftBreakPoint3Ds(UnitOfMeasure unit)**

Retrieve the three-dimensional left boundary line breakpoint set. Unit: Pixel.

**public ArrayList\<Vector3D\> rightBreakPoint3Ds(UnitOfMeasure unit)**

Retrieve the three-dimensional right boundary line breakpoint set. Unit: Pixel.

**public ArrayList\<Vector3D\> leftBreak3DsPartly(Point fromPoint, Point toPoint, UnitOfMeasure unit)**

Retrieve the three-dimensional partial left breakpoint set. Unit: Pixel.

Parameters: 

[ in ] fromPoint: A point on the centerline serving as the start point.

[ in ] toPoint: A point on the centerline designated as the endpoint.

**public ArrayList\<Vector3D\> rightBreak3DsPartly(Point fromPoint, Point toPoint, UnitOfMeasure unit)**

Retrieve the right-side partial 3D breakpoint set. Unit: Pixel.

Parameters: 

[ in ] fromPoint: A point on the centerline serving as the start point.

[ in ] toPoint: A point on the centerline designated as the endpoint.

**public double distToStartPoint(Point p, UnitOfMeasure unit)**

Distance from a point on the centerline to the start point. Unit: Pixel.

Parameters: 

[ in ] p: Coordinates of the current point.

**public double distToStartPointWithSegmIndex(Point p, int segmIndex, boolean bOnCentLine, UnitOfMeasure unit)**

Distance from a point on the centerline to the start point, with the additional condition being the segment index of the lane where the point resides. Unit: Pixel.

Parameters: 

[ in ] p: Coordinates of the current point.

[ in ] segmIndex: The segment index of the lane where the point resides.

[ in ] bOnCentLine: Indicates whether the point is on the centerline.

**public boolean getPointAndIndexByDist(double dist, Point outPoint, int outIndex, UnitOfMeasure unit)**

Calculate the point and segment index at a distance dist extended forward from the centerline start point; return false if the target point is not on the centerline, otherwise return true. Unit: Pixel.

Parameters: 

[ in ] dist: Distance extended forward from the centerline start point.

[ out ] outPoint: The point at a distance dist extended forward from the centerline start point.

[ out ] outIndex: Index of the segment located at a distance dist forward from the start point of the centerline.

**public boolean getPointByDist(double dist, Point outPoint, UnitOfMeasure unit)**

Calculate the point at a distance dist extended forward from the centerline start point; return false if the target point is not on the centerline, otherwise return true. Unit: Pixel.

Parameters: 

[ in ] dist: Distance extended forward from the centerline start point.

[ out ] outPoint: The point at a distance dist extended forward from the centerline start point.

**public void setOtherAttr(JsonObject attr)**

Set other attributes of the lane or lane connection.

**public ILane castToLane()**

Convert ILaneObject to ILane; returns null if the current ILaneObject is a lane connection.

**public ILaneConnector castToLaneConnector()**

Convert ILaneObject to ILaneConnector; returns null if the current ILaneObject is a lane.

#### 3.4.1.6. Lane (ILane)

**public int gtype()**

Type: the lane type is GLaneType.

**public long id()**

Obtain the lane ID.

**public ILink link()**

Obtain the road segment where the lane is located.

**public ISection section()**

Obtain the section to which the lane belongs.

**public double length(UnitOfMeasure unit)**

Obtain the lane length. Unit: Pixel.

**public double width(UnitOfMeasure unit)**

Obtain the lane width. Unit: Pixel.

**public int number()**

Obtain the lane index, starting from 0 (counted from the outer side to the inner side, i.e., numbered sequentially from right to left).

**public String actionType()**

Obtain the lane’s behavioral type.

**public ArrayList\<ILaneConnector\> fromLaneConnectors()**

Obtain the upstream lane connection list.

**public ArrayList\<ILaneConnector\> toLaneConnectors()**

Obtain the downstream lane connection list.

**public ArrayList\<Point\> centerBreakPoints(UnitOfMeasure unit)**

Obtain the lane centerline breakpoint set. Unit: Pixel.

**public ArrayList\<Point\> leftBreakPoints(UnitOfMeasure unit)**

Obtain the lane left boundary breakpoint set. Unit: Pixel.

**public ArrayList\<Point\> rightBreakPoints(UnitOfMeasure unit)**

Obtain the lane right boundary breakpoint set. Unit: Pixel.

**public ArrayList\<Vector3D\> centerBreakPoint3Ds(UnitOfMeasure unit)**

Obtain the lane centerline 3D breakpoint set. Unit: Pixel.

**public ArrayList\<Vector3D\> leftBreakPoint3Ds(UnitOfMeasure unit)**

​	Retrieve the 3D breakpoint set of the lane's left boundary line. Unit: pixel.

**public ArrayList\<Vector3D\> rightBreakPoint3Ds(UnitOfMeasure unit)**

​	Retrieve the 3D breakpoint set of the lane's right boundary line. Unit: pixel.

**public ArrayList\<Vector3D\> leftBreak3DsPartly(Point fromPoint, Point toPoint, UnitOfMeasure unit)**

Retrieve the three-dimensional partial left breakpoint set. Unit: Pixel.

Parameters: 

[ in ] fromPoint: A point on the centerline serving as the start point.

[ in ] toPoint: A point on the centerline designated as the endpoint.

**public ArrayList\<Vector3D\> rightBreak3DsPartly(Point fromPoint, Point toPoint, UnitOfMeasure unit)**

Retrieve the right-side partial 3D breakpoint set. Unit: Pixel.

Parameters: 

[ in ] fromPoint: A point on the centerline serving as the start point.

[ in ] toPoint: A point on the centerline designated as the endpoint.

**public double distToStartPoint(Point p, UnitOfMeasure unit)**

Distance from a point on the centerline to the start point. Unit: Pixel.

Parameters: 

[ in ] p: Coordinates of the current point.

**public double distToStartPointWithSegmIndex(Point p, int segmIndex, boolean bOnCentLine, UnitOfMeasure unit)**

Distance from a point on the centerline to the start point, with the additional condition being the segment index of the lane where the point resides. Unit: Pixel.

Parameters: 

​	[ in ] p: The coordinate of the point on the current centerline.

[ in ] segmIndex: The segment index of the lane where the point resides.

[ in ] bOnCentLine: Indicates whether the point is on the centerline.

**public boolean getPointAndIndexByDist(double dist, Point outPoint, int outIndex, UnitOfMeasure unit)**

Calculate the point and segment index at a distance dist extended forward from the centerline start point; return false if the target point is not on the centerline, otherwise return true. Unit: Pixel.

Parameters: 

[ in ] dist: Distance extended forward from the centerline start point.

[ out ] outPoint: The point at a distance dist extended forward from the centerline start point.

[ out ] outIndex: Index of the segment located at a distance dist forward from the start point of the centerline.

**public boolean getPointByDist(double dist, Point outPoint, UnitOfMeasure unit)**

Calculate the point at a distance dist extended forward from the centerline start point; return false if the target point is not on the centerline, otherwise return true. Unit: Pixel.

Parameters: 

[ in ] dist: Distance extended forward from the centerline start point.

[ out ] outPoint: The point at a distance dist extended forward from the centerline start point.

Example:

```java
// Obtain point coordinates at a specified distance from the lane start
Point outPoint = new Point();
boolean result = lane.getPointByDist(50, outPoint, UnitOfMeasure.Metric);
if (result) {
    double x = outPoint.x();
    double y = outPoint.y();
}
```

**public void setOtherAttr(JsonObject attr)**

Set additional lane attributes.

**public void setLaneType(String type)**

​	Set the lane type.

Parameters: 

​	[ in ] type: Lane type; select one of the following: "Motor Vehicle Lane", "Shared Motor and Non-motor Lane", "Non-motor Vehicle Lane", "Bus Exclusive Lane".

Example:

```java
// Set lane type
lane.setLaneType("MotorizedLane");
```

**public Vector\<Point\> polygon()**

​	Retrieve the polygonal contour vertices of the lane.

#### 3.4.1.7. Lane Connection (ILaneConnector)

**public int gtype()**

​	Type, GLaneType or GLaneConnectorType; the lane connection segment uses GLaneConnectorType.

**public long id()**

​	Retrieve the lane connection ID.

**public IConnector connector()**

​	Retrieve the connection segment to which the lane connection belongs.

**public ISection section()**

Obtain the section to which the lane belongs.

**public ILane fromLane()**

Upstream lane.

**public ILane toLane()**

Downstream lane.

**public double length(UnitOfMeasure unit)**

Get lane connection length. Unit: pixel.

**public ArrayList\<Point\> centerBreakPoints(UnitOfMeasure unit)**

Get lane connection centerline breakpoint set. Unit: pixel.

**public ArrayList\<Point\> leftBreakPoints(UnitOfMeasure unit)**

Get lane connection left line breakpoint set. Unit: pixel.

**public ArrayList\<Point\> rightBreakPoints(UnitOfMeasure unit)**

Get lane connection right line breakpoint set. Unit: pixel.

**public ArrayList\<Vector3D\> centerBreakPoint3Ds(UnitOfMeasure unit)**

Get lane connection centerline 3D breakpoint set. Unit: pixel.

**public ArrayList\<Vector3D\> leftBreakPoint3Ds(UnitOfMeasure unit)**

Get lane connection left line 3D breakpoint set. Unit: pixel.

**public ArrayList\<Vector3D\> rightBreakPoint3Ds(UnitOfMeasure unit)**

Get lane connection right line 3D breakpoint set. Unit: pixel.

**public ArrayList\<Vector3D\> leftBreak3DsPartly(Point fromPoint, Point toPoint, UnitOfMeasure unit)**

Get lane connection left portion 3D breakpoint set. Unit: pixel.

Parameters: 

[ in ] fromPoint: A point on the centerline serving as the start point.

[ in ] toPoint: A point on the centerline designated as the endpoint.

**public ArrayList\<Vector3D\> rightBreak3DsPartly(Point fromPoint, Point toPoint, UnitOfMeasure unit)**

Get lane connection right portion 3D breakpoint set. Unit: pixel.

Parameters: 

[ in ] fromPoint: A point on the centerline serving as the start point.

[ in ] toPoint: A point on the centerline designated as the endpoint.

**public double distToStartPoint(Point p, UnitOfMeasure unit)**

Distance from a point on the centerline to the start point. Unit: Pixel.

Parameters: 

[ in ] p: Coordinates of the current point.

**public double distToStartPointWithSegmIndex(Point p, int segmIndex, boolean bOnCentLine, UnitOfMeasure unit)**

Distance from a point on the centerline to the start point, with the additional condition being the segment index of the lane where the point resides. Unit: Pixel.

Parameters: 

[ in ] p: Coordinates of the current point.

[ in ] segmIndex: segment index.

[ in ] bOnCentLine: Indicates whether the point is on the centerline.

**public boolean getPointAndIndexByDist(double dist, Point outPoint, int outIndex, UnitOfMeasure unit)**

Calculate the point and segment index at a distance dist extended forward from the centerline start point; return false if the target point is not on the centerline, otherwise return true. Unit: Pixel.

Parameters: 

[ in ] dist: Distance extended forward from the centerline start point.

[ out ] outPoint: The point at a distance dist extended forward from the centerline start point.

[ out ] outIndex: Index of the segment located at a distance dist forward from the start point of the centerline.

**public boolean getPointByDist(double dist, Point outPoint, UnitOfMeasure unit)**

Calculate the point at a distance dist extended forward from the centerline start point; return false if the target point is not on the centerline, otherwise return true. Unit: Pixel.

Parameters: 

[ in ] dist: Distance extended forward from the centerline start point.

[ out ] outPoint: The point at a distance dist extended forward from the centerline start point.

**public void setOtherAttr(JsonObject attr)**

Set other properties of the lane connection.

#### 3.4.1.8. Connection Segment Area (IConnectorArea)

**public long id()**

Area ID. The area refers to a region formed by overlapping multiple connectors.

**public ArrayList\<IConnector\> allConnector()**

All connection segments associated with the area.

**public Point centerPoint(UnitOfMeasure unit)**

Retrieve the center position of the area. Unit: pixel.

### 3.4.2. Dispatch Point

#### 3.4.2.1. Dispatch Point (IDispatchPoint)

**public long id()**

Retrieve the dispatch point ID.

**public String name()**

Retrieve the dispatch point name.

**public ILink link()**

Retrieve the road segment where the dispatch point is located.

**public long addDispatchInterval(long vehiCompId, int interval, int vehiCount)**

Add a dispatch interval for the dispatch point.

Parameters: 

[ in ] vehiCompId: vehicle type composition ID.

[ in ] interval: time duration. Unit: s.

​	[ in ] vehiCount: Number of dispatches.

Return value: 

​	Dispatch interval ID.

**public void setDynaModified(boolean bModified)**

​	Set whether it is dynamically modified. By default, once the dispatch information is dynamically modified, the entire file cannot be saved to prevent damage to the original dispatch settings.

**public Vector\<Point\> polygon()**

​	Get the vertices of the dispatch point polygon outline.

### 3.4.3. Decision Points and Vehicle Paths

#### 3.4.3.1. Decision Point (IDecisionPoint)

**public long id()**

​	Decision Point ID.

**public String name()**

​	Decision Point name.

**public ILink link()**

​	Road segment where the Decision Point is located.

**public double distance(UnitOfMeasure unit)**

​	Get the distance from the start of the road segment. Unit: Pixel.

**public ArrayList\<IRouting\> routings()**

​	Related decision routes.

**public void setDynaModified(boolean bModified)**

​	Set whether it is dynamically modified. By default, once the dispatch information is dynamically modified, the entire file cannot be saved to prevent damage to the original dispatch settings.

Parameters: 

​	[ in ] bModified: Indicates whether it has been dynamically modified; true means modified, false means not modified.

**public Vector\<Point\> polygon()**

Vertices of the decision point polygonal contour.

#### 3.4.3.2. Vehicle Path (IRouting)

**public long id()**

Route ID.

**public double calcuLength(UnitOfMeasure unit)**

Calculate the route length. Unit: Pixel.

**public ArrayList\<ILink\> getLinks()**

Obtain the sequence of road segments.

**public long deciPointId()**

Associated decision point ID.

**public boolean contain(ISection pRoad)**

Determine whether the given road is on the current route.

Parameters: 

[ in ] pRoad: Road segment or connection segment.

**public ISection nextRoad(ISection pRoad)**

Retrieve the subsequent road based on the given road.

Parameters: 

[ in ] pRoad: Road segment or connection segment.

### 3.4.4. Signal Control

#### 3.4.4.1. Signal Controller (ISignalController)

**public long id()**

Get the signal controller ID.

**public String name()**

Get the signal controller name.

**public void setName(String name)**

Set the signal controller name.

Parameters: 

[ in ] name: New name.

**public void addPlan(ISignalPlan plan)**

Add a signal control plan.

Parameters: 

[ in ] plan: Signal control plan.

**public void removePlan(ISignalPlan plan)**

Remove the signal control plan.

Parameters: 

[ in ] plan: Signal control plan to be removed.

**public ArrayList\<ISignalPlan\> plans()**

Retrieve all signal control plans.

**public boolean isValid()**

Verify the validity of the signal controller.

#### 3.4.4.2. Signal Control Plan (ISignalPlan)

**public long id()**

Get ID.

**public String Name()**

Get traffic signal group name.

**public String trafficName()**

Get the name of the signal control plan.

**public int cycleTime()**

Get signal cycle. Unit: seconds.

**public long fromTime()**

Get start time. Unit: seconds.

**public long toTime()**

Get end time. Unit: seconds.

**public ArrayList\<ISignalPhase\> phases()**

Get the list of phases.

**public void setName(String name)**

Set the name of the signal control plan.

Parameters: 

[ in ] name: New name.

**public void setcycleTime(int period)**

Set signal cycle. Unit: seconds.

Parameters: 

[ in ] period: Signal cycle. Unit: seconds.

**public void setFromTime(long time)**

Set start time. Unit: seconds.

Parameters: 

[ in ] time: Start time. Unit: s.

**public void setToTime(long time)**

Set end time. Unit: s.

Parameters: 

[ in ] time: End time. Unit: s.

#### 3.4.4.3. Traffic Signal Phase (ISignalPhase)

**public long id()**

Phase ID.

**public String phaseName()**

Phase Name.

**public ArrayList\<ColorInterval\> listColor()**

Get the list of phase light colors.

**public void setColorList(ArrayList\<ColorInterval\> lColor)**

Set the list of traffic signals.

Parameters: 

[ in ] lColor: Light duration information, including traffic signal color and signal duration.

Example:

```java
// Construct a list of lamp color and duration objects
ArrayList<ColorInterval> colorObjList = new ArrayList<>(Arrays.asList(
    new ColorInterval ("R", 10),  // Red, duration 10
    new ColorInterval ("G", 60),  // Green, duration 60
    new ColorInterval ("Y", 3),  // Yellow, duration 3
    new ColorInterval ("R", 17)  // Red, duration 17
));
// Find the traffic signal phase with ID 7
SignalPhase signalPhase = netiface.findSignalPhase(7);
if (signalPhase != null) {
    // Set the list of light colors
    signalPhase.setColorList(colorObjList);
}
```

**public int cycleTime()**

Get the phase cycle. Unit: s.

**public SignalPhaseColor phaseColor()**

Get the current phase light color.

**public ISignalPlan signalPlan()**

Get the signal control plan associated with the phase.

**public ArrayList\<ISignalLamp\> signalLamps()**

Get the list of related traffic signals.

**public void setPhaseName(String name)**

Set the phase name.

Parameters: 

[ in ] name: New name.

#### 3.4.4.4. Traffic Signal Lamp Head (ISignalLamp)

**public long id()**

Obtain the Traffic Signal ID.

**public void setSignalPhase(ISignalPhase pPhase)**

Set the phase. The specified phase may correspond to that of another Traffic Signal group.

Parameters: 

[ in ] pPhase: Phase.

**public void setPhaseNumber(int num)**

Set the phase index, with numbering starting at 1. If the index exceeds the total number of phases, the setting will not be applied.

**public void setLampColor(String colorStr)**

Set the Traffic Signal Color.

Parameters: 

[ in ] colorStr: Color specified as a string. Four options are available: "Red", "Green", "Yellow", "Gray", or alternatively "R", "G", "Y", "grey". 

**public String color()**

Obtain the Traffic Signal Color. "R", "G", "Y", and "gray" correspond to "Red", "Green", "Yellow", and "Gray" respectively.

**public String name()**

Get Traffic Signal Name.

**public void setName(String name)**

Set Traffic Signal Name.

**public void setDistToStart(double dist, UnitOfMeasure unit)**

Set Traffic Signal Distance from Road Segment Start. Unit: Pixels.

Parameters: 

[ in ] dist: Distance value.

**public ISignalPlan signalPlan()**

Get Signal Control Plan.

**public ISignalPhase signalPhase()**

Get Phase.

**public ILaneObject laneObject()**

Get Lane or Lane Connection.

**public Vector\<Point\> polygon()**

Get Vertices of the Traffic Signal Polygon Outline.

**public double angle()**

Get Traffic Signal Angle.

### 3.4.5. Data Collection Devices

#### 3.4.5.1. Data Collector (IVehicleDrivInfoCollector)

**public long id()**

Get Collector ID.

**public String collName()**

Get Collector Name.

**public boolean onLink()**

Indicates whether it is on a Road Segment; if true, connector() returns null.

**public ILink link()**

Road Segment where the Collector is located.

**public IConnector connector()**

Connection Segment where the collector is located.

**public ILane lane()**

Returns the Lane if the collector is on a Road Segment; otherwise, returns null.

**public ILaneConnector laneConnector()**

Returns the Lane Connection if the collector is on a Connection Segment; otherwise, returns null.

**public double distToStart(UnitOfMeasure unit)**

Gets the distance from the collector to the start point of the Road Segment. Unit: Pixel.

**public Point point(UnitOfMeasure unit)**

Gets the collector's position coordinates. Unit: Pixel.

**public long fromTime()**

Collector start time. Unit: s.

**public long toTime()**

Collector stop time. Unit: s.

**public long aggregateInterval()**

Aggregated data interval. Unit: s.

**public void setName(String name)**

Sets the collector name.

**public void setDistToStart(double dist, UnitOfMeasure unit)**

Sets the distance from the collector to the start point of the Road Segment. Unit: Pixel.

Parameters: 

[ in ] dist: Distance value.

**public void setFromTime(long time)**

Sets the collector start time. Unit: s.

Parameters: 

[ in ] time: Start time of operation. Unit: s.

**public void setToTime(long time)**

Set the collector operation end time. Unit: s.

Parameters: 

[ in ] time: End time of operation. Unit: s.

**public void setAggregateInterval(int interval)**

Set the data aggregation interval of the collector. Unit: s.

**public Vector\<Point\> polygon()**

Get the polygonal outline vertices of the collector.

#### 3.4.5.2. Queue Counter (IVehicleQueueCounter)

**public long id()**

Get the counter ID.

**public String counterName()**

Get the counter name.

**public boolean onLink()**

Indicates whether it is on a Road Segment; if true, connector() returns null.

**public ILink link()**

Road segment where the counter is located.

**public IConnector connector()**

Connection segment where the counter is located.

**public ILane lane()**

Returns the lane if the counter is on a road segment; otherwise, returns null.

**public ILaneConnector laneConnector()**

Returns the lane connection if the counter is on a connection segment; otherwise, returns null.

**public double distToStart(UnitOfMeasure unit)**

Get the distance from the counter to the start point of the road segment. Unit: pixel.

**public Point point(UnitOfMeasure unit)**

Get the counter position coordinates. Unit: Pixel.

**public long fromTime()**

Counter operation start time. Unit: s.

**public long toTime()**

Counter operation stop time. Unit: s.

**public long aggregateInterval()**

Counter aggregated data time interval. Unit: s.

**public void setName(String name)**

Set the counter name.

Parameters: 

[ in ] name: Counter name.

**public void setDistToStart(double dist, UnitOfMeasure unit)**

Set the counter distance from the start of the road segment. Unit: Pixel.

Parameters: 

[ in ] dist: Distance value.

**public void setFromTime(long time)**

Set the operation start time. Unit: s.

**public void setToTime(long time)**

Set the operation end time. Unit: s.

**public void setAggregateInterval(int interval)**

Set the aggregated data time interval. Unit: s.

**public Vector\<Point\> polygon()**

Get the polygonal contour vertices of the counter.

#### 3.4.5.3. Travel Time Detector (IVehicleTravelDetector)

**public long id()**

Get the detector ID.

**public String detectorName()**

Get the detector name.

**public boolean isStartDetector()**

Is this the detector start point?

**public boolean isOnLink_startDetector()**

Indicates whether the detector start point is on the road segment; if not, it is on the connection segment.

**public boolean isOnLink_endDetector()**

Indicates whether the detector endpoint is on the road segment; if not, it is on the connection segment.

**public ILink link_startDetector()**

Returns the road segment where the detector start point is located; otherwise, returns null.

**public ILaneConnector laneConnector_startDetector()**

Returns the lane connection where the detector start point is located; otherwise, returns null.

**public ILink link_endDetector()**

Returns the road segment where the detector endpoint is located; otherwise, returns null.

**public ILaneConnector laneConnector_endDetector()**

Returns the lane connection where the detector endpoint is located; otherwise, returns null.

**public double distance_startDetector(UnitOfMeasure unit)**

Gets the distance from the detector start point to the start of the road segment. Unit: Pixel.

**public double distance_endDetector(UnitOfMeasure unit)**

Obtain the distance from the end detector to the start point of the road segment. Unit: Pixel.

**public Point point_startDetector(UnitOfMeasure unit)**

Obtain the coordinate position of the start detector. Unit: Pixel.

**public Point point_endDetector(UnitOfMeasure unit)**

Obtain the coordinate position of the end detector. Unit: Pixel.

**public long fromTime()**

Detector operation start time. Unit: s.

**public long toTime()**

Detector operation stop time. Unit: s.

**public long aggregateInterval()**

Aggregated data interval. Unit: s.

**public void setName(String name)**

Set the detector name.

**public void setDistance_startDetector(double dist, UnitOfMeasure unit)**

Set the distance from the start detector to the start point of the road segment. Unit: Pixel.

Parameters: 

[ in ] dist: Distance value.

**public void setDistance_endDetector(double dist, UnitOfMeasure unit)**

Set the distance from the end detector to the start point of the road segment. Unit: Pixel.

Parameters: 

[ in ] dist: Distance value.

**public void setFromTime(long time)**

Set the detector operation start time. Unit: s.

Parameters: 

[ in ] time: Start time of operation. Unit: s.

**public void setToTime(long time)**

Set the detector operation end time. Unit: s.

Parameters: 

[ in ] time: End time of operation. Unit: s.

**public void setAggregateInterval(int interval)**

Set the detector aggregated data time interval. Unit: s.

Parameters: 

[ in ] interval: Aggregated data time interval. Unit: s.

**public Vector\<Point\> polygon_startDetector()**

Retrieve the vertices of the polygonal outline at the starting point of the Travel Time Detector.

**public Vector\<Point\> polygon_endDetector()**

Retrieve the vertices of the polygonal outline at the ending point of the Travel Time Detector.

### 3.4.6. Guidance Arrows

#### 3.4.6.1. Guidance Arrow (IGuidArrow)

**public long id()**

Get the ID of the guidance arrow.

**public ILane lane()**

Get the lane where the guidance arrow is located.

**public double length(UnitOfMeasure unit)**

Get the length of the guidance arrow. Unit: pixels.

**public double distToTerminal(UnitOfMeasure unit)**

Get the distance from the guidance arrow to the endpoint. Unit: pixels.

**public GuideArrowType arrowType()**

Get the type of the guidance arrow. The types include: straight, left turn, right turn, straight or left turn, straight or right turn, straight left turn or right turn, left turn or right turn, U-turn, straight or U-turn, and left turn or U-turn.

**public Vector\<Point\> polygon()**

Retrieve the vertices of the polygonal outline of the guiding arrow.

### 3.4.7. Bus System

#### 3.4.7.1. Bus Route (IBusLine)

**public long id()**

Retrieve the bus route ID.

**public String name()**

Route name.

**public double length(UnitOfMeasure unit)**

Retrieve the length of the bus route. Unit: Pixel.

**public int dispatchFreq()**

Departure interval. Unit: s.

**public int dispatchStartTime()**

Departure start time. Unit: s.

**public int dispatchEndTime()**

Departure end time. Unit: s.

**public double desirSpeed(UnitOfMeasure unit)**

Retrieve the desired speed of the bus route. Unit: Pixel/s.

**public int passCountAtStartTime()**

Initial passenger count.

**public ArrayList\<ILink\> links()**

Road segments traversed by the bus route.

**public ArrayList\<IBusStation\> stations()**

All stops on the route.

**public ArrayList\<IBusStationLine\> stationLines()**

Bus stop line, parameters related to passenger boarding and alighting at stops pertinent to the current route.

**public void setName(String name)**

Set the route name.

**public void setDispatchFreq(int freq)**

Set the departure interval for the current bus route. Unit: s.

Parameters: 

[ in ] freq: Departure interval. Unit: s.

**public void setDispatchStartTime(int startTime)**

Set the start departure time for the first bus vehicle on the current bus route. Unit: s.

Parameters: 

[ in ] startTime: Start departure time. Unit: s.

**public void setDispatchEndTime(int endTime)**

Set the end departure time for the last bus vehicle on the current bus route. Unit: s.

Parameters: 

[ in ] endTime: End departure time. Unit: s.

**public void setDesirSpeed(double speed, UnitOfMeasure unit)**

Set the desired speed for the current bus route. Unit: Pixel/s.

Parameters: 

[ in ] speed: Speed value.

**public void setPassCountAtStartTime(int count)**

Set the initial passenger count.

#### 3.4.7.2. Bus Station (IBusStation)

**public long id()**

Get the bus station ID.

**public String name()**

Get the bus stop name.

**public int laneNumber()**

Get the lane index where the bus stop is located.

**public double x(UnitOfMeasure unit)**

Get the X coordinate of the bus stop. Unit: Pixel.

**public double y(UnitOfMeasure unit)**

Get the Y coordinate of the bus stop. Unit: Pixel.

**public double length(UnitOfMeasure unit)**

Get the length of the bus stop. Unit: Pixel.

**public int stationType()**

Bus stop type, 1: Curbside, 2: Bay-type.

**public ILink link()**

Road segment where the bus stop is located.

**public ILane lane()**

Lane where the bus stop is located.

**public double distance(UnitOfMeasure unit)**

Get the distance from the bus stop to the start of the road segment. Unit: Pixel.

**public void setName(String name)**

Set the bus stop name.

Parameters: 

[ in ] name: New name.

**public void setDistToStart(double dist, UnitOfMeasure unit)**

Set the distance from the bus stop to the start of the road segment. Unit: Pixel.

Parameters: 

[ in ] dist: Distance value.

**public void setLength(double length, UnitOfMeasure unit)**

Set the length of the bus stop. Unit: Pixel.

Parameters: 

[ in ] length: length value.

**public void setType(int type)**

Set the bus stop type.

Parameters: 

[ in ] type: Station type, 1 Curbside, 2 Bay.

**public Vector\<Point\> polygon()**

Vertices of the polygonal outline of the bus station.

#### 3.4.7.3. Bus Station - Line (IBusStationLine)

**public long id()**

Get the Bus "Station-Line" ID.

**public long stationId()**

Bus Station ID.

**public long lineId()**

Bus Route ID.

**public int busParkingTime()**

Vehicle dwell time. Unit: s.

**public double getOutPercent()**

Percentage of passengers alighting.

**public double getOnTimePerPerson()**

Average boarding time per passenger. Unit: s.

**public double getOutTimePerPerson()**

Average alighting time per passenger. Unit: s.

**public void setBusParkingTime(int time)**

Set vehicle dwell time.

Parameters: 

[ in ] time: Vehicle dwell time. Unit: s.

**public void setGetOutPercent(double percent)**

Set the alighting percentage.

Parameters: 

[ in ] percent: Alighting percentage.

**public void setGetOnTimePerPerson(double time)**

Set the average boarding time per passenger.

Parameters: 

[ in ] time: Average boarding time per passenger. Unit: s.

**public void setGetOutTimePerPerson(double time)**

Set the average alighting time per passenger.

Parameters: 

[ in ] time: Average alighting time per passenger. Unit: s.

### 3.4.8. Event Zone

#### 3.4.8.1. Accident Zone (IAccidentZone)

**public long id()**

Retrieve the accident zone ID.

**public String name()**

Retrieve the accident zone name.

**public double location(UnitOfMeasure unit)**

Retrieve the distance from the start of the road segment to the accident zone during the current time period. Unit: Pixel.

**public double zoneLength(UnitOfMeasure unit)**

Retrieve the length of the accident zone during the current time period. Unit: Pixel.

**public double limitedSpeed(UnitOfMeasure unit)**

Obtain the current time limit in the accident area. Unit: Pixel (km/h).

**public ISection section()**

Retrieve the road segment or connection segment where the accident zone is located.

**public long roadId()**

Retrieve the ID of the road segment where the accident zone is located.

**public String roadType()**

Retrieve the type of road (road segment or connection segment) where the accident zone is located.

**public ArrayList\<ILaneObject\> laneObjects()**

Retrieve the list of lanes occupied by the accident zone during the current time interval.

**public double controlLength(UnitOfMeasure unit)**

Retrieve the control distance for the accident zone during the current time interval (vehicles within this distance from the start of the accident zone are required to change lanes). Unit: Pixel.

**public IAccidentZoneInterval addAccidentZoneInterval(DynaAccidentZoneIntervalParam param)**

Add an accident time interval.

Parameters: 

[ in ] param: Accident time interval parameter.

**public void removeAccidentZoneInterval(long accidentZoneIntervalId)**

Remove an accident time interval.

Parameters: 

[ in ] accidentZoneIntervalId: Accident time interval ID.

**public boolean updateAccidentZoneInterval(DynaAccidentZoneIntervalParam param)**

Update an accident time interval.

Parameters: 

[ in ] param: Accident time interval parameter.

**public ArrayList\<IAccidentZoneInterval\> accidentZoneIntervals()**

Retrieve all accident time intervals.

**public IAccidentZoneInterval findAccidentZoneIntervalById(long accidentZoneIntervalId)**

Query an accident time interval by ID.

Parameters: 

[ in ] accidentZoneIntervalId: Accident time interval ID.

**public IAccidentZoneInterval findAccidentZoneIntervalByStartTime(long startTime)**

Query accident intervals by start time.

Parameters: 

[ in ] startTime: Start time of the accident interval.

#### 3.4.8.2. Accident Zone Interval (IAccidentZoneInterval)

**public long intervalId()**

Get the accident interval ID.

**public long accidentZoneId()**

Get the related accident zone ID.

**public long startTime()**

Get the accident interval start time.

**public long endTime()**

Get the accident interval end time.

**public double length(UnitOfMeasure unit)**

Get the length of the accident zone during this interval. Unit: Pixel.

**public double location(UnitOfMeasure unit)**

Get the distance from the starting point to the accident zone during this interval. Unit: Pixel.

**public double limitedSpeed(UnitOfMeasure unit)**

Get the speed limit of the accident zone during this interval. Unit: Pixel (km/h).

**public double controlLength(UnitOfMeasure unit)**

Get the control distance of the accident zone during this interval (vehicles within this distance from the start point of the accident zone must change lanes). Unit: Pixel.

**public ArrayList\<Int\> laneNumbers()**

Retrieve the lane index occupied by the accident zone during the specified time period.

#### 3.4.8.3. Construction Zone (IRoadWorkZone)

**public long id()**

Retrieve the Construction Zone ID.

**public String name()**

Retrieve the Construction Zone name.

**public double location(UnitOfMeasure unit)**

Retrieve the distance from the Construction Zone to the starting point of its road segment. Unit: Pixel.

**public double zoneLength(UnitOfMeasure unit)**

Retrieve the length of the Construction Zone. Unit: Pixel.

**public double limitSpeed(UnitOfMeasure unit)**

Retrieve the speed limit of the Construction Zone. Unit: Pixel (km/h).

**public long sectionId()**

Retrieve the ID of the road segment or connection segment where the Construction Zone is located.

**public String sectionName()**

Retrieve the name of the road segment or connection segment where the Construction Zone is located.

**public String sectionType()**

Retrieve the road type of the road where the Construction Zone is located. Values: link (road segment), connector (connection segment).

**public ArrayList\<ILaneObject\> laneObjects()**

Retrieve the list of lanes occupied by the Construction Zone.

**public ArrayList\<Long\> laneObjectIds()**

Retrieve the list of Lane IDs occupied by the Construction Zone.

**public double upCautionLength(UnitOfMeasure unit)**

Retrieve the length of the upstream warning area of the Construction Zone, in pixels.

**public double upTransitionLength(UnitOfMeasure unit)**

Retrieve the length of the upstream transition area of the Construction Zone, in pixels.

**public double upBufferLength(UnitOfMeasure unit)**

Retrieve the length of the upstream buffer area of the Construction Zone, in pixels.

**public double downTransitionLength(UnitOfMeasure unit)**

Retrieve the length of the downstream transition area of the Construction Zone, in pixels.

**public double downTerminationLength(UnitOfMeasure unit)**

Retrieve the length of the downstream termination area of the Construction Zone, in pixels.

**public long duration()**

Construction duration. If the duration since the simulation process creation exceeds this value, the Construction Zone will be removed. Unit: seconds.

**public boolean isBorrowed()**

Determine whether the Construction Zone involves lane borrowing.

#### 3.4.8.4. Limited Zone (ILimitedZone)

**public long id()**

Retrieve the Limited Zone ID.

**public String name()**

Retrieve the Limited Zone name.

**public double location(UnitOfMeasure unit)**

Get the distance from the restricted area to the start point of the corresponding road segment. Unit: Pixel.

**public double zoneLength(UnitOfMeasure unit)**

Get the length of the restricted area. Unit: Pixel.

**public double limitSpeed(UnitOfMeasure unit)**

Get the speed limit of the restricted area. Unit: Pixel (km/h).

**public long sectionId()**

Get the ID of the road segment or connection segment.

**public String sectionName()**

Get the Section name.

**public String sectionType()**

Get the road type: "link" indicates road segment, "connector" indicates connection segment.

**public ArrayList\<ILaneObject\> laneObjects()**

Get the list of related Lane Objects.

**public long duration()**

Get the restriction duration. If the duration exceeds this value after the simulation process is created, the restriction is removed. Unit: s.

#### 3.4.8.5. Reconstruction and Expansion Lane Borrowing (IReconstruction)

**public long id()**

Get the Reconstruction and Expansion ID.

**public long roadWorkZoneId()**

Get the starting Construction Zone ID of the Reconstruction and Expansion.

**public long limitedZoneId()**

Get the ID of the restricted area for lane borrowing.

**public double passagewayLength(UnitOfMeasure unit)**

Get clearance length. Unit: Pixel.

**public long duration()**

Get reconstruction and expansion duration.

**public int borrowedNum()**

Get the number of lane borrowings.

**public double passagewayLimitedSpeed(UnitOfMeasure unit)**

Get clearance opening speed limit. Unit: Pixel (km/h).

**public DynaReconstructionParam dynaReconstructionParam()**

Get dynamic parameters of reconstruction and expansion.

#### 3.4.8.6. Speed Limit Zone (IReduceSpeedArea)

**public long id()**

Get speed limit zone ID.

**public String name()**

Get speed limit zone name.

**public double location(UnitOfMeasure unit)**

Get distance from starting point. Unit: Pixel.

**public double areaLength(UnitOfMeasure unit)**

Get speed limit zone length. Unit: Pixel.

**public long sectionId()**

Get the ID of the road segment or connection segment.

**public int laneNumber()**

Get lane index.

**public int toLaneNumber()**

Get target lane index.

**public IReduceSpeedInterval addReduceSpeedInterval(DynaReduceSpeedIntervalParam param)**

Add speed limit interval.

Parameters: 

[ in ] param: Speed limit interval parameters.

**public void removeReduceSpeedInterval(long id)**

Remove speed limit interval.

Parameters: 

[ in ] id: Speed limit interval ID.

**public boolean updateReduceSpeedInterval(DynaReduceSpeedIntervalParam param)**

Update Speed Limit Zone interval.

Parameters: 

[ in ] param: Speed limit interval parameters.

**public ArrayList\<IReduceSpeedInterval\> reduceSpeedIntervals()**

Retrieve the list of Speed Limit Zone intervals.

**public IReduceSpeedInterval findReduceSpeedIntervalById(long id)**

Retrieve a Speed Limit Zone interval by ID.

Parameters: 

[ in ] id: Speed limit interval ID.

**public IReduceSpeedInterval findReduceSpeedIntervalByStartTime(long startTime)**

Retrieve a Speed Limit Zone interval by start time.

Parameters: 

[ in ] startTime: Start time.

**public Vector\<Point\> polygon()**

Retrieve polygonal outline.

#### 3.4.8.7. Speed Limit Interval (IReduceSpeedInterval)

**public long id()**

Retrieve Speed Limit Interval ID.

**public long reduceSpeedAreaId()**

Retrieve associated Speed Limit Zone ID.

**public long intervalStartTime()**

Retrieve start time.

**public long intervalEndTime()**

Retrieve end time.

**public IReduceSpeedVehiType addReduceSpeedVehiType(DynaReduceSpeedVehiTypeParam param)**

Add speed-limited vehicle type.

Parameters: 

[ in ] param: Parameter of speed-limited vehicle type.

**public void removeReduceSpeedVehiType(long id)**

Remove speed-limited vehicle type.

Parameters: 

[ in ] id: Speed-limited vehicle type ID.

**public boolean updateReduceSpeedVehiType(DynaReduceSpeedVehiTypeParam param)**

Update speed-limited vehicle type.

Parameters: 

[ in ] param: Parameter of speed-limited vehicle type.

**public ArrayList\<IReduceSpeedVehiType\> reduceSpeedVehiTypes()**

Retrieve the list of speed-limited vehicle types and parameters within this interval.

**public IReduceSpeedVehiType findReduceSpeedVehiTypeById(long id)**

Obtain the speed-limited vehicle type by ID.

Parameters: 

[ in ] id: Speed-limited vehicle type ID.

**public IReduceSpeedVehiType findReduceSpeedVehiTypeByCode(long vehicleTypeCode)**

Obtain the speed-limited vehicle type by vehicle type code.

Parameters: 

[ in ] vehicleTypeCode: Vehicle type code.

#### 3.4.8.8. Speed-Limited Vehicle Type (IReduceSpeedVehiType)

**public long id()**

Get the speed-limited vehicle type ID.

**public long intervalId()**

Get the associated speed limit period ID.

**public long reduceSpeedAreaId()**

Retrieve associated Speed Limit Zone ID.

**public long vehiTypeCode()**

Get the vehicle type code.

**public double averageSpeed(UnitOfMeasure unit)**

Get the average vehicle speed. Unit: Pixel/s.

**public double speedStandardDeviation(UnitOfMeasure unit)**

Get the standard deviation of the vehicle speed. Unit: Pixel/s.

### 3.4.9. Pedestrian Module

#### 3.4.9.1. Obstacle Region (IObstacleRegion)

**public boolean isObstacle()**

Get whether the region is an obstacle.

**public void setObstacle(boolean b)**

Set whether the region is an obstacle.

Parameters: 

[ in ] b: Whether it is an obstacle.

#### 3.4.9.2. Passenger Area (IPassengerRegion)

**public boolean isBoardingArea()**

Get whether the area is designated as a boarding area.

**public void setIsBoardingArea(boolean b)**

Set whether the area is designated as a boarding area.

**public boolean isAlightingArea()**

Get whether the area is designated as an alighting area.

**public void setIsAlightingArea(boolean b)**

Set whether the area is designated as an alighting area.

#### 3.4.9.3. Pedestrian Path Area Base Class (IPedestrianPathRegionBase)

**public long getId()**

Get Area ID.

**public String getName()**

Get area name.

**public void setName(String name)**

Set area name.

**public Color getRegionColor()**

Get area color.

**public void setRegionColor(Color color)**

Set area color.

**public Point getPosition(UnitOfMeasure unit)**

Get area position. Unit: Pixel.

**public void setPosition(Point scenePos, UnitOfMeasure unit)**

Set area position. Unit: Pixel.

Parameters: 

[ in ] scenePos: Position in the scene coordinate system.

**public int getGType()**

Retrieve the surface area type.

#### 3.4.9.4. Pedestrian Surface Area (IPedestrianRegion)

**public long getId()**

Get Area ID.

**public String getName()**

Get area name.

**public void setName(String name)**

Set area name.

**public Color getRegionColor()**

Get area color.

**public void setRegionColor(Color color)**

Set area color.

**public Point getPosition(UnitOfMeasure unit)**

Get area position. Unit: Pixel.

**public void setPosition(Point scenePos, UnitOfMeasure unit)**

Set area position. Unit: Pixel.

Parameters: 

[ in ] scenePos: Position in the scene coordinate system.

**public int getGType()**

Retrieve the surface area type.

**public double getExpectSpeedFactor()**

Retrieve the desired speed coefficient.

**public void setExpectSpeedFactor(double val)**

Set the desired speed coefficient.

Parameters: 

[ in ] val: Desired speed coefficient.

**public double getElevation()**

Retrieve the surface area elevation.

**public void setElevation(double elevation)**

Set the surface area elevation.

Parameters: 

[ in ] elevation: Elevation.

**public Vector\<Point\> getPolygon()**

Retrieve the surface area polygon.

**public long getLayerId()**

Retrieve the layer ID where the surface area is located.

**public void setLayerId(long id)**

Set the layer where the surface area is located; no changes will be applied if the layer ID is invalid.

Parameters: 

[ in ] id: Layer ID.

#### 3.4.9.5. Rectangular Pedestrian Surface Area (IPedestrianRectRegion)

**public long getId()**

Get Area ID.

**public String getName()**

Get area name.

**public void setName(String name)**

Set area name.

**public Color getRegionColor()**

Get area color.

**public void setRegionColor(Color color)**

Set area color.

**public Point getPosition(UnitOfMeasure unit)**

Get area position. Unit: Pixel.

**public void setPosition(Point scenePos, UnitOfMeasure unit)**

Set area position. Unit: Pixel.

Parameters: 

[ in ] scenePos: Position in the scene coordinate system.

**public int getGType()**

Retrieve the surface area type.

**public double getExpectSpeedFactor()**

Retrieve the desired speed coefficient.

**public void setExpectSpeedFactor(double val)**

Set the desired speed coefficient.

**public double getElevation()**

Retrieve the surface area elevation.

**public void setElevation(double elevation)**

Set the surface area elevation.

**public Vector\<Point\> getPolygon()**

Retrieve the surface area polygon.

**public long getLayerId()**

Retrieve the layer ID where the surface area is located.

**public void setLayerId(long id)**

Set the layer where the surface area is located; no changes will be applied if the layer ID is invalid.

**public boolean isObstacle()**

Get whether the region is an obstacle.

**public void setObstacle(boolean b)**

Set whether the region is an obstacle.

**public boolean isBoardingArea()**

Get whether the area is designated as a boarding area.

**public void setIsBoardingArea(boolean b)**

Set whether the area is designated as a boarding area.

**public boolean isAlightingArea()**

Get whether the area is designated as an alighting area.

**public void setIsAlightingArea(boolean b)**

Set whether the area is designated as an alighting area.

#### 3.4.9.6. Triangular Pedestrian Surface Area (IPedestrianTriangleRegion)

**public long getId()**

Get Area ID.

**public String getName()**

Get area name.

**public void setName(String name)**

Set area name.

**public Color getRegionColor()**

Get area color.

**public void setRegionColor(Color color)**

Set area color.

**public Point getPosition(UnitOfMeasure unit)**

Get area position. Unit: Pixel.

**public void setPosition(Point scenePos, UnitOfMeasure unit)**

Set area position. Unit: Pixel.

Parameters: 

[ in ] scenePos: Position in the scene coordinate system.

**public int getGType()**

Retrieve the surface area type.

**public double getExpectSpeedFactor()**

Retrieve the desired speed coefficient.

**public void setExpectSpeedFactor(double val)**

Set the desired speed coefficient.

**public double getElevation()**

Retrieve the surface area elevation.

**public void setElevation(double elevation)**

Set the surface area elevation.

**public Vector\<Point\> getPolygon()**

Retrieve the surface area polygon.

**public long getLayerId()**

Retrieve the layer ID where the surface area is located.

**public void setLayerId(long id)**

Set the layer where the surface area is located; no changes will be applied if the layer ID is invalid.

**public boolean isObstacle()**

Get whether the region is an obstacle.

**public void setObstacle(boolean b)**

Set whether the region is an obstacle.

**public boolean isBoardingArea()**

Get whether the area is designated as a boarding area.

**public void setIsBoardingArea(boolean b)**

Set whether the area is designated as a boarding area.

**public boolean isAlightingArea()**

Get whether the area is designated as an alighting area.

**public void setIsAlightingArea(boolean b)**

Set whether the area is designated as an alighting area.

#### 3.4.9.7. Elliptical Pedestrian Surface Area (IPedestrianEllipseRegion)

**public long getId()**

Get Area ID.

**public String getName()**

Get area name.

**public void setName(String name)**

Set area name.

**public Color getRegionColor()**

Get area color.

**public void setRegionColor(Color color)**

Set area color.

**public Point getPosition(UnitOfMeasure unit)**

Get area position. Unit: Pixel.

**public void setPosition(Point scenePos, UnitOfMeasure unit)**

Set area position. Unit: Pixel.

Parameters: 

[ in ] scenePos: Position in the scene coordinate system.

**public int getGType()**

Retrieve the surface area type.

**public double getExpectSpeedFactor()**

Retrieve the desired speed coefficient.

**public void setExpectSpeedFactor(double val)**

Set the desired speed coefficient.

**public double getElevation()**

Retrieve the surface area elevation.

**public void setElevation(double elevation)**

Set the surface area elevation.

**public Vector\<Point\> getPolygon()**

Retrieve the surface area polygon.

**public long getLayerId()**

Retrieve the layer ID where the surface area is located.

**public void setLayerId(long id)**

Set the layer where the surface area is located; no changes will be applied if the layer ID is invalid.

**public boolean isObstacle()**

Get whether the region is an obstacle.

**public void setObstacle(boolean b)**

Set whether the region is an obstacle.

**public boolean isBoardingArea()**

Get whether the area is designated as a boarding area.

**public void setIsBoardingArea(boolean b)**

Set whether the area is designated as a boarding area.

**public boolean isAlightingArea()**

Get whether the area is designated as an alighting area.

**public void setIsAlightingArea(boolean b)**

Set whether the area is designated as an alighting area.

#### 3.4.9.8. Fan-shaped Pedestrian Surface Area (IPedestrianFanShapeRegion)

**public long getId()**

Get Area ID.

**public String getName()**

Get area name.

**public void setName(String name)**

Set area name.

**public Color getRegionColor()**

Get area color.

**public void setRegionColor(Color color)**

Set area color.

**public Point getPosition(UnitOfMeasure unit)**

Get area position. Unit: Pixel.

**public void setPosition(Point scenePos, UnitOfMeasure unit)**

Set area position. Unit: Pixel.

Parameters: 

[ in ] scenePos: Position in the scene coordinate system.

**public int getGType()**

Retrieve the surface area type.

**public double getExpectSpeedFactor()**

Retrieve the desired speed coefficient.

**public void setExpectSpeedFactor(double val)**

Set the desired speed coefficient.

**public double getElevation()**

Retrieve the surface area elevation.

**public void setElevation(double elevation)**

Set the surface area elevation.

**public Vector\<Point\> getPolygon()**

Retrieve the surface area polygon.

**public long getLayerId()**

Retrieve the layer ID where the surface area is located.

**public void setLayerId(long id)**

Set the layer where the surface area is located; no changes will be applied if the layer ID is invalid.

**public boolean isObstacle()**

Get whether the region is an obstacle.

**public void setObstacle(boolean b)**

Set whether the region is an obstacle.

**public boolean isBoardingArea()**

Get whether the area is designated as a boarding area.

**public void setIsBoardingArea(boolean b)**

Set whether the area is designated as a boarding area.

**public boolean isAlightingArea()**

Get whether the area is designated as an alighting area.

**public void setIsAlightingArea(boolean b)**

Set whether the area is designated as an alighting area.

**public double getInnerRadius()**

Get the inner radius, unit: meters.

**public double getOuterRadius()**

Get the outer radius, unit: meters.

**public double getStartAngle()**

Get the starting angle, unit: degrees.

**public double getSweepAngle()**

Get the swept angle, unit: degrees.

#### 3.4.9.9. Polygonal Pedestrian Surface Area (IPedestrianPolygonRegion)

**public long getId()**

Get Area ID.

**public String getName()**

Get area name.

**public void setName(String name)**

Set area name.

**public Color getRegionColor()**

Get area color.

**public void setRegionColor(Color color)**

Set area color.

**public Point getPosition(UnitOfMeasure unit)**

Get area position. Unit: Pixel.

**public void setPosition(Point scenePos, UnitOfMeasure unit)**

Set area position. Unit: Pixel.

Parameters: 

[ in ] scenePos: Position in the scene coordinate system.

**public int getGType()**

Retrieve the surface area type.

**public double getExpectSpeedFactor()**

Retrieve the desired speed coefficient.

**public void setExpectSpeedFactor(double val)**

Set the desired speed coefficient.

**public double getElevation()**

Retrieve the surface area elevation.

**public void setElevation(double elevation)**

Set the surface area elevation.

**public Vector\<Point\> getPolygon()**

Retrieve the surface area polygon.

**public long getLayerId()**

Retrieve the layer ID where the surface area is located.

**public void setLayerId(long id)**

Set the layer where the surface area is located; no changes will be applied if the layer ID is invalid.

**public boolean isObstacle()**

Get whether the region is an obstacle.

**public void setObstacle(boolean b)**

Set whether the region is an obstacle.

**public boolean isBoardingArea()**

Get whether the area is designated as a boarding area.

**public void setIsBoardingArea(boolean b)**

Set whether the area is designated as a boarding area.

**public boolean isAlightingArea()**

Get whether the area is designated as an alighting area.

**public void setIsAlightingArea(boolean b)**

Set whether the area is designated as an alighting area.

#### 3.4.9.10. Sidewalk Pedestrian Surface Area (IPedestrianSideWalkRegion)

**public long getId()**

Get Area ID.

**public String getName()**

Get area name.

**public void setName(String name)**

Set area name.

Parameters: 

[ in ] name: New name.

**public Color getRegionColor()**

Get area color.

**public void setRegionColor(Color color)**

Set area color.

Parameters: 

[ in ] color: surface area color.

**public Point getPosition(UnitOfMeasure unit)**

Get area position. Unit: Pixel.

**public void setPosition(Point scenePos, UnitOfMeasure unit)**

Set area position. Unit: Pixel.

Parameters: 

[ in ] scenePos: Position in the scene coordinate system.

**public int getGType()**

Retrieve the surface area type.

**public double getExpectSpeedFactor()**

Retrieve the desired speed coefficient.

**public void setExpectSpeedFactor(double val)**

Set the desired speed coefficient.

**public double getElevation()**

Retrieve the surface area elevation.

**public void setElevation(double elevation)**

Set the surface area elevation.

**public Vector\<Point\> getPolygon()**

Retrieve the surface area polygon.

**public long getLayerId()**

Retrieve the layer ID where the surface area is located.

**public void setLayerId(long id)**

Set the layer where the surface area is located; no changes will be applied if the layer ID is invalid.

Parameters: 

[ in ] id: Layer ID.

**public double getWidth()**

Get the sidewalk width.

**public void setWidth(double width)**

Set the sidewalk width.

Parameters: 

[ in ] width: Sidewalk width, unit: m.

**public ArrayList\<QGraphicsEllipseItem\> getVetexs()**

Retrieve sidewalk vertices, i.e., initial polyline vertices.

**public ArrayList\<QGraphicsEllipseItem\> getControl1Vetexs()**

Retrieve sidewalk Bezier curve control point P1.

**public ArrayList\<QGraphicsEllipseItem\> getControl2Vetexs()**

Retrieve sidewalk Bezier curve control point P2.

**public ArrayList\<QGraphicsEllipseItem\> getCandidateVetexs()**

Retrieve candidate vertices.

**public void removeVetex(int index)**

Delete the vertex at the specified index.

Parameters: 

[ in ] index: Vertex index.

**public void insertVetex(Point pos, int index)**

Insert a vertex at the specified index position; the initial position is pos.

Parameters: 

[ in ] pos: Vertex position.

[ in ] index: Insertion position.

#### 3.4.9.11. Pedestrian Crosswalk Pedestrian Surface Area (IPedestrianCrossWalkRegion)

**public long getId()**

Get Area ID.

**public String getName()**

Get area name.

**public void setName(String name)**

Set area name.

Parameters: 

[ in ] name: New name.

**public Color getRegionColor()**

Get area color.

**public void setRegionColor(Color color)**

Set area color.

Parameters: 

[ in ] color: surface area color.

**public Point getPosition(UnitOfMeasure unit)**

Get area position. Unit: Pixel.

**public void setPosition(Point scenePos, UnitOfMeasure unit)**

Set area position. Unit: Pixel.

Parameters: 

[ in ] scenePos: Position in the scene coordinate system.

**public int getGType()**

Retrieve the surface area type.

**public double getExpectSpeedFactor()**

Retrieve the desired speed coefficient.

**public void setExpectSpeedFactor(double val)**

Set the desired speed coefficient.

**public double getElevation()**

Retrieve the surface area elevation.

**public void setElevation(double elevation)**

Set the surface area elevation.

**public Vector\<Point\> getPolygon()**

Retrieve the surface area polygon.

**public long getLayerId()**

Retrieve the layer ID where the surface area is located.

**public void setLayerId(long id)**

Set the layer where the surface area is located; no changes will be applied if the layer ID is invalid.

**public double getWidth()**

Retrieve pedestrian crosswalk width, unit: meters.

**public void setWidth(double width)**

Set the width of the pedestrian crosswalk, unit: meters.

**public QLineF getSceneLine(UnitOfMeasure unit)**

Obtain the line segment from the start point to the end point of the pedestrian crosswalk in the scenario coordinate system. Unit: Pixel.

**public double getAngle()**

Obtain the inclination angle of the pedestrian crosswalk.

**public void setAngle(double angle)**

Set the inclination angle of the pedestrian crosswalk.

**public double getRedLightSpeedFactor()**

Obtain the red light clearing speed coefficient.

**public void setRedLightSpeedFactor(double factor)**

Set the red light clearing speed coefficient.

**public Vector2D getUnitDirectionFromStartToEnd()**

Obtain the unit direction vector from the start point to the end point in the scenario coordinate system.

**public Vector2D getLocalUnitDirectionFromStartToEnd()**

Obtain the unit direction vector from the start point to the end point in the pedestrian crosswalk's local coordinate system.

**public QGraphicsEllipseItem getStartControlPoint()**

Obtain the start control point.

**public QGraphicsEllipseItem getEndControlPoint()**

Obtain the end control point.

**public QGraphicsEllipseItem getLeftControlPoint()**

Obtain the left control point.

**public QGraphicsEllipseItem getRightControlPoint()**

Get the right control point.

**public ICrosswalkSignalLamp getPositiveDirectionSignalLamp()**

Get the traffic signal controlling forward movement.

**public ICrosswalkSignalLamp getNegativeDirectionSignalLamp()**

Get the traffic signal controlling reverse movement.

**public boolean isPositiveTrafficLightAdded()**

Determine whether a traffic signal controlling forward movement has been added.

**public boolean isReverseTrafficLightAdded()**

Determine whether a traffic signal controlling reverse movement has been added.

#### 3.4.9.12. Pedestrian Stair Surface Area (IPedestrianStairRegion)

**public long getId()**

Get Area ID.

**public String getName()**

Get area name.

**public void setName(String name)**

Set area name.

**public Color getRegionColor()**

Get area color.

**public void setRegionColor(Color color)**

Set area color.

**public Point getPosition(UnitOfMeasure unit)**

Get area position. Unit: Pixel.

**public void setPosition(Point scenePos, UnitOfMeasure unit)**

Set area position. Unit: Pixel.

Parameters: 

[ in ] scenePos: Position in the scene coordinate system.

**public int getGType()**

Retrieve the surface area type.

**public double getWidth()**

Get the stair width, unit: m.

**public void setWidth(double width)**

Set the stair width, unit: m.

**public Point getStartPoint()**

Get the starting point in the scenario coordinate system.

**public Point getEndPoint()**

Get the ending point in the scenario coordinate system.

**public double getStartConnectionAreaLength()**

Get the length of the starting connection region, unit: m.

**public double getEndConnectionAreaLength()**

Retrieve the length of the terminal connection area, unit: m.

**public Point getStartRegionCenterPoint()**

Retrieve the center of the starting connection area in the scenario coordinate system.

**public Point getEndRegionCenterPoint()**

Retrieve the center of the terminal connection area in the scenario coordinate system.

**public QPainterPath getStartSceneRegion()**

Retrieve the shape of the starting connection area in the scenario coordinate system.

**public QPainterPath getEndSceneRegion()**

Retrieve the shape of the terminal connection area in the scenario coordinate system.

**public QPainterPath getMainQueueRegion()**

Retrieve the main body shape of the staircase in the scenario coordinate system.

**public QPainterPath getFullQueueregion()**

Retrieve the overall shape of the staircase in the scenario coordinate system.

**public Vector\<Point\> getMainQueuePolygon()**

Retrieve the polygon of the main body of the staircase in the scenario coordinate system.

**public StairType getStairType()**

Retrieve the type of the staircase.

**public void setStairType(StairType type)**

Set the type of the staircase.

**public long getStartLayerId()**

Get the starting level.

**public void setStartLayerId(long id)**

Set the starting level.

**public long getEndLayerId()**

Get the ending level.

**public void setEndLayerId(long id)**

Set the ending level.

**public double getTransmissionSpeed()**

Get the conveyance speed, unit: m/s.

**public void setTransmissionSpeed(double speed)**

Set the conveyance speed, unit: m/s.

**public double getHeadroom()**

Get the net height of the stair.

**public void setHeadroom(double headroom)**

Set the net height of the stair.

**public QGraphicsEllipseItem getStartControlPoint()**

Obtain the start control point.

**public QGraphicsEllipseItem getEndControlPoint()**

Obtain the end control point.

**public QGraphicsEllipseItem getLeftControlPoint()**

Obtain the left control point.

**public QGraphicsEllipseItem getRightControlPoint()**

Get the right control point.

**public QGraphicsEllipseItem getStartConnectionAreaControlPoint()**

Get the starting junction area length control point.

**public QGraphicsEllipseItem getEndConnectionAreaControlPoint()**

Get the ending junction area length control point.

#### 3.4.9.13. Pedestrian Route (IPedestrianPath)

**public long getId()**

Get the pedestrian route ID.

**public IPedestrianPathPoint getPathStartPoint()**

Get the starting point of the pedestrian route.

**public IPedestrianPathPoint getPathEndPoint()**

Get the end point of the pedestrian route.

**public ArrayList\<IPedestrianPathPoint\> getPathMiddlePoints()**

Get the intermediate point of the pedestrian route.

**public boolean isLocalPath()**

Determine whether it is a local route.

#### 3.4.9.14. Pedestrian Path Point (IPedestrianPathPoint)

**public long getId()**

Obtain the ID of the pedestrian path point.

**public Point getScenePos(UnitOfMeasure unit)**

Obtain the position of the pedestrian path point within the scenario coordinate system. Unit: Pixel.

**public double getRadius()**

Obtain the radius of the pedestrian path point. Unit: m.

#### 3.4.9.15. Crosswalk Traffic Signal (ICrosswalkSignalLamp)

**public long id()**

Obtain the Traffic Signal ID.

**public void setSignalPhase(ISignalPhase pPhase)**

Set the phase. The specified phase may correspond to that of another Traffic Signal group.

**public void setPhaseNumber(int num)**

Set the phase index, with numbering starting at 1. If the index exceeds the total number of phases, the setting will not be applied.

**public void setLampColor(String colorStr)**

Set the Traffic Signal Color.

Parameters: 

[ in ] colorStr: Color represented as a string with four options: "Red", "Green", "Yellow", "Gray", or "R", "G", "Y", "gray". 

**public String color()**

Obtain the Traffic Signal Color. "R", "G", "Y", and "gray" correspond to "Red", "Green", "Yellow", and "Gray" respectively.

**public String name()**

Get Traffic Signal Name.

**public void setName(String name)**

Set Traffic Signal Name.

**public void setDistToStart(double dist, UnitOfMeasure unit)**

Set Traffic Signal Distance from Road Segment Start. Unit: Pixels.

Parameters: 

[ in ] dist: Distance value.

**public ISignalPlan signalPlan()**

Get Signal Control Plan.

**public ISignalPhase signalPhase()**

Get Phase.

**public ILaneObject laneObject()**

Get Lane or Lane Connection.

**public Vector\<Point\> polygon()**

Get Vertices of the Traffic Signal Polygon Outline.

**public double angle()**

Get Traffic Signal Angle.

**public IPedestrianCrossWalkRegion getICrossWalk()**

Obtain the associated crosswalk.

### 3.4.10. Parking Module

#### 3.4.10.1. Parking Stall (IParkingStall)

**public long id()**

Retrieve the parking space ID.

**public long parkingRegionId()**

Retrieve the associated parking area ID.

**public IParkingRegion parkingRegion()**

Retrieve the associated parking area.

**public double distance()**

Retrieve the distance from the start of the road segment, unit: m.

**public int stallType()**

Retrieve the parking space type, consistent with the vehicle type code.

#### 3.4.10.2. Parking Area (IParkingRegion)

**public long id()**

Retrieve the parking area ID.

**public String name()**

Retrieve the parking area name.

**public void setName(String name)**

Set the parking area name.

Parameters: 

[ in ] name: New name.

**public ArrayList\<IParkingStall\> parkingStalls()**

Retrieve all parking spaces.

**public DynaParkingRegion dynaParkingRegion()**

Retrieve dynamic parking area information.

#### 3.4.10.3. Parking Route Decision Point (IParkingDecisionPoint)

**public long id()**

Retrieve the parking decision point ID.

**public String name()**

Retrieve the parking decision point name.

**public ILink link()**

Retrieve the road segment where the parking decision point is located.

**public double distance()**

Get the distance from the parking decision point to the start of the road segment, unit: m.

**public ArrayList\<IParkingRouting\> routings()**

Retrieve the associated parking route.

**public boolean updateParkDisInfo(ArrayList\<DynaParkDisInfo\> tollDisInfoList)**

Update parking allocation information.

Parameters: 

[ in ] tollDisInfoList: List of parking allocation information.

**public ArrayList\<DynaParkDisInfo\> parkDisInfoList()**

Retrieve the list of parking allocation information.

**public Vector\<Point\> polygon()**

Obtain the polygonal contour of the parking decision point.

#### 3.4.10.4. Parking Route (IParkingRouting)

**public long id()**

Get the route ID.

**public long parkingDeciPointId()**

Get the associated decision point ID.

**public long parkingRegionId()**

ID of the parking area reached by the route.

**public double calcuLength()**

Calculate the route length.

**public boolean contain(ISection pRoad)**

Determine whether the given road is on the current route.

Parameters: 

[ in ] pRoad: Road segment or connection segment.

**public ISection nextRoad(ISection pRoad)**

Retrieve the subsequent road based on the given road.

Parameters: 

[ in ] pRoad: Road segment or connection segment.

**public ArrayList\<ILink\> getLinks()**

Obtain the sequence of road segments.

### 3.4.11. Toll Station Module

#### 3.4.11.1. Toll Point (ITollPoint)

**public long id()**

Get the toll point ID.

**public double distance()**

Retrieve the distance from the start of the road segment, unit: m.

**public long tollLaneId()**

Get the associated toll lane ID.

**public ITollLane tollLane()**

Get the associated toll lane.

**public boolean isEnabled()**

Check whether it is enabled.

**public boolean setEnabled(boolean enabled)**

Set the enabled status.

Parameters: 

[ in ] enabled: Whether it is enabled.

**public int tollType()**

Get the toll type.

**public boolean setTollType(int tollType)**

Set the toll type.

Parameters: 

[ in ] tollType: Toll type.

**public int timeDisId()**

Get the parking time distribution ID.

**public boolean setTimeDisId(int timeDisId)**

Set the parking time distribution ID.

Parameters: 

[ in ] timeDisId: Time distribution ID.

#### 3.4.11.2. Toll Lane (ITollLane)

**public long id()**

Get the toll lane ID.

**public String name()**

Get the toll lane name.

**public double distance()**

Retrieve the distance from the start of the road segment, unit: m.

**public void setName(String name)**

Set the toll lane name.

Parameters: 

[ in ] name: New toll lane name.

**public void setWorkTime(long startTime, long endTime)**

Set the working time, which corresponds to the simulation time.

Parameters: 

[ in ] startTime: Start time, unit: seconds.

[ in ] endTime: End time. Unit: s.

**public DynaTollLane dynaTollLane()**

Retrieve dynamic toll lane information.

**public ArrayList\<ITollPoint\> tollPoints()**

Retrieve all toll points within the toll lane.

#### 3.4.11.3. Toll Decision Point (ITollDecisionPoint)

**public long id()**

Retrieve the toll decision point ID.

**public String name()**

Retrieve the name of the toll decision point.

**public ILink link()**

Retrieve the road segment where the toll decision point is located.

**public double distance()**

Retrieve the distance from the start of the road segment. Unit: m.

**public ArrayList\<ITollRouting\> routings()**

Retrieve the associated toll routes.

**public ArrayList\<DynaTollDisInfo\> tollDisInfoList()**

Retrieve the toll allocation information list.

**public void updateTollDisInfoList(ArrayList\<DynaTollDisInfo\> tollDisInfoList)**

Update the toll allocation information list.

Parameters: 

[ in ] tollDisInfoList: Toll allocation information list.

**public Vector\<Point\> polygon()**

Retrieve the polygonal contour of the toll decision point.

#### 3.4.11.4. Toll Routing (ITollRouting)

**public long id()**

Get the route ID.

**public long tollDeciPointId()**

Retrieve the ID of the associated toll decision point.

**public long tollLaneId()**

ID of the toll area reached by the route.

**public double calcuLength()**

Calculate the route length.

**public boolean contain(ISection pRoad)**

Determine whether the given road is on the current route.

Parameters: 

[ in ] pRoad: Road segment or connection segment.

**public ISection nextRoad(ISection pRoad)**

Retrieve the subsequent road based on the given road.

Parameters: 

[ in ] pRoad: Road segment or connection segment.

**public ArrayList\<ILink\> getLinks()**

Obtain the sequence of road segments.

### 3.4.12. Node Module

#### 3.4.12.1. Node (IJunction)

**public long getId()**

Retrieve the node ID.

**public String name()**

Retrieve the node name.

**public void setName(String strName)**

Set the node name.

Parameters: 

[ in ] strName: New name.

**public ArrayList\<ILink\> getJunctionLinks()**

Retrieve the road segments within the node.

**public ArrayList\<IConnector\> getJunctionConnectors()**

Retrieve the connection segments within the node.

**public ArrayList\<TurnningBaseInfo\> getAllTurnningInfo()**

Retrieve all traffic flow information within the node.

**public TurnningBaseInfo getTurnningInfo(long turningId)**

Retrieve specified traffic flow information within the node.

### 3.4.13. Vehicles and Pedestrians

#### 3.4.13.1. Vehicle (IVehicle)

Vehicle interface for accessing and controlling vehicles. This interface allows reading vehicle attributes, setting some vehicle attributes, and during the simulation process, accessing the current road conditions, vehicles adjacent in front, behind, left, and right, as well as their distances.

**public long id()**

Vehicle ID. The Vehicle ID is composed as x * 100000 + y, where the x value for each dispatch point is unique, starting from 1 and incrementing by 1, and y is the sequence number of vehicles dispatched from each dispatch point, starting at 1 and incrementing. Vehicle IDs dispatched from the first dispatch point start incrementing at 100001, while those from the second dispatch point start incrementing at 200001.

**public ILink startLink()**

The starting road segment when the vehicle enters the road network.

**public long startSimuTime()**

The start time when the vehicle enters the road network.

**public long roadId()**

The ID of the road segment or connection segment where the vehicle is located.

**public void road()**

Road: returns ILink if on a road segment, or IConnector if on a connection segment.

**public ISection section()**

The section where the vehicle is located, i.e., a road segment or a connection segment.

**public ILaneObject laneObj()**

The lane or lane connection where the vehicle is located.

**public int segmIndex()**

Segment index of the vehicle on the current LaneObject.

**public boolean roadIsLink()**

Indicates whether the road on which the vehicle is located is a Road Segment.

**public String roadName()**

Road name.

**public double initSpeed(double speed, UnitOfMeasure unit)**

Initial speed.

Parameters: 

[ in ] speed: Initial speed value. Unit: Pixel/s.

**public void initLane(int laneNumber, double dist, double speed, UnitOfMeasure unit)**

Initialize the vehicle on the road segment.

Parameters: 

[ in ] laneNumber: Lane Index.

[ in ] dist: Distance from the starting point, unit: Pixel.

[ in ] speed: Initial speed, unit: Pixel/s.

**public void initLaneConnector(int laneNumber, int toLaneNumber, double dist, double speed, UnitOfMeasure unit)**

Initialize the vehicle on the connection segment. Unit: Pixel.

Parameters: 

[ in ] laneNumber: Starting Lane Index.

[ in ] toLaneNumber: Target Lane Index.

[ in ] dist: Distance from the starting point, unit: Pixel.

[ in ] speed: Initial speed, unit: Pixel/s.

**public void setVehiType(int code)**

Set the vehicle type. The vehicle type is determined upon creation; this method allows changing it.

Parameters: 

[ in ] code: Vehicle type code.

**public void setColor(String color)**

Set vehicle color.

Parameters: 

[ in ] color: Color RGB, for example: "#EE0000".

Example:

```java
// Set vehicle color to blue
vehicle.setColor("#00AFF0");
```

**public double length(UnitOfMeasure unit)**

Get vehicle length. Unit: pixel.

**public void setLength(double len, boolean bRestWidth, UnitOfMeasure unit)**

Set vehicle length. Unit: pixel.

Parameters: 

[ in ] len: Length value, unit: pixel or meter (depending on the unit parameter).

[ in ] bRestWidth: Whether to constrain width proportionally.

**public long laneId()**

If toLaneId() is less than or equal to 0, laneId() returns the current lane ID; if toLaneId() is greater than 0, the vehicle is on a lane connection, and laneId() returns the upstream lane ID.

**public long toLaneId()**

Downstream lane ID. If less than or equal to 0, the vehicle is on a lane of a road segment; otherwise, it is on a lane connection of a connection segment.

**public ILane lane()**

​	Obtain the current lane; if the vehicle is on a lane connection, obtain the upstream lane of that lane connection.

**public ILane toLane()**

​	If the vehicle is on a lane connection, return the downstream lane of that lane connection; if not on a lane connection, return null.

**public ILaneConnector laneConnector()**

​	Obtain the current lane connection; return null if the vehicle is on a lane.

**public long currBatchNumber()**

​	Current simulation computation batch.

**public int roadType()**

​	Type of road where the vehicle is located. GLinkType represents a Road Segment; GConnectorType represents a Connection Segment.

**public double limitMaxSpeed(UnitOfMeasure unit)**

​	Obtain the maximum speed limit, unit: pixels/s.

**public double limitMinSpeed(UnitOfMeasure unit)**

​	Obtain the minimum speed limit, unit: pixels/s.

**public long vehicleTypeCode()**

​	Vehicle type code.

**public String vehicleTypeName()**

​	Obtain the vehicle type name, e.g., "Passenger Car".

**public String name()**

​	Obtain the vehicle name.

**public IVehicleDriving vehicleDriving()**

​	Obtain the vehicle driving behavior interface.

**public void driving()**

​	Drive the vehicle. This method is called once for each active vehicle during every computation cycle.

**public Point pos(UnitOfMeasure unit)**

Get current position. Unit: Pixel.

**public double zValue(UnitOfMeasure unit)**

Get current elevation. Unit: Pixel.

**public double acce(UnitOfMeasure unit)**

Get current acceleration. Unit: Pixel.

**public double currSpeed(UnitOfMeasure unit)**

Get current speed. Unit: Pixel/s.

**public double angle()**

Current angle, 0 degrees pointing north, measured clockwise.

**public boolean isStarted()**

Running status. Returning false indicates the vehicle has either exited the road network or has not yet entered the road.

**public IVehicle vehicleFront()**

Preceding vehicle object.

**public IVehicle vehicleRear()**

Following vehicle object.

**public IVehicle vehicleLFront()**

Front-left vehicle object.

**public IVehicle vehicleLRear()**

Rear-left vehicle object.

**public IVehicle vehicleRFront()**

Front-right vehicle object.

**public IVehicle vehicleRRear()**

Rear-right vehicle object.

**public double vehiDistFront(UnitOfMeasure unit)**

Get distance to preceding vehicle. Unit: Pixel.

**public double vehiSpeedFront(UnitOfMeasure unit)**

Get speed of preceding vehicle. Unit: Pixel/s.

**public double vehiHeadwayFront(UnitOfMeasure unit)**

Obtain the time headway to the preceding vehicle, unit: seconds.

**public double vehiDistRear(UnitOfMeasure unit)**

Obtain the distance to the following vehicle. Unit: pixel.

**public double vehiSpeedRear(UnitOfMeasure unit)**

Obtain the speed of the following vehicle, unit: pixel/s.

**public double vehiHeadwaytoRear(UnitOfMeasure unit)**

Obtain the time headway to the following vehicle, unit: seconds.

**public double vehiDistLLaneFront(UnitOfMeasure unit)**

Obtain the distance to the front-left vehicle. Unit: pixel.

**public double vehiSpeedLLaneFront(UnitOfMeasure unit)**

Obtain the speed of the front-left vehicle. Unit: pixel.

**public double vehiDistLLaneRear(UnitOfMeasure unit)**

Obtain the distance to the rear-left vehicle. Unit: pixel.

**public double vehiSpeedLLaneRear(UnitOfMeasure unit)**

Obtain the speed of the rear-left vehicle. Unit: pixel.

**public double vehiDistRLaneFront(UnitOfMeasure unit)**

Obtain the distance to the front-right vehicle. Unit: pixel.

**public double vehiSpeedRLaneFront(UnitOfMeasure unit)**

Obtain the speed of the front-right vehicle. Unit: pixel.

**public double vehiDistRLaneRear(UnitOfMeasure unit)**

Obtain the distance to the rear-right vehicle. Unit: pixel.

**public double vehiSpeedRLaneRear(UnitOfMeasure unit)**

Obtain the speed of the rear-right vehicle. Unit: pixel.

**public void setDynaInfo(void pDynaInfo)**

Set dynamic information.

**public void dynaInfo()**

Retrieve dynamic information.

**public ArrayList\<Point\> lLaneObjectVertex(UnitOfMeasure unit)**

Retrieve the set of interior points of the lane or lane connection centerline. Unit: Pixel.

**public IRouting routing()**

Current route.

**public QPicture picture()**

Retrieve vehicle image.

**public Vector\<Point\> boundingPolygon()**

Retrieve the polygon formed by the four corners determined by the vehicle's orientation and length.

**public void setTag(long tag)**

Set the state represented by the label.

**public long tag()**

Retrieve the state represented by the label.

**public void setTextTag(String text)**

Set text information for temporarily storing data during runtime to facilitate development.

**public String textTag()**

Text information temporarily stored during runtime to facilitate development.

**public void setJsonInfo(JsonObject info)**

Set JSON-formatted data.

**public JsonObject jsonInfo()**

Return JSON-formatted data.

**public QVariant jsonProperty(String propName)**

Return the value of a JSON field.

**public void setJsonProperty(String key, QVariant value)**

Set JSON data attributes.

#### 3.4.13.2. Vehicle Driving Behavior (IVehicleDriving)

Vehicle driving behavior interface. This interface allows controlling the vehicle’s left and right lane changes, setting the vehicle’s angle, and managing parameters such as vehicle speed and position. **After obtaining the vehicle object `vehicle`, invoke methods via `vehicle.vehicleDriving().xxx()`.**

**public IVehicle vehicle()**

The currently driving vehicle.

**public long getRandomNumber()**

Retrieve a random number.

**public boolean nextPoint()**

Calculate the next position, including determining vehicle following relationships, whether a bus is arriving or departing, lane changes, acceleration, speed, travel distance, car-following type, and trajectory type.

**public long zeroSpeedInterval()**

Duration of the current zero speed state. Unit: ms.

**public boolean isHavingDeciPointOnLink()**

Currently on a road segment and at a decision point.

**public int followingType()**

Type of the lead vehicle in car-following, i.e., the type of the preceding vehicle, classified as: 0: stopped, 1: normal, 5: urgent deceleration, 6: urgent acceleration, 7: merging, 8: crossing, 9: cooperative deceleration, 10: cooperative acceleration, 11: decelerating while awaiting turn, 12: accelerating while awaiting turn.

**public boolean isOnRouting()**

Currently on the route.

**public void stopVehicle()**

Stop operation and remove the vehicle from the road network.

**public double angle()**

Rotation angle. Unit: degrees. North is 0 degrees, clockwise.

**public void setAngle(double angle)**

Set vehicle rotation angle.

Parameters: 

[ in ] angle: rotation angle, 360 degrees per revolution.

**public Vector3D euler(boolean bPositive)**

Return the vehicle's Euler angles.

Parameters: 

[ in ] bPositive: whether the vehicle's heading direction is calculated forward; if bPositive is false, the calculation is reversed.

**public double desirSpeed(UnitOfMeasure unit)**

Get desired speed, unit: pixel/s.

**public ISection getCurrRoad()**

Return the current road segment or connection segment.

**public ISection getNextRoad()**

Next road segment or connection segment.

**public int differToTargetLaneNumber()**

Difference from target lane index. A nonzero value indicates a forced lane change intention. A positive value indicates a left lane change intention, while a negative value indicates a right lane change intention. The absolute value represents the required number of forced lane changes.

**public void toLeftLane(boolean bFource)**

Left lane change.

Parameters: 

[ in ] bForce: Whether to enforce lane change; default is false.

Example:

```java
// Control the vehicle to change lane to the left
vehicle.vehicleDriving().toLeftLane();
```

**public void toRightLane(boolean bFource)**

Right lane change.

Parameters: 

[ in ] bForce: Whether to enforce lane change; default is false.

Example:

```java
// Control the vehicle to change lane to the right
vehicle.vehicleDriving().toRightLane();
```

**public int laneNumber()**

Current lane index, with the rightmost index as 0.

**public void initTrace()**

Initialize trajectory.

**public void setTrace(ArrayList\<Point\> lPoint, UnitOfMeasure unit)**

Set trajectory point set. Unit: Pixel.

Parameters: 

[ in ] lPoint: Set of trajectory point coordinates.

**public void calcTraceLength()**

Calculate trajectory length.

**public int tracingType()**

Return trajectory type, classified as: 0: Car-following, 1: Left lane change, 2: Right lane change, 3: Left virtual lane change, 4: Right virtual lane change, 5: Left turn waiting, 6: Right turn waiting, 7: Enter bay, 8: Exit bay.

**public void setTracingType(int type)**

Set trajectory type.

**public void setLaneNumber(int number)**

Set the current Lane Index.

Parameters: 

[ in ] number: Lane Index.

**public double currDistanceInRoad(UnitOfMeasure unit)**

Get the traveled distance on the current Road Segment or Connection Segment. Unit: pixel.

**public void setCurrDistanceInRoad(double dist, UnitOfMeasure unit)**

Set the traveled distance on the current Road Segment or Connection Segment. Unit: pixel.

Parameters: 

[ in ] dist: Distance.

**public void setVehiDrivDistance(double dist, UnitOfMeasure unit)**

Set the total traveled mileage. Unit: pixel.

Parameters: 

[ in ] dist: Total mileage.

**public double getVehiDrivDistance(UnitOfMeasure unit)**

Get the total traveled mileage. Unit: pixel.

**public double currDistanceInSegment(UnitOfMeasure unit)**

Get the traveled distance on the current section. Unit: pixel.

**public void setCurrDistanceInSegment(double dist, UnitOfMeasure unit)**

Set the traveled distance on the current section. Unit: pixel.

Parameters: 

[ in ] dist: Distance.

**public void setSegmentIndex(int index)**

Set the section index.

**public void setCurrDistanceInTrace(double dist, UnitOfMeasure unit)**

Set the traveled distance along the curvilinear trajectory. Unit: pixel.

Parameters: 

[ in ] dist: Distance.

**public void setX(double posX, UnitOfMeasure unit)**

Set the horizontal coordinate. Unit: Pixel.

Parameters: 

[ in ] posX: Horizontal coordinate.

**public void setY(double posY, UnitOfMeasure unit)**

Set the vertical coordinate. Unit: Pixel.

Parameters: 

[ in ] posY: Vertical coordinate.

**public void setV3z(double v3z, UnitOfMeasure unit)**

Set the elevation coordinate. Unit: Pixel.

Parameters: 

[ in ] v3z: Elevation coordinate.

**public ArrayList\<Point\> changingTrace(UnitOfMeasure unit)**

Retrieve the set of lane-changing points. Unit: Pixel.

**public double changingTraceLength(UnitOfMeasure unit)**

Retrieve the lane-changing length. Unit: Pixel.

**public double distToStartPoint(boolean fromVehiHead, boolean bOnCentLine, UnitOfMeasure unit)**

Retrieve the distance to the start point on the lane or lane connection. Unit: Pixel.

Parameters: 

[ in ] fromVehiHead: Whether calculation is from the vehicle front.

[ in ] bOnCentLine: Whether currently on the centerline.

**public double distToEndpoint(boolean fromVehiHead, boolean bOnCentLine, UnitOfMeasure unit)**

Retrieve the distance to the end point on the lane or lane connection. Unit: Pixel.

Parameters: 

[ in ] fromVehiHead: Whether calculation is from the vehicle front.

[ in ] bOnCentLine: Whether currently on the centerline.

**public boolean setRouting(IRouting pRouting)**

Set the Route. The externally set Route may not necessarily contain Decision Points and may be created temporarily. If the Vehicle is not on this Route, the setting will fail and return false.

Example:

```java
// 1. Use vehicle routes associated with existing decision points
IRouting routing1 = netiface.findRouting(1);
vehicle.vehicleDriving().setRouting(routing1);

// 2. Create vehicle routes not bound to decision points
ArrayList<Integer> linkIdList = new ArrayList<>(Arrays.asList(8, 16, 25));
ArrayList<ILink> linkList = new ArrayList<>();
for (int linkId : linkIdList) {
    linkList.add(netiface.findLink(linkId));
}
IRouting routing2 = netiface.createRouting(linkList);
vehicle.vehicleDriving().setRouting(routing2);
```

**public IRouting routing()**

Current route.

**public boolean moveToLane(ILane pLane, double dist, UnitOfMeasure unit)**

Move the Vehicle to another Lane. Unit: Pixel.

Parameters: 

[ in ] pLane: Target Lane.

[ in ] dist: Distance to the start point of the target Lane.

**public boolean moveToLaneConnector(ILaneConnector pLaneConnector, double dist, UnitOfMeasure unit)**

Move the Vehicle to another Lane Connection. Unit: Pixel.

Parameters: 

[ in ] pLaneConnector: Target Lane Connection.

[ in ] dist: Distance to the start point of the target Lane Connection.

**public boolean move(ILaneObject pILaneObject, double dist, UnitOfMeasure unit)**

Move the Vehicle to another Lane or Lane Connection. Unit: Pixel.

Parameters: 

[ in ] pILaneObject: Target Lane or Lane Connection.

[ in ] dist: Distance to the target start point.

Example:

```java
// Get Lane object
lane = netiface.findLane(6);
// Position, Unit: m
dist = 50;
// Move the vehicle to the specified lane and position, enabling instantaneous relocation of the vehicle.
vehicle.vehicleDriving().move(lane, dist, UnitOfMeasure.Metric);
```

#### 3.4.13.3. Pedestrian (IPedestrian)

**public long getId()**

Obtain the pedestrian ID.

**public double getRadius()**

Obtain the pedestrian radius, unit: m.

**public double getWeight()**

Obtain the pedestrian mass, unit: kg.

**public String getColor()**

Obtain the pedestrian color in RGB format, e.g.: "#EE0000".

**public Point getPos()**

Obtain the pedestrian current position, unit: m.

**public double getAngle()**

Obtain the pedestrian current angle in the Qt coordinate system, where the positive x-axis is 0 and angles increase counterclockwise.

**public Vector2D getDirection()**

Obtain the pedestrian current 2D directional vector.

**public double getElevation()**

Obtain the pedestrian current elevation, unit: m.

**public Vector2D getSpeed()**

Obtain the pedestrian current speed, unit: m/s.

**public double getDesiredSpeed()**

Obtain the pedestrian desired speed, unit: m/s.

**public double getMaxSpeed()**

Retrieve the pedestrian's maximum speed limit, unit: m/s.

**public Vector2D getAcce()**

Retrieve the pedestrian's current acceleration, unit: m/s².

**public double getMaxAcce()**

Retrieve the pedestrian's maximum acceleration limit, unit: m/s².

**public Vector3D getEuler()**

Retrieve the pedestrian's Euler angles.

**public Vector3D getSpeedEuler()**

Retrieve the pedestrian's velocity Euler angles.

**public Vector2D getWallFDirection()**

Retrieve the wall direction unit vector.

**public IPedestrianRegion getRegion()**

Retrieve the pedestrian's current domain.

**public long getPedestrianTypeId()**

Retrieve the pedestrian type ID.

**public void stop()**

Stop the simulation; the current pedestrian will be removed in the next simulation batch to release resources.

<div style="page-break-after: always;"></div>

# 4. High-Frequency Interfaces

This section provides code examples of commonly used interfaces in TESS NG secondary development.



## 4.1. Road Network Modeling

### 4.1.1. Creating Road Segments and Connection Segments

The code for creating road segments and connection segments is as follows. **Additionally, the open-source road network editing tool pytessng (implemented via TESS NG Python Secondary Development) supports importing data in OpenDrive, shapefile, and OpenStreetMap formats to create road networks. For detailed instructions, please refer to [pytessng · PyPI](https://pypi.org/project/pytessng/) .**

```java
// ==================== Create Road Segments ====================
// Create the first road segment: Cao'an Highway
Point startPoint1 = new Point(-300, 0);
Point endPoint1 = new Point(300, 0);
ArrayList<Point> linkPoints1 = new ArrayList<>(Arrays.asList(startPoint1, endPoint1));
ILink link1 = netiface.createLink(linkPoints1, 7, "Cao'an Highway", true, UnitOfMeasure.Metric);
if (link1 != null) {
    // Lane list (converted to ArrayList)
    ArrayList<ILane> lanes1 = new ArrayList<>(link1.lanes());
    // Print all lane IDs of this road segment
    System.out.print("Cao'an Highway lane ID list: ");
    for (ILane lane : lanes1) {
        System.out.print(lane.id() + " ");
    }
    System.out.println();
    // Create a dispatch point on the current road segment
    IDispatchPoint dp1 = netiface.createDispatchPoint(link1);
    if (dp1 != null) {
        // Set dispatch interval, including vehicle type composition, time interval, and dispatch count
        dp1.addDispatchInterval(1, 2, 28);
    }
}

// Create the second road segment
Point startPoint2 = new Point(-300, -25);
Point endPoint2 = new Point(300, -25);
ArrayList<Point> linkPoints2 = new ArrayList<>(Arrays.asList(startPoint2, endPoint2));
ILink link2 = netiface.createLink(linkPoints2, 7, "Secondary Arterial Road", true, UnitOfMeasure.Metric);
if (link2 != null) {
    // Create a dispatch point on the current road segment
    IDispatchPoint dp2 = netiface.createDispatchPoint(link2);
    if (dp2 != null) {
        dp2.addDispatchInterval(1, 3600, 3600);
    }
    // Set the outermost lane as a bus-only lane
    ArrayList<ILane> lanes2 = new ArrayList<>(link2.lanes());
    ILane lane = lanes2.get(0);
    lane.setLaneType("Bus-only Lane");
}

// Create the third road segment
Point startPoint3 = new Point(-300, 25);
Point endPoint3 = new Point(-150, 25);
ArrayList<Point> linkPoints3 = new ArrayList<>(Arrays.asList(startPoint3, endPoint3));
ILink link3 = netiface.createLink(linkPoints3, 3, "link3", true, UnitOfMeasure.Metric);
if (link3 != null) {
    IDispatchPoint dp3 = netiface.createDispatchPoint(link3);
    if (dp3 != null) {
        dp3.addDispatchInterval(1, 3600, 3600);
    }
}

// Create the fourth road segment
Point startPoint4 = new Point(-50, 25);
Point endPoint4 = new Point(50, 25);
ArrayList<Point> linkPoints4 = new ArrayList<>(Arrays.asList(startPoint4, endPoint4));
ILink link4 = netiface.createLink(linkPoints4, 3, "link4", true, UnitOfMeasure.Metric);

// Create the fifth road segment
Point startPoint5 = new Point(150, 25);
Point endPoint5 = new Point(300, 25);
ArrayList<Point> linkPoints5 = new ArrayList<>(Arrays.asList(startPoint5, endPoint5));
ILink link5 = netiface.createLink(linkPoints5, 3, "Custom Speed Limit Segment", true, UnitOfMeasure.Metric);
if (link5 != null) {
    link5.setLimitSpeed(30); // Unit: km/h
}

// Create the sixth road segment
Point startPoint6 = new Point(-300, 50);
Point endPoint6 = new Point(300, 50);
ArrayList<Point> linkPoints6 = new ArrayList<>(Arrays.asList(startPoint6, endPoint6));
ILink link6 = netiface.createLink(linkPoints6, 3, "Dynamic Dispatch Segment", true, UnitOfMeasure.Metric);
if (link6 != null) {
    link6.setLimitSpeed(80);
}

// Create the seventh road segment
Point startPoint7 = new Point(-300, 75);
Point endPoint7 = new Point(-250, 75);
ArrayList<Point> linkPoints7 = new ArrayList<>(Arrays.asList(startPoint7, endPoint7));
ILink link7 = netiface.createLink(linkPoints7, 3);
if (link7 != null) {
    link7.setLimitSpeed(80);
}

// Create the eighth road segment
Point startPoint8 = new Point(-50, 75);
Point endPoint8 = new Point(300, 75);
ArrayList<Point> linkPoints8 = new ArrayList<>(Arrays.asList(startPoint8, endPoint8));
ILink link8 = netiface.createLink(linkPoints8, 3);
if (link8 != null) {
    link8.setLimitSpeed(80);
}

// ==================== Create Connectors ====================
// Connect link3 and link4
if (link3 != null && link4 != null) {
    ArrayList<Integer> fromLaneNumbers1 = new ArrayList<>(Arrays.asList(1, 2, 3));
    ArrayList<Integer> toLaneNumbers1 = new ArrayList<>(Arrays.asList(1, 2, 3));
    IConnector connector1 = netiface.createConnector(link3.id(), link4.id(), fromLaneNumbers1, toLaneNumbers1, "Connector 1", true);
}

// Connect link4 and link5
if (link4 != null && link5 != null) {
    ArrayList<Integer> fromLaneNumbers2 = new ArrayList<>(Arrays.asList(1, 2, 3));
    ArrayList<Integer> toLaneNumbers2 = new ArrayList<>(Arrays.asList(1, 2, 3));
    IConnector connector2 = netiface.createConnector(link4.id(), link5.id(), fromLaneNumbers2, toLaneNumbers2, "Connector 2", true);
}

// Connect link7 and link8
if (link7 != null && link8 != null) {
    ArrayList<Integer> fromLaneNumbers3 = new ArrayList<>(Arrays.asList(1, 2, 3));
    ArrayList<Integer> toLaneNumbers3 = new ArrayList<>(Arrays.asList(1, 2, 3));
    IConnector connector3 = netiface.createConnector(link7.id(), link8.id(), fromLaneNumbers3, toLaneNumbers3, "Dynamic Dispatch Connector", true);
}
```

### 4.1.2. Creating Various Collection Devices

The various collection devices include: Data Collector, Queue Counter, and Travel Time Detector. The code to create them is as follows.

```java
// ==================== Create Data Collectors ====================
// Get lane object
ILane lane = netiface.findLane(1);
// Position, unit: m
double dist = 50;
// Create data collector on road segment
IVehicleDrivInfoCollector collector = netiface.createVehiCollectorOnLink(lane, dist, UnitOfMeasure.Metric);

// Get lane connector object
ILaneConnector laneConnector = netiface.findLaneConnector(1, 4);
// Position, unit: m
double dist = 50;
// Create data collector on connector
IVehicleDrivInfoCollector collector = netiface.createVehiCollectorOnConnector(laneConnector, dist, UnitOfMeasure.Metric);

// ==================== Create Queue Counters ====================
// Get lane object
ILane lane = netiface.findLane(1);
// Position, unit: m
double dist = 80;
// Create queue counter on road segment
IVehicleQueueCounter counter = netiface.createVehiQueueCounterOnLink(lane, dist, UnitOfMeasure.Metric);

// Get lane connector object
laneConnector = netiface.findLaneConnector(1, 4);
// Position, unit: m
double dist = 80;
// Create queue counter on connector
IVehicleQueueCounter counter = netiface.createVehiQueueCounterOnConnector(laneConnector, dist, UnitOfMeasure.Metric);

// ==================== Create Travel Time Detectors ====================
// Get start link object
ILink startLink = netiface.findLink(1);
// Get end link object
ILink endLink = netiface.findLink(2);
// Detector start position on start link, unit: m
double startDist = 10;
// Detector end position on end link, unit: m
double endDist = 90;
// Create travel time detector with start on link and end on link
ArrayList<IVehicleTravelDetector> detectors = netiface.createVehicleTravelDetector_link2link(startLink, endLink, startDist, endDist, UnitOfMeasure.Metric);

// Get start link object
ILink startLink = netiface.findLink(1);
// Get end lane connector object
ILaneConnector endLaneConnector = netiface.findLaneConnector(1, 4);
// Detector start position on start link, unit: m
double startDist = 10;
// Detector end position on end lane connector, unit: m
double endDist = 10;
// Create travel time detector with start on link and end on connector
ArrayList<IVehicleTravelDetector> detectors = netiface.createVehicleTravelDetector_link2conn(startLink, endLaneConnector, startDist, endDist, UnitOfMeasure.Metric);

// Get start lane connector object
ILaneConnector startLaneConnector = netiface.findLaneConnector(1, 4);
// Get end link object
ILink endLink = netiface.findLink(2);
// Detector start position on start lane connector, unit: m
double startDist = 10;
// Detector end position on end link, unit: m
double endDist = 90;
// Create travel time detector with start on connector and end on link
ArrayList<IVehicleTravelDetector> detectors = netiface.createVehicleTravelDetector_conn2link(startLaneConnector, endLink, startDist, endDist, UnitOfMeasure.Metric);

// Get start lane connector object
ILaneConnector startLaneConnector = netiface.findLaneConnector(1, 4);
// Get end lane connector object
ILaneConnector endLaneConnector = netiface.findLaneConnector(4, 7);
// Detector start position on start lane connector, unit: m
double startDist = 10;
// Detector end position on end lane connector, unit: m
double endDist = 90;
// Create travel time detector with start on connector and end on connector
ArrayList<IVehicleTravelDetector> detectors = netiface.createVehicleTravelDetector_conn2conn(startLaneConnector, endLaneConnector, startDist, endDist, UnitOfMeasure.Metric);
```

### 4.1.3. Creating Directional Arrows

The code to create directional arrows is as follows.

```java
ILane lane = netiface.findLane(4);
if (lane != null) {
    double length = 4;
    double distToTerminal = 10;
    GuideArrowType arrowType = GuideArrowType.StraightRight;
	IGuidArrow guidArrow = netiface.createGuidArrow(lane, length, distToTerminal, arrowType, UnitOfMeasure.Metric);
}
```

### 4.1.4. Creating Bus Stops and Bus Routes

The code to create bus stops and bus routes is as follows.

```java
// Create bus station
ILane lane = netiface.findLane(1);
IBusStation busStation = netiface.createBusStation(lane, 30, 50, "Bus Station 1", UnitOfMeasure.Metric);
// Set station type 1: curb-side, 2: bay-type
busStation.setType(1);

// Create bus line
ILink link1 = netiface.findLink(1);
ILink link2 = netiface.findLink(2);
ArrayList<ILink> links = new ArrayList<>(Arrays.asList(link1, link2));
IBusLine busLine = netiface.createBusLine(links);

// Associate bus line with bus station
boolean result = netiface.addBusStationToLine(busLine, busStation);
// Association successful
if (result) {
    // Get all bus stations on the bus line
    ArrayList<IBusStationLine> stationLineList = busLine.stationLines();
    // Get the first bus station
    IBusStationLine stationLine = stationLineList.get(0);
    // Set vehicle parking time, unit: s
    stationLine.setBusParkingTime(20);
}
```

### 4.1.5. Creating Various Event Areas

Various event areas include: Accident Zone, Construction Zone, Restricted Area, and Reconstruction and Expansion Borrowed Lane. The code to create them is as follows.

```java
// ==================== Create Accident Zone ====================
// Build parameters
DynaAccidentZoneParam param = new DynaAccidentZoneParam();
// Accident zone name
param.setName("Accident Zone");
// Road ID
param.setRoadId(1); 
// Location: distance from start of link/connector, unit: m
param.setLocation(100);
// Length, unit: m
param.setLength(50);
// Lane number list (starting from 0, continuous and ordered)
ArrayList<Integer> fromLaneNumbers = new ArrayList<>(Arrays.asList(0));
param.setMlFromLaneNumber(fromLaneNumbers); // Fixed variable name: accidentZoneParam → param
// Start time, unit: s
param.setStartTime(10); 
// Duration, unit: s
param.setDuration(600); 
// Speed limit for adjacent lanes, unit: km/h
param.setLimitedSpeed(40);
// Create accident zone
IAccidentZoneInterval accidentZone = netiface.createAccidentZone(param, UnitOfMeasure.Metric);

// ==================== Create Road Work Zone ====================
// Build parameters
DynaRoadWorkZoneParam param = new DynaRoadWorkZoneParam();
// Road work zone name
param.setName("Road Work Zone");
// Road ID
param.setRoadId(1);
// Location: distance from start of link/connector, unit: m
param.setLocation(200);
// Length, unit: m
param.setLength(50);  
param.setUpCautionLength(70);  // Advance warning length
param.setUpTransitionLength(50);  // Transition zone length
param.setUpBufferLength(50);  // Buffer zone length
param.setDownTransitionLength(40);  // Downstream transition zone length
param.setDownTerminationLength(40);  // Termination zone length
// Lane number list (starting from 0, continuous and ordered)
ArrayList<Integer> fromLaneNumbers = new ArrayList<>(Arrays.asList(0));
param.setMlFromLaneNumber(fromLaneNumbers);
// Start time, unit: s
param.setStartTime(0);
// Duration, unit: s
param.setDuration(3600);
// Speed limit for adjacent lanes, unit: km/h
param.setLimitSpeed(40);
// Create road work zone
IRoadWorkZone roadWorkZone = netiface.createRoadWorkZone(param, UnitOfMeasure.Metric);

// ==================== Create Restricted Zone ====================
// Build parameters
DynaLimitedZoneParam param = new DynaLimitedZoneParam();
// Restricted zone name
param.setName("Restricted Zone");
// Road ID
param.setRoadId(1); 
// Location: distance from start of link/connector, unit: m
param.setLocation(100);
// Length, unit: m
param.setLength(50);
// Lane number list (starting from 0, continuous and ordered)
ArrayList<Integer> fromLaneNumbers = new ArrayList<>(Arrays.asList(0));
param.setMlFromLaneNumber(fromLaneNumbers); // Fixed variable name: accidentZoneParam → param
// Start time, unit: s
param.setStartTime(10); 
// Duration, unit: s
param.setDuration(600); 
// Speed limit for adjacent lanes, unit: km/h
param.setLimitedSpeed(40);
// Create restricted zone
ILimitedZone limitedZone = netiface.createLimitedZone(param, UnitOfMeasure.Metric);

// ==================== Create Reconstruction Lane Borrowing ====================
// Build parameters
DynaReconstructionParam param = new DynaReconstructionParam();
// Road work zone ID
param.setRoadWorkZoneId(rwzId);
// ID of the borrowed link
param.setBeBorrowedLinkId(2);
// Number of borrowed lanes
param.setBorrowedNum(1);
// Passageway opening length, unit: m
param.setPassagewayLength(80);
// Passageway opening speed limit, unit: m/s
param.setPassagewayLimitedSpeed(40 / 3.6);
// Create reconstruction lane borrowing
IReconstruction reconstruction = netiface.createReconstruction(param, UnitOfMeasure.Metric);
```



## 4.2. Demand Modeling

### 4.2.1. Setting Dispatch

Dispatch settings can be configured in bulk via Dispatch Points before the simulation starts, or individual vehicles can be dynamically created during the simulation process.

(1) Before simulation starts, the code below creates vehicle types, vehicle compositions, dispatch points, and dispatch flows.

```java
// ==================== Create Vehicle Type ====================
// Build parameters
_VehicleType vehicleType = new _VehicleType();
vehicleType.setVehicleTypeName("New Vehicle Type 1");  // Vehicle type name
vehicleType.setLength(4.5);  // Length, unit: m
vehicleType.setLengthSD(0.5);  // Length standard deviation, unit: m
vehicleType.setWidth(2);  // Width, unit: m
vehicleType.setWidthSD(0.2);  // Width standard deviation, unit: m
vehicleType.setAvgSpeed(60);  // Desired speed, unit: km/h
vehicleType.setSpeedSD(10);  // Desired speed standard deviation, unit: km/h
vehicleType.setAvgAcce(4);  // Desired acceleration, unit: m/s²
vehicleType.setAcceSD(0.5);  // Desired acceleration standard deviation, unit: m/s²
vehicleType.setAvgDece(6);  // Desired deceleration, unit: m/s²
vehicleType.setDeceSD(0.5);  // Desired deceleration standard deviation, unit: m/s²
vehicleType.setMaxAcce(5.5);  // Maximum acceleration, unit: m/s²
vehicleType.setMaxDece(7.5);  // Maximum deceleration, unit: m/s²
vehicleType.setMaxSpeed(80);  // Maximum speed, unit: km/h
vehicleType.setCommercialVehicle(false);  // Whether it is a commercial vehicle
vehicleType.setMaxPassengerCapacity(1);  // Rated passenger capacity, unit: person
// Create vehicle type
boolean result = netiface.createVehicleType(vehicleType);
System.out.println("Vehicle type creation success: " + result);

// ==================== Create Vehicle Composition ====================
// Build vehicle type proportion list
List<VehiComposition> vehiTypeProportionList = new ArrayList<>(Arrays.asList(
    new VehiComposition(1, 0.3),  // Small passenger car, proportion 0.3
    new VehiComposition(2, 0.2),  // Large passenger car, proportion 0.2
    new VehiComposition(3, 0.1),  // Bus, proportion 0.1
    new VehiComposition(4, 0.4)   // Truck, proportion 0.4
));
// Create vehicle composition
int vehiCompositionId = netiface.createVehicleComposition("Dynamically Created Vehicle Composition", vehiTypeProportionList);

// ==================== Create Dispatch Point ====================
// Get link object
ILink link = netiface.findLink(1);
// Create dispatch point
IDispatchPoint dp = netiface.createDispatchPoint(link);
if (dp != null) {
    // Add dispatch intervals, including vehicle type composition, time interval, and dispatch count
    dp.addDispatchInterval(1, 600, 300);
    dp.addDispatchInterval(1, 600, 300);
}
```

(2) During simulation, without using dispatch points, the code below creates single vehicles at specified locations.

```java
// ==================== Create Vehicle on Road Segment ====================
// Build parameters
DynaVehiParam dvp1 = new DynaVehiParam();
// Vehicle type ID
dvp1.setVehiTypeCode(1);
// Road segment ID
dvp1.setRoadId(4);
// Lane number
dvp1.setLaneNumber(0);
// Position, unit: m
dvp1.setDist(m2p(50));
// Speed, unit: m/s
dvp1.setSpeed(m2p(20));
// Color
dvp1.setColor("#00AFF0");
// Dynamically create vehicle
IVehicle vehicle1 = simuiface.createGVehicle(dvp1);
if (vehicle1 != null) { // Fixed variable name: vehicle → vehicle1
    System.out.println("Created vehicle on road segment with ID: " + vehicle1.id());
}

// ==================== Create Vehicle on Connector ====================
// Build parameters
DynaVehiParam dvp2 = new DynaVehiParam();
// Vehicle type ID
dvp2.setVehiTypeCode(1);
// Connector ID
dvp2.setRoadId(4);
// Lane number of upstream link
dvp2.setLaneNumber(0);
// Lane number of downstream link
dvp2.setToLaneNumber(0);
// Position, unit: m
dvp2.setDist(m2p(50));
// Speed, unit: m/s
dvp2.setSpeed(m2p(20));
// Color
dvp2.setColor("#00AFF0");
// Dynamically create vehicle
IVehicle vehicle2 = simuiface.createGVehicle(dvp2);
if (vehicle2 != null) {
    System.out.println("Created vehicle on connector with ID: " + vehicle2.id());
}
```

### 4.2.2. Setting Routes

Route settings can be based on flow proportion distribution at Decision Points before or during the simulation, or a specific driving route can be directly assigned to individual vehicles.	

​	(1) Before starting the simulation, create decision points and update their routes and route flow ratios using the following code.

```java
// ============================== Create Decision Point ==============================
ILink link = netiface.findLink(1);
double location = 50;
String decisionPointName = "New Decision Point"; // Fixed variable declaration
IDecisionPoint decisionPoint = netiface.createDecisionPoint(link, location, decisionPointName, UnitOfMeasure.Metric);

// ==================== Create Vehicle Routes for Decision Point ====================
// Link ID lists
ArrayList<Integer> linkIdList1 = new ArrayList<>(Arrays.asList(1, 2));
ArrayList<Integer> linkIdList2 = new ArrayList<>(Arrays.asList(1, 3));
ArrayList<Integer> linkIdList3 = new ArrayList<>(Arrays.asList(1, 4));

// Build link object lists
ArrayList<ILink> linkList1 = new ArrayList<>();
for (Integer linkId : linkIdList1) {
    linkList1.add(netiface.findLink(linkId));
}
ArrayList<ILink> linkList2 = new ArrayList<>();
for (Integer linkId : linkIdList2) {
    linkList2.add(netiface.findLink(linkId));
}
ArrayList<ILink> linkList3 = new ArrayList<>();
for (Integer linkId : linkIdList3) {
    linkList3.add(netiface.findLink(linkId));
}

// Create vehicle routes for decision point
IRouting routing1 = netiface.createDeciRouting(decisionPoint, linkList1);
IRouting routing2 = netiface.createDeciRouting(decisionPoint, linkList2);
IRouting routing3 = netiface.createDeciRouting(decisionPoint, linkList3);

// ==================== Update Decision Point Route Flow Ratio Configuration ====================
// Initialize left/straight/right flow ratio objects
RoutingFlowRatio flowRatioLeft = new RoutingFlowRatio();
flowRatioLeft.routingFlowRatioID = 1;
flowRatioLeft.routingID = routing1.id(); // Fixed variable name: decisionRouting1 → routing1
flowRatioLeft.startDateTime = 0;
flowRatioLeft.endDateTime = 999999;
flowRatioLeft.ratio = 2.0;

RoutingFlowRatio flowRatioStraight = new RoutingFlowRatio();
flowRatioStraight.routingFlowRatioID = 2;
flowRatioStraight.routingID = routing2.id(); // Fixed variable name: decisionRouting2 → routing2
flowRatioStraight.startDateTime = 0;
flowRatioStraight.endDateTime = 999999;
flowRatioStraight.ratio = 3.0;

RoutingFlowRatio flowRatioRight = new RoutingFlowRatio();
flowRatioRight.routingFlowRatioID = 3;
flowRatioRight.routingID = routing3.id(); // Fixed variable name: decisionRouting3 → routing3
flowRatioRight.startDateTime = 0;
flowRatioRight.endDateTime = 999999;
flowRatioRight.ratio = 1.0;

// Initialize decision point data
_DecisionPoint decisionPointData = new _DecisionPoint(); // Fixed class name: DecisionPointData → _DecisionPoint
decisionPointData.deciPointID = decisionPoint.id();
decisionPointData.deciPointName = decisionPoint.name();
Point decisionPointPos = new Point();
if (decisionPoint.link().getPointByDist(decisionPoint.distance(), decisionPointPos)) {
    decisionPointData.X = decisionPointPos.getX();
    decisionPointData.Y = decisionPointPos.getY();
    decisionPointData.Z = decisionPoint.link().z();
}

// Construct flow ratio list
List<RoutingFlowRatio> flowRatioList = new ArrayList<>();
flowRatioList.add(flowRatioLeft);
flowRatioList.add(flowRatioStraight);
flowRatioList.add(flowRatioRight);

// Update decision point route flow ratio configuration
IDecisionPoint updatedDecisionPoint = netiface.updateDecipointPoint(decisionPointData, flowRatioList);
```

​	(2) During the simulation, dynamically modify the route flow ratios of existing decision points using the following code.

```java
// MySimulator.java

@Override
public ArrayList<DecipointFlowRatioByInterval> calcDynaFlowRatioParameters() {
    ArrayList<DecipointFlowRatioByInterval> result = new ArrayList<>();
    // Current simulation calculation batch number
    long batchNumber = simuiface.batchNumber();
    // Modify the flow ratio of each route at a specific decision point when calculating the 20th batch
    if (batchNumber == 20) {
        // Vehicle allocation ratio of each route at a decision point for a specific time period
        DecipointFlowRatioByInterval dfi = new DecipointFlowRatioByInterval();
        // Decision point ID
        dfi.setDeciPointID(5);
        // Start time, unit: seconds
        dfi.setStartDateTime(1);
        // End time, unit: seconds
        dfi.setEndDateTime(999999);
        // Route flow ratios
        ArrayList<RoutingFlowRatio> ratios = new ArrayList<>();
        ratios.add(new RoutingFlowRatio(1, 3));
        ratios.add(new RoutingFlowRatio(2, 4));
        ratios.add(new RoutingFlowRatio(3, 3));
        dfi.setRoutingFlowRatios(ratios);
        result.add(dfi);
    }
    return result;
}
```

​	(3) During the simulation, assign routes to vehicles using the following code.

```java
// 1. Use existing vehicle route of decision point
IRouting routing1 = netiface.findRouting(1);
vehicle.vehicleDriving().setRouting(routing1);

// 2. Create vehicle route not bound to decision point
ArrayList<Integer> linkIdList = new ArrayList<>(Arrays.asList(8, 16, 25));
ArrayList<ILink> linkList = new ArrayList<>();
for (int linkId : linkIdList) {
    linkList.add(netiface.findLink(linkId));
}
IRouting routing2 = netiface.createRouting(linkList);
vehicle.vehicleDriving().setRouting(routing2);
```




## 4.3. Signal Control

### 4.3.1. Creating Signal Controllers, Signal Control Plans, Traffic Signal Phases, and Traffic Signals

​	Before starting the simulation, signal controllers, signal control plans, traffic signal phases, and traffic signals can be created sequentially. During creation, the following binding relationships are simultaneously established: **Traffic Signal → Traffic Signal Phase → Signal Control Plan → Signal Controller**. The code is as follows.

```java
// ==================== Create Signal Controller (usually one per intersection) ====================
// Signal controller name
String signalControllerName = "Shuanglong Avenue-Jiyin Avenue Intersection";
// Create signal controller
ISignalController signalController = netiface.createSignalController(signalControllerName);

// ==================== Create Signal Plan (multiple plans can be configured for a controller in different periods) ====================
// Get signal controller object
ISignalController signalController = netiface.findSignalControllerByID(1);
// Signal plan name
String signalPlanName = "Off-peak Plan";
// Cycle time, unit: s
int cycleTime = 120;
// Phase difference, unit: s
int phaseDifference = 0;
// Start time, unit: s
int startTime = 0;
// End time, unit: s
int endTime = 3600;
// Create signal plan
ISignalPlan signalPlan = netiface.createSignalPlan(signalController, signalPlanName, cycleTime, phaseDifference, startTime, endTime);

// ==================== Create Signal Phase (a plan assigns phases to different directions/turns) ====================
// Get signal timing plan
ISignalPlan signalPlan = netiface.findSignalPlanById(1);
// Phase name
String signalPhaseName = "East-West Straight";
// Build color interval list
String[] colors = {"R", "G", "Y", "R"};
int[] intervals = {30, 26, 3, 61};
ArrayList<ColorInterval> colorIntervalList = new ArrayList<>();
for (int i = 0; i < colors.length; i++) {
    colorIntervalList.add(new ColorInterval(colors[i], intervals[i]));
}
// Create signal phase
ISignalPhase signalPhase = netiface.createSignalPlanSignalPhase(signalPlan, signalPhaseName, colorIntervalList);

// ==================== Create Signal Lamp (a phase controls lamps for multiple lanes) ====================
// Get phase object
ISignalPhase signalPhase = netiface.findSignalPhase(1);
// Signal lamp name
String signalLampName = "East Straight 1";
// Lane ID
long laneId = 1;
// Downstream lane ID
long toLaneId = -1;
// Position, unit: m
double distance = m2p(50);
// Create signal lamp
ISignalLamp signalLamp = netiface.createSignalLamp(signalPhase, signalLampName, laneId, toLaneId, distance);
```

### 4.3.2. Controlling Traffic Signal Colors

Signal light colors can be modified at two levels of granularity: by **Signal Controller Phase** or by **Individual Traffic Signal**.

(1) The following code modifies colors and durations by signal controller phase, either before the simulation starts or during the simulation process.

```java
// Build color and duration object list
ArrayList<ColorInterval> colorObjList = new ArrayList<>(Arrays.asList(
    new ColorInterval("R", 10),  // Red, duration 10
    new ColorInterval("G", 60),  // Green, duration 60
    new ColorInterval("Y", 3),   // Yellow, duration 3
    new ColorInterval("R", 17)   // Red, duration 17
));
// Find signal phase with ID 7
SignalPhase signalPhase = netiface.findSignalPhase(7);
if (signalPhase != null) {
    // Set color list
    signalPhase.setColorList(colorObjList);
}
```

After the creation of signal controllers, signal control schemes, signal light phases, and traffic signals within the road network, if it is necessary to modify the signal control scheme of an individual intersection during the simulation process, the example code below may be referenced. It is required to have previously recorded the phase IDs corresponding to each phase.

```java
// Define signal phase data structure
class PhaseData {
    // Signal phase ID
    int signalPhaseId;
    List<Integer> intervals;

    PhaseData(int id, List<Integer> intervals) {
        this.signalPhaseId = id;
        this.intervals = intervals;
    }
}

@Override
public void afterOneStep() {
    // Get current simulation time, unit: ms
    long simuTime = simuiface.simuIntervalScheming();
    
    // Reach specified time
    if (simuTime == 60 * 1000) {
        // Signal phase mapping for a single intersection
        Map<String, PhaseData> signalIntervalMapping = new HashMap<>();
        signalIntervalMapping.put("East-West Straight", new PhaseData(1, List.of(0, 31, 3, 86)));
        signalIntervalMapping.put("East-West Left Turn", new PhaseData(2, List.of(35, 21, 3, 61)));
        signalIntervalMapping.put("North-South Straight", new PhaseData(3, List.of(60, 31, 3, 26)));
        signalIntervalMapping.put("North-South Left Turn", new PhaseData(4, List.of(95, 21, 3, 1)));

        // Set by signal phase
        for (Map.Entry<String, PhaseData> entry : signalIntervalMapping.entrySet()) {
            PhaseData phaseData = entry.getValue();
            // Get signal phase ID
            long signlPhaseId = phaseData.signalPhaseId;
            // Get signal phase object
            ISignalPhase signalPhase = netInterface.findSignalPhase(signlPhaseId);
            if (signalPhase == null) {
                continue;
            }
            // Build color and duration list
            List<Online.ColorInterval> colorList = new ArrayList<>(List.of(
                new Online.ColorInterval("R", phaseData.intervals.get(0)),  // Red
                new Online.ColorInterval("G", phaseData.intervals.get(1)),  // Green
                new Online.ColorInterval("Y", phaseData.intervals.get(2)),  // Yellow
                new Online.ColorInterval("R", phaseData.intervals.get(3))   // Red
            ));
            // Set new timing plan
            signalPhase.setColorList(colorList);
        }
    }
}
```

(2) The following code directly modifies the colors of individual traffic signals during the simulation process. Since this operation essentially modifies or overrides the results already computed by TESS NG, such adjustments **take effect only within the current frame**. This means that **it is insufficient to perform the setting once at a single moment when the condition is met; instead, the setting operation must be continuously applied throughout the entire duration during which the condition holds**.

```java
// MySimulator.java

@Override
public boolean calcLampColor(ISignalLamp pSignalLamp) {
    // Get current simulation time, unit: ms
    long simuTime = simuiface.simuIntervalScheming();
    // If the signal lamp ID is 1 and within the specified time range, set to green
    if (pSignalLamp.id() == 1 && simuTime >= 60 * 1000 && simuTime <= 90 * 1000) {
        pSignalLamp.setLampColor("G");
        return true;
    }
    return false;
}
```



## 4.4. Vehicle Control

### 4.4.1. Setting Vehicle Desired Speed

During the simulation process, the code for setting a vehicle’s desired speed is as follows.

```java
// Set the vehicle's desired speed, unit: pixels/s
vehicle.setDesirSpeed(m2p(80 / 3.6));
```

### 4.4.2. Setting Vehicle Speed

During the simulation process, the code for setting a vehicle’s speed is as follows.

```java
// MySimulator.java

// Unit: m/s
@Override
public boolean ref_reSetSpeed_unit(IVehicle pIVehicle, ObjReal ref_inOutSpeed, ObjUnitOfMeasure ref_unit) {
    if (pIVehicle.id() == 100001) {
        // Directly specify the vehicle's speed
        ref_inOutSpeed.setValue(80 / 3.6);
        return true;
    }
    return false;
}
```

### 4.4.3. Setting Vehicle Acceleration

The code for setting vehicle acceleration is as follows.

```java
// MySimulator.java

// This function is calculated before TESS NG computes acceleration, unit: m/s²
@Override
public boolean ref_calcAcce_unit(IVehicle pIVehicle, ObjReal acce, ObjUnitOfMeasure ref_unit) {
    if ("Cao'an Highway".equals(pIVehicle.roadName())) { // Fixed string comparison
        // Calculate acceleration directly based on different speeds
        if (pIVehicle.currSpeed() > 20/3.6) {
            acce.setValue(-3);
            return true;
        }
        else if (pIVehicle.currSpeed() > 10/3.6) {
            acce.setValue(-1);
            return true;
        }
    }
    return false;
}

// This function is calculated after TESS NG computes acceleration, unit: m/s²
@Override
public boolean ref_reSetAcce_unit(IVehicle pIVehicle, ObjReal inOutAcce, ObjUnitOfMeasure ref_unit) {
    if ("Cao'an Highway".equals(pIVehicle.roadName())) { // Fixed string comparison
        // Correct the calculated acceleration based on different speeds
        if (pIVehicle.currSpeed() > 20/3.6) {
            inOutAcce.setValue(inOutAcce.getValue() + (-3)); // Fixed parameter name: acce → inOutAcce
            return true;
        }
        else if (pIVehicle.currSpeed() > 10/3.6) {
            inOutAcce.setValue(inOutAcce.getValue() + (-1)); // Fixed parameter name: acce → inOutAcce
            return true;
        }
    }
    return false;
}
```

### 4.4.4. Setting Vehicle Lane Change

The code for controlling vehicle lane changes to the left or right is as follows.

```java
// Control the vehicle to change lane to the left
vehicle.vehicleDriving().toLeftLane();

// Control the vehicle to change lane to the right
vehicle.vehicleDriving().toRightLane();
```

The code for canceling a vehicle lane change is as follows.

```java
// MySimulator.java

@Override
public boolean reCalcDismissChangeLane(IVehicle pIVehicle) {
	// Cancel all free lane changing when the distance to the end of the road segment is less than 50 m, thereby prohibiting free lane changing
    if (pIVehicle.vehicleDriving().distToEndpoint(true, true, UnitOfMeasure.Metric) < 50) {
        return true;
    }
    return false;
}
```

### 4.4.5. Setting Vehicle Lane Restrictions

The code for setting vehicle lane restrictions is as follows.

```java
// MySimulator.java

@Override
public ArrayList<Int> calcLimitedLaneNumber(IVehicle pIVehicle) {
    // If the vehicle is on the road segment and its length exceeds 8 m, entering the innermost lane is prohibited
    if (pIVehicle.roadIsLink() && pIVehicle.length(UnitOfMeasure.Metric) > 8) {
        int limitLaneNumber = pIVehicle.lane().link().laneCount();
        List<Integer> restrictedLanes = new ArrayList<>();
        restrictedLanes.add(limitLaneNumber);
        return restrictedLanes;
    }
    return new ArrayList<>();
}
```

### 4.4.6. Setting Vehicle Route

The code for setting the vehicle route is as follows.

```java
// 1. Use vehicle routes associated with existing decision points
IRouting routing1 = netiface.findRouting(1);
vehicle.vehicleDriving().setRouting(routing1);

// 2. Create vehicle routes not bound to decision points
ArrayList<Integer> linkIdList = new ArrayList<>(Arrays.asList(8, 16, 25));
ArrayList<ILink> linkList = new ArrayList<>();
for (int linkId : linkIdList) {
    linkList.add(netiface.findLink(linkId));
}
IRouting routing2 = netiface.createRouting(linkList);
vehicle.vehicleDriving().setRouting(routing2);
```

### 4.4.7. Setting Vehicle Car-Following Parameters

The code for setting vehicle car-following parameters is as follows. **Currently, only modifying parameters of the IDM car-following model is supported.**

```java
// Set the vehicle's desired acceleration, unit: pixels/s²
vehicle.setDesirAcce(m2p(5.5));

// Set the vehicle's maximum deceleration, unit: pixels/s²
vehicle.setMaxDece(m2p(7.5));

// Set the vehicle's safe time interval, unit: s
vehicle.vehicleDriving().setSafeTimeInterval(1.5);

// Set the vehicle's stopping distance, unit: pixels
vehicle.vehicleDriving().setStoppingDistance(m2p(2));
```

### 4.4.8. Setting Vehicle Jump

The code for setting vehicle jumps is as follows.

```java
// Target point
Point targetPoint = new Point(50, 50);
// Project the target point onto lanes within a certain nearby range to obtain positioning information sequence
ArrayList<Location> locations = netiface.locateOnCrid(targetPoint, 9, UnitOfMeasure.Metric);  // Need to execute netiface.buildNetGrid(10) first
// If a lane object is located
if (!locations.isEmpty()) {
    Location location = locations.get(0);
    // Lane object
    ILaneObject laneObj = location.getPLaneObject();
    // Position, unit: m
    double dist = location.getDistToStart();

    // Move the vehicle to the specified lane and position to achieve instant vehicle position teleportation
    vehicle.vehicleDriving().move(laneObj, dist, UnitOfMeasure.Metric);
}
```

### 4.4.9. Setting Vehicle Information and Visualization

The code for setting vehicle information is as follows.

```java
// MySimulator.java
    
@Override
public String vehiRunInfo(IVehicle pIVehicle) {
    return String.format("The vehicle is currently on the road with ID=%d", pIVehicle.roadId());
}
```

The code for setting vehicle color is as follows.

```java
// Set vehicle color to blue
vehicle.setColor("#00AFF0");
```



## 4.5. Simulation Control

### 4.5.1. Setting Simulation Parameters

Before starting the simulation, the code for setting simulation parameters is as follows.

```java
// MySimulator.java

// Set the following parameters before simulation starts
@Override
public void beforeStart(ObjBool keepOn) {
    // Set simulation acceleration multiple
    simuiface.setAcceMultiples(5);
    // Set simulation duration, unit: s
    simuiface.setSimuIntervalScheming(3600);
    // Set simulation accuracy
    simuiface.setSimuAccuracy(10);
    // Set random seed
    simuiface.setRandSeed(42);
    // Set whether to record vehicle trajectories
    simuiface.setIsRecordTrace(true);
    // Set whether to record pedestrian trajectories
    simuiface.setIsRecordPedestrianTrace(true);
}
```

### 4.5.2. Starting, Pausing, and Stopping the Simulation

The code for starting, pausing, and stopping the simulation is as follows.

```java
// Start simulation (typically written in afterLoadNet or afterStop)
if (!simuiface.isRunning() || simuiface.isPausing()) {
    simuiface.startSimu();
}

// Pause simulation (typically written in afterOneStep)
if (simuiface.isRunning()) {
    simuiface.pauseSimu();
}

// Stop simulation (typically written in afterOneStep)
if (simuiface.isRunning()) {
    simuiface.stopSimu();
}
```

### 4.5.3. Running Consecutive Multiple Simulations

The code for running consecutive multiple simulations is as follows.

```java
// MySimulator.java

public class MySimulator extends JCustomerSimulator {
    // Interface representing TESS NG
    private TessInterface iface;
    // Road network sub-interface representing TESS NG
    private NetInterface netiface;
    // Simulation sub-interface representing TESS NG
    private SimuInterface simuiface;

    // Current simulation count
    private int currentSimuCount = 0;
    // Maximum simulation count
    private int maxSimuCount = 10;

    public MySimulator() {
        super();
        iface = TESSNG.tessngIFace();
        netiface = iface.netInterface();
        simuiface = iface.simuInterface();
    }

    @Override
    public void afterStart() {
        // Increment simulation count
        currentSimuCount += 1;
    }
    
    @Override
    public void afterOneStep() {
        // Current simulation time, unit: ms
        long simuTime = simuiface.simuTimeIntervalWithAcceMutiples();
        if (simuTime > 600 * 1000) {
            // Stop simulation
            simuiface.stopSimu();
        }
    }
    
    @Override
    public void afterStop() {
        // Maximum simulation count not reached
        if (currentSimuCount < maxSimuCount) {
            // Start simulation
            simuiface.startSimu();
        }
    }
}
```



## 4.6. Data Output

### 4.6.1. Output of Road Network Geometric Linear Data

The road network consists of road segments and connection segments, where road segments are composed of lanes, and connection segments are composed of lane connections. Road segments, lanes, and lane connections each contain a series of breakpoints for the centerline, left boundary line, and right boundary line. Vehicles travel along these breakpoint-defined lines. The code for obtaining breakpoint data of road segments, lanes, and lane connections is as follows.

```java
// Get the breakpoint coordinates of the center line, left line, and right line of a specific road segment
ILink link = netiface.findLink(1);
ArrayList<Vector3D> linkCenterPoints = link.centerBreakPoint3Ds(UnitOfMeasure.Metric);
ArrayList<Vector3D> linkLeftPoints = link.leftBreakPoint3Ds(UnitOfMeasure.Metric);
ArrayList<Vector3D> linkRightPoints = link.rightBreakPoint3Ds(UnitOfMeasure.Metric);

// Get the breakpoint coordinates of the center line, left line, and right line of a specific lane
ILane lane = netiface.findLane(1);
ArrayList<Vector3D> laneCenterPoints = lane.centerBreakPoint3Ds(UnitOfMeasure.Metric);
ArrayList<Vector3D> laneLeftPoints = lane.leftBreakPoint3Ds(UnitOfMeasure.Metric);
ArrayList<Vector3D> laneRightPoints = lane.rightBreakPoint3Ds(UnitOfMeasure.Metric);
        
// Get the breakpoint coordinates of the center line, left line, and right line of a specific lane connector
ILaneConnector laneConnector = netiface.findLaneConnector(1, 4);
ArrayList<Vector3D> laneConnectorCenterPoints = laneConnector.centerBreakPoint3Ds(UnitOfMeasure.Metric);
ArrayList<Vector3D> laneConnectorLeftPoints = laneConnector.leftBreakPoint3Ds(UnitOfMeasure.Metric);
ArrayList<Vector3D> laneConnectorRightPoints = laneConnector.rightBreakPoint3Ds(UnitOfMeasure.Metric);
```

### 4.6.2. Output Vehicle Trajectory Data

The following code obtains vehicle data for a specific simulation frame during the simulation process.

```java
// Get the list of currently running vehicles
ArrayList<IVehicle> allVehicles = simuiface.allVehiStarted();
for (IVehicle vehicle : allVehicles) {
    System.out.println("Vehicle ID: " + vehicle.id());
    System.out.println("Vehicle Name: " + vehicle.name());
    System.out.println("Vehicle Type Code: " + vehicle.vehicleTypeCode());
    System.out.println("Vehicle Type Name: " + vehicle.vehicleTypeName());
    System.out.println("Vehicle Length: " + vehicle.length(UnitOfMeasure.Metric) + " m");

    System.out.println("Vehicle Current Abscissa: " + vehicle.pos(UnitOfMeasure.Metric).getX() + " m");
    System.out.println("Vehicle Current Ordinate: " + vehicle.pos(UnitOfMeasure.Metric).getY() + " m");
    System.out.println("Vehicle Current Elevation: " + vehicle.v3z() + " m");
    System.out.println("Vehicle Current Road ID: " + vehicle.roadId());
    System.out.println("Vehicle Current Road Name: " + vehicle.roadName());
    System.out.println("Vehicle Is on Link: " + vehicle.roadIsLink());
    System.out.println("Vehicle Current Lane ID: " + vehicle.laneId());
    if (vehicle.roadIsLink()) {
        System.out.println("Vehicle Current Lane Number: " + vehicle.vehicleDriving().laneNumber());
    }
    System.out.println("Vehicle Distance to Lane Start Point: " + vehicle.vehicleDriving().distToStartPoint(true, true, UnitOfMeasure.Metric) + " m");
    
    System.out.println("Vehicle Current Speed: " + vehicle.currSpeed(UnitOfMeasure.Metric) * 3.6 + " km/h");
    System.out.println("Vehicle Current Desired Speed: " + vehicle.vehicleDriving().desirSpeed(UnitOfMeasure.Metric) * 3.6 + " km/h");
    System.out.println("Vehicle Current Acceleration: " + vehicle.acce(UnitOfMeasure.Metric) + " m/s²");
    System.out.println("Vehicle Current Heading Angle: " + vehicle.angle() + " °");
}
```

### 4.6.3. Output Traffic Signal Data

The following code obtains traffic signal data for a specific simulation frame during the simulation process.

```java
ArrayList<SignalPhaseColor> allSignalPhaseColor = simuiface.getSignalPhasesColor();
for (SignalPhaseColor signalPhaseColor : allSignalPhaseColor) {
    System.out.println("Signal Group ID: " + signalPhaseColor.getSignalGroupId());
    System.out.println("Signal Phase ID: " + signalPhaseColor.getPhaseId());
    System.out.println("Signal Phase Number: " + signalPhaseColor.getPhaseNumber());
    System.out.println("Current Color: " + signalPhaseColor.getColor());
    System.out.println("Current Color Set Time (ms): " + signalPhaseColor.getMrIntervalSetted());
    System.out.println("Current Color Duration (ms): " + signalPhaseColor.getMrIntervalByNow());
}
```

### 4.6.4. Output Various Data Collector Device Data

Various data collector devices include: Data Collectors, Queue Counters, and Travel Time Detectors. The following code obtains their sample data and aggregated data during the simulation process. Note that **aggregated data can only be obtained in the simulation frame corresponding to the end of the aggregation period**.

```java
// ==================== Sample Data of Data Collectors ====================
ArrayList<VehiInfoCollected> allVehiInfoCollected = simuiface.getVehisInfoCollected();
for (VehiInfoCollected vehiInfo : allVehiInfoCollected) {
    System.out.println("Collector ID: " + vehiInfo.getCollectorId());
    System.out.println("Simulation Time (s): " + vehiInfo.getSimuInterval());
    System.out.println("Vehicle ID: " + vehiInfo.getVehiId());
}

// ==================== Aggregated Data of Data Collectors ====================
ArrayList<VehiInfoAggregated> allVehiInfoAggregated = simuiface.getVehisInfoAggregated();
for (VehiInfoAggregated vehiInfoAgg : allVehiInfoAggregated) {
    System.out.println("Collector ID: " + vehiInfoAgg.getCollectorId());
    System.out.println("Time Period ID: " + vehiInfoAgg.getTimeId());
    System.out.println("Start Time (s): " + vehiInfoAgg.getFromTime());
    System.out.println("End Time (s): " + vehiInfoAgg.getToTime());
    System.out.println("Vehicle Count (veh): " + vehiInfoAgg.getVehiCount());
    System.out.println("Average Speed (km/h): " + vehiInfoAgg.getAvgSpeed());
    System.out.println("Average Occupancy: " + vehiInfoAgg.getOccupancy());
}

// ==================== Sample Data of Queue Counters ====================
ArrayList<VehiQueueCounted> allVehiQueueCounted = simuiface.getVehisQueueCounted();
for (VehiQueueCounted vehiQueue : allVehiQueueCounted) {
    System.out.println("Counter ID: " + vehiQueue.getCounterId());
    System.out.println("Simulation Time (s): " + vehiQueue.getSimuTime());
    System.out.println("Queued Vehicle Count (veh): " + vehiQueue.getVehiCount());
    System.out.println("Queue Length (m): " + vehiQueue.getQueueLength());
}

// ==================== Aggregated Data of Queue Counters ====================
ArrayList<VehiQueueAggregated> allVehiQueueAggregated = simuiface.getVehisQueueAggregated();
for (VehiQueueAggregated vehiQueueAgg : allVehiQueueAggregated) {
    System.out.println("Counter ID: " + vehiQueueAgg.getCounterId());
    System.out.println("Time Period ID: " + vehiQueueAgg.getTimeId());
    System.out.println("Start Time (s): " + vehiQueueAgg.getFromTime());
    System.out.println("End Time (s): " + vehiQueueAgg.getToTime());
    System.out.println("Average Queued Vehicle Count (veh): " + vehiQueueAgg.getAvgVehiCount());
    System.out.println("Average Queue Length (m): " + vehiQueueAgg.getAvgQueueLength());
    System.out.println("Maximum Queue Length (m): " + vehiQueueAgg.getMaxQueueLength());
    System.out.println("Minimum Queue Length (m): " + vehiQueueAgg.getMinQueueLength());
}

// ==================== Sample Data of Travel Time Detectors ====================
ArrayList<VehiTravelDetected> allVehiTravelDetected = simuiface.getVehisTravelDetected();
for (VehiTravelDetected vehiTravel : allVehiTravelDetected) {
    System.out.println("Detector ID: " + vehiTravel.getDetectedId());
    System.out.println("Vehicle ID: " + vehiTravel.getVehiId());
    System.out.println("Travel Time (s): " + vehiTravel.getTravelTime());
    System.out.println("Travel Distance (m): " + vehiTravel.getTravelDistance());
    System.out.println("Delay (s): " + vehiTravel.getDelay());
}

// ==================== Aggregated Data of Travel Time Detectors ====================
ArrayList<VehiTravelAggregated> allVehiTravelAggregated = simuiface.getVehisTravelAggregated();
for (VehiTravelAggregated vehiTravelAgg : allVehiTravelAggregated) {
    System.out.println("Detector ID: " + vehiTravelAgg.getDetectedId());
    System.out.println("Time Period ID: " + vehiTravelAgg.getTimeId());
    System.out.println("Start Time (s): " + vehiTravelAgg.getFromTime());
    System.out.println("End Time (s): " + vehiTravelAgg.getToTime());
    System.out.println("Vehicle Count: " + vehiTravelAgg.getVehiCount());
    System.out.println("Average Travel Time (s): " + vehiTravelAgg.getAvgTravelTime());
    System.out.println("Average Travel Distance (m): " + vehiTravelAgg.getAvgTravelDistance());
    System.out.println("Average Delay (s): " + vehiTravelAgg.getAvgDelay());
}
```

<div style="page-break-after: always;"></div>

# 5. Industry Use Cases

The industry case studies implemented based on the secondary development of TESS NG are listed in the table below. For the complete source code, please refer to the [GitHub](https://github.com/jIDa-traffic/TESSNG_SecondaryDev) repository or the [Gitee](https://gitee.com/jidatraffic/tessng-secondary-doc) repository.

|       Category       | Function Item                           |
| :--------------: | :------------------------------- |
|       Highway       | Construction Zone Simulation                       |
|                  | Accident and Incident Simulation                   |
|                  | Lane Speed Limit Management                     |
|                  | Lane Closure Simulation                     |
|                  | Hard Shoulder and Emergency Lane Opening             |
|                  | Ramp Signal Control                     |
|                  | Congestion Warning                         |
|                  | Highway Control Pre-evaluation System               |
|                  | High-speed Road Parameter Calibration                 |
|       Urban       | Single-point Signal Adaptive Control                   |
|                  | Intersection Lane Channelization Changes, Reversible Lane |
|                  | Trunk Line Coordination                         |
|                  | Vehicle Route Guidance                     |
|                  | Congestion Warning                         |
|                  | Lane Control Simulation                     |
|                  | Vehicle Accident Simulation                     |
|                  | Vehicle Speed Guidance (VMS Information Board)        |
|                  | Urban Road Parameter Calibration                 |
|                  | Bus Signal Priority                     |
|   V2X Autonomous Driving   | V2X Intersection                        |
|                  | Speed Guidance                         |
|                  | Vehicle Platooning                     |
| Autonomous Driving Joint Simulation | Carla Integration                        |
|                  | Prescan Integration                      |
|                  | Scanner Integration                      |
|                  | Traffic Digital Twin: Integration with UE5 and Unity   |
|                  | Autonomous Driving Test Scenario Design             |

<div style="page-break-after: always;"></div>

# 6. Precautions

## 6.1. Software Activation

Users must activate TESS NG Secondary Development upon first use. Trial users follow the same activation process as first-time users, using the JIDaTraffic_key located in the Cert folder of the installation package.

The software trial period is 30 days. After the trial period ends, the secondary development interfaces remain available; however, custom plugins will no longer be usable. Commercial version users have unrestricted access.

Additionally, you can **modify the `workspacePath` parameter in `Main.java`** to specify the installation directory of TESS NG. After this configuration, all output files will be uniformly generated in this directory, enabling activation file sharing (to avoid repeated activations) and 3D model file sharing (to prevent missing model files during 3D conversion).



## 6.2. Measurement Units

Since TESS NG is developed based on the Qt framework, and Qt’s graphics system uses pixels as the base unit, its coordinate system inherently differs from the physical units used in the real world (such as meters). Qt's drawing operations, interface layout, and interaction responses are all based on pixel dimensions, with screen pixels set as the default standard for rendering and positioning; this does not directly correspond to physical scales in real-world space.	

Therefore, in TESS NG secondary development, special attention must be given to the conversion logic between **pixels and metric units**, whether defining the dimensions of road network elements, calculating and mapping vehicle positions, rendering custom graphics, or parsing coordinates for interaction operations. By default, 1 pixel corresponds to 1 meter; however, if the pixel ratio changes due to operations such as importing a base map, unit conversion can be achieved by the following methods:

- Metric to Pixel Conversion: public static double m2p(double value)
- Pixel to Metric Conversion: public static double p2m(double value)

Additionally, some methods in the plugin and interface include the **UnitOfMeasure unit** parameter, whose default value is `UnitOfMeasure.Default` (i.e., pixel unit). Passing `UnitOfMeasure.Metric` indicates the use of metric units (supports both read and write operations). For example, `vehicle.currSpeed()` returns the vehicle's speed in pixel units, while `vehicle.currSpeed(UnitOfMeasure.Metric)` returns its speed in metric units. Note that since the `unit` parameter is typically the last in the method parameter list, **if this parameter is explicitly specified, all preceding parameters with default values must also be explicitly provided with corresponding arguments**. This rule is stated here for clarity and will not be reiterated in the interface documentation.



## 6.3. Coordinate System

As TESS NG is developed based on the Qt framework, its coordinate system design directly follows Qt's core conventions — Qt employs a **y-axis pointing downwards** coordinate system to suit screen display and graphical rendering logic (screen pixels generally have the origin at the top-left corner, with the positive y-axis directed downward). The origin is usually situated at the top-left corner of the canvas/window, the x-axis extends horizontally to the right, and the y-axis extends vertically downward.

Therefore, in the secondary development process of TESS NG, all scenarios involving coordinate calculations, graphical rendering (such as positioning of road network elements, vehicle location annotation, and custom graphic rendering), as well as mouse interaction positioning, must comply with this **y-axis pointing downwards** coordinate system convention. Particular attention must be paid to differences in coordinate axis directions when converting data or mapping positions between the real-world geographic coordinate system (typically with the y-axis oriented upwards) and custom coordinate systems, to avoid graphical displacement, position calculation errors, and other related issues caused by coordinate system misunderstandings.



## 6.4. Importing Dependency Classes

It is generally necessary to import required dependency classes at the beginning of the file. Individual classes or entire packages can be imported as needed. An example is provided below.

```java
// Import the entire package
import com.jidatraffic.tessng.*;

// Import specified classes and static methods
import com.jidatraffic.tessng.TESSNG;
import static com.jidatraffic.tessng.TESSNG.m2p;
```



## 6.5. Sub-plugin Functional Rules

Adjustments to vehicle acceleration, desired speed, driving speed, steering angle, and traffic signal color settings within simulation plugins fundamentally serve as corrections or overrides to the results computed by TESS NG; therefore, such adjustments **take effect only within the current simulation frame**. This means that operations such as setting traffic signal colors **cannot be performed only once at a specific moment when the conditions are met, but must be continuously applied throughout the entire time interval during which the conditions remain satisfied**.



## 6.6. Usage Rules for Sub-plugin Functions That Modify Input Values

​	Since TESS NG is implemented with a C++ core, and C++ supports modifying basic types such as integers, floats, and booleans through pass-by-reference, whereas Java does not support reference modification for these types. To address this difference, for functions that require modifying input values, we prefix their names with "ref_" and have specially designed adapter types such as `objInt`, `objReal`, and `objBool`.

For example, the original function `public boolean reSetSpeed(IVehicle pIVehicle, ObjReal inOutSpeed)` will have a corresponding function `public boolean ref_reSetSpeed(IVehicle pIVehicle, ObjReal ref_inOutSpeed)` added. Among them, the type of `ref_inOutSpeed` is `objReal`, and assignment can be performed via `ref_inOutSpeed.setValue(1)`.

These functions are mainly concentrated in JCustomerSimulator and JCustomerNet. The interface details list both functions without the `ref_` prefix and those with the `ref_` prefix:

- If there is a need to modify the passed-in values, functions prefixed with `ref_` should be used；

- If there is no need to modify the input parameter, such as in `public void beforeStart(ObjBool keepOn)`, either the function without the `ref_` prefix or the one with the `ref_` prefix can be used.

  


## 6.7. Graphical interface related functionalities are temporarily unavailable.

​	Since TESS NG is developed based on the Qt framework, and the current Qt framework does not support Java, graphical interface functionalities in TESS NG are temporarily unavailable in the Java development environment.

<div style="page-break-after: always;"></div>

# 7. Q&A List

### 1. Why is the secondary development code I wrote in the MySimulator built-in functions not taking effect?

**Answer:** This may be because the trial period has expired, causing the system to lack permission to load the plugin, which prevents the custom code from executing.

