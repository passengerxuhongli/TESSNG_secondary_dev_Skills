# Microscopic Traffic Simulation Software TESS NG Secondary Development API Documentation (C++ Edition)

[TOC]

<div style="page-break-after: always;"></div>

# 1. Introduction

## 1.1. Relevant Links

* [Official Website of Shanghai Jida Traffic Technology Co., Ltd.](https://jidatraffic.com/#/home)
* [Official Documentation for TESS NG Secondary Development](http://jidatraffic.com:82/)
* [TESS NG Secondary Development GitHub Repository](https://github.com/jIDa-traffic/TESSNG_SecondaryDev)
* [TESS NG Secondary Development Gitee Repository](https://gitee.com/jidatraffic/tessng-secondary-doc)



## 1.2. Research and Development Background

**The domestic microscopic traffic simulation software TESS NG** integrates state-of-the-art technologies from interdisciplinary fields such as traffic engineering, software engineering, and system simulation, and exhibits the following distinctive features: fully independent intellectual property, convenient and efficient modeling capabilities, open external interface modules, and customizable user services.

　　In the process of functional extension and project development, TESS NG enhances its design by highly abstracting the implementation of numerous functions and deeply integrating these abstract logics with core functionalities. The abstract logic is further refined into interface methods, while the concrete interface implementations are carried out by users according to actual application scenarios. Under this architectural design, TESS NG has successfully developed plugin modules such as vehicle-road coordination, online simulation, and integrated micro-macro simulation, with the design and application of relevant interfaces becoming increasingly mature.

　　TESS NG’s secondary development capabilities are realized through user-authored code interacting with the software, thereby extending functionalities and customizing scenarios. Users can not only achieve highly automated and personalized simulation services but also construct traffic digital twins and scientific research experimental environments tailored to specific requirements, which constitute important approaches for conducting traffic research and applications.

　　Currently, TESS NG’s secondary development supports three programming languages: **C++, Python, and Java**. The interface names are fully consistent across all three languages.



## 1.3. Application Scenarios

The secondary development capabilities of TESS NG enable the construction of a wide variety of simulation scenarios. Its applicable scenarios are extensive, including but not limited to those presented in the table below.

| No. |     Category     |       Scenario       |                             Application                             |
| :--: | :----------: | :--------------: | :----------------------------------------------------------: |
|  1   |   Urban Simulation   |     Signal Control     |                     Single-Point Webster Signal Control Algorithm                      |
|  2   |              |     Bus Priority     |                         Mainline Green Wave Algorithm                         |
|  3   |              |   Vehicle Route Guidance   | **By adjusting the route proportions at decision points to guide vehicle flow**<br/>**Evaluation and analysis of queue lengths on downstream road sections at guidance points** |
|  4   |   Highway Simulation   |     Ramp Signal Control     |                  Ramp ALINEA Signal Control Algorithm Application                  |
|  5   |              |   Lane Speed Limit Management   |                  Dynamic Management of Highway Lane Speed Limits                  |
|  6   |              |   Emergency Incident Handling   |                    Vehicle Accident and Incident Simulation                    |
|  7   |              |     Road Construction     |                        Simulation of Three Types of Construction Zones                        |
|  8   |     Education     | Continuous Intersection Speed Guidance |                     Application of Green Wave Speed Guidance Strategy                     |
|  9   |              |    Traffic Flow Reconstruction    |                 Calibration of Car-Following and Lane-Changing Model Parameters for High-Speed Expressways                 |
|  10  |              |   Preliminary Research on AI Algorithms    |             Research on Variable Speed Limit Optimization for Expressways Based on Reinforcement Learning             |
|  11  |   Network Construction   |     Network Editing     |          CRUD Operations for Simulation Elements such as Network, Road Segment, and Connection Segment          |
|  12  |              |     Signal Control Editing     |         CRUD Operations for Traffic Signal Lights, Signal Groups, and Support for Dual-Ring Structure Signal Control Loading         |
|  13  |              |     Demand Editing     | **Dispatch Point Flow Loading Configuration**<br/>**Individual Vehicle Spawning at Specified Locations**<br/>**Vehicle Composition Customization**<br/>**CRUD Operations for Decision Points and Path Proportions** |
|  14  | Simulation Process Control |     Workflow Control     | **Simulation start, pause, resume, and stop operations**<br/>**Simulation snapshot functionality application**<br/>**Acquisition of simulation information, network information, and vehicle information**<br/>**Conversion between vehicle trajectory planar coordinates and geographic coordinates**<br/>**Parameter settings for acceleration, simulation accuracy, random seed, etc.** |
|  15  |              |     Action Control     | **Speed limit zones, accident zones, and construction zones setup**<br/>**Vehicle movement, information modification, lane changing, and heading angle adjustment**<br/>**Traffic light color, path, and phase information updates**<br/>**Lane activation/deactivation, route schemes, and path information management**<br/>**Car-following model and lane-changing model parameter modifications** |
|  16  |              |     Simulation Output     | **Detector and collector configuration**<br/>**Data output at specified time intervals**<br/>**Acquisition of binding relationships between detectors/collectors and simulation road network**<br/>**Vehicle trajectory output**<br/>**Structured data output of simulation road network** |
|  17  | Interactive Interface Development |      Menu Bar      |      Support for User-Defined Custom Menus to Enable Interaction with TESS NG Software       |
|  18  |              |      Toolbar      |     Supports users in adding custom toolbars to enable interaction with the TESS NG software.      |



## 1.4. Interface Architecture

​	TESS NG exposes its core functionalities to users by implementing TessInterface and its three sub-interfaces. Upon launching TESS NG, users can obtain the top-level interface and then access the three sub-interfaces through it to invoke their methods. After loading a plugin, TESS NG can invoke the interface methods implemented by the plugin. Within plugin methods, users can control simulation execution and vehicle driving behavior, traffic signal light states, route vehicle allocation, and more via TessInterface and its sub-interfaces.

​	The overall architecture of the secondary development framework is illustrated in the figure below.

<img src="http://129.211.28.237:5566/document/images/0_interface_architecture" alt="Secondary Development Overall Architecture Diagram" style="zoom: 50%;" />



## 1.5. Update Log

**【 2025-01-21 】**

- The TESS NG kernel has been upgraded from V3.1 to V4.0; the secondary development version supports the core functionalities of the V4.0 Professional Edition.

- [New] ISignalPlan Traffic Signal Control Scheme Interface, supporting multi-period signal control schemes, replacing the original ISignalGroup interface.

- [New] ISignalLamp Traffic Signal Light Interface, supporting the creation of traffic signal lights and their association with traffic signal controllers.

- [New] ICrosswalkSignalLamp Pedestrian Signal Light Interface, supporting the creation of pedestrian signal lights and their association with traffic signal controllers.

- [New] IRoadWorkZone Lane Occupancy Construction Interface, supporting the creation of construction zones.

- [New] IAccIDentZone Accident Zone interface upgrade, including IAccIDentZoneInterval for accident time intervals, enabling the creation of Accident Zones with multiple periods and distinct parameters.

- [New] ILimitedZone Restricted Zone, which constitutes part of the lane borrowing construction; it may not be used directly, but users can also employ it to define custom restriction-type areas.

- [New] IReconstruction Lane borrowing construction (modification and expansion), supporting fine-grained generation and control of modified and expanded road networks.

- [New] IReduceSpeedArea newly introduced Speed Limit Zone interface, supporting lane speed limits by time intervals through IReduceSpeedInterval and by vehicle types through IReduceSpeedVehiType.

- [New] Added a series of Toll Station interfaces, including toll lanes ITollLane, toll decision points ITollDecisionPoint, toll routes ITollRouting, and toll station stopping points ITollPoint.

- [New] Parking-related interfaces, including parking stall interface IParkingStall, parking region interface IParkingRegion, parking decision point interface IParkingDecisionPoint, and parking routing interface IParkingRouting.

- [New] Junction construction and route reconstruction interface IJunction, featuring automatic calculation of junction flow direction and input observation data for route reconstruction.

- [New] Pedestrian domain interfaces include: pedestrian base domain IPedestrian, obstacle domain IObstacleRegion, passenger boarding and alighting domain IPassengerRegion, and elliptical domain. IPedestrianEllipseRegion, fan-shaped domain IPedestrianFanShapeRegion, polygonal domain IPedestrianPolygonRegion, rectangular domain IPedestrianRectRegion, and triangular domain IPedestrianTriangleRegion.

- [New] IPedestrianSIDeWalkRegion interface for pedestrian sidewalk areas.

- [New] IPedestrianCrossWalkRegion interface for pedestrian crosswalks (zebra crossings).

- [New] IPedestrianStairRegion interface for pedestrian stair areas.

- [New] ICrosswalkSignalLamp interface for pedestrian crosswalk traffic signal lights.

- [New] A series of pedestrian path interfaces, including IPedestrianPath for pedestrian routes and IPedestrianPathPoint for pedestrian path waypoints.

- [New] Added CRUD operations for IJunction node objects under the NetInterface class; added CRUD for pedestrian areas and paths; added CRUD for Accident Zone, Construction Zone, Reconstruction and Expansion, Speed Limit Zone, Traffic Signal Lights, Traffic Signal Controllers, signal control schemes, and star-phase groups; added CRUD for parking lots and Toll Stations.

- [Added] New interfaces under the SimuInterface class to retrieve pedestrian status and moving pedestrian information, as well as a single-step simulation interface.

- [Optimized] Standardized interface units: the V3 series defaults to pixel units, while V4 commonly adopts metric units for speed, length, and related measurements. A unitOfMeasure parameter has been added to explicitly specify unit types, thereby eliminating cumbersome m2p and p2m conversions.

  

**【 2025-09-30 】**

- [Added] Interfaces to set vehicle safety time interval and stopping distance: setSafeTimeInterval and setStoppingDistance.
- [Added] Interfaces to read and set whether to output Traffic Signal Light head data: isRecordSignalLampStatus and setIsRecordSignalLampStatus.
- [Removed] Deprecated plugin functions related to lane changing: reSetChangeLaneFreelyParam and isPassbyEventZone.

<div style="page-break-after: always;"></div>

# 2. Quick Start

​	This section provides a quick start guide. By means of installation and execution, example explanations, and important notes, readers can quickly grasp how to build and run TESS NG's C++ API examples in a local environment. These materials lay a practical foundation for subsequent plugin development and interface invocation, enabling developers to first complete the overall workflow and then progressively deepen their functional extensions.



## 2.1. Installation and Execution (Windows)

#### <span style="color: green;">Step 1: Download the Sample Code Package</span>

1. Download the latest version of TESS NG from the [Jida Traffic Official Website](https://www.jidatraffic.com/#/simulation) ;

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_01" alt="Figure 1" style="zoom: 60%;" />

2. Upon completion of installation, the C++ sample code package named **`TESS_CppAPI_EXAMPLE`** can be located within the **`SecondDev`** folder in the software directory.

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_02" alt="Figure 2" style="zoom: 60%;" />

#### <span style="color: green;">Step 2: Configure the Development Environment</span>

1. **Install Qt**:

   - Access the [Qt official download page](https://download.qt.io/archive/qt/5.12/5.12.2/) and download the Qt 5.12.x installer, specifically the `qt-opensource-windows-x86-5.12.2.exe` file;
   - Double-click the downloaded `qt-opensource-windows-x86-5.12.2.exe` to initiate the installation wizard;
   - Click “Next” to proceed to the Qt account login interface, enter your Qt account username and password (register if you do not have an account), and then click “Next”.
   - Follow the installation wizard by clicking “Next” consecutively; you may choose a custom installation directory as needed. Ensure that the “MSVC 2017 64-bit” component is checked, then wait until the installation process completes.

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_03" alt="Figure 3" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_04" alt="Figure 4" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_05" alt="Figure 5" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_06" alt="Figure 6" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_07" alt="Figure 7" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_08" alt="Figure 8" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_09" alt="Figure 9" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_10" alt="Figure 10" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_11" alt="Figure 11" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_12" alt="Figure 12" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_13" alt="Figure 13" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_14" alt="Figure 14" style="zoom: 60%;" />

2. **Configure Environment Variables**:

   - After installation, manually add the Qt `bin` directory to the system environment variable `Path` (sample path: `D:/Qt/5.12.2/msvc2019_64/bin`).

3. **Verify Installation Results**:

   - After configuration, press `Win + R`, type `cmd` to open the system terminal;
   - Run the command `qmake -v`. If the output shows version information such as `QMake version 3.1` and `Using Qt version 5.15.2 in D:/Qt/5.15.2/msvc2019_64/lib`, it indicates that the installation and configuration were successful.

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_15" alt="Figure 15" style="zoom: 60%;" />


#### <span style="color: green;">Step 3: Select and Configure the IDE</span>

- It is recommended to use **Visual Studio** or **Visual Studio Code (VS Code)**. If using Visual Studio, the procedure is as follows:

1. **Install Visual Studio:**

   - Visit the [Visual Studio Official Website](https://visualstudio.microsoft.com/zh-hans/downloads/) to download the installer for Windows (recommended version is 2017 or later) ;
   - Double-click the downloaded `VisualStudioSetup.exe` file to launch the installer;
   - Wait for the installer to load and prepare, then proceed to the 'Workloads' selection screen. **Be sure to select the 'Desktop development with C++' workload** (this workload includes the core toolchains necessary for compiling C++ projects, such as the MSVC compiler and CMake). Other non-essential components can be left unchecked to save installation space. You may also customize the installation path as needed;
   - Click the 'Install' button and wait for the installation progress to complete.
   
   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_16" alt="Figure 16" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_17" alt="Figure 17" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_18" alt="Figure 18" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_19" alt="Figure 19" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_20" alt="Figure 20" style="zoom: 60%;" />

#### <span style="color: green;">Step 4: Run the Sample Project</span>

1. **Startup Code:**
   
   - Launch Visual Studio; optionally sign in with a Microsoft or GitHub account, or select 'Skip and add account later.'
   - On the 'Get Started' page, click 'Open a local folder,' then select and open the `TESS_CppAPI_EXAMPLE` folder (or via the top menu bar, navigate to 'File > Open > CMake,' locate the `TESS_CppAPI_EXAMPLE` project folder, and open the **`CMakeLists.txt`** file as a 'CMake Project').
   - In the right (or possibly left) 'Solution Explorer - Folder View,' right-click the **`CMakeLists.txt`** file, select 'Set as Startup Item,' and confirm that the startup item in the toolbar above has switched to `CMakeLists.txt`.
   - Click the “Run” button on the toolbar above (green triangle icon), or press the shortcut key `F5` to launch the program in Debug mode.
   
   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_21" alt="Figure 21" style="zoom: 60%;" />
   
    <img src="http://129.211.28.237:5566/document/images/cpp_2_1_22" alt="Figure 22" style="zoom: 60%;" />
   
    <img src="http://129.211.28.237:5566/document/images/cpp_2_1_23" alt="Figure 23" style="zoom: 60%;" />
   
    <img src="http://129.211.28.237:5566/document/images/cpp_2_1_24" alt="Figure 24" style="zoom: 60%;" />
   
    <img src="http://129.211.28.237:5566/document/images/cpp_2_1_25" alt="Figure 25" style="zoom: 60%;" />
   
2. **Software Activation**:
   - Upon first launch, the TESS NG software activation window will appear; follow the prompts to complete activation (a valid license is required).
   - After successful activation, close the popup, then click the 'Run' button again to launch the example project normally.

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_26" alt="Figure 26" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_27" alt="Figure 27" style="zoom: 60%;" />



## 2.2. Example Explanation

#### <span style="color: dodgerblue;">Note 1: Directory Structure and Description</span>

​	`TESS_CppAPI_EXAMPLE` adheres to the standard engineering structure of C++ projects, separating directories for compiled output, header files, source files, and libraries, and supports multiple build configurations (Debug/Release). The descriptions of each directory and file are as follows:

- **bin**: Root directory for compiled artifacts (executables), categorized by build configuration
  - **Debug**: Output directory for executables in Debug build configuration (includes debug information, intended for development and debugging phases)
  - **Release**: Output directory for executables in Release build configuration (without debug information, smaller size, and higher runtime efficiency, intended for formal deployment)
- **build**: Root directory for compilation process files (such as intermediate object files, CMake cache files, etc.), categorized by build configuration
  - **Debug**: Directory for intermediate compilation files in Debug mode (such as `.obj`, `.pdb`, etc.; not used directly during runtime, only compilation artifacts)
  - **Release**: Directory for intermediate compilation files in Release mode, functionally equivalent to the Debug subdirectory, tailored for the Release build process.

- **include**: Centralized directory for project header files (`.h`), containing interface declarations for custom plugins and core modules, available for source file inclusion.
- **lib**: Root directory for dependency libraries, separated by build configuration into Debug and Release versions.
  - **Debug**: Dependency library files (e.g., `.lib`) for Debug mode, used in compiling and linking the Debug build of the project.
  - **Release**: Dependency library files for Release mode, used in compiling and linking the Release build of the project.

- **src**：项目源文件（`.cpp`/`.h`）存放目录，按功能模块拆分文件。
  - **main.cpp**: Project main entry source file, responsible for initializing the TESS NG instance and launching the application.
  - **MyPlugin.h / MyPlugin.cpp**: Header and source files for a custom plugin, responsible for plugin initialization.
  - **MyNet.h / MyNet.cpp**: Header and source files for the custom road network plugin, enabling custom operations before and after road network loading, as well as control over the rendering of road network elements.
  - **MySimulator.h / MySimulator.cpp**: Header and source files for the custom simulation plugin, permitting custom operations before, during, and after simulation; supporting both global control of simulation start-stop logic and fine-grained intervention in individual vehicle driving behavior.
  - **MyGUI.h / MyGUI.cpp / MyGUI.ui**: Header, source, and UI design files for the custom interface plugin, used to extend the TESS NG interactive interface (e.g., adding new buttons, dialogs, data display panels, etc.).

- **CMakeLists.txt**: C++ project build configuration file defining compilation rules (such as source file paths, dependency references, and compilation mode parameters); supports cross-platform compilation and serves as the core configuration file recognized by IDEs (e.g., Visual Studio).

#### <span style="color: dodgerblue;">Note 2: Plugin Registration Mechanism and Simulation Control Logic</span>

Many TESS NG beginners often wonder: how is the custom plugin code they write invoked by TESS NG? By examining the implementation logic in the project's main entry file `main.cpp`, this process can be clearly understood. At the same time, it is essential to clarify the core development approach for the simulation scenario, detailed as follows:

1. First, address the core question: **How is custom code invoked by TESS NG?** The key lies in the line `gpTessInterface->loadPluginFromMem(pPlugin)` within `main.cpp`. This acts as the “bridge” connecting user-defined plugins with the TESS NG simulation core. The `loadPluginFromMem` method of `gpTessInterface` (the interface provided by TESS NG) registers the user-created custom plugin instance—created via `auto *pPlugin = new MyPlugin()`, where `MyPlugin` is the user-implemented plugin class encapsulating all custom logic—into the simulation core through the underlying TESS NG interface. After registration, TESS NG automatically invokes user-overridden hook methods in `MyPlugin` and its sub-plugins `MyNet` and `MySimulator` at critical simulation nodes (such as simulation start, each simulation step advancement, and simulation end) without requiring manual invocation code, thereby enabling functional extension.
2. To clarify the core concept of simulation scenario development: beginners often fall into the misconception of “how to embed TESS NG simulation into their own computational code.” The correct approach is to “**embed custom computational code into the TESS NG simulation workflow**.”TESS NG provides a mature simulation framework (including foundational capabilities such as road network loading, simulation advancement, and interface interaction), where the central role of `main.cpp` is to “configure and launch this framework.”Users do not need to construct the simulation framework themselves; it suffices to encapsulate their computational code (such as custom vehicle behavior, data collection, special scenario trigger logic, etc.) within the designated methods of `MyPlugin` and its sub-plugins `MyNet` and `MySimulator` (for example, the per-step simulation trigger method `afterOneStep` or the simulation start trigger method `afterStart` provided by TESS NG). Once `gpTessInterface->loadPluginFromMem` completes the plugin registration, these logics will be automatically integrated into the simulation workflow by TESS NG and executed accordingly during the simulation.

The main entry source file is main.cpp, as shown below:

```cpp
#include "MyPlugin.h"

#include <QtWidgets/QApplication>
#include <QMainWindow>
#include <QTextCodec>
#include <QLibrary>

int main(int argc, char *argv[])
{
	// Create Qt application instance
	QApplication a(argc, argv);
	QMainWindow *pWindow = tessng();
	if (pWindow)
	{
		// Create custom plugin class instance
		auto *pPlugin = new MyPlugin();
		pPlugin->init();
		// Load plugin
		gpTessInterface->loadPluginFromMem(pPlugin);

		// Display window and run event loop
		pWindow->showMaximized();
		int result = a.exec();

		// Clean up resources
		pWindow->deleteLater();
		return result;
	}
	return 0;
}
```

#### <span style="color: dodgerblue;">Note 3: Modifying the Road Network at Startup</span>

In the directory at the same level as `TESSNG.exe` (distinguishing between paths corresponding to Debug and Release modes), create a new text file named `config.json`, and add the following two configuration properties:

- `"__netfilepath"`: Specifies the default Road Network file path to be loaded when TESS NG starts;

- `"__simuafterload"`: Specifies whether to immediately start the simulation after loading the Road Network file in TESS NG.

  For example:


```json
{
	"__netfilepath": "C:/TESSNG_4.1.0/Examles/杭州武林门区域路网公交优先方案.tess",	
	"__simuafterload": true
}
```

#### <span style="color: dodgerblue;">Note 4: Addition, Deletion, Query, and Modification of Road Network Elements and Their Properties</span>

Via the `netiface` interface, it is possible to **add, delete, query, and modify** Road Network Elements (such as Road Segments, Connection Segments, etc.). Additionally, once Road Network Element objects are obtained, their properties can be **queried** and **modified**.

- The following example demonstrates CRUD operations on road network elements (via the `netiface` interface).

```cpp
// 1. Query all links: Get a list of all links in the current network
QList<ILink*> links = netiface->links();

// 2. Query specific link by ID: Get the link with ID 1 (returns nullptr if it doesn't exist)
ILink* link = netiface->findLink(1);

// 3. Add new link: Create and return a new link object by passing vertex coordinates (linkPoints), lane count (7), and link name ("Cao'an Highway")
QList<QPointF> linkPoints = {QPointF(-300, 0), QPointF(300, 0)};
ILink* link1 = netiface->createLink(linkPoints, 7, "Cao'an Highway", true, UnitOfMeasure::Metric);

// 4. Delete link: Remove the specified link object (link1) from the network
netiface->removeLink(link1);
```

- The following example demonstrates querying and modifying attributes of road network elements (via element objects).


```cpp
// 1. Attribute query: Get related attributes of link1
int laneCount = link1->laneCount();  // Query the number of lanes in the link (returns integer, e.g., 3)
qreal laneLength = link1->length();  // Query the length of the link (returns floating-point number, unit: m)

// 2. Attribute modification: Modify the name and speed limit of link1
link1->setName("曹安公路");  // Set the link name to "Cao'an Highway"
link1->setLimitSpeed(80);  // Set the link speed limit to 80 km/h
```

#### <span style="color: dodgerblue;">Note 5: Custom Operations Before and After Road Network Loading</span>

​	In the custom road network plugin (class `MyNet`), overriding the `beforeLoadNet` and `afterLoadNet` methods enables **pre-processing before road network loading** and **post-processing after road network loading**.

- The following example demonstrates: after the road network has been loaded, first check whether the road network currently contains any road segments; If none exist, invoke the custom method `createNetwork()` to create the basic road network (including road segments, connection segments, departure points, etc.).

```cpp
// MyNet.cpp: Implementation file for the custom road network plugin
void MyNet::afterLoadNet()
{
    // 1. Query the total number of links in the current road network
    int linkCount = netiface->linkCount();

    // 2. If there are no links in the road network (linkCount == 0), execute the custom road network creation logic
    if (linkCount == 0)
    {
        // Custom method: Internal implementation logic for creating links, connectors, and origin points
        createNetwork();
    }
}
```

#### <span style="color: dodgerblue;">Note 6: Display Control of Road Network Elements</span>

​	In the custom road network plugin (class `MyNet`), refined control over the labeling of road network elements (such as Road Segments and Connection segments) can be implemented by overriding the `labelNameAndFont` method—including customization of label content (display name / ID / no display) and font size—to satisfy diverse visualization requirements in different scenarios.

- The following example: the label of the Road Segment named “Cao'an Highway” shows the Road Segment Name; other Road Segment labels display their IDs; Connection segment labels all display the name.

```cpp
// MyNet.cpp: Implementation file for the custom road network plugin
void MyNet::labelNameAndFont(int itemType, long itemId, int &outPropName, qreal &outFontSize)
{
    // 1. When simulation is running, do not draw labels for links/lanes to avoid interfering with simulation observation
    if (!simuiface->isRunning())
    {
        outPropName = GraphicsItemPropName::None;  // Do not display any labels
        return;  // Directly return, no need to execute subsequent logic
    }

    // 2. Default configuration: labels display element ID, font size 6 meters
    outPropName = GraphicsItemPropName::Id;
    outFontSize = 6;

    // 3. Special configuration for connectors: display names for all (regardless of ID, uniformly identified by name)
    if (itemType == NetItemType::GConnectorType)
    {
        outPropName = GraphicsItemPropName::Name;
    }
    // 4. Special configuration for links: display names only for IDs 1/5/6, others display ID
    else if (itemType == NetItemType::GLinkType)
    {
        if (itemId == 1 || itemId == 5 || itemId == 6)
        {
            outPropName = GraphicsItemPropName::Name;
        }
    }
}
```

#### <span style="color: dodgerblue;">Note 7: Querying and Modifying Simulation Information</span>

​	The `simuiface` interface provides querying and modification capabilities for **core simulation parameters**, including simulation duration, precision, acceleration factor, and more.

```cpp
// 1. Simulation information query: Retrieve key parameters of the current simulation
long simuInterval = simuiface->simuIntervalScheming();  // Query the preset total simulation duration (unit: s)
int simuAccuracy = simuiface->simuAccuracy();  // Query simulation accuracy
int simuMultiples = simuiface->acceMultiples();  // Query simulation speed multiplier
long simuTime = simuiface->simuTimeIntervalWithAcceMutiples();  // Query the current simulated time (unit: ms)

// 2. Simulation information modification: Set key parameters of the simulation
simuiface->setSimuIntervalScheming(3600);  // Set total simulation duration to 3600 seconds
simuiface->setSimuAccuracy(1);  // Set simulation accuracy to 1
simuiface->setAcceMultiples(5);  // Set simulation speed multiplier to 5
```

#### <span style="color: dodgerblue;">Note 8: Addition, Deletion, Query, and Attribute Operations of Simulation Vehicles</span>	

​	Addition, deletion, and querying of **simulation vehicles** can be performed via the `simuiface` interface. It also supports obtaining vehicle objects to query all their attributes and modify **static attributes** (attributes that do not change dynamically during the simulation, such as length and maximum speed).

- The following example demonstrates: Addition, deletion, query, and modification of simulation vehicles (through the `simuiface` interface).

```cpp
// 1. Query vehicles: Retrieve a list of vehicles within a specified scope
QList<IVehicle*> allVehicles = simuiface->allVehiStarted();  // Get all currently started vehicles
QList<IVehicle*> linkVehicles = simuiface->vehisInLink(1);  // Get vehicles currently traveling on the link with ID 1

// 2. Add vehicles: Dynamically create vehicles on a specified link (requires configuring vehicle parameters DynaVehiParam first)
Online::DynaVehiParam dvp;  // Vehicle dynamic parameter object
dvp.vehiTypeCode = qrand() % 4 + 1;  // Randomly set vehicle type code (1-4, corresponding to different vehicle types)
dvp.roadId = 6;  // Specify the initial link ID where the vehicle is located (here it's 6)
dvp.laneNumber = qrand() % 3;  // Randomly set initial lane number (0-2, corresponding to lanes 1-3 of the link)
dvp.dist = 50;  // Initial distance of the vehicle on the link (50m from the start of the link)
dvp.speed = 20;  // Initial speed of the vehicle (unit: m/s)
dvp.color = "#00AFF0";  // Vehicle display color
// Call the interface to create the vehicle, returns the new vehicle object (or nullptr if creation fails)
IVehicle* vehicle1 = simuiface->createGVehicle(dvp);
// Check if the vehicle was created successfully
if (vehicle1 != nullptr)
{
    qDebug() << "Vehicle created on the link, vehicle ID:" << vehicle1->id();
}

// 3. Remove vehicles: Stop the specified vehicle (vehicle1) from driving and remove it from the simulation
simuiface->stopVehicleDriving(vehicle1);
```

- The following example demonstrates: Querying and static modification of vehicle attributes (through vehicle objects).


```cpp
// 1. Attribute query: Retrieve relevant attributes of the vehicle (vehicle)
QString roadName = vehicle->roadName();  // Name of the link or connector where the vehicle is located
qreal speed = vehicle->currSpeed();  // Get the current speed of the vehicle (unit: m/s)

// 2. Attribute modification: Adjust the length and speed limit of the vehicle (vehicle)
vehicle->setLength(5);  // Modify the vehicle's length (unit: m)
vehicle->setMaxSpeed(80/3.6);  // Modify the vehicle's maximum speed (unit: m/s)
```

#### <span style="color: dodgerblue;">Note 9: Dynamic Attribute Modification of Simulation Vehicles</span>

The **dynamic attributes** of vehicles (e.g., real-time speed, acceleration, which vary dynamically during the simulation process) cannot be directly modified through the vehicle object. They must be overridden in specific object methods within a **custom simulation plugin (`MySimulator` class)**—in essence, correcting or overriding the dynamic values computed in real-time by TESS NG.

- The following example illustrates: inside the `reSetSpeed` method, based on vehicle ID and the current road segment, forcibly assigning the real-time speed of certain vehicles (making vehicles with IDs 2 through N follow the speed of vehicle ID 1).

```cpp
// MySimulator.cpp: Implementation file for the custom simulation plugin
bool MySimulator::reSetSpeed(IVehicle *pIVehicle, qreal &inOutSpeed)
{
    // 1. Process vehicle ID (use modulo to avoid excessively long IDs, keeping only the last 5 digits)
    long tmpVehicleId = pIVehicle->id() % 100000;

    // 2. Get the name of the current link where the vehicle is located
    QString roadName = pIVehicle->roadName();

    // 3. Only perform speed control logic for vehicles on "Cao'an Highway"
    if (roadName == "曹安公路")
    {
        // For vehicle with ID=1: record its current speed (as the reference speed)
        if (tmpVehicleId == 1)
        {
            planeSpeed = pIVehicle->currSpeed();
        }
        // For vehicles with IDs 2 to squareVehiCount: enforce their speed to match the reference speed
        else if (tmpVehicleId >= 2 && tmpVehicleId <= squareVehiCount)
        {
            // Override the speed value calculated by TESS NG
            inOutSpeed = planeSpeed;
            // Return true to indicate the speed modification is effective
            return true;
        }
    }
    // Return false to indicate no speed modification, using TESS NG's default calculated value
    return false;
}
```

#### <span style="color: dodgerblue;">Note 10: Custom operations at specific simulation timings</span>

​	In custom simulation plugins (the `MySimulator` class), specific methods provided by TESS NG can be overridden to **trigger custom logic at different simulation nodes**: supporting execution at **global simulation timings** (e.g., before simulation start, after simulation end) as well as at **vehicle-specific behavioral timings** (e.g., vehicle creation, vehicle removal, before vehicle lane change), thus meeting the requirements of fine-grained simulation customization.

- By overriding the `beforeStart` (before simulation start) and `afterStop` (after simulation end) methods, global simulation pre-processing and post-processing can be achieved, such as initializing simulation parameters, restarting simulations in a loop, and exporting simulation results. The following example demonstrates: after the simulation ends, check if the cumulative simulation count is ≤ 3; if this condition is met, the simulation will automatically restart (achieving looped simulation).

```cpp
// MySimulator.cpp: Implementation file for the custom simulation plugin
void MySimulator::afterStop()
{
    // 1. simuCount is a custom variable used to accumulate the total number of simulations
    if (simuCount <= 3)
    {
        // 2. Call the interface to restart the simulation
        simuiface->startSimu();
    }
}
```

- By overriding methods bound to Vehicle behavior, logic can be triggered when a Vehicle meets specific conditions, such as initializing attributes upon Vehicle creation or recording data upon Vehicle removal. The following example demonstrates: after a simulation Vehicle is created, set the Vehicle’s type, position, and length according to its Vehicle ID.

```cpp
// MySimulator.cpp: Implementation file for the custom simulation plugin
void MySimulator::initVehicle(IVehicle *pIVehicle)
{
    // 1. Retrieve basic information of the current vehicle (name and ID of the current link/connector)
    QString roadName = pIVehicle->roadName();  // Name of the link/connector where the vehicle is currently located
    long roadId = pIVehicle->roadId();  // ID of the link/connector where the vehicle is currently located

    // 2. Only perform special customization logic for vehicles on "Cao'an Highway"
    if (roadName == "曹安公路")
    {
        // Process vehicle ID: Use modulo 100000 to remove the first digit (which usually indicates the vehicle's origin, such as departure point or bus route)
        long tmpVehicleId = pIVehicle->id() % 100000;

        // 3. For specific vehicle IDs, set dedicated vehicle types and initial positions
        if (tmpVehicleId == 1)
        {
            // Set vehicle with ID=1 to "Vehicle Type 12"
            pIVehicle->setVehiType(12);
            // Initialize the vehicle's initial lane, position, and speed
            pIVehicle->initLane(3, m2p(105), 0);
        }
        // Additional customization logic for other vehicle IDs (e.g., tmpVehicleId=2, 3, etc.) can be added here

        // 4. For vehicles with IDs 23~28, set a specific length
        if (tmpVehicleId >= 23 && tmpVehicleId <= 28)
        {
            pIVehicle->setLength(m2p(4.5), true);
        }
    }
}
```

<div style="page-break-after: always;"></div>

# 3. Interface Details

This section first introduces the **Global Configuration Parameters (config.json)**, then sequentially presents the contents of **Plugins (Plugin)**, **Interfaces (Interface)**, and **Objects (Object)**, to help readers progressively understand the TESS NG secondary development model from an overall perspective down to details.



## 3.1 Global Configuration Parameters

The global configuration parameters recognized by TESS NG in config.json are as follows: 

```json
{
	"__netfilepath": "xxx.tess", 		
	"__simuafterload": false, 
	"__timebycpu": false, 
	"__writesimuresult": true, 
	"__custsimubysteps": false,
    "__allowspopup": false
}
```

**__netfilepath**

Specifies the file path of the Road Network to load upon TESS NG startup; supports absolute or relative paths. If the file does not exist, a blank Road Network will be opened by default.

**__simuafterload**

Specifies whether the simulation automatically starts after loading the Road Network in TESS NG, defaulting to false. 

**__timebycpu**

Specifies the time basis for the simulation cycle calculation: either real elapsed time based on the CPU clock or duration based on simulation precision, defaulting to false. When running online simulations under computational constraints, this attribute can be set to true.

**__writesimuresult**

Controls whether simulation results are output, defaulting to true. If set to false, no result files are written after simulation ends, and during the simulation, vehicles that have exited the Road Network for a period are recycled back to the available queue to reduce memory usage.

**__custsimubysteps**

Set the frequency basis for TESSNG to invoke plugin methods; the default value is false. When set to false, the method is called once per simulation cycle (not according to the plugin’s frequency setting); When set to true, the method invocations will follow the frequency configured within the plugin.

**__allowspopup**

Control whether to allow pop-up prompt windows to avoid blocking program execution; the default is true.



## 3.2. Plugin

Generally, software functionality extension is implemented by defining plugin interfaces that users then implement. TESS NG adopts this approach as well, featuring the top-level plugin interface TessPlugin, along with three sub-plugin interfaces: CustomerNet, CustomerSimulator, and CustomerGui. Unlike the TessInterface interface, which only allows the invocation of interface methods without altering the internal operational logic, users who implement TessPlugin and its sub-interface methods can deeply intervene in the internal runtime of TESS NG, influencing processes such as Road Network Loading, Simulation Process, and window interactions, thereby modifying its operational logic to achieve more advanced functional extensions. All methods of these three sub-plugins provide default implementations; users may selectively implement some or all methods according to their needs.

Due to differences in the invocation scenarios and purposes of plugin interface methods, most methods adopt the following structural pattern for a unified understanding:

```cpp
bool method(type &outParam) 
{
    outParam = 1;
	return true;
}
```

When TESS NG calls these methods, it follows the logic below: **If the return value is false, it is considered that the user did not respond, and the call will be ignored.**If the return value is true, it indicates that the user has responded. Subsequent processing will then be performed using the value of the parameter outParam**. Using the example scenario as a reference: when vehicles queue on Cao'an Highway, it is necessary to reset the speed of the vehicles behind the airplane to match that of the airplane. In this case, the subclass MySimulator of CustomerSimulator can fulfill this requirement by implementing the `reSetSpeed` method.

```cpp
bool MySimulator::reSetSpeed(IVehicle *pIVehicle, qreal &inOutSpeed)
{
	long tmpVehicleId = pIVehicle->id() % 100000;
	QString roadName = pIVehicle->roadName();
	if (roadName == "曹安公路")
	{
		if (tmpVehicleId == 1)
		{
			planeSpeed = pIVehicle->currSpeed();
		}
		else if (tmpVehicleId >= 2 && tmpVehicleId <= squareVehiCount)
		{
			inOutSpeed = planeSpeed;
			return true;
		}
	}
	return false;
}
```

After TESS NG calculates a vehicle's speed, it calls the plugin's reSetSpeed method. If this method returns true, it is considered that the plugin has responded accordingly, and the outSpeed value will replace the originally calculated vehicle speed. The procedure by which TESS NG invokes the plugin's `reSetSpeed` method is as follows:

```cpp
if (gpTessPlugin && gpTessPlugin->customerSimulator())
{
   qreal outSpeed = mrCurrSpeed；
   if (gpTessPlugin->customerSimulator()->reSetSpeed(mpGVehicle，outSpeed))
   {
       mrCurrSpeed = outSpeed；
   }
}
```

### 3.2.1. Top-Level Plugin (TessPlugin)

Header file: Plugin / tessplugin.h

TessPlugin is the top-level plugin interface for user development. It includes three sub-plugin interfaces: CustomerNet, CustomerSimulator, and CustomerGui. Users interact with TESS NG in the domains of road network, simulation process, and GUI window by implementing these three sub-plugins respectively.

**void init()**

Plugin initialization, where subclasses of CustomerNet, CustomerSimulator, and CustomerGui can be instantiated in this method.

**CustomerNet\* customerNet()**

Returns the CustomerNet object.

**CustomerSimulator\* customerSimulator()**

Returns the CustomerSimulator object.

**CustomerGui\* customerGui()**

Returns the CustomerGui object.


### 3.2.2. Road Network Plugin (CustomerNet)

Header file: Plugin / customernet.h	

CustomerNet is a sub-plugin interface of TessPlugin. By implementing this plugin, users can perform custom operations before and after road network loading, control the rendering of road network elements, and define response logic for viewport events.

#### 3.2.2.1. Road Network Loading

**void beforeLoadNet()**

Called before loading the road network; users can utilize this method to perform necessary initialization preparations before the road network is loaded.

**void afterLoadNet()**

Called after the road network has been loaded.

Example:

```cpp
void MyNet::afterLoadNet()
{
    // Get the number of links in the current road network
    int linkCount = netiface->linkCount();
    
    // Check if the road network is empty (no links exist)
    if (linkCount == 0)
    {
        // If the road network is empty, call the custom method to create a basic network
        createNetwork();
    }
}
```

#### 3.2.2.2. Road Network Element Rendering

**bool isPermitForCustDraw()**

Indicates whether client-side rendering is permitted. This method aims to reduce unnecessary code invocations and eliminate adverse effects on runtime performance.

Return value:

Indicates whether to render; true means rendering, false means no rendering. The default is true.

**bool isDrawLinkCenterLine(long linkId)**

Indicates whether to render the centerline of the road segment.

Parameters:

[ in ] linkID: Road Segment ID.

Return value:

Indicates whether to render; true means rendering, false means no rendering. The default is true.

Example:

```cpp
bool MyNet::isDrawLinkCenterLine(long linkId)
{
    // Do not draw centerline for link with ID 1
    return linkId != 1;
}
```

**bool isDrawLinkCorner(long linkId)**

Indicates whether to render circular and square shapes at the four corners of the road segment.

Parameters:

[ in ] linkID: Road Segment ID.

Return value:

Indicates whether to render; true means rendering, false means no rendering. The default is true.

**bool isDrawLaneCenterLine(long laneId)**

Whether to render the lane centerline.

Parameters:

[ in ] laneID: Lane ID.

Return value:

Whether to render; true means render, false means do not render, default is false.

**bool linkType(QList\<QString\> &lType)**

Road Segment type.

Parameters:

[ in ] lType: User-defined list of road segment types.

Return value:

Whether it is user-defined.

**bool laneType(QList\<QString\> &lType)**

Lane type.

Parameters:

[ in ] lType: User-defined list of lane types.

Return value:

Whether it is user-defined.

**bool paint(int itemType，long itemID，QPainter\* painter)**

Render road network element.

Parameters:

[ in ] itemType: Road network element type.

[ in ] itemID: Road network element ID.

[ in ] painter: QPainter object.

Return value:

If true is returned, TESS NG considers the plugin as having rendered the element and will not render it further; otherwise, TESS NG will proceed with rendering.

**bool paintLaneObject(ILaneObject\* pILaneObj，QPainter\* painter)**

Render lane or lane connection.

Parameters:

[ in ] pILaneObj: Lane or lane connection.

[ in ] painter: QPainter object.

Return value:

If true is returned, TESS NG considers the plugin as having rendered the element and will not render it further; otherwise, TESS NG will proceed with rendering.

**bool linkBuildGLanes(ILink\* pILink)**

Create lane.

Parameters:

[ in ] pILink: Road Segment object.

Return value:

If true is returned, TESS NG considers that the plugin has already created the lane, and TESS NG will not create it again.

**bool linkBrushColor(long linkID，QColor& color)**

Road Segment brush color.

Parameters:

[ in ] linkID: Road Segment ID.

[ out ] color: QColor object.

Return value:

True indicates that the road segment is drawn using the specified color.

Example:

```cpp
bool MyNet::linkBrushColor(long linkID, QColor& color)
{
    // Set specified links to red
    QSet<long> targetLinkIds = {1, 2, 3};
    if (targetLinkIds.contains(linkID)) 
    {
        color.setNamedColor("#FF0000");
        return true;
    }
    return false;
}
```

**bool laneBrushAndPen(long laneID，QBrush &brush，QPen &pen)**

Set the brush for drawing the lane by specifying the Lane ID.

Parameters:

[ in ] laneID: Lane ID.

[ out ] brush: QBrush object.

[ out ] pen: QPen object.

Return value:

True indicates that the lane with ID equal to laneID is drawn using the specified brush and pen.

**bool connectorAreaBrushColor(long connAreaID，QColor& color)**

Polygon brush color.

Parameters:

[ in ] connAreaID: Polygon ID.

[ out ] color: Brush color.

Return value:

A value of true indicates that TESSNG uses color to render the polygon area.

**void labelNameAndFont(int itemType，long itemID，GraphicsItemPropName &outPropName，qreal &outFontSize)**

Determines whether to use the ID or the name as the rendering content of the label based on the type and ID of the road network element.

Parameters:

[ in ] itemType: Road Segment element type.

[ in ] itemID: Road network element ID.

[ out ] outPropName: Enumerated value. If GraphicsItemPropName::ID is assigned, the ID is used as the rendering content; if GraphicsItemPropName::Name is assigned, the name of the road network element is used as the rendering content.

[ out ] outFontSize: Font size. Unit: m.

Return value:	

A value of true indicates the label is rendered using either ID or name as determined by the specified outPropName value, and drawn with the specified size.

Example:

```cpp
bool MyNet::labelNameAndFont(int itemType，long itemID，GraphicsItemPropName &outPropName，qreal &outFontSize) 
{
    // If the simulation is running, do not draw labels for links and lanes
	if (simuiface->isRunning())
	{
		outPropName = GraphicsItemPropName::None;
        return;
	}

	// Default to drawing ID
	outPropName = GraphicsItemPropName::Id;
	// Label size is 6m
	outFontSize = 6;

	// If it is a connector, always draw the name
	if (itemType == NetItemType::GConnectorType)
	{
		outPropName = GraphicsItemPropName::Name;
	}
	// If it is a link, determine whether to draw the name based on ID
	else if (itemType == NetItemType::GLinkType)
	{
		if (itemId == 1 || itemId == 5 || itemId == 6)
		{
			outPropName = GraphicsItemPropName::Name;
		}
	}
}
```

#### 3.2.2.3. Viewport Event Handling

**void afterViewMousePressEvent(QMouseEvent\* event)**

Used to implement custom response logic upon mouse click.

Parameters:

[ in ] event: Mouse event object.

Example:

```cpp
void MyNet::afterViewMousePressEvent(QMouseEvent* event)
{
    // Get mouse coordinates
    QPoint mousePos = event->pos();
    // Convert to simulation scene coordinates
    QPointF scenePos = netiface.graphicsView()->mapToScene(mousePos);
    qreal x = scenePos.x();
    qreal y = scenePos.y();
}
```

**void afterViewMouseReleaseEvent(QMouseEvent\* event)**

Used to implement custom response logic upon mouse release.

Parameters:

[ in ] event: Mouse event object.

**void afterViewMouseDoubleClickEvent(QMouseEvent\* event)**

Used to implement custom response logic upon mouse double-click.

Parameters:

[ in ] event: Mouse event object.

**void afterViewMouseMoveEvent(QMouseEvent\* event)**

Used to implement custom response logic upon mouse movement.

Parameters:

[ in ] event: Mouse event object.

**void afterViewWheelEvent(QWheelEvent\* event)**

Used to implement custom response logic upon mouse scroll.

Parameters:

[ in ] event: Mouse wheel event object.

**void afterViewKeyReleaseEvent(QKeyEvent\* event)**

Used to implement custom response logic upon keyboard release.

Parameters:

[ in ] event: Keyboard event object.

**void afterViewResizeEvent(QResizeEvent\* event)**

Used to implement custom response logic upon screen zoom.

Parameters:

[ in ] event: Screen scaling event object.

**void afterViewScrollContentsBy(int dx，int dy)**

Used to implement custom response logic following window scrollbar movements.

Parameters:

[ in ] dx: Horizontal scroll offset; values greater than 0 indicate scrolling to the left. Unit: pixel.

[ in ] dy: Vertical scroll offset; values greater than 0 indicate scrolling upward. Unit: pixel.

### 3.2.3. Simulation Plugin (CustomerSimulator)

Header file: Plugin/customersimulator.h

CustomerSimulator is a TessPlugin sub-plugin interface. By implementing this plugin, users can execute custom operations before, during, and after the simulation process, enabling both global control of simulation start/stop logic and fine-grained intervention in the driving behavior of individual vehicles.

#### 3.2.3.1. Simulation Start and Stop

**void beforeStart(bool &keepOn)**

Used to implement custom operations before starting the simulation. If necessary, the user can abort the simulation by setting keepOn to false.

Parameters:

[ out ] keepOn: whether to continue; default is true.

**void afterStart()**

Used to implement custom operations after starting the simulation.

**void afterStop()**

Used to implement custom operations after ending the simulation.

Example:

```cpp
void MySimulator::afterStop()
{
    // If the number of simulations is less than 3, restart the simulation
	if (simuCount <= 3)
	{
		simuiface->startSimu();
	}
}
```

**void afterOneStep ()**

Used to implement custom operations after completing one simulation frame. At this point, all vehicles have completed the same batch of computations. Typically, vehicle trajectories, detector data, and necessary subtotals are obtained in this method. Calculations performed in this method generally do not affect the consistency of the simulation results; however, efficiency is low, and a large workload may impact simulation performance.

**void duringOneStep()**

This method is invoked during the same batch calculation process across multiple worker threads, where some vehicles have completed their calculations and others are still processing. The computation in this method is not fully thread-safe but provides higher efficiency.

**bool calcSimuConfig(Online::SimuConfig& config)**

Calculate simulation parameters.

Parameters:

[ out ] config: Simulation parameter information.

Return value:

A value of true indicates that simulation parameters are updated using those in config. Once the simulation has started, simulation accuracy and the number of threads cannot be updated; however, simulation duration and acceleration factor can be modified.

#### 3.2.3.2. Vehicle Control

**void initVehicle(IVehicle\* pIVehicle)**

Used to implement custom operations following vehicle creation. Users can initialize the vehicle’s lane number, starting position, and dimensions within this method.

Parameters:

[ in ] pIVehicle: Vehicle Object.

Example:

```cpp
void MySimulator::initVehicle(IVehicle* pIVehicle)
{
	// If it is a car, set it to blue
    if (pIVehicle->vehicleTypeCode() == 1)
    {
        pIVehicle->setColor("#00AFF0");
    }
}
```

**bool isStopDriving(IVehicle\* pIVehicle)**

Used to determine whether to stop the vehicle's operation.

Parameters:

[ in ] pIVehicle: Vehicle Object.

Return value:

A return value of true indicates that the vehicle's operation will be stopped and it will be removed from the road network.

Example:

```cpp
bool MySimulator::isStopDriving(IVehicle* pIVehicle)
{
    // If the vehicle enters link 12, remove it
    if (pIVehicle->roadIsLink() && pIVehicle->roadId() == 12)
    {
        return true;
    }
    return false;
}
```

**void beforeStopVehicle(IVehicle\* pIVehicle)**

Used to implement custom operations prior to vehicle removal.

Parameters:

[ in ] pIVehicle: Vehicle Object. 

**void afterStopVehicle(IVehicle\* pIVehicle)**

Used to implement custom operations following vehicle removal.

Parameters:

[ in ] pIVehicle: Vehicle Object.

**void afterStep (IVehicle\* pIVehicle)**

Used to implement custom operations after the vehicle completes a simulation frame. Vehicle current information can be obtained here, such as current road, position, heading angle, speed, desired speed, and vehicles ahead, behind, left, and right.

Parameters:

[ in ] pIVehicle: Vehicle Object.

**bool calcAcce(IVehicle\* pIVehicle，qreal &acce)**

**bool calcAcce(IVehicle\* pIVehicle，qreal &acce，UnitOfMeasure\* unit)**

Calculate the vehicle's acceleration.

Parameters:

[ in ] pIVehicle: Vehicle Object.

[ out ] acce: Vehicle acceleration. Unit: pixel/s².

Return value:	

If true is returned, acce will be adopted as the current acceleration.

Example:

```cpp
bool MySimulator::calcAcce(IVehicle* pIVehicle, qreal &acce, UnitOfMeasure* unit)
{
    if (pIVehicle->roadName() == "曹安公路")
    {
        // Calculate acceleration directly based on different speeds
        if (pIVehicle->currSpeed() > 20/3.6)
        {
            acce = -3;
            return true;
        }
        else if (pIVehicle->currSpeed() > 10/3.6)
        {
            acce = -1;
            return true;
        }
    }
    return false;
}
```

**bool reSetAcce(IVehicle\* pIVehicle，qreal &inOutAcce)**

**bool reSetAcce(IVehicle\* pIVehicle，qreal &inOutAcce，UnitOfMeasure\* unit)**

Recalculate the vehicle's acceleration.

Parameters:

[ in ] pIVehicle: Vehicle Object.

[ in, out ] inOutAcce: Vehicle acceleration. Unit: pixel/s².

Return value:

If true is returned, inOutAcce will be set as the current acceleration.

Example:

```cpp
bool MySimulator::reSetAcce(IVehicle* pIVehicle, qreal &inOutAcce, UnitOfMeasure* unit)
{
    if (pIVehicle->roadName() == "曹安公路")
    {
        // Adjust the calculated acceleration based on different speed ranges
        if (pIVehicle->currSpeed() > 20/3.6)
        {
            acce += -3;
            return true;
        }
        else if (pIVehicle->currSpeed() > 10/3.6)
        {
            acce += -1;
            return true;
        }
    }
    return false;
}
```

**bool reCalcdesirSpeed(IVehicle\* pIVehicle，qreal &inOutDesirSpeed)**

**bool reCalcdesirSpeed(IVehicle\* pIVehicle，qreal &inOutDesirSpeed，UnitOfMeasure\* unit)**

Recalculate the vehicle's desired speed.

Parameters:

[ in ] pIVehicle: Vehicle Object.

[ in, out ] inOutDesirSpeed: Vehicle desired speed. Unit: pixel/s².

Return value:

If true is returned, inOutDesirSpeed will be set as the desired speed.

**bool calcMaxLimitedSpeed(IVehicle\* pIVehicle，qreal &inOutLimitedSpeed)**

**bool calcMaxLimitedSpeed(IVehicle\* pIVehicle，qreal &inOutLimitedSpeed，UnitOfMeasure\* unit)**

Recalculate the vehicle's current maximum speed limit. Without plugin intervention, when the vehicle speed exceeds the road limit, the vehicle travels at the road's maximum speed limit. Under the intervention of this method, the speed limit can be raised to allow the vehicle to exceed the road speed limit.

Parameters:

[ in ] pIVehicle: Vehicle Object.

[ in, out ] inOutLimitedSpeed: Vehicle maximum speed limit, Unit: pixel/second.

Return value:

If true is returned, inOutLimitedSpeed will be treated as the current Road speed limit.

**bool calcSpeedLimitByLane(ILink\* pILink，int laneNumber，qreal& outSpeed)**

**bool calcSpeedLimitByLane(ILink\* pILink，int laneNumber，qreal& outSpeed，UnitOfMeasure\* unit)**

Speed limit determined by Lane.

Parameters:

[ in ] pILink: Road Segment object.

[ in ] laneNumber: Lane number, with the rightmost lane numbered as 0.

[ in, out ] outSpeed: Vehicle speed limit. Unit: km/h.

Return value:	

If true is returned, outSpeed will be used as the Lane speed limit.

**bool reSetSpeed(IVehicle\* pIVehicle，qreal &inOutSpeed)**

**bool reSetSpeed(IVehicle\* pIVehicle，qreal &inOutSpeed，UnitOfMeasure\* unit)**

Recalculate the Vehicle's speed.

Parameters:

[ in ] pIVehicle: Vehicle Object.

[ in, out ] inOutSpeed: Vehicle speed. Unit: pixel/s.

Return value:

If true is returned, inOutSpeed will be used as the current Vehicle speed.

Example:

```cpp
bool MySimulator::reSetSpeed(IVehicle* pIVehicle, qreal &inOutSpeed, UnitOfMeasure* unit)
{
    if (pIVehicle->id() == 100001)
    {
		// Directly specify the vehicle speed
        inOutSpeed = 80 / 3.6;
        return true;
    }
    return false;
}
```

**bool reCalcAngle(IVehicle\* pIVehicle，qreal &inOutAngle)**

Recalculate the Vehicle's angle. North is 0 degrees, clockwise rotation.

Parameters:

[ in ] pIVehicle: Vehicle Object.

[ in, out ] inOutAngle: Vehicle angle. Unit: degree.

Return value:

If the return value is true, inOutAngle will be considered the vehicle's current angle.


**bool reSetFollowingType(IVehicle\* pIVehicle，int& outTypeValue)**

Reset the vehicle's car-following type.

Parameters:

[ in ] pIVehicle: Vehicle Object.

[ out ] outTypeValue: Car-following type. 0: stopped, 1: normal, 5: emergency deceleration, 6: emergency acceleration, 7: merging, 8: crossing, 9: cooperative deceleration, 10: cooperative acceleration, 11: decelerating while preparing to turn, 12: accelerating while preparing to turn.

Return value:	

If the return value is true, outTypeValue will be considered the vehicle’s car-following type.

**bool reSetFollowingParam(IVehicle\* pIVehicle，qreal &inOutSafeInterval，qreal &inOutSafeDistance)**

**bool reSetFollowingParam(IVehicle\* pIVehicle，qreal &inOutSafeInterval，qreal &inOutSafeDistance，UnitOfMeasure\* unit)**

Reset the vehicle's car-following model safety gap and safety time headway.

Parameters:

[ in ] pIVehicle: Vehicle Object.

[ in, out ] inOutSafeInterval: Safety time headway, unit: seconds.

[ in, out ] inOutSafeDistance: Safe distance, Unit: Pixel.

Return value:

If true is returned, inOutSafeInterval will be used as the vehicle’s safe time headway, and inOutSafeDistance as the vehicle’s safe distance.

**QList\<Online::FollowingModelParam\> reSetFollowingParams()**

Reset the car-following model parameters of vehicles by replacing the currently applied car-following model in the simulation with the obtained car-following model data, affecting all vehicles.

Return value:

Car-following parameter list to reset the car-following parameters for both motorized and non-motorized vehicles. **Once set, these parameters will be continuously applied** until superseded by new parameters.

**bool reSetDistanceFront(IVehicle\* pIVehicle，qreal& distance，qreal& s0)**

**bool reSetDistanceFront(IVehicle\* pIVehicle，qreal& distance，qreal& s0，UnitOfMeasure\* unit)**

Reset the vehicle’s headway and stopping distance.

Parameters:

[ in ] pIVehicle: Vehicle Object.

[ in, out ] distance: The current distance between the vehicle and the preceding vehicle. Unit: Pixel.

[ in, out ] s0: Stopping distance. Unit: Pixel.

Return value:

If true is returned, distance is set as the vehicle’s front vehicle distance, and s0 is set as the vehicle’s stopping distance.

**bool calcChangeLaneSafeDist(IVehicle\* pIVehicle，qreal& dist)**

**bool calcChangeLaneSafeDist(IVehicle\* pIVehicle，qreal& dist，UnitOfMeasure\* unit)**

Calculate the vehicle’s safe lane change distance.

Parameters:

[ in ] pIVehicle: Vehicle instance for which the safe lane change distance is calculated.

[ in, out ] dist: Safe lane change distance. Unit: Pixel.

Return value:

If true is returned, dist is set as the vehicle’s safe lane change distance.

**bool reCalcToLeftLane(IVehicle\* pIVehicle)**

Determine whether a mandatory left lane change is required; this is effective only when TESSNG deems no mandatory left lane change execution is necessary, and cannot override TESSNG’s control over the vehicle’s mandatory left lane change.

Parameters:

[ in ] pIVehicle: Vehicle Object.

Return value:

If true is returned, the vehicle is controlled to perform a forced lane change to the left.

**bool reCalcToRightLane(IVehicle\* pIVehicle)**

Determines whether to perform a forced lane change to the right; this is effective only when TESSNG determines that a forced lane change to the right is unnecessary and cannot prevent TESSNG from enforcing a forced lane change to the right.

Parameters:

[ in ] pIVehicle: Vehicle Object.

Return value:

If true is returned, the vehicle is controlled to perform a forced lane change to the right.

**void beforeToLeftFreely(IVehicle\* pIVehicle，bool &bKeepOn)**

Pre-processing before TESSNG calculates whether to perform a free lane change to the left.

Parameters:

[ in ] pIVehicle: Vehicle Object.

[ in, out ] bKeepOn: whether to continue; if set to false, TESSNG will no longer compute whether the vehicle can perform a free lane change to the left.

**void beforeToRightFreely(IVehicle\* pIVehicle，bool& bKeepOn)**

Pre-processing before TESSNG calculates whether to perform a free lane change to the right.

[ in ] pIVehicle: Vehicle Object.

[ in, out ] bKeepOn: whether to continue; if set to false, TESSNG will no longer compute whether the vehicle can perform a free lane change to the right.

**bool reCalcToLeftFreely(IVehicle\* pIVehicle)**

Recalculate whether the Vehicle needs to perform a free left lane change; this only takes effect when TESSNG determines that performing a free left lane change is unnecessary, and it cannot override TESSNG’s control of the Vehicle’s free left lane change.

Parameters:

[ in ] pIVehicle: Vehicle Object.

Return value:

If true is returned, the Vehicle will be controlled to execute a free left lane change.

**bool reCalcToRightFreely(IVehicle\* pIVehicle)**

Recalculate whether the Vehicle needs to perform a free right lane change; this only takes effect when TESSNG determines that performing a free right lane change is unnecessary, and it cannot override TESSNG’s control of the Vehicle’s free right lane change.

Parameters:

[ in ] pIVehicle: Vehicle Object.

Return value:

If true is returned, the Vehicle will be controlled to execute a free right lane change.

**bool reCalcDismissChangeLane(IVehicle\* pIVehicle)**

Recalculate whether the Vehicle should cancel the lane change.

Parameters:

[ in ] pIVehicle: Vehicle Object.

Return value:

If true is returned, and the current lane change progress does not exceed one third, the current lane change action will be canceled.

Example:

```cpp
bool MySimulator::reCalcDismissChangeLane(IVehicle* pIVehicle)
{
	// When the distance to the end of the link is less than 50m, cancel all free lane changes to achieve the effect of prohibiting free lane changes
    if (pIVehicle->vehicleDriving()->distToEndpoint(true, true, UnitOfMeasure::Metric) < 50)
    {
        return true;
    }
    return false;
}
```

**QList\<int\> calcLimitedLaneNumber(IVehicle\* pIVehicle)**

Calculate restricted lane numbers: such as controlled, hazardous, etc., with the rightmost lane numbered 0.

Parameters:

[ in ] pVehicle: Vehicle object.

Return value:

Sequence of lane numbers representing lanes that the vehicle is not permitted to enter.

Example:

```cpp
QList<int> MySimulator::calcLimitedLaneNumber(IVehicle* pIVehicle)
{
// If the vehicle is on a link and its length is greater than 8m, prohibit it from entering the innermost lane
    if (pIVehicle->roadIsLink() && (pIVehicle->length(UnitOfMeasure::Metric) > 8)) 
    {
        int limitLaneNumber = pIVehicle->lane()->link()->laneCount();
        return QList<int>() << limitLaneNumber;
    }
    return QList<int>();
}
```

**QList\<ILaneConnector\*\> candIDateLaneConnectors(IVehicle\* pIVehicle，QList\<ILaneConnector\*\> lInLC)**

Calculate the subsequent reachable lane connections after the vehicle leaves the road segment. The user may filter or recompute from the sequence of accessible lane connections. This step is ignored if the vehicle has a predefined path.

Parameters:

[ in ] pVehicle: Vehicle object.

[ in ] lInLC: All lane connections reachable from the current lane that have been computed.

Return value:

Sequence of subsequently reachable lane connections.

**ILaneConnector\* candIDateLaneConnector(IVehicle\* pIVehicle，ILaneConnector\* pCurrLaneConnector)**

Calculate the lane connection that the vehicle will take next; at this moment, the vehicle is crossing out of the current road segment and will enter pCurrLaneConnector. This method can alter the subsequent lane connection. If the returned lane connection is null, TESSNG will disregard this method call. If the returned lane connection is not on the original path, or if this method assigns a new path that does not include the returned lane connection, TESSNG will set the path to null after invoking this method.

Parameters:

[ in ] pVehicle: Vehicle object.

[ in ] pCurrLaneConnector: The currently computed lane connection for the current lane.

Return value:

The lane connection to be reset.

**void beforeNextPoint(IVehicle\* pIVehicle，bool &keepOn)**

Operation performed before calculating the vehicle’s movement to the next point. Users can utilize this method to instruct TESSNG to forgo the computation of the specified vehicle’s movement to the next point.

Parameters:

[ in ] pIVehicle: Vehicle Object.

[ out ] keepOn: Whether to continue. If keepOn is assigned false, TESSNG abandons the calculation for the movement to the next point but does not remove the vehicle from the road network.

**void beforeMergingToLane(IVehicle\* pIVehicle，bool &keepOn)**

The computation before the merging lane in a lane connection allows TESS NG to bypass the merging calculation, thereby enabling users to implement their own merging logic.

Parameters:

[ in ] pIVehicle: Vehicle Object.

[ out ] keepOn: Indicates whether to bypass; if keepOn is set to false, TESS NG cancels the merging.

**void beforeNextRoad(IVehicle\* pIVehicle，QGraphicsItem\*& pRoad，bool& keepOn)**

Processing before calculating the subsequent road.

Parameters:

[ in ] pIVehicle: Vehicle Object.

[ in ] pRoad: Parameter currently unused.

[ in, out ] keepOn: Indicates whether to continue calculation; if keepOn is set to false, TESS NG will not process subsequent roads.

**void afterCalcTracingType(IVehicle\* pIVehicle)**

Processing after car-following type calculation.

Parameters:

[ in ] pIVehicle: Vehicle Object.

**void busArriving(IVehicle\* pIVehicle，IBusStationLine\* pStationLine，int alightingCount，int alightingTime，int boardingCount，int boardingTime)**

Processing after bus arrival at the station.

Parameters:

[ in ] pIVehicle: Vehicle Object.

[ in ] pStationLine: Station line.

[ in ] alightingCount: Number of passengers alighting. Unit: persons.

[ in ] alightingTime: Total time required for alighting. Unit: s.

[ in ] boardingCount: Number of boarding passengers. Unit: person.

[ in ] boardingTime: Total time required for boarding. Unit: s.

**void leaveForNextLaneObj(IVehicle\* pIVehicle, ILaneObject\* pCurrLaneObj, ILaneObject\* pNextLaneObj)**

Called when a vehicle is about to cross a road.

Parameters:

[ in ] pIVehicle: Vehicle Object.

[ in ] pCurrLaneObj: Current lane object.

[ in ] pNextLaneObj: Lane object to be entered next.

**bool travelOnChangingTrace(IVehicle\* pIVehicle)**

Called when the vehicle is traveling on a lane-changing trajectory.

Parameters:

[ in ] pIVehicle: Vehicle Object.

**bool leaveOffChangingTrace(IVehicle\* pIVehicle, qreal differ, qreal& s)**

Called when the vehicle leaves the lane-changing trajectory.

Parameters:

[ in ] pIVehicle: Vehicle Object.

**bool isCalcVehicleVector3D()**

Whether to calculate the vehicle's 3D attributes, such as Euler angles.

Return value:

Returning true indicates that the vehicle's 3D attributes need to be calculated.

**QVector3D calcVehicleEuler(IVehicle\* pIVehicle，bool bPosIDire = true)**

Calculate the vehicle's Euler angles.

Parameters:

[ in ] pIVehicle: Vehicle Object.

[ in ] bPosIDire: Indicates whether the vehicle head direction is calculated in the forward direction; if bPosIDire is false, the calculation is performed in the reverse direction.

Return value:

Euler angles of the vehicle.

**QString vehiRunInfo(IVehicle\* pIVehicle)**

Text content of the textbox in the vehicle operation status popup. During the simulation process, selecting a vehicle and pressing Ctrl+i will display the vehicle operation status popup.

Return value:

Text content displayed in the textbox of the vehicle operation status popup.

Example:

```cpp
QString MySimulator::vehiRunInfo(IVehicle* pIVehicle)
{
    return QString("车辆当前在ID=%1的道路上").arg(pIVehicle->roadId());
}
```

**bool boundingRect(IVehicle\* pIVehicle，QRectF& outRect) const**

Obtain the vehicle boundary rectangle.

Parameters:

[ in ] pIVehicle: Vehicle Object.

[ out ] outRect: Vehicle boundary rectangle.

**bool shape(IVehicle\* pIVehicle，QPainterPath& outShape) const**

Obtain the vehicle graphical path.

Parameters:

[ in ] pIVehicle: Vehicle Object.

[ out ] outShape: Vehicle shape path.

**bool paintVehicle(IVehicle\* pIVehicle，QPainter\* painter)**

Render the vehicle.

Parameters:

[ in ] pIVehicle: Vehicle Object.

[ in ] painter: QPainter object.

Return value:	

If true is returned, TESSNG considers the vehicle to have been drawn by the user, and will no longer draw the vehicle.

**bool paintVehicleWithRotation(IVehicle\* pIVehicle，QPainter\* painter，qreal& inOutRotation)**

Draw the vehicle, rotating the Vehicle Object by the specified angle prior to drawing.

Parameters:

[ in ] pIVehicle: Vehicle Object.

[ in ] painter: QPainter object.

[ in ] inOutRotation: Rotation angle. Unit: degrees.

Return value:

If true is returned, TESSNG considers the vehicle to have been drawn by the user, and will no longer draw the vehicle.

**void rePaintVehicle(IVehicle\* pIVehicle，QPainter\* painter)**

Add custom drawing content following TESSNG’s vehicle rendering.

Parameters:

[ in ] pIVehicle: Vehicle Object.

[ in ] painter: QPainter object.

Example:

```cpp
void MySimulator::rePaintVehicle(Tessng::IVehicle* pIVehicle, QPainter* painter)
{
    // Add vehicle name label on the vehicle body
    QString label = pIVehicle->name();

    // Create QFont object, set font family and size
    QFont font("Arial", 1);
    // Set font to non-bold
    font.setBold(false);

    // Create QFontMetrics object to get font metrics information
    QFontMetrics fontMetrics(font);
    // Get the bounding rectangle of the text
    QRect boundingRect = fontMetrics.boundingRect(label);
    // Calculate text position
    qreal newX = -boundingRect.center().x() - pIVehicle->width() * 0.5;
    qreal newY = -boundingRect.center().y();
    QPointF position(newX, newY);

    // Create QPainterPath object to draw text
    QPainterPath textPath;
    // Add text to the path
    textPath.addText(position, font, label);
      
    // Set pen scaling ratio
    painter->scale(1, 1);
    // Fill path to draw text
    painter->fillPath(textPath, QColor("#c94f4f"));
}
```

#### 3.2.3.3. Traffic Signal Control

**bool beforeCalcLampColor(bool& keepOn)**

Used to perform custom operations before calculating the traffic signal color.

Parameters:

[ in, out ] Indicates whether to continue calculation.

Return value:	

If true is returned and keepOn is set to false, TESSNG will cease calculating the traffic signal color.

**bool calcLampColor(ISignalLamp\* pSignalLamp)**

Calculate the traffic signal color.

Parameters:

[ in ] pSignalLamp: Traffic Signal Object.

Return value:

If true is returned, it indicates that the user has modified the traffic signal color, and TESS NG will no longer compute the signal color.

Example:

```cpp
bool MySimulator::calcLampColor(ISignalLamp* pSignalLamp) 
{
    // If the signal lamp ID is 1, set it to green
	if (pSignalLamp->id() == 1) 
    {
		pSignalLamp->setLampColor("G");
		return true;
	}
	return false;
}
```

#### 3.2.3.4. Others

**void beforeCreateGVehiclesForBusLine(IBusLine\* pBusLine，bool& keepOn)**

Used to implement custom operations before creating bus vehicles.

Parameters:

[ in ] pBusLine: Bus Line.

[ in, out ] keepOn: Whether to continue executing bus vehicle creation.

Return value:

If true is returned and keepOn is set to false, TESS NG will no longer create bus vehicles.

**QList\<Online::DecipointFlowRatioByInterval\> calcDynaFlowRatioParameters()**

Calculate dynamic traffic assignment information.

Return value:

Sequence of dynamic traffic assignment information at decision points.

Example:

```cpp
QList<Online::DecipointFlowRatioByInterval> MySimulator::calcDynaFlowRatioParameters()
{
	QList<Online::DecipointFlowRatioByInterval> lDecipointFLowRatioByInterval;
	// Current simulation calculation batch
	long batchNumber = simuiface->batchNumber();
	// Modify the flow ratios of various paths at a decision point when calculating batch 20
	if (batchNumber == 20)
	{
		// Vehicle distribution ratios for various paths at a decision point during a certain period
		Online::DecipointFlowRatioByInterval dfi = Online::DecipointFlowRatioByInterval();
		// Decision point ID
		dfi.deciPointID = 1;
		// Start time in seconds
		dfi.startDateTime = 1;
		// End time in seconds
		dfi.endDateTime = 999999;
		// Path flow ratios
		Online::RoutingFlowRatio rfr1 = Online::RoutingFlowRatio(1, 3);
		Online::RoutingFlowRatio rfr2 = Online::RoutingFlowRatio(2, 4);
		Online::RoutingFlowRatio rfr3 = Online::RoutingFlowRatio(3, 3);
		dfi.mlRoutingFlowRatio << rfr1;
		dfi.mlRoutingFlowRatio << rfr2;
		dfi.mlRoutingFlowRatio << rfr3;
		lDecipointFLowRatioByInterval << dfi;
	}
	return lDecipointFLowRatioByInterval;
}
```

**QList\<Online::DispatchInterval\> calcDynaDispatchParameters()**

Calculate dynamic dispatch information.

Return value:

Sequence of dynamic dispatch information.

Example:

```cpp
QList<Online::DispatchInterval> MySimulator::calcDynaDispatchParameters()
{
    // Dispatch point ID
	di.dispatchId = 1;
    // Start time, unit: s
	di.fromTime = 0;
    // End time, unit: s
	di.toTime = 300;
    // Vehicle count
	di.vehiCount = 300;
    // Vehicle composition list
	di.mlVehicleConsDetail << Online::VehiComposition(1, 60) << Online::VehiComposition(2, 40);
    QList<Online::DispatchInterval> lDispatchInterval;
	lDispatchInterval << di;
	return lDispatchInterval;
}
```



## 3.3. Interface

Unlike plugins that focus on 'process extension and logic intervention', the interface emphasizes **'data exchange and state regulation'**. It includes the top-level interface TessInterface, as well as three sub-interfaces: NetInterface, SimuInterface, and GuiInterface, providing users with capabilities to access and configure three core types of information: road network, simulation, and GUI. Through these interfaces, users can directly retrieve the topology of the road network, real-time simulation parameters (such as time step and total number of vehicles), and display settings of the GUI (such as window size and view zoom scale). Users can also actively modify these data to adjust the fundamental state of the system.

The top-level interface object exhibits the properties of a global variable and can be instantiated anywhere within the code. However, from the perspective of code maintainability and usability, we recommend performing initialization of each interface within the **constructor**, for example:

```cpp
// MySimulator.h
class MySimulator : public QObject, public CustomerSimulator
{
private:
	// Represents the network sub-interface of TESS NG
	NetInterface* netiface;
	// Represents the simulation sub-interface of TESS NG
	SimuInterface* simuiface;
    // Represents the GUI sub-interface of TESS NG
    GuiInterface* guiInterface;
}

// MySimulator.cpp
MySimulator::MySimulator()
{
	netiface = gpTessInterface->netiface();
	simuiface = gpTessInterface->simuiface();
    guiInterface = gpTessInterface->guiInterface();
}
```

### 3.3.1. Top-level Interface (TessInterface)

Header file: tessinterface.h

TessInterface is the top-level interface exposed by TESS NG, consisting of three sub-interfaces: NetInterface, SimuInterface, and GuiInterface, which are used respectively for accessing or controlling the Road Network, Simulation Process, and User Interaction Interface.

**QJsonObject config()**

Retrieves a JSON object containing information from the config.json configuration file; the configuration data is reloaded each time the Road Network is loaded.

**void setConfigProperty(QString key，QVariant value)**

Sets configuration properties.

**bool loadPluginFromMem()**

Loads a plugin.

**void releasePlugins()**

Unloads a plugin.

**NetInterface\* netiface()**

Returns the NetInterface used for accessing and controlling the Road Network.

Example:

```cpp
netiface = gpTessInterface->netiface();
```

**SimuInterface\* simuiface()**

Returns the SimuInterface used to control the simulation process.

Example:

```cpp
simuiface = gpTessInterface->simuiface();
```

**GuiInterface\* guiInterface()**

Returns the GuiInterface used to access and control the user interface.

Example:

```cpp
guiInterface = gpTessInterface->guiInterface();
```

### 3.3.2. Road Network Interface (NetInterface)

Header file: netinterface.h

NetInterface is a sub-interface of TessInterface employed for accessing and managing road network elements. This interface enables querying, creating, deleting, and modifying road network elements such as road segments and connection segments.

#### 3.3.2.1. Road Network

**QString netFilePath()**

Retrieves the full path name of the road network file. If the road network is stored as professional data, the returned value is the road network ID.

Example:

```cpp
QString netFilePath = netiface->netFilePath();
```

**void saveRoadNet()**

Saves the current road network file.

**void openNetFle(QString filePath)**

Opens a road network file.

Parameters:

[ in ] filePath: Full path name of the road network file.

**bool createEmptyNetFile(QString filePath，long dbver = 5)**

Creates a blank road network.

Parameters:

[ in ] filePath: Full path name of the blank Road Network.

[ in ] dbver: Database version.

**void openNetByNetId(long netId)**

Load the Road Network from a professional database.

**IRoadNet\* netAttrs()**

Retrieve the Road Network attribute object.

**IRoadNet\* roadNet()**

Retrieve the Road Network attribute object, same as netAttrs.

**IRoadNet\* setNetAttrs (QString name，QString sourceType = QString("TESSNG")，QPointF centerPoint = QPointF()，QString backgroundUrl = QString()，QJsonObject otherAttrsJson = QJsonObject())**

Set the basic information of the Road Network.

Parameters:

[ in ] name: Name of the Road Network.

[ in ] sourceType: Data source classification, default is "TESSNG", indicating the Road Network was created directly by the TESSNG software. Value "OPENDRIVE" indicates that the Road Network is imported via the OpenDRIVE Road Network import.

[ in ] centerPoint: The Road Network containing the coordinates of the center point, default is (0, 0). Users may also save the center point coordinates in the otherAttrsJson field.

[ in ] backgroundUrl: Path of the background map.

​	[ in ] otherAttrsJson: Additional attributes stored in the JSON object, such as geodetic coordinate information.

Return value:

​	Road Network attribute object.

**QGraphicsScene\* graphicsScene()**

​	Retrieve the scene object.

**QGraphicsView\* graphicsView()**

​	Retrieve the view object.

**qreal sceneScale()**

​	**Get the pixel ratio in the scene. Unit: meters per pixel (m/pixel).**

**qreal sceneWidth(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	Retrieve the scene width. Unit: Pixel.

**qreal sceneHeigth(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	Retrieve the scene height. Unit: Pixel.

**QByteArray backgroundMap()**

​	Retrieve the background image bytes.

**QRectF boundingRect()**

​	Retrieve the Road Network boundary.

**long getIDByItemName(QString name)**

​	Retrieve the auto-increment ID by Road Network Element name.

Parameters:

​	[ in ] name: Road Network Element name.

**bool initSequence(QString schemaName = QString())**

​	Initialize the database sequence for professional databases storing the Road Network; currently supports PostgreSQL.

Parameters:

​	[ in ] schemaName: Database schema name.

#### 3.3.2.2. Road

**QList\<ISection\*\> sections()**

​	Retrieve all Roads.

#### 3.3.2.3. Road Segment

**int linkCount()**

Retrieve the number of road segments.

**QList\<long\> linkIds()**

Retrieve the road segment ID sequence.

**QList\<ILink\*\> links()**

Retrieve the sequence of road segment objects.

Example:

```cpp
for (auto link : netiface->links()) 
{
    qDebug() << link->id();
}
```

**ILink\* findLink(long id)**

Retrieve the road segment object by road segment ID.

**QList\<QPointF\> linkCenterPoints(long linkID，UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the specified road segment centerline breakpoint sequence. Unit: Pixel.

Parameters:

[ in ] linkID: Specified road segment ID.

**ILink\* createLink(QList\<QPointF\> lCenterPoint，int laneCount，QString linkName = QString()，bool bAddToScene = true，UnitOfMeasure unit = UnitOfMeasure::Default)**

Create a road segment. Unit: Pixel.

Parameters:

[ in ] lCenterPoint: Road segment centerline breakpoint sequence.

[ in ] laneCount: Number of lanes.

[ in ] linkName: Road segment name.

[ in ] bAddToScene: Whether to add to the scene.

Return value:

Road segment object.

Example:

```cpp
QList<QPointF> linkPoints2D = {QPointF(-300, 0), QPointF(300, 0)};
ILink* link = netiface->createLink(linkPoints2D, 7, "曹安公路", true, UnitOfMeasure::Metric);
```

**ILink\* createLink3D(QList\<QVector3D\> lCenterV3，int laneCount，QString linkName = QString()，bool bAddToScene = true，UnitOfMeasure unit = UnitOfMeasure::Default)**

Create a 3D road segment. Unit: Pixel.

Parameters:

[ in ] lCenterV3: Road segment centerline 3D breakpoint sequence.

[ in ] laneCount: Number of lanes.

[ in ] linkName: Road segment name.

[ in ] bAddToScene: Whether to add to the scene.

[ in ] unit: Unit parameter, default is Default; Metric indicates metric units, Default indicates no unit restriction.

Return value:

Road segment object.

Example:

```cpp
QList<QVector3D> linkPoints3D = {QVector3D(-300, 0, 10), QVector3D(300, 0, 20)};
ILink* link = netiface->createLink3D(linkPoints3D, 7, "曹安公路", true, UnitOfMeasure::Metric);
```

**ILink\* createLinkWithLaneWidth(QList\<QPointF\> lCenterPoint，QList\<qreal\> lLaneWidth，QString linkName = QString()，bool bAddToScene = true，UnitOfMeasure unit = UnitOfMeasure::Default)**

Create a road segment with specified lane widths. Unit: Pixel.

Parameters:

[ in ] lCenterPoint: Road segment centerline breakpoint sequence.

[ in ] lLaneWidth: List of lane widths.

[ in ] linkName: Road segment name.

[ in ] bAddToScene: Whether to add to the scene.

Return value:

Road segment object.

Example:

```cpp
QList<QPointF> linkPointsWithWidth = {QPointF(-300, 0), QPointF(300, 0)};
QList<double> laneWidthList = {1, 3.5, 3.5, 3.5};
ILink* link = netiface->createLinkWithLaneWidth(linkPointsWithWidth, laneWidthList, "曹安公路", true, UnitOfMeasure::Metric);
```

**ILink\* createLink3DWithLaneWidth(QList\<QVector3D\> lCenterV3，QList\<qreal\> lLaneWidth，QString linkName = QString()，bool bAddToScene = true，UnitOfMeasure unit = UnitOfMeasure::Default)**

Create a 3D road segment with specified lane widths. Unit: Pixel.

Parameters:

[ in ] lCenterV3: 3D breakpoint sequence of the road segment centerline.

[ in ] lLaneWidth: List of lane widths.

[ in ] linkName: Road segment name.

[ in ] bAddToScene: Whether to add to the scene.

Return value:

Road segment object.

Example:

```cpp
QList<QVector3D> linkPoints3DWithWidth = {QVector3D(-300, 0, 10), QVector3D(300, 0, 20)};
ILink* link = netiface->createLink3DWithLaneWidth(linkPoints3DWithWidth, laneWidthList, "曹安公路", true, UnitOfMeasure::Metric);
```

**ILink\* createLink3DWithLanePoints(QList\<QVector3D\> lCenterLineV3，QList<\QMap\<QString, QList\<QVector3D\>\>\> lanesWithPoints，QString linkName = QString()，bool bAddToScene = true，UnitOfMeasure unit = UnitOfMeasure::Default)**

Create a 3D road segment with specified lane breakpoints. Unit: Pixel.

Parameters:

[ in ] lCenterLineV3: 3D breakpoint sequence of the road segment centerline.

[ in ] lanesWithPoints: Collection of lane point sets.

[ in ] linkName: Road segment name.

[ in ] bAddToScene: Whether to add to the scene.

Return value:

Road segment object.

Example:

```cpp
// Link centerline
QList<QVector3D> linkPoints = {QVector3D(-300, 0, 10), QVector3D(300, 0, 20)};

// Left, center and right lines of each lane
QList<QMap<QString, QList<QVector3D>>> lanesPoints = {
    {
        {"left", {QVector3D(-300, 0, 10), QVector3D(300, 0, 20)}},
        {"center", {QVector3D(-300, 1.75, 10), QVector3D(300, 1.75, 20)}},
        {"right", {QVector3D(-300, 3.5, 10), QVector3D(300, 3.5, 20)}}
    },
    {
        {"left", {QVector3D(-300, -3.5, 10), QVector3D(300, -3.5, 20)}},
        {"center", {QVector3D(-300, -1.75, 10), QVector3D(300, -1.75, 20)}},
        {"right", {QVector3D(-300, 0, 10), QVector3D(300, 0, 20)}}
    }
};
    
ILink* link = netiface->createLink3DWithLanePoints(linkPoints, lanesPoints, "曹安公路", true, UnitOfMeasure::Metric);
```

**ILink\* createLink3DWithLanePointsAndAttrs(QList\<QVector3D\> lCenterLineV3，QList\<QMap\<QString, QList\<QVector3D\>\>\> lanesWithPoints，QList\<QString\> lLaneType，QList\<QJsonObject\> lAttr，QString linkName = QString()，bool bAddToScene = true，UnitOfMeasure unit = UnitOfMeasure::Default)**

Create a 3D road segment with specified lane breakpoints and attributes. Unit: Pixel.

Parameters:

[ in ] lCenterLineV3: 3D breakpoint sequence of the road segment centerline.

[ in ] lanesWithPoints: Collection of lane point sets.

[ in ] lLaneType: Sequence of lane types.

[ in ] lAttr: Sequence of additional lane attributes.

[ in ] linkName: Road segment name.

[ in ] bAddToScene: Whether to add to the scene.

Return value:

Road segment object.

**void removeLink(ILink\* pLink)**

Remove road segment.

Parameters:

[ in ] pLink: Road Segment Object.

Example:

```cpp
// Remove the link with ID 1
link = netiface->findLink(1);
netiface->removeLink(link);
```

**ILink\* updateLink(\_Link link，QList\<\_Lane\> lLane = QList\<\_Lane\>()，QList\<QPointF\> lPoint = QList\<QPointF\>()，UnitOfMeasure unit = UnitOfMeasure::Default)**

Update road segment. Unit: pixel.

Parameters:

[ in ] link: Basic road segment information.

[ in ] lLane: List of lanes.

[ in ] lPoint: List of breakpoints.

Return value:

Updated road segment object.

**void moveLinks(QList\<ILink\*\> lLink，QPointF offset，UnitOfMeasure unit = UnitOfMeasure::Default)**

Move road segment and related connection segments. Unit: pixel.

Parameters:

[ in ] lLink: Sequence of road segment objects.

[ in ] offset: Offset value.

Example:

```cpp
// Get all links
QList<ILink*> links = netiface->links();
// Move all links
netiface->moveLinks(links, QPointF(100, 100));
```

**bool judgeLinkToCross(long linkId)**

Determine whether the downstream of the road segment enters an intersection based on the presence of multiple connection segments within the polygonal area and the angle between the current and subsequent road segments.

Parameters:

[ in ] linkID: Road Segment ID.

Return value:

Whether the downstream of the road segment enters an intersection.

#### 3.3.2.4. Lane

**ILane\* findLane(long id)**

Retrieve the lane object by Lane ID.

**QList\<QPointF\> laneCenterPoints(long laneID，UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the breakpoint sequence of the lane centerline by specified ID. Unit: Pixel.

Parameters:

[ in ] laneID: Lane ID.

Return value:

Specify the breakpoint sequence of the lane centerline.

#### 3.3.2.5. Connection Segment

**int connectorCount()**

Retrieve the number of connection segments.

**QList\<long\> connectorIds()**

Retrieve the sequence of connection segment IDs.

**QList\<IConnector\*\> connectors()**

Retrieve the sequence of connection segment objects.

**IConnector\* findConnector(long id)**

Retrieve the connection segment object by connection segment ID.

**IConnector\* findConnectorByLinkIds(long fromLinkID，long toLinkId)**

Retrieve the connection segment object by upstream Road Segment ID and downstream Road Segment ID.

**IConnector\* createConnector(long fromLinkID，long toLinkID，QList\<int\> lFromLaneNumber，QList\<int\> lToLaneNumber，QString connName = QString()，bool bAddToScene = true)**

Create a connection segment.

Parameters:

[ in ] fromLinkID: Upstream Road Segment ID.

[ in ] toLinkID: Downstream Road Segment ID.

[ in ] lFromLaneNumber: Sequence of lane numbers on the upstream Road Segment.

[ in ] LToLaneNumber: Sequence of lane numbers on the downstream Road Segment.

[ in ] connName: Connection segment name, default is empty; the name is generated by concatenating the IDs of the two road segments.

[ in ] bAddToScene: Whether to add to the Road Network Scenario after creation; default is true.

Return value:

Connection segment object.

Example:

```cpp
// Create a connector between link 1 and link 2
QList<int> fromLaneNumbers = {1, 2, 3};
QList<int> toLaneNumbers = {1, 2, 3};
IConnector* connector = netiface->createConnector(1，2，lFromLaneNumber，lToLaneNumber，"连接段1")；
} 
```

**IConnector\* createConnector3DWithPoints(long fromLinkID，long toLinkID，QList\<int\> lFromLaneNumber，QList\<int\> lToLaneNumber，QList\<QMap\<QString, QList\<QVector3D\>\>\> laneConnectorWithPoints，QString connName = QString()，bool bAddToScene = true，UnitOfMeasure unit = UnitOfMeasure::Default)**

Create a 3D connection segment with specified breakpoints. Unit: Pixel.

Parameters:

[ in ] fromLinkID: Upstream Road Segment ID.

[ in ] toLinkID: Downstream Road Segment ID.

[ in ] lFromLaneNumber: List of lane numbers of the upstream road segment.

[ in ] lToLaneNumber: List of lane numbers of the downstream road segment.

[ in ] laneConnectorWithPoints: Collection of lane connection point sets.

[ in ] connName: Connection segment name.

[ in ] bAddToScene: Whether to add to the scene.

Return value:

Connection segment object.

**void removeConnector(IConnector\* pConnector)**

Remove the connection segment.

Parameters:

[ in ] pConnector: Connection segment object.

**IConnector\* updateConnector(\_Connector connector)**

Update the connection segment. Unit: Pixel.

Parameters:

[ in ] connector: Basic information of the connection segment.

Return value:

Connection segment object.

#### 3.3.2.6. Lane Connection

**ILaneConnector\* findLaneConnector(long id)**

Retrieve the lane connection object by lane connection ID.

**ILaneConnector\* findLaneConnector(long fromLaneID，long toLaneId)**

Retrieve the lane connection object by upstream lane ID and downstream lane ID.

**QList\<Online::CrossPoint\> crossPoints(ILaneConnector\* pLaneConnector)**

The current lane connection intersects with other lane connections, forming a sequence of intersection points.

Parameters:

[ in ] pLaneConnector: Lane connection object.

Return value:

Sequence of intersection points.

#### 3.3.2.7. Connection Segment Polygon

**QList\<IConnectorArea\*\> allConnectorArea()**

Retrieve the complete sequence of connection segment polygon objects.

**IConnectorArea\* findConnectorArea(long id)**

Retrieve the polygon object by polygon ID.

#### 3.3.2.8. Road Network Grid

**void buildNetGrid(qreal width，UnitOfMeasure unit = UnitOfMeasure::Default)**

Road network gridding.

Parameters:

[ in ] width: Cell width. Unit: pixel.

**QList\<ISection\*\> findSectionOn1Cell(QPointF point，UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve all roads contained within the cell where the point is located.

Parameters:

[ in ] point: Coordinates of the point. Unit: pixel.

Return value:

Sequence of Road objects.

**QList\<ISection\*\> findSectionOn4Cell(QPointF point，UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve all Roads within the nearest 4 cells based on the point.

Parameters:

[ in ] point: Coordinates of the point. Unit: pixel.

Return value:

Sequence of Road objects.

**QList\<ISection\*\> findSectionOn9Cell(QPointF point，UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve all Roads within the nearest 9 cells based on the point.

Parameters:

[ in ] point: Coordinates of the point. Unit: pixel.

Return value:

Sequence of Road objects.

**QList\<Online::Location\> locateOnCrid(QPointF point，int cellCount = 1，UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve base Lane objects from multiple cells surrounding the point.

Parameters:

[ in ] point: Coordinates of the point. Unit: pixel.

[ in ] cellCount: Number of cells; defaults to 1 if less than 1, 4 if between 1 and 4, and 9 if greater than 4.

Return value:	

Sequence of positioning information, sorted by ascending shortest distance.

Example:

```cpp
// Target point
QPointF targetPoint(50, 50);
// Project the target point to lanes within a certain range to obtain location information sequence
QList<Online::Location> locations = netiface->locateOnCrid(targetPoint, 9, UnitOfMeasure::Metric);  // Need to execute netiface->buildNetGrid(10) first before using
for (auto location: locations) 
{
    qDebug() << "车道/车道连接ID为：" << location.pLaneObject->id();
    qDebug() << "投影点为：(" << location.point.x() << ", " << location.point.y() << ")";
    qDebug() << "目标点与投影点的间距为：" << location.leastDist << " m";
    qDebug() << "投影点与车道起点的间距为：" << location.distToStart << " m";
    qDebug() << "投影点在所在车道的分段序号为：" << location.segmIndex;
} 
```

**QList\<Online::Location\> locateOnSections(QPointF point，QList\<ISection\*\> lSection，qreal referDistance = 0，UnitOfMeasure unit = UnitOfMeasure::Default)**

Compute the shortest distance from the point to every Lane of each Road in the Road list.

Parameters:

[ in ] point: Coordinates of the point. Unit: pixel.

[ in ] lSection: List of Roads.

[ in ] referDistance: Distance from the point to the nearest position on the LaneObject relative to its start, used solely to improve computational efficiency; default value is 0.

Return value:

Sequence of positioning information, sorted by ascending shortest distance.

#### 3.3.2.9. Vehicle Type

**bool createVehicleType(\_VehicleType \_vt)**

Create a vehicle type.

Parameters:

[ in ] vt: Vehicle type data. A vehicle type name distinct from existing types must be specified; otherwise, creation will fail. The code of the newly created vehicle type will be automatically set to the current maximum code value plus one.

Return value:

Indicates whether creation was successful.

Example:

```cpp
// Build parameters
_VehicleType vehicleType = _VehicleType();
vehicleType.vehicleTypeName = "新建车型1";  // Vehicle type name
vehicleType.Length = 4.5;  // Length, unit: m
vehicleType.lengthSD = 0.5;  // Length standard deviation, unit: m
vehicleType.width = 2;  // Width, unit: m
vehicleType.widthSD = 0.2;  // Width standard deviation, unit: m
vehicleType.avgSpeed = 60;  // Desired speed, unit: km/h
vehicleType.speedSD = 10;  // Desired speed standard deviation, unit: km/h
vehicleType.avgAcce = 4;  // Desired acceleration, unit: m/s²
vehicleType.acceSD = 0.5;  // Desired acceleration standard deviation, unit: m/s²
vehicleType.avgDece = 6;  // Desired deceleration, unit: m/s²
vehicleType.deceSD = 0.5;  // Desired deceleration standard deviation, unit: m/s²
vehicleType.maxAcce = 5.5;  // Maximum acceleration, unit: m/s²
vehicleType.maxDece = 7.5;  // Maximum deceleration, unit: m/s²
vehicleType.maxSpeed = 80;  // Maximum speed, unit: km/h
vehicleType.commercialVehicle = false;  // Whether it is a commercial vehicle
vehicleType.maxPassengerCapacity = 1;  // Maximum passenger capacity, unit: persons
// Create vehicle type
bool result = netiface->createVehicleType(vehicleType);
qDebug() << "创建车型是否成功：" << result;
```

#### 3.3.2.10. Vehicle Composition

**long createVehicleComposition(QString name，QList\<Online::VehicleComposition\> lVehiComp)**

Create a vehicle composition.

Parameters:

[ in ] name: Name of the vehicle composition.

[ in ] lVehiComp: Sequence of proportions for different vehicle types.

Return value:

Vehicle composition ID; returns -1 if the composition name already exists, if any referenced vehicle type code does not exist, or if any proportion is less than zero.

Example:

```cpp
// Build vehicle type proportion list
QList<Online::VehiComposition> vehiTypeProportionList = { 
    Online::VehiComposition(1, 0.3),  // Passenger car, proportion 0.3
    Online::VehiComposition(2, 0.2),  // Coach, proportion 0.2
    Online::VehiComposition(3, 0.1),  // Bus, proportion 0.1
    Online::VehiComposition(4, 0.4)   // Truck, proportion 0.4
};

// Create vehicle composition
int vehiCompositionId = netiface->createVehicleComposition("动态创建车型组成", vehiTypeProportionList);
```

**bool removeVehicleComposition(long vehiCompId)**

Remove a vehicle composition.

Parameters:

[ in ] vehiCompID: Vehicle composition ID.

#### 3.3.2.11. Departure Point

**QList\<IDispatchPoint\*\> dispatchPoints()**

​	Retrieve the entire sequence of all departure points.

**IDispatchPoint\* findDispatchPoint(long id)**

​	Retrieve a departure point by its ID.

**IDispatchPoint\* createDispatchPoint(ILink\* pLink，QString dpName = QString()，bool bAddToScene = true)**

​	Create a departure point.

Parameters:

​	[ in ] pLink: Road segment on which to create the departure point.

​	[ in ] dpName: Name of the departure point; defaults to empty, using the departure point ID as the name.

[ in ] bAddToScene: Whether to add to the Road Network Scenario after creation; default is true.

Example:

```cpp
// Get link object
ILink* link = netiface->findLink(1);
// Create dispatch point
IDispatchPoint* dp = netiface->createDispatchPoint(link);
if (dp)
{
    // Add dispatch interval, including vehicle composition, time interval, and number of dispatches
    dp->addDispatchInterval(1, 600, 300);
    dp->addDispatchInterval(1, 600, 400);
}
```

**bool removeDispatchPoint(IDispatchPoint\* pDispPoint)**

​	Remove a departure point.

Parameters:

​	[ in ] pDispPoint: Departure point object.

#### 3.3.2.12. Decision Point

**QList< IDecisionPoint\* > decisionPoints()**

​	Retrieve the entire sequence of all decision points.

**IDecisionPoint\* findDecisionPoint(long id)**

​	Retrieve a decision point by its ID.

**IDecisionPoint\* createDecisionPoint(ILink\* pLink，qreal distance，QString name = QString()，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	Create a decision point.

Parameters:

​	[ in ] pLink: Road segment where the decision point is located.

​	[ in ] distance: Distance from the start of the road segment to the decision point. Unit: pixel.

[ in ] name: Name of the Decision Point.

Return value:

Decision Point Object.

Example:

```cpp
ILink* link = netiface->findLink(1);
qreal location = 50;
QString decisionPointName = "新建决策点";
IDecisionPoint* decisionPoint = netiface->createDecisionPoint(link, location, decisionPointName, UnitOfMeasure::Metric);
```

**IDecisionPoint\* updateDecipointPoint(\_DecisionPoint deciPoint，QList\<\_RoutingFLowRatio\> lFlowRatio = QList\<\_RoutingFLowRatio\>())**

Update the Decision Point and its flow ratios across different time intervals for each Path.

Parameters:

[ in ] deciPoint: Decision Point data.

[ in ] lFlowRatio: Collection of flow ratio data per Path segmented by time intervals.


Return value:

Decision Point Object.

Example:

```cpp
// Initialize left, straight, and right flow ratio objects
_RoutingFLowRatio flowRatioLeft;
flowRatioLeft.RoutingFLowRatioID = 1;
flowRatioLeft.routingID = decisionRouting1->id();
flowRatioLeft.startDateTime = 0;
flowRatioLeft.endDateTime = 999999;
flowRatioLeft.ratio = 2.0;

_RoutingFLowRatio flowRatioStraight;
flowRatioStraight.RoutingFLowRatioID = 2;
flowRatioStraight.routingID = decisionRouting2->id();
flowRatioStraight.startDateTime = 0;
flowRatioStraight.endDateTime = 999999;
flowRatioStraight.ratio = 3.0;

_RoutingFLowRatio flowRatioRight;
flowRatioRight.RoutingFLowRatioID = 3;
flowRatioRight.routingID = decisionRouting3->id();
flowRatioRight.startDateTime = 0;
flowRatioRight.endDateTime = 999999;
flowRatioRight.ratio = 1.0;

// Initialize decision point data
_DecisionPoint decisionPointData;
decisionPointData.deciPointID = decisionPoint->id();
decisionPointData.deciPointName = decisionPoint->name();
QPointF decisionPointPos;
if (decisionPoint->link()->getPointByDist (decisionPoint->distance(), decisionPointPos)) 
{
    decisionPointData.X = decisionPointPos.x();
    decisionPointData.Y = decisionPointPos.y();
    decisionPointData.Z = decisionPoint->link()->z();
}

// Construct flow ratio list
QList<_RoutingFLowRatio> flowRatioList = {flowRatioLeft, flowRatioStraight, flowRatioRight};

// Update the path flow ratio configuration of the decision point
IDecisionPoint* updatedDecisionPoint = netiface->updateDecipointPoint(decisionPointData, flowRatioList);
```

#### 3.3.2.13. Vehicle Path

**IRouting\* findRouting(long id)**

Retrieve the Path Object using the Path ID.

**IRouting\* createRouting(QList\<ILink\*\> lILink)**

Create a Path that is not bound to any Decision Point.

Parameters:

[ in ] lILink: Sequence of Road Segment Objects that must be continuous.

Return value:

Path Object.

Example:

```cpp
// Link ID list
QList<int> linkIdList = {1, 2, 3, 4};
// Build link object list
QList<Link*> linkList;
for (int linkId : linkIdList) {
    linkList.append(netiface->findLink(linkId));
}
// Create vehicle route
IRouting* routing = netiface->createRouting(linkList);
```

**IRouting\* createDeciRouting(IDecisionPoint\* pDeciPoint，QList\<ILink\*\> lILink)**

Add a Vehicle Path to a Decision Point.

Parameters:

[ in ] pDeciPoint: Decision Point Object.

[ in ] lILink: Sequence of Road Segment Objects starting from the Road Segment where the Decision Point is located, which must be continuous.

Return value:

Path Object.

**bool removeDeciRouting(IDecisionPoint\* pDeciPoint，IRouting\* pRouting)**

Remove the Vehicle Path from the Decision Point.

Parameters:

[ in ] pDeciPoint: Decision Point Object.

[ in ] pRouting: Path Object.

Return value:

Indicates whether the removal was successful.

**IRouting\* shortestRouting(ILink\* pFromLink，ILink\* pToLink)**

Calculate the shortest Path between two Road Segments.

Parameters:

[ in ] pFromLink: Starting Road Segment.

[ in ] pToLink: Target Road Segment.

Return value:	

Path Object.

#### 3.3.2.14. Signal Controller

**int signalControllerCount()**

Get the number of Signal Controllers.

**QList\<long\> signalControllerIds()**

Get the sequence of Signal Controller IDs.

**QList\<ISignalController\*\> signalControllers()**

Get the sequence of all Signal Controller objects.

**ISignalController\* findSignalControllerById(long id)**

Retrieve a Signal Controller object by ID.

**ISignalController\* findSignalControllerByName(QString name)**

Retrieve a Signal Controller object by name; returns the first if duplicates exist.

**ISignalController\* createSignalController(QString name)**

Create a Signal Controller.

Parameters:

[ in ] name: Signal Controller name.

Return value:

Signal Controller object.

Example:

```cpp
// Signal controller name
QString signalControllerName = "双龙大道-吉印大道交叉口";
// Create signal controller
ISignalController* signalController = netiface->createSignalController(signalControllerName);
```

#### 3.3.2.15. Signal Control Scheme

**int signalPlanCount()**

Retrieve the number of Signal Control Scheme groups.

**QList\<long\> signalPlanIds()**

Retrieve the sequence of Signal Control Scheme IDs.

**QList\<ISignalPlan\*\> signalPlans()**

Retrieve the sequence of Signal Control Scheme Objects.

**ISignalPlan\* findSignalPlanById(long id)**

Retrieve the Signal Control Scheme Object by ID.

**ISignalPlan\* findSignalPlanByName(QString name)**

Retrieve the Signal Control Scheme Object by name.

**ISignalPlan\* createSignalPlan(ISignalController\* pITrafficLight，QString name，int cycle，int phasedifference，int startTime，int endTime)**

Create a Signal Control Scheme.

Parameters:

[ in ] pITrafficLight: Signal Controller object.

[ in ] name: Scheme name.

[ in ] cycle: Cycle duration.

[ in ] phasedifference: Phase difference.

[ in ] startTime: Start time.

[ in ] endTime: End time.

Return value:

Signal Control Scheme Object.

Example:

```cpp
// Get signal controller object
ISignalController* signalController = netiface->findSignalControllerByID(1);
// Signal control plan name
QString signalPlanName = "平峰方案";
// Cycle length, unit: s
int cycleTime = 120;
// Phase offset, unit: s
int phaseDifference = 0;
// Start time, unit: s
int startTime = 0;
// End time, unit: s
int endTime = 3600;
// Create signal control plan
ISignalPlan* signalPlan = netiface->createSignalPlan(signalController, signalPlanName, cycleTime, phaseDifference, startTime, endTime);
```

#### 3.3.2.16. Traffic Signal Phase

**ISignalPhase\* findSignalPhase(long id)**

Retrieve the Traffic Signal Phase Object by Traffic Signal Phase ID.

**ISignalPhase* createSignalPlanSignalPhase(ISignalPlan* SignalPlan, QString name, QList\<Online::ColorInterval\> lColor)**

Create a Traffic Signal Phase.

Parameters:

[ in ] SignalPlan: Signal Control Scheme Object.

[ in ] name: Phase name.

[ in ] lColor: List of light color objects.

Return value:

Traffic Signal Phase Object.

Example:

```cpp
// Get signal timing plan
ISignalPlan* signalPlan = netiface->findSignalPlanByID(1);
// Phase name
QString signalPhaseName = "东西直行";
// Build color object list
QString<QString> colors = {"R", "G", "Y", "R"};
QList<int> intervals = {30, 26, 3, 61};
QList<Online::ColorInterval> colorIntervalList;
for (int i = 0; i < colors.size(); ++i) 
{
    colorIntervalList.append(Online::ColorInterval(colors[i], intervals[i]));
}
// Create signal phase
ISignalPhase* signalPhase = netiface->createSignalPlanSignalPhase(signalPlan, signalPhaseName, colorIntervalList);
```

**void removeSignalPhase(ISignalPlan\* pPlan，long phaseId)**

Remove an existing Traffic Signal Phase; after removal, the original phase sequence is automatically reordered.

Parameters:

[ in ] pPlan: Signal Control Scheme Object.

[ in ] phaseID: ID of the phase to be removed.

#### 3.3.2.17. Traffic Signal Head

**int signalLampCount()**

Get the number of traffic signals.

**QList\<long\> signalLampIds()**

Get the sequence of traffic signal IDs.

**QList\<ISignalLamp\*\> signalLamps()**

Get the sequence of traffic signal objects.

**ISignalLamp\* findSignalLamp(long id)**

Obtain a traffic signal object by its ID.

**ISignalLamp\* createSignalLamp(ISignalPhase\* pPhase，QString name，long laneID，long toLaneID，qreal distance)**

Create a traffic signal.

Parameters:

[ in ] pPhase: Phase object.

[ in ] name: Traffic Signal name.

[ in ] laneID: Lane ID where the Traffic Signal is located, or upstream Lane ID of the Lane connection where the Traffic Signal is located.

[ in ] toLaneID: Downstream Lane ID of the Lane connection where the Traffic Signal is located.

[ in ] distance: Distance from the Traffic Signal to the start of the Lane or Lane connection. Unit: Pixel.

Return value:

Traffic Signal Object.

Example:

```cpp
// Get phase object
ISignalPhase* signalPhase = netiface->findSignalPhase(1);
// Signal lamp name
QString signalLampName = "东直1";
// Lane ID
long laneId = 1;
// Downstream lane ID
long toLaneId = -1;
// Position, unit: m
qreal distance = m2p(50);
// Create signal lamp
ISignalLamp* signalLamp = netiface->createSignalLamp(signalPhase, signalLampName, laneId, toLaneId, distance);
```

**ISignalLamp\* createTrafficSignalLamp(ISignalController\* pTrafficLight，QString name，long laneID，long toLaneID，qreal distance)**

Create a traffic signal.

Parameters:

[ in ] pTrafficLight: Signal Controller.

[ in ] name: Traffic Signal name.

[ in ] laneID: Lane ID where the Traffic Signal is located, or upstream Lane ID of the Lane connection where the Traffic Signal is located.

[ in ] toLaneID: Downstream Lane ID of the Lane connection where the Traffic Signal is located.

[ in ] distance: Distance from the Traffic Signal to the start of the Lane or Lane connection. Unit: Pixel.

Return value:

Traffic Signal Object.

**void addSignalPhaseToLamp(int SignalPhaseID，ISignalLamp\* signalLamp)**

Add a bound Phase to the Traffic Signal.

Parameters:

[ in ] SignalPhaseID: Signal Phase ID.

[ in ] signalLamp: Traffic Signal Object.

**void removeSignalPhaseFromLamp(int SignalPhaseID，ISignalLamp\* signalLamp)**

Remove a bound Phase from the Traffic Signal; if the Phase list contains only one Phase, the associated Phase will be set to null.

Parameters:

[ in ] SignalPhaseID: Signal Phase ID.

[ in ] signalLamp: Traffic Signal Object.

**void transferSignalPhase(ISignalPhase\* pFromISignalPhase，ISignalPhase\* pToISignalPhase，ISignalLamp\* signalLamp)**

The traffic signal switches the bound phase, but crossing signal controllers is not allowed.

Parameters:

[ in ] pFromISignalPhase: Original phase.

[ in ] pToISignalPhase: Target phase.

[ in ] signalLamp: Traffic Signal Object.

#### 3.3.2.18. Data Collector

**QList\<IVehicleDrivInfoCollector\*\> vehiInfoCollectors()**

Retrieve the sequence of all data collector objects.

**IVehicleDrivInfoCollector\* findVehiInfoCollector(long id)**

Access a data collector object by ID.

**IVehicleDrivInfoCollector\* createVehiCollectorOnLink(ILane\* pLane，qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

Create a data collector on a lane within a road segment.

Parameters:

[ in ] pLane: Lane object.

[ in ] dist: Distance from the start of the lane. Unit: Pixel.

Return value:

Data collector object.

Example:

```cpp
// Get lane object
ILane* lane = netiface->findLane(1);
// Position, unit: m
qreal dist = 50;
// Create data collector on the link
IVehicleDrivInfoCollector* collector = netiface->createVehiCollectorOnLink(lane, dist, UnitOfMeasure::Metric);
```

**IVehicleDrivInfoCollector\* createVehiCollectorOnConnector(ILaneConnector\* pLaneConnector，qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

Create a data collector on a lane connection within a connection segment.

Parameters:

[ in ] pLaneConnector: Lane connection object.

[ in ] dist: Distance from the start of the lane connection. Unit: Pixel.

Return value:

Data collector object.

Example:

```cpp
// Get lane connector object
ILaneConnector* laneConnector = netiface->findLaneConnector(1, 4);
// Position, unit: m
qreal dist = 50;
// Create data collector on the connector
IVehicleDrivInfoCollector* collector = netiface->createVehiCollectorOnConnector(laneConnector, dist, UnitOfMeasure::Metric);
```

**bool removeVehiCollector(IVehicleDrivInfoCollector\* pCollector)**

Remove the vehicle information collector.

Parameters:

[ in ] pCollector: Vehicle information collector object.

Return value:

Indicates whether the removal was successful.

#### 3.3.2.19. Queue Counter

**QList\<IVehicleQueueCounter\*\> vehiQueueCounters()**

Retrieve all queue counter objects.

**IVehicleQueueCounter\* findVehiQueueCounter(long id)**

Retrieve a queue counter object by ID.

**IVehicleQueueCounter\* createVehiQueueCounterOnLink(ILane\* pLane，qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

Create a vehicle queue counter on a road segment lane.

Parameters:

[ in ] pLane: Lane object.

[ in ] dist: Distance from the start of the lane. Unit: Pixel.

Return value:

Queue counter object.

Example:

```cpp
// Get lane object
ILane* lane = netiface->findLane(1);
// Position, unit: m
qreal dist = 80;
// Create queue counter on the link
IVehicleQueueCounter* counter = netiface->createVehiQueueCounterOnLink(lane, dist, UnitOfMeasure::Metric);
```

**IVehicleQueueCounter\* createVehiQueueCounterOnConnector(ILaneConnector\* pLaneConnector，qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

Create a vehicle queue counter on the lane connection of a connection segment.

Parameters:

[ in ] pLaneConnector: Lane connection object.

[ in ] dist: Distance from the start of the lane connection. Unit: Pixel.

Return value:

Queue counter object.

Example:

```cpp
// Get lane connector object
laneConnector* = netiface->findLaneConnector(1, 4);
// Position, unit: m
double dist = 80;
// Create queue counter on the connector
IVehicleQueueCounter* counter = netiface->createVehiQueueCounterOnConnector(laneConnector, dist, UnitOfMeasure::Metric);
```

#### 3.3.2.20. Travel Time Detector

**QList\<IVehicleTravelDetector\*\> vehiTravelDetectors()**

Retrieve all vehicle travel time detector objects.

**IVehicleTravelDetector\* findVehiTravelDetector(long id)**

Retrieve a vehicle travel time detector object by ID.

**QList\<IVehicleTravelDetector\*\> createVehicleTravelDetector_link2link(ILink\* pStartLink，ILink\* pEndLink，qreal dist1，qreal dist2，UnitOfMeasure unit = UnitOfMeasure::Default)**

Create a travel time detector from one road segment to another.

Parameters:

[ in ] pStartLink: Starting road segment object.

[ in ] pEndLink: Terminal road segment object.

[ in ] dist1: Distance from the detector start point to the start point of the road segment. Unit: Pixel.

[ in ] dist2: Distance from the detector end point to the start point of the road segment. Unit: Pixel.

Example:

```cpp
// Get start link object
ILink* startLink = netiface->findLink(1);
// Get end link object
ILink* endLink = netiface->findLink(2);
// Detector start position on the start link, unit: m
qreal startDist = 10;
// Detector end position on the end link, unit: m
qreal endDist = 90;
// Create travel time detector with start on link and end on link
QList<IVehicleTravelDetector*> detectors = netiface->createVehicleTravelDetector_link2link(startLink, endLink, startDist, endDist, UnitOfMeasure::Metric);
```

**QList\<IVehicleTravelDetector\*> createVehicleTravelDetector_link2conn(ILink\* pStartLink，ILaneConnector\* pEndLaneConnector，qreal dist1，qreal dist2，UnitOfMeasure unit = UnitOfMeasure::Default)**

Create a travel time detector from a road segment to a connection segment.

Parameters:

[ in ] pStartLink: Starting road segment object.

[ in ] pEndLaneConnector: Terminal lane connection object.

[ in ] dist1: Distance from the detector start point to the start point of the road segment. Unit: Pixel.

[ in ] dist2: Distance from the detector end point to the start point of the lane connection. Unit: Pixel.

Return value:

Travel time detector object.

Example:

```cpp
// Get start link object
ILink* startLink = netiface->findLink(1);
// Get end lane connector object
ILaneConnector* endLaneConnector = netiface->findLaneConnector(1, 4);
// Detector start position on the start link, unit: m
qreal startDist = 10;
// Detector end position on the end lane connector, unit: m
qreal endDist = 10;
// Create travel time detector with start on link and end on connector
QList<IVehicleTravelDetector*> detectors = netiface->createVehicleTravelDetector_link2conn(startLink, endLaneConnector, startDist, endDist, UnitOfMeasure::Metric);
```

**QList\<IVehicleTravelDetector\*\> createVehicleTravelDetector_conn2link(ILaneConnector\* pStartLaneConnector，ILink\* pEndLink，qreal dist1，qreal dist2，UnitOfMeasure unit = UnitOfMeasure::Default)**

Create a travel time detector from a connection segment to a road segment.

Parameters:

[ in ] pStartLaneConnector: Starting lane connection object.

[ in ] pEndLink: Terminal road segment object.

[ in ] dist1: Distance from the detector's start point to the lane connection start point. Unit: Pixel.

[ in ] dist2: Distance from the detector end point to the start point of the road segment. Unit: Pixel.

Return value:

Travel time detector object.

Example:

```cpp
// Get start lane connector object
ILink* startLaneConnector = netiface->findLaneConnector(1, 4);
// Get end link object
ILaneConnector* endLink = netiface->findLink(2);
// Detector start position on the start lane connector, unit: m
qreal startDist = 10;
// Detector end position on the end link, unit: m
qreal endDist = 90;
// Create travel time detector with start on connector and end on link
QList<IVehicleTravelDetector*> detectors = netiface->createVehicleTravelDetector_conn2link(startLaneConnector, endLink, startDist, endDist, UnitOfMeasure::Metric);
```

**QList\<IVehicleTravelDetector\*\> createVehicleTravelDetector_conn2conn(ILaneConnector\* pStartLaneConnector，ILaneConnector\* pEndLaneConnector，qreal dist1，qreal dist2，UnitOfMeasure unit = UnitOfMeasure::Default)**

Create a trip time detector from one connection segment to another.

Parameters:

[ in ] pStartLaneConnector: Starting lane connection object.

[ in ] pEndLaneConnector: Terminal lane connection object.

[ in ] dist1: Distance from the detector's start point to the lane connection start point. Unit: Pixel.

[ in ] dist2: Distance from the detector end point to the start point of the lane connection. Unit: Pixel.

Return value:

Travel time detector object.

Example:

```cpp
// Get start lane connector object
ILaneConnector* startLaneConnector = netiface->findLaneConnector(1, 4);
// Get end link object
ILaneConnector* endLaneConnector = netiface->findLaneConnector(4, 7);
// Detector start position on the start lane connector, unit: m
qreal startDist = 10;
// Detector end position on the end lane connector, unit: m
qreal endDist = 90;
// Create travel time detector with start on connector and end on connector
QList<IVehicleTravelDetector*> detectors = netiface->createVehicleTravelDetector_conn2conn(startLaneConnector, endLaneConnector, startDist, endDist, UnitOfMeasure::Metric);
```

#### 3.3.2.21. Direction Arrow

**int guidArrowCount()**

Retrieve the number of direction arrows.

**QList\<long\> guidArrowIds()**

Retrieve the sequence of direction arrow IDs.

**QList\<IGuidArrow\*\> guidArrows()**

Retrieve the sequence of direction arrow objects.

**IGuidArrow\* findGuidArrow(long id)**

Retrieve the direction arrow object by its ID.

**IGuidArrow\* createGuidArrow(ILane\* pLane，qreal length，qreal distToTerminal，Online::GuideArrowType arrowType，UnitOfMeasure unit = UnitOfMeasure::Default)**

Create a direction arrow.

Parameters:

[ in ] pLane: Lane object.

[ in ] length: Length. Unit: Pixel.

[ in ] distToTerminal: Distance to the lane terminal. Unit: Pixel.

[ in ] arrowType: Type of arrow.

Return value:

Direction arrow object.

Example:

```cpp
ILane* lane = netiface->findLane(4);
if (lane)
{
    qreal length = 4;
    qreal distToTerminal = 10;
    Online::GuideArrowType arrowType = Online::GuideArrowType::StraightRight;
	IGuidArrow* guidArrow = netiface->createGuidArrow(lane, length, distToTerminal, arrowType, UnitOfMeasure::Metric);
}
```

**void removeGuidArrow(IGuidArrow\* pArrow)**

Remove the direction arrow.

Parameters:

​	[ in ] pArrow: Directed Arrow Object.

#### 3.3.2.22. Bus Route

**QList\<IBusLine\*\> buslines()**

​	Retrieve the sequence of Bus Route Objects.

**IBusLine\* findBusline(long buslineId)**

​	Retrieve a Bus Route by Bus Route ID.

**IBusLine\* findBuslineByFirstLinkId(long linkId)**

​	Retrieve a Bus Route by the starting Road Segment ID.

**IBusLine\* createBusLine(QList\<ILink\*\> lLink)**

​	Create a Bus Route where adjacent Road Segments in the lLink list may be either adjacent or non-adjacent on the Road Network; if non-adjacent, TESSNG will generate the shortest Path between them. If adjacent Road Segments in the lLink list are not adjacent on the Road Network and no shortest Path exists between them, the second adjacent Road Segment and all subsequent segments are considered invalid.

Parameters:
	[ in ] lLink: sequence of Road Segment Objects traversed by the Bus Route.

Return value:

Bus line object.

Example:

```cpp
ILink* link1 = netiface->findLink(1);
ILink* link2 = netiface->findLink(2);
QList<ILink*> links = {link1, link2};
IBusLine* busLine = netiface->createBusLine(links);
```

**bool removeBusLine(IBusLine\* pBusLine)**

Remove bus line.

Parameters:

[ in ] pBusLine: Bus line object.

#### 3.3.2.23. Bus Stop

**QList\<IBusStation\*\> busStations()**

Get the sequence of bus stop objects.

**IBusStation\* findBusStation(long stationId)**

Get bus stop object by bus stop ID.

**IBusStation\* createBusStation(ILane\* pLane，qreal length，qreal dist，QString name = QString()，UnitOfMeasure unit = UnitOfMeasure::Default)**

Create a bus stop.

Parameters:

[ in ] pLane: Lane object.

[ in ] length: Stop length. Unit: pixel.

[ in ] dist: Distance from the stop start point to the lane start point. Unit: pixel.

[ in ] name: Stop name.	

Return value:

Bus stop object.

Example:

```cpp
ILane* lane = netiface->findLane(1);
IBusStation* busStation = netiface->createBusStation(lane, 30, 50, "公交站1", UnitOfMeasure::Metric);
// Set station type 1: curb type, 2: bay type
busStation.setType(1);
```

**bool removeBusStation(IBusStation\* pStation)**

Remove bus stop.

Parameters:

[ in ] pStation: Bus stop object.

#### 3.3.2.24. Bus Line - Stop

**QList\<IBusStationLine\*\> findBusStationLineByStationId(long stationId)**

Get bus line-stop object by bus stop ID.

**bool addBusStationToLine(IBusLine\* pBusLine，IBusStation\* pStation)**

Associate a bus stop with a bus route.

Parameters:

[ in ] pBusLine: Bus line object.

[ in ] pStation: Bus stop object.

**bool removeBusStationFromLine(IBusLine\* pBusLine，IBusStation\* pStation)**

Remove the association between a bus stop and a bus route.

Parameters:

[ in ] pBusLine: Bus line object.

[ in ] pStation: Bus stop object.

#### 3.3.2.25. Accident Zone

**QList\<IAccidentZone\*\> accidentZones()**

Retrieve all Accident Zone objects.

**IAccidentZone\* findAccidentZone(long accidentZoneId)**

Retrieve an Accident Zone object by its ID.

**IAccidentZone\* createAccidentZone(Online::DynaAccidentZoneParam param)**

Create an Accident Zone.

Parameters:

[ in ] param: Dynamic Accident Zone information.

Return value:

Accident Zone object.

Example:

```cpp
// Build parameters
Online::DynaAccidentZoneParam param;
// Accident zone name
param.name = "事故区";
// Road ID
param.roadID = 1;
// Position, distance from the start of the link or connector, unit: m
param.location = 100;
// Length, unit: m
param.length = 50;
// Lane number list, starting from 0, continuous and ordered
param.mlFromLaneNumber.append(0);
// Start time, unit: s
param.startTime= 10
// Duration, unit: s
param.duration = 600
// Adjacent lane speed limit, unit: km/h
param.limitSpeed = 40
// Create accident zone
IAccidentZone* accidentZone = netiface->createAccidentZone(param, UnitOfMeasure::Metric);
```

**void removeAccidentZone(IAccidentZone\* pIAccidentZone)**

Remove an Accident Zone.

Parameters:

[ in ] pIAccidentZone: Accident Zone object.

#### 3.3.2.26. Construction Zone

**QList\<IRoadWorkZone\*\> roadWorkZones()**

Retrieve all Construction Zone object sequences.

**IRoadWorkZone\* findRoadWorkZone(long roadWorkZoneId)**

Retrieve a Construction Zone object by its ID.

**IRoadWorkZone\* createRoadWorkZone(Online::DynaRoadWorkZoneParam param，UnitOfMeasure unit = UnitOfMeasure::Default)**

Create a Construction Zone.

Parameters:

[ in ] param: Construction Zone parameters. Unit: Pixel.

Return value:

Construction zone object.

Example:

```cpp
// Build parameters
Online::DynaRoadWorkZoneParam param;
// Construction zone name
param.name = "施工区";
// Road ID
param.roadID = 1;
// Position, distance from the start of the link or connector, unit: m
param.location = 200;
// Length, unit: m
param.length = 50;  // Length
param.upCautionLength = 70;  // Advance warning length
param.upTransitionLength = 50;  // Transition zone length
param.upBufferLength = 50;  // Buffer zone length
param.downTransitionLength = 40;  // Downstream transition zone length
param.downTerminationLength = 40;  // Termination zone length
// Lane number list, starting from 0, continuous and ordered
param.mlFromLaneNumber.append(0);
// Start time, unit: s
param.startTime = 0;
// Duration, unit: s
param.duration = 3600;
// Adjacent lane speed limit, unit: km/h
param.limitSpeed = 40;
// Create construction zone
IRoadWorkZone* roadWorkZone = netiface->createRoadWorkZone(param, UnitOfMeasure::Metric);
```

**void removeRoadWorkZone(IRoadWorkZone\* pIRoadWorkZone)**

Remove construction zone.

Parameters:

[ in ] pIRoadWorkZone: Construction zone object.

**bool updateRoadWorkZone(Online::DynaRoadWorkZoneParam param，UnitOfMeasure unit = UnitOfMeasure::Default)**

Update construction zone.

Parameters:

[ in ] param: Construction Zone parameters. Unit: Pixel.

#### 3.3.2.27. Restricted Area

**QList\<ILimitedZone\*\> limitedZones()**

Retrieve all restricted area object sequences.

**ILimitedZone\* findLimitedZone(long limitedZoneId)**

Retrieve restricted area object by restricted area ID.

**ILimitedZone\* createLimitedZone(Online::DynaLimitedZoneParam param，UnitOfMeasure unit = UnitOfMeasure::Default)**

Create restricted area.

Parameters:

[ in ] param: Restricted area parameters. Unit: Pixel.

Return value:

Restricted area object.

Example:

```cpp
// Build parameters
Online::DynaLimitedZoneParam param;
// Restricted zone name
param.name = "限行区";
// Road ID
param.roadID = 1;
// Position, distance from the start of the link or connector, unit: m
param.location = 200;
// Length, unit: m
param.length = 50;
// Lane number list, starting from 0, continuous and ordered
param.mlFromLaneNumber.append(0);
// Start time, unit: s
param.startTime = 0;
// Duration, unit: s
param.duration = 3600;
// Adjacent lane speed limit, unit: km/h
param.limitSpeed = 40;
// Create restricted zone
ILimitedZone* limitedZone = netiface->createLimitedZone(param, UnitOfMeasure::Metric);
```

**void removeLimitedZone(ILimitedZone\* pILimitedZone)**

Remove restricted area.

Parameters:

[ in ] pILimitedZone: Restricted area object.

**bool updateLimitedZone(Online::DynaLimitedZoneParam param，UnitOfMeasure unit = UnitOfMeasure::Default)**

Update restricted area.

Parameters:

[ in ] param: Restricted area parameters. Unit: Pixel.

#### 3.3.2.28. Reconstruction and Expansion Lane Borrowing

**QList\<IReconstruction\*\> reconstructions()**

Retrieve all reconstruction and expansion objects.

**IReconstruction\* findReconstruction(long reconstructionId)**

Retrieve reconstruction and expansion object by ID.

**IReconstruction\* createReconstruction(Online::DynaReconstructionParam param，UnitOfMeasure unit = UnitOfMeasure::Default)**

Create reconstruction and expansion.

Parameters:

[ in ] param: Reconstruction and expansion parameters. Unit: Pixel.

Return value:

Reconstruction and expansion object.

Example:

```cpp
// Build parameters
Online::DynaReconstructionParam param;
// Construction zone ID
param.roadWorkZoneId = rwzId;
// Link ID being borrowed
param.beBorrowedLinkId = 2;
// Number of lanes being borrowed
param.borrowedNum = 1;
// Passageway length, unit: m
param.passagewayLength = 80;
// Passageway speed limit, unit: m/s
param.passagewayLimitedSpeed = 40 / 3.6;
// Create reconstruction lane borrowing
IReconstruction* reconstruction = netiface->createReconstruction(param, UnitOfMeasure::Metric);
```

**void removeReconstruction(IReconstruction\* pIReconstruction)**

Remove reconstruction and expansion.

Parameters:

[ in ] pIReconstruction: Reconstruction and expansion object.

**bool updateReconStruction(Online::DynaReconstructionParam param，UnitOfMeasure unit = UnitOfMeasure::Default)**

Update reconstruction and expansion.

Parameters:

[ in ] param: Reconstruction and expansion parameters. Unit: Pixel.

**qreal reCalcPassagewayLength(Online::DynaReconstructionParam param，UnitOfMeasure unit = UnitOfMeasure::Default)**

Recalculate the traffic protection opening length, which can be derived from detailed traffic protection parameters.

Parameters:

[ in ] param: Reconstruction and expansion parameters. Unit: Pixel.

Return value:

Traffic protection opening length.

#### 3.3.2.29. Speed limit zone

**QList\<IReduceSpeedArea\*\> reduceSpeedAreas()**

Retrieve the complete set of speed limit zone objects.

**IReduceSpeedArea\* findReduceSpeedArea(long id)**

Retrieve a speed limit zone object by its ID.

**IReduceSpeedArea\* createReduceSpeedArea(Online::DynaReduceSpeedAreaParam param)**

Create a speed limit zone.

Parameters:

[ in ] param: Speed limit zone parameters. Unit: Pixel.

Return value:

Speed limit zone object.

**void removeReduceSpeedAea(IReduceSpeedArea\* pIReduceSpeedArea)**

Remove a speed limit zone.

Parameters:

[ in ] pIReduceSpeedArea: Speed limit zone object.

**bool updateReduceSpeedArea(Online::DynaReduceSpeedAreaParam param)**

Update speed limit zone.

Parameters:

[ in ] param: Speed limit zone parameters. Unit: Pixel.

#### 3.3.2.30. Pedestrian Type

**QList\<IPedestrianType\> pedestrianTypes()**

Retrieve the sequence of all pedestrian type objects.

#### 3.3.2.31. Pedestrian Composition

**QList\<Online::Pedestrian::PedestrianComposition\> pedestrianCompositions()**

Retrieve the sequence of all pedestrian composition information.

**long createPedestrianComposition(QString name，QMap\<int, qreal\> mpCompositionRatio)**

Create pedestrian composition.

Parameters:

[ in ] name: Composition name.

[ in ] mpCompositionRatio: Composition details, where the key is the pedestrian type code and the value is the pedestrian type proportion.

Return value:

Pedestrian composition ID; returns -1 if creation fails.

**bool removePedestrianComposition(long compositionId)**

Remove pedestrian composition.

Parameters:

[ in ] compositionID: Pedestrian composition ID.

**bool updatePedestrianComposition(long compositionID，QMap\<int, qreal\> mpCompositionRatio)**

Update pedestrian composition.

Parameters:

[ in ] compositionID: Pedestrian composition ID.

[ in ] mpCompositionRatio: Composition details, where the key is the pedestrian type code and the value is the pedestrian type proportion.

Return value:

Indicates whether the update was successful.

#### 3.3.2.32. Pedestrian Surface Domain Hierarchy

**QList\<Online::Pedestrian::LayerInfo\> layerInfos()**

Retrieve all hierarchy information.

**Online::Pedestrian::LayerInfo addLayerInfo(QString name，qreal height，bool visible，bool locked)**

Add a new hierarchy; returns the added hierarchy information.

Parameters:

[ in ] name: Layer name.

[ in ] height: Layer height.

[ in ] visible: Visibility flag.

[ in ] locked: Lock status; when locked, subsequent fields cannot be modified.

**void removeLayerInfo(long layerId)**

Deleting a layer will remove all elements contained within it.

Parameters:

[ in ] layerID: Layer ID.

**bool updateLayerInfo(long layerID，QString name，qreal height，bool visible，bool locked)**

Update layer information.

Parameters:

[ in ] layerID: Layer ID.

[ in ] name: Layer name.

[ in ] height: Layer height.

[ in ] visible: Visibility flag.

[ in ] locked: Lock status; when locked, subsequent fields cannot be modified.

Return value:

Indicates whether the update was successful.

#### 3.3.2.33. Pedestrian polygonal areas

**QList\<IPedestrianRegion\*\> pedestrianRegions()**

Retrieve the sequence of all pedestrian polygonal area objects.

**QList\<IPedestrianRectRegion\*\> pedestrianRectRegions()**

Retrieve the sequence of all rectangular polygonal area objects.

**QList\<IPedestrianTriangleRegion\*\> pedestrianTriangleRegions()**

Retrieve the sequence of all triangular polygonal area objects.

**QList\<IPedestrianEllipseRegion\*\> pedestrianEllipseRegions()**

Retrieve the sequence of all elliptical polygonal area objects.

**QList\<IPedestrianFanShapeRegion\*\> pedestrianFanShapeRegions()**

Retrieve the sequence of all sector-shaped polygonal area objects.

**QList\<IPedestrianPolygonRegion\*\> pedestrianPolygonRegions()**

Retrieve the sequence of all polygon objects.

**QList\<IPedestrianSIDeWalkRegion\*\> pedestrianSIDeWalkRegions()**

Retrieve the sequence of all sidewalk objects.

**QList\<IPedestrianCrossWalkRegion\*\> pedestrianCrossWalkRegions()**

Retrieve the sequence of all pedestrian crossing objects.

**IPedestrianRegion\* findPedestrianRegion(long id)**

Retrieve the pedestrian area object by Polygon ID.

**IPedestrianRectRegion\* findPedestrianRectRegion(long id)**

Retrieve the rectangular area object by Polygon ID.

**IPedestrianEllipseRegion\* findPedestrianEllipseRegion(long id)**

Retrieve the elliptical area object by Polygon ID.

**IPedestrianTriangleRegion\* findPedestrianTriangleRegion(long id)**

Retrieve the triangular area object by Polygon ID.

**IPedestrianFanShapeRegion\* findPedestrianFanShapeRegion(long id)**

Retrieve the sector area object by Polygon ID.

**IPedestrianPolygonRegion\* findPedestrianPolygonRegion(long id)**

Retrieve the polygon area object by Polygon ID.

**IPedestrianSIDeWalkRegion\* findPedestrianSIDeWalkRegion(long id)**

Retrieve the sidewalk object by Polygon ID.

**IPedestrianCrossWalkRegion\* findPedestrianCrossWalkRegion(long id)**

Retrieve the pedestrian crossing object by Polygon ID.

**IPedestrianRectRegion\* createPedestrianRectRegion(QPointF startPoint，QPointF endPoint)**

Create a rectangular pedestrian area.

Parameters:

[ in ] startPoint: Top-left coordinate.

[ in ] endPoint: Bottom-right coordinate.

Return	

Rectangular pedestrian area object.

**IPedestrianTriangleRegion\* createPedestrianTriangleRegion(QPointF startPoint，QPointF endPoint)**

Create triangular pedestrian area.

Parameters:

[ in ] startPoint: Top-left coordinate.

[ in ] endPoint: Bottom-right coordinate.

Return value:

Triangular pedestrian area object.

**IPedestrianEllipseRegion\* createPedestrianEllipseRegion(QPointF startPoint，QPointF endPoint)**

Create elliptical pedestrian area.

Parameters:

[ in ] startPoint: Top-left coordinate.

[ in ] endPoint: Bottom-right coordinate.

Return value:	

Elliptical pedestrian area object.

**IPedestrianFanShapeRegion\* createPedestrianFanShapeRegion(QPointF startPoint，QPointF endPoint)**

Create sector-shaped pedestrian area.

Parameters:

[ in ] startPoint: Center coordinate.

[ in ] endPoint: Outer radius endpoint coordinate.

Return value:

Sector-shaped pedestrian area object.

**IPedestrianPolygonRegion\* createPedestrianPolygonRegion(QPolygonF polygon)**

Create polygonal pedestrian area.

Parameters:

[ in ] polygon: Polygon vertices.

Return value:

Polygonal pedestrian area object.

**IPedestrianSIDeWalkRegion\* createPedestrianSIDeWalkRegion(QList\<QPointF\> vertexs)**

Create a sidewalk.

Parameters:

[ in ] vertexs: list of vertices.

Return value:	

Sidewalk object.

**IPedestrianCrossWalkRegion\* createPedestrianCrossWalkRegion(QPointF startPoint，QPointF endPoint)**

Create a crosswalk.

Parameters:

[ in ] startPoint: Top-left coordinate.

[ in ] endPoint: Bottom-right coordinate.

Return value:

Crosswalk object.

**IPedestrianStairRegion\* createPedestrianStairRegion(QPointF startPoint，QPointF endPoint)**

Create a staircase.

Parameters:

[ in ] startPoint: start coordinates.

[ in ] endPoint: end coordinates.

Return value:	

Staircase object.

**void removePedestrianRectRegion(IPedestrianRectRegion\* pIPedestrianRectRegion)**

Delete a rectangular pedestrian region.

Parameters:

[ in ] pIPedestrianRectRegion: rectangular pedestrian region object.

**void removePedestrianTriangleRegion(IPedestrianTriangleRegion\* pIPedestrianTriangleRegion)**

Delete a triangular pedestrian region.

Parameters:

[ in ] pIPedestrianTriangleRegion: triangular pedestrian region object.

**void removePedestrianEllipseRegion(IPedestrianEllipseRegion\* pIPedestrianEllipseRegion)**

Delete an elliptical pedestrian region.

Parameters:

[ in ] pIPedestrianEllipseRegion: elliptical pedestrian region object.

**void removePedestrianFanShapeRegion(IPedestrianFanShapeRegion\* pIPedestrianFanShapeRegion)**

Delete pedestrian fan-shaped region.

Parameters:

[ in ] pIPedestrianFanShapeRegion: fan-shaped pedestrian region object.

**void removePedestrianPolygonRegion(IPedestrianPolygonRegion\* pIPedestrianPolygonRegion)**

Delete pedestrian polygon region.

Parameters:

[ in ] pIPedestrianPolygonRegion: pedestrian polygon region object.

**void removePedestrianSIDeWalkRegion(IPedestrianSIDeWalkRegion\* pIPedestrianSIDeWalkRegion)**

Delete sidewalk.

Parameters:

[ in ] pIPedestrianSIDeWalkRegion: sidewalk object.

**void removePedestrianCrossWalkRegion(IPedestrianCrossWalkRegion\* pIPedestrianCrossWalkRegion)**

Delete pedestrian crosswalk.

Parameters:

[ in ] pIPedestrianCrossWalkRegion: pedestrian crosswalk object.

**void removePedestrianStairRegion(IPedestrianStairRegion\* pIPedestrianStairRegion)**

Delete staircase.

Parameters:

[ in ] pIPedestrianStairRegion: staircase object.

#### 3.3.2.34. Pedestrian Origin Point

**QList\<IPedestrianPathPoint\*\> pedestrianPathStartPoints()**

Retrieve the sequence of all pedestrian origin point objects.

**IPedestrianPathPoint\* findPedestrianPathStartPoint(long id)**

Get pedestrian origin point object by pedestrian origin point ID.

**Online::Pedestrian::PedestrianPathStartPointConfigInfo findPedestrianStartPointConfigInfo(long id)**

Retrieve pedestrian generation point configuration information by pedestrian generation point ID.

**IPedestrianPathPoint\* createPedestrianPathStartPoint(QPointF scenePos)**

Create a pedestrian generation point.

Parameters:

[ in ] scenePos: scene coordinates.

Return value:	

Pedestrian generation point object.

**void removePedestrianPathStartPoint(IPedestrianPathPoint\* pIPedestrianPathStartPoint)**

Delete a pedestrian generation point.

Parameters:

[ in ] pIPedestrianPathStartPoint: pedestrian generation point object.

**bool updatePedestrianStartPointConfigInfo(Online::Pedestrian::PedestrianPathStartPointConfigInfo info)**

Update pedestrian generation point configuration information.

Parameters:

[ in ] info: pedestrian generation point configuration information.

Return value:	

Indicates whether the update was successful.

#### 3.3.2.35. Pedestrian End Point

**QList\<IPedestrianPathPoint\*\> pedestrianPathEndPoints()**

Retrieve the sequence of all pedestrian end point objects.

**IPedestrianPathPoint\* findPedestrianPathEndPoint(long id)**

Retrieve pedestrian end point object by ID.

**IPedestrianPathPoint\* createPedestrianPathEndPoint(QPointF scenePos)**

Create a pedestrian end point.

Parameters:

[ in ] scenePos: scene coordinates.

Return value:

Pedestrian end point object.

**void removePedestrianPathEndPoint(IPedestrianPathPoint\* pIPedestrianPathEndPoint)**

Delete a pedestrian end point.

Parameters:

[ in ] pIPedestrianPathEndPoint: pedestrian end point object.

#### 3.3.2.36. Pedestrian Decision Point

**QList\<IPedestrianPathPoint\*\> pedestrianPathDecisionPoints()**

Retrieve the sequence of all Pedestrian Decision Point objects.

**IPedestrianPathPoint\* findPedestrianDecisionPoint(long id)**

Retrieve the Pedestrian Decision Point object by its ID.

**Online::Pedestrian::PedestrianDecisionPointConfigInfo findPedestrianDecisionPointConfigInfo(long id)**

Retrieve the configuration information of a Pedestrian Decision Point by its ID.

**IPedestrianPathPoint\* createPedestrianDecisionPoint(QPointF scenePos)**

Create a Pedestrian Decision Point.

Parameters:

[ in ] scenePos: scene coordinates.

Return value:

Pedestrian Decision Point object.

**void removePedestrianDecisionPoint(IPedestrianPathPoint\* pIPedestrianDecisionPoint)**

Delete a Pedestrian Decision Point.

Parameters:

[ in ] pIPedestrianDecisionPoint: Pedestrian Decision Point object.

**bool updatePedestrianDecisionPointConfigInfo(Online::Pedestrian::PedestrianDecisionPointConfigInfo info)**

Update the configuration information of a Pedestrian Decision Point.

Parameters:

[ in ] info: Configuration information of the Pedestrian Decision Point.

Return value:	

Indicates whether the update was successful.

#### 3.3.2.37. Pedestrian Path

**QList\<IPedestrianPath\*\> pedestrianPaths()**

Retrieve the sequence of all Pedestrian Path objects, including local paths.

**IPedestrianPath\* findPedestrianPath(long id)**

Retrieve the Pedestrian Path by its ID, including local paths.

**IPedestrianPath\* createPedestrianPath(IPedestrianPathPoint\* pStartPoint，IPedestrianPathPoint\* pEndPoint，QList\<QPointF\> mIDdlePoints)**

Create pedestrian Path (or local pedestrian Path).

Parameters:

[ in ] pStartPoint: pedestrian origin point (or pedestrian Decision Point).

[ in ] pEndPoint: pedestrian endpoint.

[ in ] mIDdlePoints: a set of mandatory intermediate points.

Return value:	

Pedestrian Path Object.

**void removePedestrianPath(IPedestrianPath\* pIPedestrianPath)**

Delete pedestrian Path.

Parameters:

[ in ] pIPedestrianPath: pedestrian Path Object.

#### 3.3.2.38. Pedestrian Traffic Signal

**QList\<ICrosswalkSignalLamp\*\> crosswalkSignalLamps()**

Retrieve all pedestrian crosswalk traffic signal object sequences.

**ICrosswalkSignalLamp\* findCrosswalkSignalLamp(long id)**

Retrieve pedestrian crosswalk traffic signal object by ID.

**void addCrossWalkSignalPhaseToLamp(int SignalPhaseID，ISignalLamp\* signalLamp)**

Add pedestrian traffic signal.

Parameters:

[ in ] SignalPhaseID: Signal Phase ID.

[ in ] signalLamp: Traffic Signal Object.

**ICrosswalkSignalLamp\* createCrossWalkSignalLamp(ISignalController\* pTrafficLight，QString name，long crosswalkID，QPointF scenePos，bool isPositive)**

Create pedestrian crosswalk traffic signal.

Parameters:

[ in ] pTrafficLight: Signal Controller Object.

[ in ] name: Traffic Signal name.

[ in ] crosswalkID: Crosswalk ID.

[ in ] scenePos: Scene coordinates within the crosswalk.

[ in ] isPositive: Indicates whether the control direction of the Traffic Signal is positive.

Return value:

Crosswalk Traffic Signal Object.

**void removeCrossWalkSignalLamp(ICrosswalkSignalLamp\* pICrosswalkSignalLamp)**

Delete the crosswalk Traffic Signal.

Parameters:

[ in ] pICrosswalkSignalLamp: Crosswalk Traffic Signal Object.

#### 3.3.2.39. Parking Lot Parking Headway Distribution

**QList\<Online::ParkingLot::DynaParkingTimeDis\> parkingTimeDis()**

Retrieve the list of parking lot parking headway distributions.

**Online::ParkingLot::DynaParkingTimeDis createParkingTimeDis(const Online::ParkingLot::DynaParkingTimeDis& param)**

Create a parking lot parking headway distribution.

Parameters:

[ in ] param: Parameters of the parking headway distribution.

**void removeParkingTimeDis(long id)**

Remove the parking lot parking headway distribution.

Parameters:

[ in ] ID: Parking Dwell Time Distribution ID.

**Online::ParkingLot::DynaParkingTimeDis updateParkingTimeDis(const Online::ParkingLot::DynaParkingTimeDis& param)**

Update the parking lot dwell time distribution.

Parameters:

[ in ] param: Parameters of the parking headway distribution.

#### 3.3.2.40. Parking Area

**QList\<IParkingRegion\*\> parkingRegions()**

Retrieve the list of all parking areas.

**IParkingRegion\* findParkingRegion(long id)**

Obtain the parking area by Parking Area ID.

**IParkingRegion\* createParkingRegion(const Online::ParkingLot::DynaParkingRegion& param)**

Create a parking area.

Parameters:

[ in ] param: Dynamic parking area information.

**void removeParkingRegion(IParkingRegion\* pIParkingRegion)**

Remove the parking area.

Parameters:

[ in ] pIParkingRegion: Parking area object.

**void removeParkingRegionById(long id)**

Remove the parking area by Parking Area ID.

Parameters:

[ in ] ID: Parking Area ID.

**IParkingRegion\* updateParkingRegion(const Online::ParkingLot::DynaParkingRegion& param)**

Update the parking area.

Parameters:

[ in ] param: Dynamic parking area information.

#### 3.3.2.41. Parking Path Decision Point

**QList\<IParkingDecisionPoint\*\> parkingDecisionPoints()**

Retrieve the complete sequence of Parking Path Decision Points.

**IParkingDecisionPoint\* findParkingDecisionPoint(long id)**

Obtain a Parking Path Decision Point object by its ID.

**IParkingDecisionPoint\* createParkingDecisionPoint(ILink\* pLink，qreal distance，QString name = QString())**

Create a Parking Path Decision Point.

Parameters:

​	[ in ] pLink: Road segment where the decision point is located.

​	[ in ] distance: Distance from the start of the road segment to the decision point. Unit: pixel.

[ in ] name: Name of the Decision Point.

**void removeParkingDecisionPoint(IParkingDecisionPoint\* pIParkingDecisionPoint)**

Remove a Parking Path Decision Point.

Parameters:

[ in ] pIParkingDecisionPoint: Parking Path Decision Point object.

**void removeParkingDecisionPointById(long id)**

Remove a Parking Path Decision Point by its ID.

Parameters:

[ in ] ID: Parking Path Decision Point ID.

#### 3.3.2.42. Parking Path

**IParkingRouting\* createParkingRouting(IParkingDecisionPoint\* pDeciPoint，IParkingRegion\* pIParkingRegion)**

Create a Parking Path.

Parameters:

[ in ] pDeciPoint: Parking Decision Point.

[ in ] pIParkingRegion: Parking Region.

**void removeParkingRouting(IParkingRouting\* pIParkingRouting)**

Remove parking path.

Parameters:

[ in ] pIParkingRouting: Parking decision point object.

**void removeParkingRoutingById(long id)**

Remove parking path by parking path ID.

Parameters:

[ in ] ID: Parking decision point ID.

#### 3.3.2.43. Toll Station Parking Headway Distribution

**QList\<Online::TollStation::DynaTollParkingTimeDis\> tollParkingTimeDis()**

Retrieve toll station parking headway distribution sequence.

**Online::TollStation::DynaTollParkingTimeDis createTollParkingTimeDis(const Online::TollStation::DynaTollParkingTimeDis& param)**

Create toll station parking headway distribution.

Parameters:

[ in ] param: Parameters of the parking headway distribution.

**void removeTollParkingTimeDis(long id)**

Remove toll station parking headway distribution.

Parameters:

[ in ] ID: Parking Dwell Time Distribution ID.

**Online::TollStation::DynaTollParkingTimeDis updateTollParkingTimeDis(const Online::TollStation::DynaTollParkingTimeDis& param)**

Update toll station parking headway distribution.

Parameters:

[ in ] param: Parameters of the parking headway distribution.

#### 3.3.2.44. Toll Lane

**QList\<ITollLane\*\> tollLanes()**

Retrieve all toll lane object sequences.

**ITollLane\* findTollLane(long id)**

Retrieve toll lane object by toll lane ID.

**ITollLane\* createTollLane(const Online::TollStation::DynaTollLane& param)**

Create toll lane.

Parameters:

[ in ] param: Dynamic toll lane information.

**void removeTollLane(ITollLane\* pITollLane)**

Remove toll lane.

Parameters:

[ in ] pITollLane: Toll lane object.

**void removeTollLaneById(long id)**

Remove toll lane by Toll Lane ID.

Parameters:

[ in ] ID: Toll Lane ID.

**ITollLane\* updateTollLane(const Online::TollStation::DynaTollLane& param)**

Update toll lane.

Parameters:

[ in ] param: Dynamic toll lane information.

#### 3.3.2.45. Toll Path Decision Point

**QList\<ITollDecisionPoint\*\> tollDecisionPoints()**

Retrieve the list of all toll path decision points.

**ITollDecisionPoint\* findTollDecisionPoint(long id)**

Retrieve a toll path decision point by ID.

**ITollDecisionPoint\* createTollDecisionPoint(ILink\* pLink，qreal distance，QString name = QString())**

Create a toll path decision point.

Parameters:

[ in ] pLink: Road segment where the decision point is located.

​	[ in ] distance: Distance from the start of the road segment to the decision point. Unit: pixel.

[ in ] name: Name of the Decision Point.

**void removeTollDecisionPoint(ITollDecisionPoint\* pITollDecisionPoint)**

Remove toll path decision point.

Parameters:

[ in ] pITollLane: Toll path decision point object.

**void removeTollDecisionPointById(long id)**

Remove toll path decision point by toll path decision point ID.

Parameters:

​	[ in ] ID: Toll Path Decision Point ID.

#### 3.3.2.46. Toll Path

**ITollRouting\* createTollRouting(ITollDecisionPoint\* pDeciPoint，ITollLane\* pITollLane)**

​	Create a toll path.

Parameters:

​	[ in ] pDeciPoint: Toll Decision Point.

​	[ in ] pITollLane: Toll Lane.

**void removeTollRouting(ITollRouting\* pITollRouting)**

​	Remove a toll path.

Parameters:

​	[ in ] pITollRouting: Toll Path Object.

**void removeTollRoutingById(long id)**

​	Remove toll path by ID.

Parameters:

​	[ in ] ID: Toll Path ID.

#### 3.3.2.47. Node

**QMap\<long, IJunction\*\> getAllJunctions()**

​	Retrieve all node object sequences.

**IJunction\* findJunction(long junctionId)**

​	Retrieve a node object by ID.

**IJunction\* createJunction(QPointF startPoint，QPointF endPoint，QString name)**

​	Create a node.

Parameters:

​	[ in ] startPoint: Upper-left starting point coordinate.

​	[ in ] endPoint: Lower-right ending point coordinate.

​	[ in ] name: Node name.

Return value:

Node object.

**bool removeJunction(long junctionId)**

Delete node.

Parameters:

[ in ] junctionID: Node ID.

Return value:

Indicates whether the removal was successful.

**bool updateJunctionName(long junctionID，QString name)**

Update node name.

Parameters:

[ in ] junctionID: Node ID.

[ in ] name: New node name.

**QHash\<long, QHash\<long, Online::Junction::FlowTurning\>\> getJunctionFlows(long junctionId)**

Retrieve node turning movement information.

Parameters:

[ in ] junctionID: Node ID.

Return value:

Node turning movement information map.

**bool updateFlow(long timeID，long junctionID，long turningID，long inputFlowValue)**

Update turning flow.

Parameters:

[ in ] timeID: Time period ID.

[ in ] junctionID: Node ID.

[ in ] turningID: Turning movement ID.

[ in ] inputFlowValue: Input flow value (veh/h).

Return value:

Indicates whether the update was successful.

**bool updateFlowAlgorithmParams(double theta，double bpra，double bprb，long maxIterateNum，bool useNewPath)**

Update flow algorithm parameters.

Parameters:

[ in ] theta: Parameter θ (0.01–1).

[ in ] bpra: BPR link impedance parameter A (0.05–0.5).

[ in ] bprb: BPR link impedance parameter B (1–10).

[ in ] maxIterateNum: Maximum number of iterations (1–5000).

[ in ] useNewPath: Indicates whether to reconstruct the static Path.

Return value:

Indicates whether the update was successful.

**bool updatePathBuildParams(bool deciPointPosFlag，bool laneConnectorFlag，long minPathNum = 3)**

Update the Path construction parameters.

Parameters:

[ in ] deciPointPosFlag: Indicates whether to consider the Decision Point position.

[ in ] laneConnectorFlag: Indicates whether to consider the Lane connection.

[ in ] minPathNum: Minimum number of Paths (default is 3).

Return value:

Indicates whether the update was successful.

**QMap\<QPair\<long, long\>, QVector\<QList\<ILink\*\>\>\> buildAndApplyPaths()**

Construct and apply the Path.

Return value:

Mapping table of Path result information.

**QHash\<long, QList\<Online::Junction::FlowTurning\>\> calculateFlows()**

Calculate and apply flow results.

Return value:

Mapping table of time period ID to flow calculation results.

#### 3.3.2.48. Node Time Period

**QList\<Online::Junction::FlowTimeInterval\> getFlowTimeIntervals()**

Retrieve all Node Time Periods.

**Online::Junction::FlowTimeInterval addFlowTimeInterval()**

Add a Node Time Period.

Return value:

Node Time Period information.

**bool deleteFlowTimeInterval(long timeId)**

Delete a Node Time Period.

Parameters:

[ in ] timeID: Node Time Period ID.

Return value:

Indicates whether the deletion was successful.

**Online::Junction::FlowTimeInterval updateFlowTimeInterval(long timeID，long startTime，long endTime)**

Update time interval.

Parameters:

[ in ] timeID: Node Time Period ID.

[ in ] startTime: Start time. Unit: s.

[ in ] endTime: End time. Unit: s.

### 3.3.3. Simulation Interface (SimuInterface)

Header file: simuinterface.h

SimuInterface is a sub-interface of TessInterface. Through this interface, the simulation can be started, paused, and stopped. It also enables setting simulation precision, retrieving vehicle objects and vehicle states during the simulation process, and obtaining both sample and aggregated data detected by various detectors.

#### 3.3.3.1. Simulation Configuration

**long simuIntervalScheming()**

Get the simulation duration. Unit: s.

**void setSimuIntervalScheming(long interval)**

Set the simulation duration. A value of 0 indicates unlimited duration. Unit: s.

**int simuAccuracy()**

Get the simulation precision.

**void setSimuAccuracy(int accuracy)**

Set the simulation precision, i.e., the number of calculation steps per second.

**int acceMultiples()**

Get the simulation acceleration factor.

**void setAcceMultiples(int multiples)**

Set the simulation acceleration factor.


**bool byCpuTime()**

Specify whether simulation time is governed by real time. Within a single computation cycle, there exist two types of time: one is the elapsed real time, and the other is the simulation time determined by the simulation precision. For instance, if the simulation precision is 20 steps per second, one simulation step corresponds to 50 milliseconds of simulation time. By default, the simulation time per computation cycle is determined by the simulation precision. During online simulation, if computational power is insufficient, a discrepancy will arise between the simulation time determined by the simulation precision and the actual real time.

**void setByCpuTime(bool bByCpuTime)**

Set whether simulation time is governed by real time. If set to true, the time elapsed during each simulation cycle in real life will be applied as the simulation time, thereby synchronizing simulation time with real time.

**bool isRecordTrace()**

Get whether vehicle trajectory recording is enabled.

**void setIsRecordTrace(bool bRecord)**

Set whether vehicle trajectory recording is enabled.

**void setThreadCount(int count)**

Set the number of working threads.

**long batchNumber()**

Get the current simulation batch.

**qreal batchIntervalReally()**

Get the actual time of the current batch. Unit: ms.

**long simuTimeIntervalWithAcceMutiples()**

Get the current simulated time. Unit: ms.

**qint64 startMSecsSinceEpoch()**

Get the real start time of the simulation. Unit: ms.

**qint64 stopMSecsSinceEpoch()**

Get the real end time of the simulation. Unit: ms.

#### 3.3.3.2. Simulation Status

**bool isRunning()**

Get whether the simulation is running.

**bool isPausing()**

Get whether the simulation is paused.

**void startSimu()**

Start the simulation.

**void pauseSimu()**

Pause the simulation.

**void stopSimu()**

Stop the simulation.

**void pauseSimuOrNot()**

Pause or resume the simulation. If the simulation is currently running, this method pauses it; if it is paused, this method resumes it.

#### 3.3.3.3. Vehicle

**long vehiCountTotal()**

Retrieve the total number of vehicles, including those created but not yet entered into the road network, vehicles currently running, and vehicles that have exited the road network.

**long vehiCountRunning()**

Retrieve the number of vehicles currently running at the current simulation time.

**IVehicle\* getVehicle(long vehiId)**

Retrieve the vehicle object by vehicle ID.

**QList\<IVehicle\*\> allVehicle()**

Retrieve the complete sequence of all vehicle objects.

**QList\<IVehicle\*\> allVehiStarted()**

Retrieve the sequence of all vehicle objects currently running at the current simulation time.

Example:

```cpp
// Obtain the list of currently running vehicles
QList<IVehicle*> allVehicles = simuiface->allVehiStarted();
for (IVehicle* vehicle : allVehicles) 
{
    qDebug() << "车辆ID：" << vehicle->id();
    qDebug() << "车辆名称：" << vehicle->name();
    qDebug() << "车辆类型编码：" << vehicle->vehicleTypeCode();
    qDebug() << "车辆类型名称：" << vehicle->vehicleTypeName();
    qDebug() << "车辆长度：" << vehicle->length(UnitOfMeasure::Metric) << " m";

    qDebug() << "车辆当前横坐标：" << vehicle->pos(UnitOfMeasure::Metric).x() << " m";
    qDebug() << "车辆当前纵坐标：" << vehicle->pos(UnitOfMeasure::Metric).y() << " m";
    qDebug() << "车辆当前高程：" << vehicle->v3z() << " m";
    qDebug() << "车辆当前所在道路ID：" << vehicle->roadId();
    qDebug() << "车辆当前所在道路名称：" << vehicle->roadName();
    qDebug() << "车辆当前是否在路段：" << (vehicle->roadIsLink() ? "是" : "否");
    qDebug() << "车辆当前所在车道ID：" << vehicle->laneId();
    if (vehicle->roadIsLink()) 
    {
        qDebug() << "车辆当前所在车道序号：" << vehicle->vehicleDriving()->laneNumber();
    }
    qDebug() << "车辆当前与车道起点的间距：" << vehicle->vehicleDriving()->distToStartPoint(true, true, UnitOfMeasure::Metric)  << " m";
    
    qDebug() << "车辆当前速度：" << vehicle->currSpeed(UnitOfMeasure::Metric) * 3.6 << " km/h";
    qDebug() << "车辆当前期望速度：" << vehicle->vehicleDriving()->desirSpeed(UnitOfMeasure::Metric) * 3.6 << " km/h";
    qDebug() << "车辆当前加速度：" << vehicle->acce(UnitOfMeasure::Metric) << " m/s²";
    qDebug() << "车辆当前朝向角：" << vehicle->angle() << " °";
}
```

**QList\<IVehicle\*\> vehisInLink(long linkId)**

Retrieve the sequence of vehicle objects on the road segment specified by ID at the current simulation time.

**QList\<IVehicle\*\> vehisInLane(long laneId)**

Retrieve the sequence of vehicle objects on the lane specified by ID at the current simulation time.

**QList\<IVehicle\*\> vehisInConnector(long connectorId)**

Retrieve the sequence of vehicle objects on the connection segment specified by ID at the current simulation time.

**QList\<IVehicle\*\> vehisInLaneConnector(long connectorID，long fromLaneID，long toLaneId)**

Retrieve the sequence of vehicle objects on the lane connection identified by connection segment ID, upstream lane ID, and downstream lane ID at the current simulation time.

Parameters:

[ in ] connectorID: Connection segment ID.

[ in ] fromLaneID: Upstream Lane ID.

[ in ] toLaneID: Downstream Lane ID.

Return value:

Sequence of Vehicle Objects.

**QList\<Online::VehicleStatus\> getVehisStatus(long batchNumber = 0，UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the status of all vehicles currently in operation.

Parameters:

[ in ] batchNumber: Batch number.

Return value:

Sequence of vehicle statuses.

**QList\<Online::VehiclePosition\> getVehiTrace(long vehiID，UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the travel trajectory of a specified vehicle. Unit: pixel.

Parameters:

[ in ] vehiID: Vehicle ID.

Return value:

Sequence of vehicle trajectory points.

**IVehicle\* createGVehicle(Online::DynaVehiParam dynaVehi)**

Create a vehicle.

Parameters:

[ in ] dynaVehi: Dynamic vehicle information.

Return value:

Vehicle Object.

```cpp
// Create vehicle on link
// Build parameters
Online::DynaVehiParam dvp1;
// Vehicle type ID
dvp1.vehiTypeCode = 1;
// Link ID
dvp1.roadId = 4;
// Lane number
dvp1.laneNumber = 0;
// Position, unit: m
dvp1.dist = m2p(50);
// Speed, unit: m/s
dvp1.speed = m2p(20);
// Color
dvp1.color = "#00AFF0";
// Create vehicle dynamically
IVehicle* vehicle1 = simuiface->createGVehicle(dvp1);
if (vehicle1)
{
    qDebug() << "在路段上创建了车辆，其ID为：" << vehicle1.id();
}

// Create vehicle on connector
// Build parameters
Online::DynaVehiParam dvp2;
// Vehicle type ID
dvp2.vehiTypeCode = 1;
// Connector ID
dvp2.roadId = 4;
// Lane number of upstream link
dvp2.laneNumber = 0;
// Lane number of downstream link
dvp2.toLaneNumber = 0;
// Position, unit: m
dvp2.dist = m2p(50);
// Speed, unit: m/s
dvp2.speed = m2p(20);
// Color
dvp2.color = "#00AFF0";
// Create vehicle dynamically
IVehicle* vehicle2 = simuiface->createGVehicle(dvp2);
if (vehicle2)
{
    qDebug() << "在连接段上创建了车辆，其ID为：" << vehicle2.id();
}
```

**IVehicle\* createBus(IBusLine\* pBusLine，qreal startSimuDateTime)**

Create a bus.

Parameters:

[ in ] pBusLine: Bus line object.

[ in ] startSimuDateTime: Departure time. Unit: ms.

#### 3.3.3.4. Pedestrians

**QList\<IPedestrian\*\> allPedestrianStarted()**

Retrieve the sequence of all pedestrians currently active.

**QList\<Online::Pedestrian::PedestrianStatus\> getPedestriansStatusByRegionId(long regionId)**

Obtain the state information of all pedestrians within the polygon at the current time by Polygon ID.

Parameters:

[ in ] regionID: Polygon ID.

Return value:

Sequence of pedestrian state information.

#### 3.3.3.5. Traffic Signal

**QList\<Online::SignalPhaseColor\> getSignalPhasesColor()**

Retrieve the colors of all traffic signal control phases at the current time.

Return value:

Sequence of phase colors.

Example:

```cpp
QList<Online::SignalPhaseColor> allSignalPhaseColor = simuiface->getSignalPhasesColor();
for (auto signalPhaseColor: allSignalPhaseColor)
{
    qDebug() << "信号机ID：" << signalPhaseColor.signalGroupId;
    qDebug() << "信控相位ID：" << signalPhaseColor.phaseId;
    qDebug() << "信控相位序号：" << signalPhaseColor.phaseNumber;
    qDebug() << "当前颜色：" << signalPhaseColor.color;
    qDebug() << "当前颜色的设置时间(ms)：" << signalPhaseColor.mrIntervalSetted;
    qDebug() << "当前颜色的已持续时间(ms)：" << signalPhaseColor.mrIntervalByNow;
}
```

#### 3.3.3.6. Data Collector

**QList\<Online::VehiInfoCollected\> getVehisInfoCollected()**

Retrieve all vehicle information collected by data collectors that have completed crossing at the current time.

Example:

```cpp
QList<Online::VehiInfoCollected> allVehiInfoCollected = simuiface->getVehisInfoCollected();
for (auto vehiInfo: allVehiInfoCollected)
{
    qDebug() << "采集器ID：" << vehiInfo.collectorId;
    qDebug() << "仿真时间(s)：" << vehiInfo.simuInterval;
    qDebug() << "车辆ID：" << vehiInfo.vehiId;
}
```

**QList\<Online::VehiInfoAggregated\> getVehisInfoAggregated()**

Retrieve the aggregated data collected by data collectors within the most recent aggregation interval.

Example:

```cpp
QList<Online::VehiInfoAggregated> allVehiInfoAggregated = simuiface->getVehisInfoAggregated();
for (auto vehiInfoAgg: allVehiInfoAggregated)
{
    qDebug() << "采集器ID：" << vehiInfoAgg.collectorId;
    qDebug() << "时间段ID：" << vehiInfoAgg.timeId;
    qDebug() << "起始时间(s)：" << vehiInfoAgg.fromTime;
    qDebug() << "结束时间(s)：" << vehiInfoAgg.toTime;
    qDebug() << "车辆数(veh)：" << vehiInfoAgg.vehiCount;
    qDebug() << "平均速度(km/h)：" << vehiInfoAgg.avgSpeed;
    qDebug() << "平均占有率：" << vehiInfoAgg.occupancy;
}
```

#### 3.3.3.7. Queue Counter

**QList\<Online::VehiQueueCounted\> getVehisQueueCounted()**

Retrieve the vehicle queue information counted by the queue counter at the current time.

Example:

```cpp
QList<Online::VehiQueueCounted> allVehiQueueCounted = simuiface->getVehisQueueCounted();
for (auto vehiQueue: allVehiQueueCounted)
{
    qDebug() << "计数器ID：" << vehiQueue.counterId;
    qDebug() << "仿真时间(s)：" << vehiQueue.simuTime;
    qDebug() << "排队车辆数(veh)：" << vehiQueue.vehiCount;
    qDebug() << "排队长度(m)：" << vehiQueue.queueLength;
}
```

**QList\<Online::VehiQueueAggregated\> getVehisQueueAggregated()**

Retrieve aggregated data collected by the queue counter during the most recent aggregation interval.

Example:

```cpp
QList<Online::VehiQueueAggregated> allVehiQueueAggregated = simuiface->getVehisQueueAggregated();
for (auto vehiQueueAgg: allVehiQueueAggregated)
{
    qDebug() << "计数器ID：" << vehiQueueAgg.counterId;
    qDebug() << "时间段ID：" << vehiQueueAgg.timeId;
    qDebug() << "起始时间(s)：" << vehiQueueAgg.fromTime;
    qDebug() << "结束时间(s)：" << vehiQueueAgg.toTime;
    qDebug() << "平均排队车辆数(veh)：" << vehiQueueAgg.avgVehiCount;
    qDebug() << "平均排队长度(m)：" << vehiQueueAgg.avgQueueLength;
    qDebug() << "最大排队长度(m)：" << vehiQueueAgg.maxQueueLength;
    qDebug() << "最小排队长度(m)：" << vehiQueueAgg.minQueueLength;
}
```

**bool queueRecently(long queueCounterID，qreal& queueLength，int& vehiCount，UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the latest queue length and number of queued vehicles from the queue counter.

Parameters:

[ in ] queueCounterID: Queue counter identifier.

[ out ] queueLength: Queue length.

[ out ] vehiCount: Number of queued vehicles.

Return value:

Indicates whether the retrieval was successful.

#### 3.3.3.8. Travel Time Detector

**QList\<Online::VehiTravelDetected\> getVehisTravelDetected()**

Retrieve the trip time detection information completed by the travel time detector at the current time.

Example:

```cpp
QList<Online::VehiTravelDetected> allVehiTravelDetected = simuiface->getVehisTravelDetected();
for (auto vehiTravel: allVehiTravelDetected)
{
    qDebug() << "检测器ID：" << vehiTravel.detectedId;
    qDebug() << "车辆ID：" << vehiTravel.vehiId;
    qDebug() << "行驶时间(s)：" << vehiTravel.travelTime;
    qDebug() << "行驶距离(m)：" << vehiTravel.travelDistance;
    qDebug() << "延误(s)：" << vehiTravel.delay;
}
```

**QList\<Online::VehiTravelAggregated\> getVehisTravelAggregated()**

Retrieve aggregated data collected by the travel time detector during the most recent aggregation interval.

Example:

```cpp
QList<Online::VehiTravelAggregated> allVehiTravelAggregated = simuiface->getVehisTravelAggregated();
for (auto vehiTravelAgg: allVehiTravelAggregated)
{
    qDebug() << "检测器ID：" << vehiTravelAgg.detectedId;
    qDebug() << "时间段ID：" << vehiTravelAgg.timeId;
    qDebug() << "起始时间(s)：" << vehiTravelAgg.fromTime;
    qDebug() << "结束时间(s)：" << vehiTravelAgg.toTime;
    qDebug() << "车辆数：" << vehiTravelAgg.vehiCount;
    qDebug() << "平均行程时间(s)：" << vehiTravelAgg.avgTravelTime;
    qDebug() << "平均行程距离(m)：" << vehiTravelAgg.avgTravelDistance;
    qDebug() << "平均延误(s)：" << vehiTravelAgg.avgDelay;
}
```

### 3.3.4. GUI Interface (GuiInterface)

Header file: guiinterface.h	

GuiInterface is a sub-interface of TessInterface. Through this interface, users can access and control TESS NG’s main window, menu bar, toolbar, and status bar, enabling the creation of menus and custom forms on the main interface.

#### 3.3.4.1. Window

**QMainWindow\* mainWindow()**

Obtain the main window of TESS NG.

#### 3.3.4.2. Menu Bar

**QMenuBar\* menuBar()**

Obtain the menu bar container of TESS NG.


#### 3.3.4.3. Toolbar

**QToolBar\* addToolBar(const QString& name)**

Add a custom toolbar.

Parameters:

[ in ] name: Name of the toolbar.

Return value:

Toolbar object.

**QToolBar\* insertToolBar(QToolBar* before，const QString& name)**

Insert a new toolbar before the specified toolbar.

Parameters:

[ in ] before: The existing toolbar before which the new toolbar will be inserted.

[ in ] name: Name of the toolbar.

Return value:

Toolbar object.



## 3.4. Objects

Objects in TESS NG are categorized into **road network objects** and **simulation objects**. Road network objects include road segments, connection segments, etc., while simulation objects include vehicles and pedestrians.

### 3.4.1. Road Network

#### 3.4.1.1. Road Network (IRoadNet)

Header file: IRoadNet.h

Road network basic information interface. This interface is designed to enable TESS NG to retain attributes of imported external road networks, such as the road network center coordinates and geodetic coordinates.

**long id()**

Retrieve the road network ID, corresponding to the number displayed in the road network editing dialog.

**QString netName()**

Retrieve the road network name.

**QString url()**

Source data path, which may be a local file or a network address.

**QString type()**

Source classification: "TESSNG" indicates native TESS NG creation; "OpenDrive" indicates import from OpenDrive data; "GeoJson" indicates import from GeoJSON data.

**QString bkgUrl()**

Retrieve the background path.

**QString explain()**

Retrieve the road network description.

**QJsonObject otherAttrs()**

Other attribute JSON data.

**QPointF centerPoint(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the center position of the road network. Unit: Pixel.

#### 3.4.1.2. Road Base Class (ISection)

Header file: ISection.h

The road base class serves as the superclass of Road Segment and Connection Segment.

**int gtype()**

Type: GLinkType or GConnectorType. GLinkType represents a Road Segment; GConnectorType represents a Connection Segment.

**bool isLink()**

Indicates whether it is a Road Segment.

**long id()**

Get the ID. If it is a Link, the ID corresponds to the Link's ID; if it is a Connection Segment, the ID corresponds to the Connection Segment's ID.

**long sectionId()**

Get the ID. If it is a Link, the ID corresponds to the Link's ID; if it is a Connection Segment, the ID corresponds to the Connection Segment's ID plus 10000000, thereby distinguishing between Road Segment and Connection Segment.

**QString name()**

Get the Section name, either the Road Segment name or the Connection Segment name.

**void setName(QString name)**

Set the Section name.

**qreal v3z(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the Section elevation. Unit: Pixel.

**qreal length(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the length of the Section. Unit: Pixel.

**QList\<ILaneObject\*\> laneObjects()**

Base interface list of Lane and Lane connection.

**ISection\* fromSection(long id)**

Obtain the upstream Section by ID. If the current object is a Road Segment, returns nullptr for id 0; otherwise, returns the upstream Connection segment with the specified ID. If the current object is a Connection segment, returns the upstream Road Segment for id 0; otherwise, returns nullptr.

**ISection\* toSection(long id)**

Obtain the downstream Section by ID. If the current object is a Road Segment, returns nullptr for id 0; otherwise, returns the downstream Connection segment with the specified ID. If the current object is a Connection segment, returns the downstream Road Segment for id 0; otherwise, returns nullptr.

**void setOtherAttr(QJsonObject otherAttr)**

Set additional attributes of the Road Segment or Connection segment.

**ILink\* castToLink()**

Cast to ILink; returns nullptr if the current instance is a Connection segment.

**IConnector\* castToConnector()**

Cast to IConnector; returns nullptr if the current instance is a Road Segment.

**QPolygonF polygon()**

Retrieve the polygon formed by the vertices of the Section’s polygonal outline.

#### 3.4.1.3. Road Segment (ILink)

Header file: ilink.h

**int gtype()**

Type, returns GLinkType.

**long id()**

Get Road Segment ID.

**qreal length(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get Road Segment length. Unit: Pixel.

**qreal width(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get Road Segment width. Unit: Pixel.

**qreal z(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get Road Segment elevation. Unit: Pixel.

**qreal v3z(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get Road Segment elevation, an overload of the ISection method. Unit: Pixel.

**QString name()**

Get Road Segment Name.

**void setName(QString name)**

Set Road Segment Name.

**QString linkType()**

Get Road Segment type, e.g.: urban arterial road, urban secondary road, sidewalk, etc.

**void setType(QString type)**

Set Road Segment type. There are 10 types: highway, urban expressway, ramp, urban primary road, secondary road, local street, non-motorized vehicle lane, sidewalk, bus-only lane, and shared motorized and non-motorized lane.

**int laneCount()**

Get the number of lanes.

**double limitSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the maximum speed limit of the road segment. Unit: km/h.

**void setLimitSpeed(qreal speed，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set the maximum speed limit of the road segment. Unit: km/h.

Parameters: 

[ in ] speed: Speed limit value.

**qreal minSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the minimum speed limit of the road segment. Unit: km/h.

**QList\<ILane\*\> lanes()**

List of lane interfaces.

**QList\<ILaneObject\*\> laneObjects()**

List of interfaces for lanes and lane connections.

**QList\<QPointF\> centerBreakPoints(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the set of centerline breakpoints of the road segment. Unit: pixel.

**QList\<QPointF\> leftBreakPoints(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the set of left boundary breakpoints of the road segment. Unit: pixel.

**QList\<QPointF\> rightBreakPoints(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the set of right boundary breakpoints of the road segment. Unit: pixel.

**QList< QVector3D\> centerBreakPoint3Ds(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the set of 3D centerline breakpoints of the road segment. Unit: pixel.

**QList\<QVector3D\> leftBreakPoint3Ds(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the set of 3D left boundary breakpoints of the road segment. Unit: pixel.

**QList\<QVector3D\> rightBreakPoint3Ds(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the set of 3D right boundary breakpoints of the road segment. Unit: pixel.

**QList\<IConnector\*\> fromConnectors()**

Obtain the list of upstream connection segments.

**QList\<IConnector\*\> toConnectors()**

Obtain the list of downstream connection segments.

**void setOtherAttr(QJsonObject otherAttr)**

Set additional attributes of the road segment.

**QJsonObject otherAttr()**

Retrieve additional attributes of the road segment.

**void setLaneTypes(QList\<QString\> lType)**

Set lane attributes. Attribute types include: "motor vehicle lane", "motor-non-motor shared lane", "non-motor vehicle lane", "bus-only lane". Lane order is from right to left.

**void setLaneOtherAtrrs(QList\<QJsonObject\> lAttrs)**

Set additional attributes of the lane.

**qreal distToStartPoint(const QPointF p，UnitOfMeasure unit = UnitOfMeasure::Default)**

Distance from a point on the centerline to the start point. Unit: Pixel.

Parameters: 

[ in ] p: Coordinates of the current point.

**bool getPointByDist(qreal dist，QPointF& outPoint，UnitOfMeasure unit = UnitOfMeasure::Default)**

Compute the point obtained by extending the centerline start point forward by dist; return false if the target point is not on the centerline, otherwise return true. Unit: Pixel.

Parameters: 

[ in ] dist: Distance to extend forward from the centerline start point.

[ out ] outPoint: The point located after extending the start point of the centerline forward by a distance of dist.

Example:

```cpp
// Get the coordinates of a point at a certain distance from the link starting point
QPointF outPoint;
bool result = link->getPointByDist(50，outPoint, UnitOfMeasure::Metric);
if(result)
{
    qreal x = outPoint.x();
    qreal y = outPoint.y();
}
```

**bool getPointAndIndexByDist(qreal dist，QPointF& outPoint，int& outIndex，UnitOfMeasure unit = UnitOfMeasure::Default)**

Calculate the point and segment index located after extending the start point of the centerline forward by a distance of dist. Returns false if the target point is not on the centerline; otherwise, returns true. Unit: Pixel.

Parameters: 

[ in ] dist: Distance to extend forward from the centerline start point.

[ out ] outPoint: The point located after extending the start point of the centerline forward by a distance of dist.

[ out ] outIndex: The segment index located after extending the start point of the centerline forward by a distance of dist.

**QPolygonF polygon()**

Obtain the polygonal contour vertices of the road segment.

#### 3.4.1.4. Connection Segment (IConnector)

Header file: IConnector.h

**int gtype()**

Type: The connection segment type is GConnectorType.

**long id()**

Obtain the connection segment ID.

**qreal length(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the length of the connection segment. Unit: Pixel.

**qreal z(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the elevation of the connection segment. Unit: Pixel.

**qreal v3z(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the elevation of the connection segment. Unit: Pixel.

**QString name()**

Get the name of the connection segment.

**void setName(QString name)**

Set the name of the connection segment.

**ILink\* fromLink()**

Get the starting road segment.

**ILink\* toLink()**

Get the target road segment.

**qreal limitSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the maximum speed limit of the connection segment. Unit: km/h.

**qreal minSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the minimum speed limit of the connection segment. Unit: km/h.

**QList\<ILaneConnector\*\> laneConnectors()**

Get the list of lane connections.

**QList\<ILaneObject\*\> laneObjects()**

List of interfaces for lanes and lane connections.

**void setLaneConnectorOtherAtrrs(QList\<QJsonObject\> lAttrs)**

Set additional attributes of the included lane connections.

**void setOtherAttr(QJsonObject otherAttr)**

Set additional attributes of the connection segment.

**QPolygonF polygon()**

Get the polygonal contour vertices of the connection segment.

#### 3.4.1.5. Lane Base Class (ILaneObject)

Header file: ILaneObject.h

The lane base class serves as the parent class for lanes and lane connections.

**int gtype()**

Type: GLaneType or GLaneConnectorType.

**bool isLane()**

Indicates whether it is a lane.

**long id()**

Get the ID; for a Lane, the ID is the Lane ID; for a lane connection, the ID is the lane connection ID.

**qreal length(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	Retrieve length. Unit: pixel.

**ISection\* section()**

​	Retrieve the associated ISection.

**ILaneObject\* fromLaneObject(long id)**

​	Retrieve upstream LaneObject by ID. If the current object is a lane, id 0 returns nullptr; otherwise, returns the upstream lane connection corresponding to the specified ID; If the current object is a connection segment, id 0 returns the upstream lane; otherwise, returns nullptr.

**ILaneObject\* toLaneObject(long id)**

​	Retrieve downstream LaneObject by ID. If the current object is a lane, id 0 returns nullptr; otherwise, returns the downstream lane connection corresponding to the specified ID; If the current object is a connection segment, id 0 returns the downstream lane; otherwise, returns nullptr.

**QList\<QPointF\> centerBreakPoints(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	Retrieve the centerline breakpoint set. Unit: pixel.

**QList\<QPointF\> leftBreakPoints(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	Retrieve the left boundary line breakpoint set. Unit: pixel.

**QList\<QPointF\> rightBreakPoints(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	Retrieve the right boundary line breakpoint set. Unit: pixel.

**QList\<QVector3D\> centerBreakPoint3Ds(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	Retrieve the 3D centerline breakpoint set. Unit: pixel.

**QList\<QVector3D\> leftBreakPoint3Ds(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the 3D breakpoint set of the left boundary line. Unit: Pixel.

**QList\<QVector3D\> rightBreakPoint3Ds(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the 3D breakpoint set of the right boundary line. Unit: Pixel.

**QList\<QVector3D\> leftBreak3DsPartly(QPointF fromPoint，QPointF toPoint，UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the 3D breakpoint set of the left partial section. Unit: Pixel.

Parameters: 

[ in ] fromPoint: A point on the centerline serving as the start point.

[ in ] toPoint: A point on the centerline serving as the end point.

**QList\<QVector3D\> rightBreak3DsPartly(QPointF fromPoint，QPointF toPoint，UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the 3D breakpoint set of the right partial section. Unit: Pixel.

Parameters: 

[ in ] fromPoint: A point on the centerline serving as the start point.

[ in ] toPoint: A point on the centerline serving as the end point.

**qreal distToStartPoint(const QPointF p，UnitOfMeasure unit = UnitOfMeasure::Default)**

Distance from a point on the centerline to the start point. Unit: Pixel.

Parameters: 

[ in ] p: Coordinates of the current point.

**qreal distToStartPointWithSegmIndex(const QPointF p，int segmIndex = 0，bool bOnCentLine = true，UnitOfMeasure unit = UnitOfMeasure: : Default)**

Distance from a point on the centerline to the start point, with the additional condition that the segment index of the lane on which the point lies is provided. Unit: Pixel.

Parameters: 

[ in ] p: Coordinates of the current point.

[ in ] segmIndex: The segment index of the lane on which the point lies.

[ in ] bOnCentLine: Indicates whether the point is on the centerline.

**bool getPointAndIndexByDist(qreal dist，QPointF& outPoint，int& outIndex，UnitOfMeasure unit = UnitOfMeasure::Default)**

Calculate the point and segment index located after extending the start point of the centerline forward by a distance of dist. Returns false if the target point is not on the centerline; otherwise, returns true. Unit: Pixel.

Parameters: 

[ in ] dist: Distance to extend forward from the centerline start point.

[ out ] outPoint: The point located after extending the start point of the centerline forward by a distance of dist.

[ out ] outIndex: The segment index located after extending the start point of the centerline forward by a distance of dist.

**bool getPointByDist(qreal dist，QPointF& outPoint，UnitOfMeasure unit = UnitOfMeasure::Default)**

Compute the point obtained by extending the centerline start point forward by dist; return false if the target point is not on the centerline, otherwise return true. Unit: Pixel.

Parameters: 

[ in ] dist: Distance to extend forward from the centerline start point.

[ out ] outPoint: The point located after extending the start point of the centerline forward by a distance of dist.

**void setOtherAttr(QJsonObject attr)**

Set additional attributes for Lane or Lane connection.

**ILane\* castToLane()**

Cast ILaneObject to ILane; returns nullptr if the current ILaneObject is a Lane connection.

**ILaneConnector\* castToLaneConnector()**

Cast ILaneObject to ILaneConnector; returns nullptr if the current ILaneObject is a Lane.

#### 3.4.1.6. Lane (ILane)

Header file: ILane.h

**int gtype()**

Type: Lane type is GLaneType.

**long id()**

Retrieve Lane ID.

**ILink\* link()**

Retrieve the Road Segment where the Lane resides.

**ISection\* section()**

Retrieve the Section to which the Lane belongs.

**qreal length(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve Lane length. Unit: Pixel.

**qreal width(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve Lane width. Unit: Pixel.

**int number()**

Retrieve Lane number, starting at 0 (numbering from the outer side to the inner side, i.e., sequentially from right to left).

**QString actionType()**

Retrieve the behavioral type of the Lane.

**QList\<ILaneConnector\*\> fromLaneConnectors()**

Obtain the list of upstream lane connections.

**QList\<ILaneConnector\*\> toLaneConnectors()**

Obtain the list of downstream lane connections.

**QList\<QPointF\> centerBreakPoints(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the lane centerline breakpoint set. Unit: Pixel.

**QList\<QPointF\> leftBreakPoints(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the lane left boundary breakpoint set. Unit: Pixel.

**QList\<QPointF\> rightBreakPoints(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the lane right boundary breakpoint set. Unit: Pixel.

**QList\<QVector3D\> centerBreakPoint3Ds(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the lane centerline 3D breakpoint set. Unit: Pixel.

**QList\<QVector3D\> leftBreakPoint3Ds(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the lane left boundary 3D breakpoint set. Unit: Pixel.

**QList\<QVector3D\> rightBreakPoint3Ds(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the lane right boundary 3D breakpoint set. Unit: Pixel.

**QList\<QVector3D\> leftBreak3DsPartly(QPointF fromPoint，QPointF toPoint，UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the 3D breakpoint set of the left partial section. Unit: Pixel.

Parameters: 

[ in ] fromPoint: A point on the centerline serving as the start point.

[ in ] toPoint: A point on the centerline serving as the end point.

**QList\<QVector3D\> rightBreak3DsPartly(QPointF fromPoint，QPointF toPoint，UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the 3D breakpoint set of the right partial section. Unit: Pixel.

Parameters: 

[ in ] fromPoint: A point on the centerline serving as the start point.

[ in ] toPoint: A point on the centerline serving as the end point.

**qreal distToStartPoint(const QPointF p，UnitOfMeasure unit = UnitOfMeasure::Default)**

Distance from a point on the centerline to the start point. Unit: Pixel.

Parameters: 

[ in ] p: Coordinates of the current point.

**qreal distToStartPointWithSegmIndex(const QPointF p，int segmIndex = 0，bool bOnCentLine = true，UnitOfMeasure unit = UnitOfMeasure: : Default)**

Distance from a point on the centerline to the start point, with the additional condition that the segment index of the lane on which the point lies is provided. Unit: Pixel.

Parameters: 

[ in ] p: Coordinate of the point on the current centerline.

[ in ] segmIndex: The segment index of the lane on which the point lies.

[ in ] bOnCentLine: Indicates whether the point is on the centerline.

**bool getPointAndIndexByDist(qreal dist，QPointF& outPoint，int& outIndex，UnitOfMeasure unit = UnitOfMeasure::Default)**

Calculate the point and segment index located after extending the start point of the centerline forward by a distance of dist. Returns false if the target point is not on the centerline; otherwise, returns true. Unit: Pixel.

Parameters: 

[ in ] dist: Distance to extend forward from the centerline start point.

[ out ] outPoint: The point located after extending the start point of the centerline forward by a distance of dist.

[ out ] outIndex: The segment index located after extending the start point of the centerline forward by a distance of dist.

**bool getPointByDist(qreal dist，QPointF& outPoint，UnitOfMeasure unit = UnitOfMeasure::Default)**

Compute the point obtained by extending the centerline start point forward by dist; return false if the target point is not on the centerline, otherwise return true. Unit: Pixel.

Parameters: 

[ in ] dist: Distance to extend forward from the centerline start point.

[ out ] outPoint: The point located after extending the start point of the centerline forward by a distance of dist.

Example:

```cpp
// Get the coordinates of a point at a certain distance from the lane starting point
QPointF outPoint;
bool result = lane->getPointByDist(50，outPoint, UnitOfMeasure::Metric);
if(result)
{
    qreal x = outPoint.x();
    qreal y = outPoint.y();
}
```

**void setOtherAttr(QJsonObject attr)**

Set additional attributes of the lane.

**void setLaneType(QString type)**

Set the lane type.

Parameters: 

[ in ] type: Lane type, choose one of the following: "Motor Vehicle Lane", "Mixed Motor and Non-motor Lane", "Non-motor Vehicle Lane", "Bus-only Lane".

Example:

```cpp
// Set lane type
lane->setLaneType("机动车道");
```

**QPolygonF polygon()**

Retrieve the polygonal contour vertices of the lane.

#### 3.4.1.7. Lane Connection (ILaneConnector)

Header file: ILaneConnector.h

**int gtype()**

Type: GLaneType or GLaneConnectorType; the lane connection segment is GLaneConnectorType.

**long id()**

Obtain the lane connection ID.

**IConnector\* connector()**

Obtain the connection segment to which the lane connection belongs.

**ISection\* section()**

Retrieve the Section to which the Lane belongs.

**ILane\* fromLane()**

Upstream lane.

**ILane\* toLane()**

Downstream lane.

**qreal length(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the lane connection length. Unit: pixel.

**QList\<QPointF\> centerBreakPoints(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the set of breakpoints of the lane connection centerline. Unit: pixel.

**QList\<QPointF\> leftBreakPoints(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the set of breakpoints of the left boundary line of the lane connection. Unit: pixel.

**QList\<QPointF\> rightBreakPoints(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the set of breakpoints of the right boundary line of the lane connection. Unit: pixel.

**QList\<QVector3D\> centerBreakPoint3Ds(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the set of 3D breakpoints of the lane connection centerline. Unit: pixel.

**QList\<QVector3D\> leftBreakPoint3Ds(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the 3D breakpoint set of the left boundary line of the lane connection. Unit: Pixel.

**QList\<QVector3D\> rightBreakPoint3Ds(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the 3D breakpoint set of the right boundary line of the lane connection. Unit: Pixel.

**QList\<QVector3D\> leftBreak3DsPartly(QPointF fromPoint，QPointF toPoint，UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the 3D breakpoint set of the left partial section of the lane connection. Unit: Pixel.

Parameters: 

[ in ] fromPoint: A point on the centerline serving as the start point.

[ in ] toPoint: A point on the centerline serving as the end point.

**QList\<QVector3D\> rightBreak3DsPartly(QPointF fromPoint，QPointF toPoint，UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the 3D breakpoint set of the right partial section of the lane connection. Unit: Pixel.

Parameters: 

[ in ] fromPoint: A point on the centerline serving as the start point.

[ in ] toPoint: A point on the centerline serving as the end point.

**qreal distToStartPoint(const QPointF p，UnitOfMeasure unit = UnitOfMeasure::Default)**

Distance from a point on the centerline to the start point. Unit: Pixel.

Parameters: 

[ in ] p: Coordinates of the current point.

**qreal distToStartPointWithSegmIndex(const QPointF p，int segmIndex，bool bOnCentLine，UnitOfMeasure unit = UnitOfMeasure: : Default)**

Distance from a point on the centerline to the start point, with the additional condition that the segment index of the lane on which the point lies is provided. Unit: Pixel.

Parameters: 

[ in ] p: Coordinates of the current point.

[ in ] segmIndex: Segment index.

[ in ] bOnCentLine: Indicates whether the point is on the centerline.

**bool getPointAndIndexByDist(qreal dist，QPointF& outPoint，int& outIndex，UnitOfMeasure unit = UnitOfMeasure::Default)**

Calculate the point and segment index located after extending the start point of the centerline forward by a distance of dist. Returns false if the target point is not on the centerline; otherwise, returns true. Unit: Pixel.

Parameters: 

[ in ] dist: Distance to extend forward from the centerline start point.

[ out ] outPoint: The point located after extending the start point of the centerline forward by a distance of dist.

[ out ] outIndex: The segment index located after extending the start point of the centerline forward by a distance of dist.

**bool getPointByDist(qreal dist，QPointF& outPoint，UnitOfMeasure unit = UnitOfMeasure::Default)**

Compute the point obtained by extending the centerline start point forward by dist; return false if the target point is not on the centerline, otherwise return true. Unit: Pixel.

Parameters: 

[ in ] dist: Distance to extend forward from the centerline start point.

[ out ] outPoint: The point located after extending the start point of the centerline forward by a distance of dist.

**void setOtherAttr(QJsonObject attr)**

Set other attributes of the lane connection.

#### 3.4.1.8. Connection Segment Polygon Area (IConnectorArea)

Header file: IConnectorArea.h

**long id()**

Polygon ID, where a polygon area is defined as a region formed by the overlap of multiple Connectors.

**QList\<IConnector\*\> allConnector()**

All connection segments associated with the polygon area.

**QPointF centerPoint(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the center point position of the polygon area. Unit: Pixel.

### 3.4.2. Departure Point

#### 3.4.2.1. Departure Point (IDispatchPoint)

Header file: IDispatchPoint.h

**long id()**

Get the departure point ID.

**QString name()**

Get the name of the departure point.

**ILink\* link()**

Get the road segment on which the departure point is located.

**long addDispatchInterval(long vehiCompId，int interval，int vehiCount)**

Add a departure interval to the departure point.

Parameters: 

[ in ] vehiCompId: Vehicle composition ID.

[ in ] interval: Time duration. Unit: s.

[ in ] vehiCount: Number of departures.

Return value: 

Departure interval ID.

**void setDynaModified(bool bModified)**

Set whether it can be dynamically modified. By default, if departure information is dynamically modified, the entire file cannot be saved to prevent corruption of the original departure settings.

**QPolygonF polygon()**

Get the vertices of the polygonal contour of the departure point.

### 3.4.3. Decision Points and Vehicle Paths

#### 3.4.3.1. Decision Point (IDecisionPoint)

Header file: IDecisionPoint.h

**long id()**

Decision Point ID.

**QString name()**

Decision Point Name.

**ILink\* link()**

Road Segment where the Decision Point is located.

**qreal distance(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get distance from the start of the Road Segment. Unit: Pixel.

**QList\<IRouting\*\> routings()**

Associated Decision Paths.

**void setDynaModified(bool bModified)**

Set whether it can be dynamically modified. By default, if departure information is dynamically modified, the entire file cannot be saved to prevent corruption of the original departure settings.

Parameters: 

[ in ] bModified: Indicates whether dynamically modified; true if dynamically modified, false otherwise.

**QPolygonF polygon()**

Vertices of the polygonal contour of the Decision Point.

#### 3.4.3.2. Vehicle Path (IRouting)

Header file: IRouting.h

**long id()**

Path ID.

**qreal calcuLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

Calculate path length. Unit: Pixel.

**QList\<ILink\*\> getLinks()**

Retrieve the sequence of road segments.

**long deciPointId()**

Associated Decision Point ID.

**bool contain(ISection\* pRoad)**

Determine whether the specified road is on the current path.

Parameters: 

[ in ] pRoad: Road segment or Connection segment.

**ISection\* nextRoad(ISection\* pRoad)**

Determine the subsequent road given the specified road.

Parameters: 

[ in ] pRoad: Road segment or Connection segment.

### 3.4.4. Signal Control

#### 3.4.4.1. Signal Controller (ISignalController)

Header file: ITrafficLight.h

**long id()**

Retrieve the Signal Controller ID.

**QString name()**

Retrieve the Signal Controller name.

**void setName(const QString& name)**

Set the Signal Controller name.

Parameters: 

[ in ] name: New name.

**void addPlan(ISignalPlan\* plan)**

Add a Signal Control Scheme.

Parameters: 

[ in ] plan: Signal Control Scheme.

**void removePlan(ISignalPlan\* plan)**

Remove a Signal Control Scheme.

Parameters: 

[ in ] plan: Signal Control Scheme to remove.

**QList\<ISignalPlan\*\> plans()**

Retrieve all signal control schemes.

**bool isValid()**

Validate the signal controller.

#### 3.4.4.2. Signal Control Scheme (ISignalPlan)

Header file: ISignalPlan.h

**long id()**

Get the ID.

**QString Name()**

Get the signal group name.

**QString trafficName()**

Get the signal control scheme name.

**int cycleTime()**

Get the signal cycle. Unit: s.

**long fromTime()**

Get the start time. Unit: s.

**long toTime()**

Get the end time. Unit: s.

**QList\<ISignalPhase\*\> phases()**

Get the phase list.

**void setName(QString name)**

Set the signal control scheme name.

Parameters: 

[ in ] name: New name.

**void setcycleTime(int period)**

Set the signal cycle. Unit: s.

Parameters: 

[ in ] period: Signal cycle. Unit: s.

**void setFromTime(long time)**

Set the start time. Unit: s.

Parameters: 

[ in ] time: Start time. Unit: s.

**void setToTime(long time)**

Set the end time. Unit: s.

Parameters: 

[ in ] time: End time. Unit: s.

#### 3.4.4.3. Traffic Signal Phase (ISignalPhase)

Header file: ISignalPhase.h

**long id()**

Phase ID.

**QString phaseName()**

Phase name.

**QList\<Online::ColorInterval\> listColor()**

Retrieve the list of phase colors.

**void setColorList(QList\<Online::ColorInterval\> lColor)**

Set the list of traffic signals.

Parameters: 

[ in ] lColor: Color duration information, including traffic signal color and duration.

Example:

```cpp
// Build color and duration object list
QList<Online::ColorInterval> colorObjList = {
    Online::ColorInterval("R", 10),   // Red, duration 10
    Online::ColorInterval("G", 60),   // Green, duration 60
    Online::ColorInterval("Y", 3),    // Yellow, duration 3
    Online::ColorInterval("R", 17)    // Red, duration 17
};
// Find signal phase with ID 7
auto signalPhase = netiface->findSignalPhase(7);
if (signalPhase) 
{
    // Set color list
    signalPhase->setColorList(colorObjList);
}
```

**int cycleTime()**

Retrieve the phase cycle. Unit: s.

**Online::SignalPhaseColor phaseColor()**

Retrieve the current phase color.

**ISignalPlan\* signalPlan()**

Retrieve the signal control scheme associated with the phase.

**QList\<ISignalLamp\*\> signalLamps()**

Retrieve the list of related traffic signals.

**void setPhaseName(QString name)**

Set the phase name.

Parameters: 

[ in ] name: New name.

#### 3.4.4.4. Traffic Signal Lamp Head (ISignalLamp)

Header file: isignallamp.h

**long id()**

Retrieve Traffic Signal ID.

**void setSignalPhase(ISignalPhase\* pPhase)**

Set Phase; the assigned phase may be from another traffic signal group.

Parameters: 

[ in ] pPhase: Phase.

**void setPhaseNumber(int num)**

Set the phase index, starting from 1. If the index exceeds the total number of phases, the setting will not be applied.

**void setLampColor(QString colorStr)**

Set Traffic Signal color.

Parameters: 

[ in ] colorStr: Color represented as a string, with four valid options: "红" (Red), "绿" (Green), "黄" (Yellow), "灰" (Gray), or "R", "G", "Y", "grey". 

**QString color()**

Retrieve Traffic Signal color. "R", "G", "Y", and "grey" correspond to "红" (Red), "绿" (Green), "黄" (Yellow), and "灰" (Gray), respectively.

**QString name()**

Retrieve the traffic signal name.

**void setName(QString name)**

Assign the traffic signal name.

**void setDistToStart(qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set the traffic signal distance from the start of the road segment. Unit: pixel.

Parameters: 

[ in ] dist: distance value.

**ISignalPlan\* signalPlan()**

Retrieve the signal control scheme.

**ISignalPhase\* signalPhase()**

Retrieve the phase.

**ILaneObject\* laneObject()**

Retrieve the lane or lane connection where it is located.

**QPolygonF polygon()**

Retrieve the vertices of the traffic signal polygonal contour.

**qreal angle()**

Retrieve the traffic signal angle.

### 3.4.5. Data Collection Devices

#### 3.4.5.1. Data Collector (IVehicleDrivInfoCollector)

Header file: IVehicleDrivInfoCollector.h

**long id()**

Retrieve the collector ID.

**QString collName()**

Retrieve the collector name.

**bool onLink()**

Indicates whether it is on the road segment; if true, connector() returns nullptr.

**ILink\* link()**

Road segment where the collector is located.

**IConnector\* connector()**

Connection segment where the collector is located.

**ILane\* lane()**

Returns the lane if the collector is on a road segment; otherwise, returns nullptr.

**ILaneConnector\* laneConnector()**

Returns the lane connection if the collector is on a connection segment; otherwise, returns nullptr.

**qreal distToStart(UnitOfMeasure unit = UnitOfMeasure::Default)**

Gets the distance from the collector to the start of the road segment. Unit: pixel.

**QPointF point(UnitOfMeasure unit = UnitOfMeasure::Default)**

Gets the collector's position coordinates. Unit: pixel.

**long fromTime()**

Collector start working time. Unit: s.

**long toTime()**

Collector stop working time. Unit: s.

**long aggregateInterval()**

Aggregation data time interval. Unit: s.

**void setName(QString name)**

Sets the collector name.

**void setDistToStart(qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

Sets the distance from the collector to the start of the road segment. Unit: pixel.

Parameters: 

[ in ] dist: distance value.

**void setFromTime(long time)**

Sets the collector start working time. Unit: s.

Parameters: 

[ in ] time: Operation start time. Unit: s.

**void setToTime(long time)**

Set the collector's operation end time. Unit: s.

Parameters: 

[ in ] time: Operation end time. Unit: s.

**void setAggregateInterval(int interval)**

Set the collector's data aggregation interval. Unit: s.

**QPolygonF polygon()**

Obtain the collector's polygonal contour vertices.

#### 3.4.5.2 Vehicle Queue Counter (IVehicleQueueCounter)

Header file: IVehicleQueueCounter.h

**long id()**

Get the counter ID.

**QString counterName()**

Get the counter name.

**bool onLink()**

Indicates whether it is on the road segment; if true, connector() returns nullptr.

**ILink\* link()**

Road segment where the counter is located.

**IConnector\* connector()**

Connection segment where the counter is located.

**ILane\* lane()**

If the counter is on a road segment, return the lane; otherwise, return nullptr.

**ILaneConnector\* laneConnector()**

If the counter is on a connection segment, return the lane connection; otherwise, return nullptr.

**qreal distToStart(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the distance of the counter from the start of the road segment. Unit: Pixel.

**QPointF point(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the coordinate position of the counter. Unit: Pixel.

**long fromTime()**

Counter operation start time. Unit: s.

**long toTime()**

Counter operation end time. Unit: s.

**long aggregateInterval()**

Counter data aggregation time interval. Unit: s.

**void setName(QString name)**

Set the counter name.

Parameters: 

[ in ] name: Counter name.

**void setDistToStart(qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set the distance of the counter from the start of the road segment. Unit: Pixel.

Parameters: 

[ in ] dist: distance value.

**void setFromTime(long time)**

Set the operation start time. Unit: s.

**void setToTime(long time)**

Set the operation end time. Unit: s.

**void setAggregateInterval(int interval)**

Set the data aggregation time interval. Unit: s.

**QPolygonF polygon()**

Retrieve the polygonal outline vertices of the counter.

#### 3.4.5.3. Vehicle Travel Time Detector (IVehicleTravelDetector)

Header file: IVehicleTravelDetector.h

**long id()**

Get the detector ID.

**QString detectorName()**

Get the detector name.

**bool isStartDetector()**

Determine whether it is the detector start point.

**bool isOnLink_startDetector()**

Check if the detector start point is on the road segment; if not, the start point is on the connection segment.

**bool isOnLink_endDetector()**

Check if the detector end point is on the road segment; if not, the end point is on the connection segment.

**ILink\* link_startDetector()**

Return the road segment where the detector start point is located if on the road segment; otherwise, return nullptr.

**ILaneConnector\* laneConnector_startDetector()**

Return the lane connection of the start point if on the connection segment; otherwise, return nullptr.

**ILink\* link_endDetector()**

Return the road segment where the detector end point is located if on the road segment; otherwise, return nullptr.

**ILaneConnector\* laneConnector_endDetector()**

Return the lane connection of the end point if on the connection segment; otherwise, return nullptr.

**qreal distance_startDetector(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the start detector's distance from the start of the road segment. Unit: pixel.

**qreal distance_endDetector(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the end detector's distance from the start of the road segment. Unit: pixel.

**QPointF point_startDetector(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the start detector's position coordinates. Unit: pixel.

**QPointF point_endDetector(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the end detector's position coordinates. Unit: pixel.

**long fromTime()**

Detector operation start time. Unit: s.

**long toTime()**

Detector operation stop time. Unit: s.

**long aggregateInterval()**

Aggregation data time interval. Unit: s.

**void setName(QString name)**

Set the detector name.

**void setDistance_startDetector(qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set the start detector's distance from the start of the road segment. Unit: pixel.

Parameters: 

[ in ] dist: distance value.

**void setDistance_endDetector(qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set the end detector's distance from the start of the road segment. Unit: pixel.

Parameters: 

[ in ] dist: distance value.

**void setFromTime(long time)**

Set the detector operation start time. Unit: s.

Parameters: 

[ in ] time: Operation start time. Unit: s.

**void setToTime(long time)**

Set the detector operation end time. Unit: s.

Parameters: 

[ in ] time: Operation end time. Unit: s.

**void setAggregateInterval(int interval)**

Set the aggregation data interval of the detector. Unit: s.

Parameters: 

[ in ] interval: Aggregation data time interval. Unit: s.

**QPolygonF polygon_startDetector()**

Retrieve the vertices of the origin polygonal contour of the travel time detector.

**QPolygonF polygon_endDetector()**

Retrieve the vertices of the terminal polygonal contour of the travel time detector.

### 3.4.6. Guiding Arrows

#### 3.4.6.1. Guiding Arrows (IGuidArrow)

Header file: IGuidArrow.h

**long id()**

Retrieve the ID of the guiding arrow.

**ILane\* lane()**

Retrieve the lane on which the guiding arrow is located.

**qreal length(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the length of the guiding arrow. Unit: Pixel.

**qreal distToTerminal(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the distance from the guiding arrow to the endpoint. Unit: Pixel.

**Online::GuideArrowType arrowType()**

Retrieve the type of guiding arrow. The guiding arrow types include: straight, left turn, right turn, straight or left turn, straight or right turn, straight, left turn, or right turn, left turn or right turn, U-turn, straight or U-turn, and left turn or U-turn.

**QPolygonF polygon()**

Retrieve the vertices of the polygonal outline of the guiding arrow.

### 3.4.7. Public Transportation System

#### 3.4.7.1. Bus Line (IBusLine)

Header file: IBusLine.h

**long id()**

Retrieve the bus line ID.

**QString name()**

Line name.

**qreal length(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the length of the bus line. Unit: pixel.

**int dispatchFreq()**

Dispatch interval. Unit: s.

**int dispatchStartTime()**

Dispatch start time. Unit: s.

**int dispatchEndTime()**

Dispatch end time. Unit: s.

**qreal desirSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the desired speed of the bus route. Unit: Pixel/s.

**int passCountAtStartTime()**

Initial number of passengers.

**QList\<ILink\*\> links()**

Road segments traversed by the bus route.

**QList\<IBusStation\*\> stations()**

All stops along the route.

**QList\<IBusStationLine\*\> stationLines()**

Bus stop route data, including parameters related to passenger boarding and alighting at the route’s stops.

**void setName(QString name)**

Set the name of the route.

**void setDispatchFreq(int freq)**

Set the departure interval for the current bus route. Unit: s.

Parameters: 

[ in ] freq: Departure interval. Unit: s.

**void setDispatchStartTime(int startTime)**

Set the start departure time for the first bus on the current route. Unit: s.

Parameters: 

[ in ] startTime: Start departure time. Unit: s.

**void setDispatchEndTime(int endTime)**

Set the end departure time for the last bus on the current route. Unit: s.

Parameters: 

[ in ] endTime: End departure time. Unit: s.

**void setDesirSpeed(qreal speed，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set the desired speed of the current bus route. Unit: pixels/s.

Parameters: 

[ in ] speed: speed value.

**void setPassCountAtStartTime(int count)**

Set the initial number of passengers.

#### 3.4.7.2. Bus Station (IBusStation)

Header file: IBusStation.h

**long id()**

Get the bus station ID.

**QString name()**

Get the bus station name.

**int laneNumber()**

Get the lane number of the bus station.

**qreal x(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the X coordinate of the station. Unit: pixels.

**qreal y(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the Y coordinate of the station. Unit: pixels.

**qreal length(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the length of the station. Unit: pixels.

**int stationType()**

Station type, 1: curbside, 2: bay.

**ILink\* link()**

Road segment where the bus station is located.

**ILane\* lane()**

Lane where the bus station is located.

**qreal distance(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the distance from the station to the start point of the road segment. Unit: Pixel.

**void setName(QString name)**

Set the station name.

Parameters: 

[ in ] name: New name.

**void setDistToStart(qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set the distance from the station to the start point of the road segment. Unit: Pixel.

Parameters: 

[ in ] dist: distance value.

**void setLength(qreal length，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set the station length. Unit: Pixel.

Parameters: 

[ in ] length: Length value.

**void setType(int type)**

Set the station type.

Parameters: 

[ in ] type: Station type, 1 for curbside, 2 for bay.

**QPolygonF polygon()**

Vertices defining the polygonal outline of the bus station.

#### 3.4.7.3. Bus Station - Line (IBusStationLine)

Header file: IBusStationLine.h

**long id()**

Obtain the bus 'Station-Line' ID.

**long stationId()**

Bus station ID.

**long lineId()**

Bus line ID.

**int busParkingTime()**

Vehicle dwell time. Unit: s.

**qreal getOutPercent()**

Disembark percentage.

**qreal getOnTimePerPerson()**

Average boarding time per passenger. Unit: s.

**qreal getOutTimePerPerson()**

Average alighting time per passenger. Unit: s.

**void setBusParkingTime(int time)**

Set vehicle dwell time.

Parameters: 

[ in ] time: Vehicle dwell time. Unit: s.

**void setGetOutPercent(qreal percent)**

Set disembark percentage.

Parameters: 

[ in ] percent: Disembark percentage.

**void setGetOnTimePerPerson(qreal time)**

Set average boarding time per passenger.

Parameters: 

[ in ] time: Average boarding time per passenger. Unit: s.

**void setGetOutTimePerPerson(qreal time)**

Set average alighting time per passenger.

Parameters: 

[ in ] time: Average alighting time per passenger. Unit: s.

### 3.4.8. Event Area

#### 3.4.8.1. Accident Zone (IAccidentZone)

Header file: IAccidentZone.h

**long id()**

Retrieve the Accident Zone ID.

**QString name()**

Retrieve the Accident Zone name.

**qreal location(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the distance from the start point of the road segment to the Accident Zone for the current time period. Unit: pixel.

**qreal zoneLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the length of the Accident Zone for the current time period. Unit: pixel.

**qreal limitedSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	Obtain the current speed limit in the accident area. Unit: Pixel (km/h).

**ISection\* section()**

Retrieve the road segment or connection segment where the Accident Zone is located.

**long roadId()**

Retrieve the ID of the road segment where the Accident Zone is located.

**QString roadType()**

Retrieve the road type (road segment or connection segment) where the Accident Zone is located.

**QList\<ILaneObject\*\> laneObjects()**

Retrieve the list of lanes occupied by the Accident Zone for the current time period.

**qreal controlLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the control distance of the Accident Zone for the current time period (vehicles within this distance from the Accident Zone start are compelled to change lanes). Unit: pixel.

**IAccidentZoneInterval\* addAccidentZoneInterval(Online::DynaAccidentZoneIntervalParam param)**

Add an accident interval.

Parameters: 

[ in ] param: Accident interval parameters.

**void removeAccidentZoneInterval(long accidentZoneIntervalId)**

Remove an accident interval.

Parameters: 

[ in ] accidentZoneIntervalId: Accident interval ID.

**bool updateAccidentZoneInterval(Online::DynaAccidentZoneIntervalParam param)**

Update an accident interval.

Parameters: 

[ in ] param: Accident interval parameters.

**QList\<IAccidentZoneInterval\*\> accidentZoneIntervals()**

Retrieve all accident intervals.

**IAccidentZoneInterval\* findAccidentZoneIntervalById(long accidentZoneIntervalId)**

Query accident interval by ID.

Parameters: 

[ in ] accidentZoneIntervalId: Accident interval ID.

**IAccidentZoneInterval\* findAccidentZoneIntervalByStartTime(long startTime)**

Query accident interval by start time.

Parameters: 

[ in ] startTime: Accident interval start time.

#### 3.4.8.2. Accident Zone Interval (IAccidentZoneInterval)

Header file: IAccidentZoneInterval.h

**long intervalId()**

Get accident interval ID.

**long accidentZoneId()**

Get associated accident zone ID.

**long startTime()**

Get accident interval start time.

**long endTime()**

Get accident interval end time.

**qreal length(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the length of the accident zone during the specified time period. Unit: Pixel.

**qreal location(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the distance from the start point to the accident zone during the specified time period. Unit: Pixel.

**qreal limitedSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the speed limit of the accident zone during the specified time period. Unit: Pixel (km/h).

**qreal controlLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the control distance of the accident zone during the specified time period (vehicles within this distance from the accident zone start point are required to change lanes). Unit: Pixel.

**QList\<int\> laneNumbers()**

Retrieve the occupied lane number of the accident zone during the specified time period.

#### 3.4.8.3. Road Work Zone (IRoadWorkZone)

Header file: IRoadWorkZone.h

**long id()**

Retrieve the ID of the road work zone.

**QString name()**

Retrieve the name of the road work zone.

**qreal location(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the distance from the start point of the road segment to the road work zone. Unit: Pixel.

**qreal zoneLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the length of the construction zone. Unit: pixel.

**qreal limitSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the speed limit of the construction zone. Unit: pixel (km/h).

**long sectionId()**

Retrieve the ID of the road segment or connection segment where the construction zone is located.

**QString sectionName()**

Retrieve the name of the road segment or connection segment where the construction zone is located.

**QString sectionType()**

Retrieve the road type of the road where the construction zone is located; link: road segment, connector: connection segment.

**QList\<ILaneObject\*\> laneObjects()**

Retrieve the list of lanes occupied by the construction zone.

**QList\<long\> laneObjectIds()**

Retrieve the list of Lane IDs occupied by the construction zone.

**qreal upCautionLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the length of the upstream warning zone of the construction zone. Unit: pixel.

**qreal upTransitionLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the length of the upstream transition zone of the construction zone. Unit: pixel.

**qreal upBufferLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the length of the upstream buffer zone of the construction zone. Unit: pixel.

**qreal downTransitionLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the length of the downstream transition zone of the construction zone. Unit: pixel.

**qreal downTerminationLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the downstream termination length of the construction zone. Unit: pixel.

**long duration()**

Construction duration: if the elapsed time since the creation of the simulation process exceeds this value, the construction zone will be removed. Unit: s.

**bool isBorrowed()**

Determine whether the construction zone uses borrowed lanes.

#### 3.4.8.4. Limited Zone (ILimitedZone)

Header file: ILimitedZone.h

**long id()**

Obtain the Limited Zone ID.

**QString name()**

Obtain the Limited Zone name.

**qreal location(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the distance from the Limited Zone to the start point of the road segment. Unit: pixel.

**qreal zoneLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the length of the Limited Zone. Unit: pixel.

**qreal limitSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the speed limit of the Limited Zone. Unit: pixel (km/h).

**long sectionId()**

Obtain the ID of the road segment or connection segment.

**QString sectionName()**

Obtain the Section name.

**QString sectionType()**

Obtain the road type; "link" indicates a road segment, "connector" indicates a connection segment.

**QList\<ILaneObject\*\> laneObjects()**

Retrieve the list of associated lane objects.

**long duration()**

Obtain the restriction duration; if the duration since simulation process creation exceeds this value, the item will be removed. Unit: s.

#### 3.4.8.5. Reconstruction and Expansion Lane Borrowing (IReconstruction)

Header file: IReconstruction.h

**long id()**

Retrieve the reconstruction ID.

**long roadWorkZoneId()**

Retrieve the starting construction zone ID of the reconstruction.

**long limitedZoneId()**

Retrieve the borrowed lane restriction zone ID.

**qreal passagewayLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the guaranteed passage length. Unit: pixel.

**long duration()**

Obtain the reconstruction duration.

**int borrowedNum()**

Obtain the number of borrowed lanes.

**qreal passagewayLimitedSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the guaranteed passage opening speed limit. Unit: pixel (km/h).

**Online::DynaReconstructionParam dynaReconstructionParam()**

Retrieve dynamic parameters of the reconstruction.

#### 3.4.8.6. Speed Limit Zone (IReduceSpeedArea)

Header file: IReduceSpeedArea.h

**long id()**

Get the Speed Limit Zone ID.

**QString name()**

Get the Speed Limit Zone name.

**qreal location(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the distance from the start point. Unit: Pixel.

**qreal areaLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the Speed Limit Zone length. Unit: Pixel.

**long sectionId()**

Obtain the ID of the road segment or connection segment.

**int laneNumber()**

Get the Lane Number.

**int toLaneNumber()**

Get the target Lane Number.

**IReduceSpeedInterval\* addReduceSpeedInterval(Online::DynaReduceSpeedIntervalParam param)**

Add a speed limit interval.

Parameters: 

[ in ] param: Speed limit interval parameters.

**void removeReduceSpeedInterval(long id)**

Remove a speed limit interval.

Parameters: 

[ in ] id: Speed limit interval ID.

**bool updateReduceSpeedInterval(Online::DynaReduceSpeedIntervalParam param)**

Update a speed limit interval.

Parameters: 

[ in ] param: Speed limit interval parameters.

**QList\<IReduceSpeedInterval\*\> reduceSpeedIntervals()**

Get the list of speed limit intervals.

**IReduceSpeedInterval\* findReduceSpeedIntervalById(long id)**

Get a speed limit interval by ID.

Parameters: 

[ in ] id: Speed limit interval ID.

**IReduceSpeedInterval\* findReduceSpeedIntervalByStartTime(long startTime)**

Get a speed limit interval by start time.

Parameters: 

[ in ] startTime: Start time.

**QPolygonF polygon()**

Get the polygonal contour.

#### 3.4.8.7. Speed Limit Interval (IReduceSpeedInterval)

Header file: IReduceSpeedInterval.h

**long id()**

Get the speed limit interval ID.

**long reduceSpeedAreaId()**

Get the associated speed limit zone ID.

**long intervalStartTime()**

Get the start time.

**long intervalEndTime()**

Get the end time.

**IReduceSpeedVehiType\* addReduceSpeedVehiType(Online::DynaReduceSpeedVehiTypeParam param)**

Add a restricted speed vehicle type.

Parameters: 

[ in ] param: Restricted speed vehicle type parameter.

**void removeReduceSpeedVehiType(long id)**

Remove a restricted speed vehicle type.

Parameters: 

[ in ] id: Restricted speed vehicle type ID.

**bool updateReduceSpeedVehiType(Online::DynaReduceSpeedVehiTypeParam param)**

Update the restricted speed vehicle type.

Parameters: 

[ in ] param: Restricted speed vehicle type parameter.

**QList\<IReduceSpeedVehiType\*\> reduceSpeedVehiTypes()**

Get the list of restricted speed vehicle types and parameters for this interval.

**IReduceSpeedVehiType\* findReduceSpeedVehiTypeById(long id)**

Retrieve the restricted speed vehicle type by ID.

Parameters: 

[ in ] id: Restricted speed vehicle type ID.

**IReduceSpeedVehiType\* findReduceSpeedVehiTypeByCode(long vehicleTypeCode)**

Retrieve the restricted speed vehicle type by vehicle type code.

Parameters: 

[ in ] vehicleTypeCode: Vehicle type code.

#### 3.4.8.8. Restricted Speed Vehicle Type (IReduceSpeedVehiType)

Header file: IReduceSpeedVehiType.h

**long id()**

Get the restricted speed vehicle type ID.

**long intervalId()**

Retrieve the associated speed limit period ID.

**long reduceSpeedAreaId()**

Get the associated speed limit zone ID.

**long vehiTypeCode()**

Retrieve the vehicle type code.

**qreal averageSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the average vehicle speed. Unit: Pixel/s.

**qreal speedStandardDeviation(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the vehicle speed standard deviation. Unit: Pixel/s.

### 3.4.9. Pedestrian Module

#### 3.4.9.1. Obstacle Region (IObstacleRegion)

Header file: IObstacleRegion.h

**bool isObstacle() const**

Obtain whether the region is designated as an obstacle.

**void setObstacle(bool b)**

Set whether the region is designated as an obstacle.

Parameters: 

[ in ] b: Indicates whether it is an obstacle.

#### 3.4.9.2. Passenger Region (IPassengerRegion)

Header file: IPassengerRegion.h

**bool isBoardingArea() const**

Obtain whether the region is a passenger boarding area.

**void setIsBoardingArea(bool b)**

Set whether the region is a passenger boarding area.

**bool isAlightingArea() const**

Get whether the polygon is a drop-off area.

**void setIsAlightingArea(bool b)**

Set whether the polygon is a drop-off area.

#### 3.4.9.3. Pedestrian Path Polygon Base Class (IPedestrianPathRegionBase)

Header file: IPedestrianPathRegionBase.h

**long getId() const**

Get Polygon ID.

**QString getName() const**

Get polygon name.

**void setName(QString name)**

Set polygon name.

**QColor getRegionColor() const**

Get polygon color.

**void setRegionColor(QColor color)**

Set polygon color.

**QPointF getPosition(UnitOfMeasure unit = UnitOfMeasure::Default) const**

Get polygon position. Unit: Pixel.

**void setPosition(QPointF scenePos，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set polygon position. Unit: Pixel.

Parameters: 

[ in ] scenePos: Position in scene coordinate system.

**int getGType() const**

Get polygon type.

#### 3.4.9.4. Pedestrian Polygon (IPedestrianRegion)

Header file: IPedestrianRegion.h

**long getId() const**

Get Polygon ID.

**QString getName() const**

Get polygon name.

**void setName(QString name)**

Set polygon name.

**QColor getRegionColor() const**

Get polygon color.

**void setRegionColor(QColor color)**

Set polygon color.

**QPointF getPosition(UnitOfMeasure unit = UnitOfMeasure::Default) const**

Get polygon position. Unit: Pixel.

**void setPosition(QPointF scenePos，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set polygon position. Unit: Pixel.

Parameters: 

[ in ] scenePos: Position in scene coordinate system.

**int getGType() const**

Get polygon type.

**qreal getExpectSpeedFactor() const**

Get the desired speed factor.

**void setExpectSpeedFactor(qreal val)**

Set the desired speed factor.

Parameters: 

[ in ] val: Desired speed factor.

**qreal getElevation() const**

Get the elevation of the region.

**void setElevation(qreal elevation)**

Set the elevation of the region.

Parameters: 

[ in ] elevation: Elevation.

**QPolygonF getPolygon() const**

Get the polygon of the region.

**long getLayerId() const**

Get the layer ID of the region.

**void setLayerId(long id)**

Set the layer of the region. If the layer ID is invalid, no changes will be made.

Parameters: 

[ in ] id: Layer ID.

#### 3.4.9.5. Rectangular Pedestrian Region (IPedestrianRectRegion)

Header file: IPedestrianRectRegion.h

**long getId() const**

Get Polygon ID.

**QString getName() const**

Get polygon name.

**void setName(QString name)**

Set polygon name.

**QColor getRegionColor() const**

Get polygon color.

**void setRegionColor(QColor color)**

Set polygon color.

**QPointF getPosition(UnitOfMeasure unit = UnitOfMeasure::Default) const**

Get polygon position. Unit: Pixel.

**void setPosition(QPointF scenePos，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set polygon position. Unit: Pixel.

Parameters: 

[ in ] scenePos: Position in scene coordinate system.

**int getGType() const**

Get polygon type.

**qreal getExpectSpeedFactor() const**

Get the desired speed factor.

**void setExpectSpeedFactor(qreal val)**

Set the desired speed factor.

**qreal getElevation() const**

Get the elevation of the region.

**void setElevation(qreal elevation)**

Set the elevation of the region.

**QPolygonF getPolygon() const**

Get the polygon of the region.

**long getLayerId() const**

Get the layer ID of the region.

**void setLayerId(long id)**

Set the layer of the region. If the layer ID is invalid, no changes will be made.

**bool isObstacle() const**

Obtain whether the region is designated as an obstacle.

**void setObstacle(bool b)**

Set whether the region is designated as an obstacle.

**bool isBoardingArea() const**

Obtain whether the region is a passenger boarding area.

**void setIsBoardingArea(bool b)**

Set whether the region is a passenger boarding area.

**bool isAlightingArea() const**

Get whether the polygon is a drop-off area.

**void setIsAlightingArea(bool b)**

Set whether the polygon is a drop-off area.

#### 3.4.9.6. Triangular Pedestrian Region (IPedestrianTriangleRegion)

Header file: IPedestrianTriangleRegion.h

**long getId() const**

Get Polygon ID.

**QString getName() const**

Get polygon name.

**void setName(QString name)**

Set polygon name.

**QColor getRegionColor() const**

Get polygon color.

**void setRegionColor(QColor color)**

Set polygon color.

**QPointF getPosition(UnitOfMeasure unit = UnitOfMeasure::Default) const**

Get polygon position. Unit: Pixel.

**void setPosition(QPointF scenePos，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set polygon position. Unit: Pixel.

Parameters: 

[ in ] scenePos: Position in scene coordinate system.

**int getGType() const**

Get polygon type.

**qreal getExpectSpeedFactor() const**

Get the desired speed factor.

**void setExpectSpeedFactor(qreal val)**

Set the desired speed factor.

**qreal getElevation() const**

Get the elevation of the region.

**void setElevation(qreal elevation)**

Set the elevation of the region.

**QPolygonF getPolygon() const**

Get the polygon of the region.

**long getLayerId() const**

Get the layer ID of the region.

**void setLayerId(long id)**

Set the layer of the region. If the layer ID is invalid, no changes will be made.

**bool isObstacle() const**

Obtain whether the region is designated as an obstacle.

**void setObstacle(bool b)**

Set whether the region is designated as an obstacle.

**bool isBoardingArea() const**

Obtain whether the region is a passenger boarding area.

**void setIsBoardingArea(bool b)**

Set whether the region is a passenger boarding area.

**bool isAlightingArea() const**

Get whether the polygon is a drop-off area.

**void setIsAlightingArea(bool b)**

Set whether the polygon is a drop-off area.

#### 3.4.9.7. Elliptical Pedestrian Region (IPedestrianEllipseRegion)

Header file: IPedestrianEllipseRegion.h

**long getId() const**

Get Polygon ID.

**QString getName() const**

Get polygon name.

**void setName(QString name)**

Set polygon name.

**QColor getRegionColor() const**

Get polygon color.

**void setRegionColor(QColor color)**

Set polygon color.

**QPointF getPosition(UnitOfMeasure unit = UnitOfMeasure::Default) const**

Get polygon position. Unit: Pixel.

**void setPosition(QPointF scenePos，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set polygon position. Unit: Pixel.

Parameters: 

[ in ] scenePos: Position in scene coordinate system.

**int getGType() const**

Get polygon type.

**qreal getExpectSpeedFactor() const**

Get the desired speed factor.

**void setExpectSpeedFactor(qreal val)**

Set the desired speed factor.

**qreal getElevation() const**

Get the elevation of the region.

**void setElevation(qreal elevation)**

Set the elevation of the region.

**QPolygonF getPolygon() const**

Get the polygon of the region.

**long getLayerId() const**

Get the layer ID of the region.

**void setLayerId(long id)**

Set the layer of the region. If the layer ID is invalid, no changes will be made.

**bool isObstacle() const**

Obtain whether the region is designated as an obstacle.

**void setObstacle(bool b)**

Set whether the region is designated as an obstacle.

**bool isBoardingArea() const**

Obtain whether the region is a passenger boarding area.

**void setIsBoardingArea(bool b)**

Set whether the region is a passenger boarding area.

**bool isAlightingArea() const**

Get whether the polygon is a drop-off area.

**void setIsAlightingArea(bool b)**

Set whether the polygon is a drop-off area.

#### 3.4.9.8. Fan-shaped Pedestrian Region (IPedestrianFanShapeRegion)

Header file: IPedestrianFanShapeRegion.h

**long getId() const**

Get Polygon ID.

**QString getName() const**

Get polygon name.

**void setName(QString name)**

Set polygon name.

**QColor getRegionColor() const**

Get polygon color.

**void setRegionColor(QColor color)**

Set polygon color.

**QPointF getPosition(UnitOfMeasure unit = UnitOfMeasure::Default) const**

Get polygon position. Unit: Pixel.

**void setPosition(QPointF scenePos，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set polygon position. Unit: Pixel.

Parameters: 

[ in ] scenePos: Position in scene coordinate system.

**int getGType() const**

Get polygon type.

**qreal getExpectSpeedFactor() const**

Get the desired speed factor.

**void setExpectSpeedFactor(qreal val)**

Set the desired speed factor.

**qreal getElevation() const**

Get the elevation of the region.

**void setElevation(qreal elevation)**

Set the elevation of the region.

**QPolygonF getPolygon() const**

Get the polygon of the region.

**long getLayerId() const**

Get the layer ID of the region.

**void setLayerId(long id)**

Set the layer of the region. If the layer ID is invalid, no changes will be made.

**bool isObstacle() const**

Obtain whether the region is designated as an obstacle.

**void setObstacle(bool b)**

Set whether the region is designated as an obstacle.

**bool isBoardingArea() const**

Obtain whether the region is a passenger boarding area.

**void setIsBoardingArea(bool b)**

Set whether the region is a passenger boarding area.

**bool isAlightingArea() const**

Get whether the polygon is a drop-off area.

**void setIsAlightingArea(bool b)**

Set whether the polygon is a drop-off area.

**qreal getInnerRadius() const**

Retrieve inner radius, Unit: meters.

**qreal getOuterRadius() const**

Retrieve outer radius, Unit: meters.

**qreal getStartAngle() const**

Retrieve start angle, Unit: degrees.

**qreal getSweepAngle() const**

Retrieve sweep angle, Unit: degrees.

#### 3.4.9.9. Polygon Pedestrian Region (IPedestrianPolygonRegion)

Header file: IPedestrianPolygonRegion.h

**long getId() const**

Get Polygon ID.

**QString getName() const**

Get polygon name.

**void setName(QString name)**

Set polygon name.

**QColor getRegionColor() const**

Get polygon color.

**void setRegionColor(QColor color)**

Set polygon color.

**QPointF getPosition(UnitOfMeasure unit = UnitOfMeasure::Default) const**

Get polygon position. Unit: Pixel.

**void setPosition(QPointF scenePos，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set polygon position. Unit: Pixel.

Parameters: 

[ in ] scenePos: Position in scene coordinate system.

**int getGType() const**

Get polygon type.

**qreal getExpectSpeedFactor() const**

Get the desired speed factor.

**void setExpectSpeedFactor(qreal val)**

Set the desired speed factor.

**qreal getElevation() const**

Get the elevation of the region.

**void setElevation(qreal elevation)**

Set the elevation of the region.

**QPolygonF getPolygon() const**

Get the polygon of the region.

**long getLayerId() const**

Get the layer ID of the region.

**void setLayerId(long id)**

Set the layer of the region. If the layer ID is invalid, no changes will be made.

**bool isObstacle() const**

Obtain whether the region is designated as an obstacle.

**void setObstacle(bool b)**

Set whether the region is designated as an obstacle.

**bool isBoardingArea() const**

Obtain whether the region is a passenger boarding area.

**void setIsBoardingArea(bool b)**

Set whether the region is a passenger boarding area.

**bool isAlightingArea() const**

Get whether the polygon is a drop-off area.

**void setIsAlightingArea(bool b)**

Set whether the polygon is a drop-off area.

#### 3.4.9.10. Sidewalk Pedestrian Region (IPedestrianSideWalkRegion)

Header file: IPedestrianSideWalkRegion.h

**long getId() const**

Get Polygon ID.

**QString getName() const**

Get polygon name.

**void setName(QString name)**

Set polygon name.

Parameters: 

[ in ] name: New name.

**QColor getRegionColor() const**

Get polygon color.

**void setRegionColor(QColor color)**

Set polygon color.

Parameters: 

[ in ] color: Surface area color.

**QPointF getPosition(UnitOfMeasure unit = UnitOfMeasure::Default) const**

Get polygon position. Unit: Pixel.

**void setPosition(QPointF scenePos，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set polygon position. Unit: Pixel.

Parameters: 

[ in ] scenePos: Position in scene coordinate system.

**int getGType() const**

Get polygon type.

**qreal getExpectSpeedFactor() const**

Get the desired speed factor.

**void setExpectSpeedFactor(qreal val)**

Set the desired speed factor.

**qreal getElevation() const**

Get the elevation of the region.

**void setElevation(qreal elevation)**

Set the elevation of the region.

**QPolygonF getPolygon() const**

Get the polygon of the region.

**long getLayerId() const**

Get the layer ID of the region.

**void setLayerId(long id)**

Set the layer of the region. If the layer ID is invalid, no changes will be made.

Parameters: 

[ in ] id: Layer ID.

**qreal getWidth() const**

Get the sidewalk width.

**void setWidth(qreal width)**

Set the sidewalk width.

Parameters: 

[ in ] width: Sidewalk width, Unit: m.

**QList\<QGraphicsEllipseItem\*\> getVetexs() const**

Get the vertices of the sidewalk, i.e., the initial polyline vertices.

**QList\<QGraphicsEllipseItem\*\> getControl1Vetexs() const**

Get the Bezier curve control point P1 of the sidewalk.

**QList\<QGraphicsEllipseItem\*\> getControl2Vetexs() const**

Get the Bezier curve control point P2 of the sidewalk.

**QList\<QGraphicsEllipseItem\*\> getCandidateVetexs() const**

Get candidate vertices.

**void removeVetex(int index)**

Delete the vertex at the specified index.

Parameters: 

[ in ] index: Vertex index.

**void insertVetex(QPointF pos，int index)**

Insert a vertex at the specified index, with the initial position at pos.

Parameters: 

[ in ] pos: Vertex position.

[ in ] index: insertion position.

#### 3.4.9.11. Pedestrian Crosswalk Region (IPedestrianCrossWalkRegion)

Header file: IPedestrianCrossWalkRegion.h

**long getId() const**

Get Polygon ID.

**QString getName() const**

Get polygon name.

**void setName(QString name)**

Set polygon name.

Parameters: 

[ in ] name: New name.

**QColor getRegionColor() const**

Get polygon color.

**void setRegionColor(QColor color)**

Set polygon color.

Parameters: 

[ in ] color: Surface area color.

**QPointF getPosition(UnitOfMeasure unit = UnitOfMeasure::Default) const**

Get polygon position. Unit: Pixel.

**void setPosition(QPointF scenePos，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set polygon position. Unit: Pixel.

Parameters: 

[ in ] scenePos: Position in scene coordinate system.

**int getGType() const**

Get polygon type.

**qreal getExpectSpeedFactor() const**

Get the desired speed factor.

**void setExpectSpeedFactor(qreal val)**

Set the desired speed factor.

**qreal getElevation() const**

Get the elevation of the region.

**void setElevation(qreal elevation)**

Set the elevation of the region.

**QPolygonF getPolygon() const**

Get the polygon of the region.

**long getLayerId() const**

Get the layer ID of the region.

**void setLayerId(long id)**

Set the layer of the region. If the layer ID is invalid, no changes will be made.

**qreal getWidth() const**

Get pedestrian crosswalk width, Unit: meter.

**void setWidth(qreal width)**

Set pedestrian crosswalk width, Unit: meter.

**QLineF getSceneLine(UnitOfMeasure unit = UnitOfMeasure::Default) const**

Get the segment from the pedestrian crosswalk start point to end point in the scene coordinate system. Unit: pixel.

**qreal getAngle() const**

Get the pedestrian crosswalk slant angle.

**void setAngle(qreal angle)**

Set the pedestrian crosswalk slant angle.

**qreal getRedLightSpeedFactor() const**

Get the red light clearance speed factor.

**void setRedLightSpeedFactor(qreal factor)**

Set the red light clearance speed factor.

**QVector2D getUnitDirectionFromStartToEnd() const**

Get the unit direction vector from the start point to the end point in the scene coordinate system.

**QVector2D getLocalUnitDirectionFromStartToEnd() const**

Obtain the unit direction vector from the start point to the end point in the local coordinate system of the crosswalk.

**QGraphicsEllipseItem\* getStartControlPoint() const**

Obtain the start control point.

**QGraphicsEllipseItem\* getEndControlPoint() const**

Obtain the end control point.

**QGraphicsEllipseItem\* getLeftControlPoint() const**

Obtain the left control point.

**QGraphicsEllipseItem\* getRightControlPoint() const**

Obtain the right control point.

**ICrosswalkSignalLamp\* getPositiveDirectionSignalLamp() const**

Obtain the traffic signal controlling forward movement.

**ICrosswalkSignalLamp\* getNegativeDirectionSignalLamp() const**

Obtain the traffic signal controlling reverse movement.

**bool isPositiveTrafficLightAdded() const**

Determine whether a traffic signal controlling forward movement has been added.

**bool isReverseTrafficLightAdded() const**

Determine whether a traffic signal controlling reverse movement has been added.

#### 3.4.9.12. Pedestrian Stair Region (IPedestrianStairRegion)

Header file: IPedestrianStairRegion.h

**long getId() const**

Get Polygon ID.

**QString getName() const**

Get polygon name.

**void setName(QString name)**

Set polygon name.

**QColor getRegionColor() const**

Get polygon color.

**void setRegionColor(QColor color)**

Set polygon color.

**QPointF getPosition(UnitOfMeasure unit = UnitOfMeasure::Default) const**

Get polygon position. Unit: Pixel.

**void setPosition(QPointF scenePos，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set polygon position. Unit: Pixel.

Parameters: 

[ in ] scenePos: Position in scene coordinate system.

**int getGType() const**

Get polygon type.

**qreal getWidth() const**

Obtain the stair width, Unit: m.

**void setWidth(qreal width)**

Set stair width, Unit: m.

**QPointF getStartPoint() const**

Get start point in the scene coordinate system.

**QPointF getEndPoint() const**

Get end point in the scene coordinate system.

**qreal getStartConnectionAreaLength() const**

Get length of the start connection area, Unit: m.

**qreal getEndConnectionAreaLength() const**

Get length of the end connection area, Unit: m.

**QPointF getStartRegionCenterPoint() const**

Get center of the start connection area in the scene coordinate system.

**QPointF getEndRegionCenterPoint() const**

Get center of the end connection area in the scene coordinate system.

**QPainterPath getStartSceneRegion() const**

Get shape of the start connection area in the scene coordinate system.

**QPainterPath getEndSceneRegion() const**

Get shape of the end connection area in the scene coordinate system.

**QPainterPath getMainQueueRegion() const**

Get the main shape of the stairs in the scene coordinate system.

**QPainterPath getFullQueueregion() const**

Retrieve the overall shape of the staircase in the scene coordinate system.

**QPolygonF getMainQueuePolygon() const**

Retrieve the main polygon of the staircase in the scene coordinate system.

**StairType getStairType() const**

Get the staircase type.

**void setStairType(StairType type)**

Set the staircase type.

**long getStartLayerId() const**

Get the starting level.

**void setStartLayerId(long id)**

Set the starting level.

**long getEndLayerId() const**

Get the ending level.

**void setEndLayerId(long id)**

Set the ending level.

**qreal getTransmissionSpeed() const**

Get the conveyor speed, Unit: m/s.

**void setTransmissionSpeed(qreal speed)**

Set the conveyor speed, Unit: m/s.

**qreal getHeadroom() const**

Get the net height of the staircase.

**void setHeadroom(qreal headroom)**

Set the net height of the staircase.

**QGraphicsEllipseItem\* getStartControlPoint() const**

Obtain the start control point.

**QGraphicsEllipseItem\* getEndControlPoint() const**

Obtain the end control point.

**QGraphicsEllipseItem\* getLeftControlPoint() const**

Obtain the left control point.

**QGraphicsEllipseItem\* getRightControlPoint() const**

Obtain the right control point.

**QGraphicsEllipseItem\* getStartConnectionAreaControlPoint() const**

Get the starting connection area length control point.

**QGraphicsEllipseItem\* getEndConnectionAreaControlPoint() const**

Get the ending connection area length control point.

#### 3.4.9.13. Pedestrian Path (IPedestrianPath)

Header file: IPedestrianPath.h

**long getId() const**

Retrieve the pedestrian path ID.

**IPedestrianPathPoint\* getPathStartPoint() const**

Retrieve the starting point of the pedestrian path.

**IPedestrianPathPoint\* getPathEndPoint() const**

Retrieve the end point of the pedestrian path.

**QList\<IPedestrianPathPoint\*\> getPathMiddlePoints() const**

Retrieve the intermediate points of the pedestrian path.

**bool isLocalPath() const**

Determine whether it is a local path.

#### 3.4.9.14. Pedestrian Path Point (IPedestrianPathPoint)

Header file: IPedestrianPathPoint.h

**long getId() const**

Retrieve the pedestrian path point ID.

**QPointF getScenePos(UnitOfMeasure unit = UnitOfMeasure::Default) const**

Retrieve the position of the pedestrian path point in the scene coordinate system. Unit: pixel.

**qreal getRadius() const**

Retrieve the radius of the pedestrian path point. Unit: m.

#### 3.4.9.15. Crosswalk Signal Lamp (ICrosswalkSignalLamp)

Header file: ICrosswalkSignalLamp.h

**long id()**

Retrieve Traffic Signal ID.

**void setSignalPhase(ISignalPhase\* pPhase)**

Set Phase; the assigned phase may be from another traffic signal group.

**void setPhaseNumber(int num)**

Set the phase index, starting from 1. If the index exceeds the total number of phases, the setting will not be applied.

**void setLampColor(QString colorStr)**

Set Traffic Signal color.

Parameters: 

[ in ] colorStr: Color expressed as a string, with four options: "red", "green", "yellow", "gray"; alternatively, "R", "G", "Y", "gray". 

**QString color()**

Retrieve Traffic Signal color. "R", "G", "Y", and "grey" correspond to "红" (Red), "绿" (Green), "黄" (Yellow), and "灰" (Gray), respectively.

**QString name()**

Retrieve the traffic signal name.

**void setName(QString name)**

Assign the traffic signal name.

**void setDistToStart(qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set the traffic signal distance from the start of the road segment. Unit: pixel.

Parameters: 

[ in ] dist: distance value.

**ISignalPlan\* signalPlan()**

Retrieve the signal control scheme.

**ISignalPhase\* signalPhase()**

Retrieve the phase.

**ILaneObject\* laneObject()**

Retrieve the lane or lane connection where it is located.

**QPolygonF polygon()**

Retrieve the vertices of the traffic signal polygonal contour.

**qreal angle()**

Retrieve the traffic signal angle.

**IPedestrianCrossWalkRegion\* getICrossWalk() const**

Get the associated pedestrian crosswalk.

### 3.4.10. Parking Module

#### 3.4.10.1. Parking Stall (IParkingStall)

Header file: IParkingStall.h

**long id()**

Get the parking stall ID.

**long parkingRegionId()**

Get the associated parking region ID.

**IParkingRegion\* parkingRegion()**

Get the associated parking region.

**qreal distance()**

Get the distance from the start of the road segment, Unit: m.

**int stallType()**

Get the stall type, consistent with the vehicle type code.

#### 3.4.10.2. Parking Region (IParkingRegion)

Header file: IParkingRegion.h

**long id()**

Get Parking Region ID.

**QString name()**

Get Parking Region Name.

**void setName(QString name)**

Set Parking Region Name.

Parameters: 

[ in ] name: New name.

**QList\<IParkingStall\*\> parkingStalls()**

Get All Parking Slots.

**Online::ParkingLot::DynaParkingRegion dynaParkingRegion()**

Get Dynamic Parking Region Information.

#### 3.4.10.3. Parking Path Decision Point (IParkingDecisionPoint)

Header file: IParkingDecisionPoint.h

**long id()**

Get Parking Decision Point ID.

**QString name()**

Get Parking Decision Point Name.

**ILink\* link()**

Get the Road Segment Where the Parking Decision Point is Located.

**qreal distance()**

Get the Distance from the Parking Decision Point to the Road Segment Start, Unit: m.

**QList\<IParkingRouting\*\> routings()**

Get Related Parking Paths.

**bool updateParkDisInfo(const QList\<Online::ParkingLot::DynaParkDisInfo\>& tollDisInfoList)**

Update Parking Allocation Information.

Parameters: 

[ in ] tollDisInfoList: List of Parking Allocation Information.

**QList\<Online::ParkingLot::DynaParkDisInfo\> parkDisInfoList()**

Retrieve the list of parking allocation information.

**QPolygonF polygon()**

Retrieve the polygonal contour of the parking decision point.

#### 3.4.10.4. Parking Path (IParkingRouting)

Header file: IParkingRouting.h

**long id()**

Get the Path ID.

**long parkingDeciPointId()**

Get the associated Decision Point ID.

**long parkingRegionId()**

ID of the parking area reached by the path.

**qreal calcuLength()**

Calculate the length of the path.

**bool contain(ISection\* pRoad)**

Determine whether the specified road is on the current path.

Parameters: 

[ in ] pRoad: Road segment or Connection segment.

**ISection\* nextRoad(ISection\* pRoad)**

Determine the subsequent road given the specified road.

Parameters: 

[ in ] pRoad: Road segment or Connection segment.

**QList\<ILink\*\> getLinks()**

Retrieve the sequence of road segments.

### 3.4.11. Toll Station Module

#### 3.4.11.1. Toll Point (ITollPoint)

Header file: ITollPoint.h

**long id()**

Get the Toll Point ID.

**qreal distance()**

Get the distance from the start of the road segment, Unit: m.

**long tollLaneId()**

Get the associated Toll Lane ID.

**ITollLane\* tollLane()**

Get the associated Toll Lane.

**bool isEnabled()**

Retrieve whether it is enabled.

**bool setEnabled(bool enabled)**

Set the enabled status.

Parameters: 

[ in ] enabled: Whether it is enabled.

**int tollType()**

Retrieve toll type.

**bool setTollType(int tollType)**

Set toll type.

Parameters: 

[ in ] tollType: Toll type.

**int timeDisId()**

Retrieve parking time distribution ID.

**bool setTimeDisId(int timeDisId)**

Set parking time distribution ID.

Parameters: 

[ in ] timeDisId: Time distribution ID.

#### 3.4.11.2. Toll Lane (ITollLane)

Header file: ITollLane.h

**long id()**

Retrieve toll lane ID.

**QString name()**

Retrieve toll lane name.

**qreal distance()**

Get the distance from the start of the road segment, Unit: m.

**void setName(QString name)**

Set toll lane name.

Parameters: 

[ in ] name: New toll lane name.

**void setWorkTime(long startTime，long endTime)**

Set working hours, which correspond to simulation time.

Parameters: 

[ in ] startTime: Start time. Unit: s.

[ in ] endTime: End time. Unit: s.

**Online::TollStation::DynaTollLane dynaTollLane()**

Retrieve dynamic toll lane information.

**QList\<ITollPoint\*\> tollPoints()**

Retrieve all toll points of the toll lane.

#### 3.4.11.3. Toll Decision Point (ITollDecisionPoint)

Header file: ITollDecisionPoint.h

**long id()**

Retrieve the ID of the toll decision point.

**QString name()**

Retrieve the name of the toll decision point.

**ILink\* link()**

Retrieve the road segment on which the toll decision point is located.

**qreal distance()**

Retrieve the distance from the start of the road segment, Unit: m.

**QList\<ITollRouting\*\> routings()**

Retrieve the associated toll paths.

**QList\<Online::TollStation::DynaTollDisInfo\> tollDisInfoList()**

Retrieve the list of toll allocation information.

**void updateTollDisInfoList(const QList\<Online::TollStation::DynaTollDisInfo\>& tollDisInfoList)**

Update the list of toll allocation information.

Parameters: 

[ in ] tollDisInfoList: List of toll allocation information.

**QPolygonF polygon()**

Retrieve the polygonal contour of the toll decision point.

#### 3.4.11.4. Toll Routing (ITollRouting)

Header file: ITollRouting.h

**long id()**

Get the Path ID.

**long tollDeciPointId()**

Obtain the associated toll decision point ID.

**long tollLaneId()**

ID of the toll area reached by the path.

**qreal calcuLength()**

Calculate the length of the path.

**bool contain(ISection\* pRoad)**

Determine whether the specified road is on the current path.

Parameters: 

[ in ] pRoad: Road segment or Connection segment.

**ISection\* nextRoad(ISection\* pRoad)**

Determine the subsequent road given the specified road.

Parameters: 

[ in ] pRoad: Road segment or Connection segment.

**QList\<ILink\*\> getLinks()**

Retrieve the sequence of road segments.

### 3.4.12. Node Module

#### 3.4.12.1. Node (IJunction)

Header file: IJunction.h

**long getId() const**

Get the node ID.

**QString name() const**

Get the node name.

**void setName(const QString& strName)**

Set the node name.

Parameters: 

[ in ] strName: New name.

**QList\<ILink\*\> getJunctionLinks()**

Get the road segments within the node.

**QList\<IConnector\*\> getJunctionConnectors()**

Get the connection segments within the node.

**QList\<Online::Junction::TurnningBaseInfo\> getAllTurnningInfo()**

Get all traffic movement information within the node.

**Online::Junction::TurnningBaseInfo getTurnningInfo(long turningId)**

Get specified traffic movement information within the node.

### 3.4.13. Vehicles and Pedestrians

#### 3.4.13.1. Vehicle (IVehicle)

Header file: ivehicle.h

Vehicle interface for accessing and controlling vehicles. This interface enables reading vehicle attributes, setting certain vehicle properties, and during the simulation process, accessing current road conditions, adjacent vehicles to the front, rear, left, and right, along with their distances.

**long id()**

Vehicle ID; the Vehicle ID is composed as x * 100000 + y, where each departure point’s x value is unique, incrementing from 1, and y is the sequence number of vehicles issued from each departure point, incrementing from 1. Vehicle IDs from the first departure point start incrementally at 100001, while those from the second departure point start incrementally at 200001.

**ILink\* startLink()**

Starting road segment when the vehicle enters the road network.

**long startSimuTime()**

Starting time when the vehicle enters the road network.

**long roadId()**

ID of the road segment or connection segment where the vehicle is currently located.

**void\* road()**

Road: returns ILink if located on a Road Segment, returns IConnector if on a Connection Segment.

**ISection\* section()**

Section where the vehicle is located, i.e., a Road Segment or Connection Segment.

**ILaneObject\* laneObj()**

Lane or Lane connection where the vehicle is located.

**int segmIndex()**

Segment index of the vehicle on the current LaneObject.

**bool roadIsLink()**

Indicates whether the Road the vehicle is on is a Road Segment.

**QString roadName()**

Road name.

**qreal initSpeed(qreal speed，UnitOfMeasure unit = UnitOfMeasure::Default)**

Initial vehicle speed.

Parameters: 

[ in ] speed: Initial speed value. Unit: pixels/s.

**void initLane(int laneNumber，qreal dist = -1，qreal speed = -1，UnitOfMeasure unit = UnitOfMeasure: : Default)**

Initialize vehicle on a Road Segment.

Parameters: 

[ in ] laneNumber: Lane number.

[ in ] dist: Distance from the start point, unit: pixels.

[ in ] speed: Initial speed, unit: pixels/s.

**void initLaneConnector(int laneNumber，int toLaneNumber，qreal dist = -1，qreal speed = -1，UnitOfMeasure unit = UnitOfMeasure: : Default)**

Initialize vehicle on a Connection Segment. Unit: pixels.

Parameters: 

[ in ] laneNumber: Starting lane number.

[ in ] toLaneNumber: Target lane number.

[ in ] dist: Distance from the start point, unit: pixels.

[ in ] speed: Initial speed, unit: pixels/s.

**void setVehiType(int code)**

Set the vehicle type. The vehicle type is determined upon creation; this method allows modifying the vehicle type.

Parameters: 

[ in ] code: Vehicle type code.

**void setColor(QString color)**

Set the vehicle color.

Parameters: 

[ in ] color: Color in RGB format, e.g.: "#EE0000".

Example:

```cpp
// Set the vehicle color to blue
vehicle->setColor("#00AFF0");
```

**qreal length(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the vehicle length. Unit: pixel.

**void setLength(qreal len，bool bRestWidth，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set the vehicle length. Unit: pixel.

Parameters: 

[ in ] len: Length value, unit: pixel or meter (depending on the unit parameter).

[ in ] bRestWidth: Whether to proportionally constrain the width.

**long laneId()**

If toLaneId() is less than or equal to 0, laneId() returns the current lane ID; if toLaneId() is greater than 0, indicating the vehicle is on a lane connection, laneId() returns the upstream lane ID.

**long toLaneId()**

Downstream lane ID. If less than or equal to 0, the vehicle is on the lane of the road segment; otherwise, the vehicle is on the lane connection of the connection segment.

**ILane\* lane()**

Get the current lane. If the vehicle is on a lane connection, returns the upstream lane of the lane connection.

**ILane\* toLane()**

If the vehicle is on a lane connection, returns the downstream lane of the lane connection; if not currently on a lane connection, returns nullptr.

**ILaneConnector\* laneConnector()**

Get the current lane connection; returns nullptr if the vehicle is on a lane.

**long currBatchNumber()**

Current simulation computation batch.

**int roadType()**

Type of road where the vehicle is located. GLinkType represents a Road Segment; GConnectorType represents a Connection Segment.

**qreal limitMaxSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the maximum speed limit, unit: pixel/s.

**qreal limitMinSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the minimum speed limit, unit: pixel/s.

**long vehicleTypeCode()**

Vehicle type code.

**QString vehicleTypeName()**

Get the vehicle type name, e.g., "Passenger Car".

**QString name()**

Retrieve the vehicle name.

**IVehicleDriving\* vehicleDriving()**

Retrieve the vehicle driving behavior interface.

**void driving()**

Drive the vehicle. This method is invoked once for each active vehicle during every computation cycle.

**QPointF pos(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the current position. Unit: Pixel.

**qreal zValue(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the current elevation. Unit: Pixel.

**qreal acce(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the current acceleration. Unit: Pixel.

**qreal currSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

Retrieve the current speed. Unit: Pixel/s.

**qreal angle()**

Current heading angle, 0 degrees facing north, positive clockwise.

**bool isStarted()**

Indicates whether the vehicle is active. Returning false means the vehicle has exited the road network or has not yet entered the road.

**IVehicle\* vehicleFront()**

Preceding vehicle object.

**IVehicle\* vehicleRear()**

Following vehicle object.

**IVehicle\* vehicleLFront()**

Front-left vehicle object.

**IVehicle\* vehicleLRear()**

Rear-left vehicle object.

**IVehicle\* vehicleRFront()**

Front-right vehicle object.

**IVehicle\* vehicleRRear()**

Right rear vehicle object.

**qreal vehiDistFront(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the distance to the preceding vehicle. Unit: Pixel.

**qreal vehiSpeedFront(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the speed of the preceding vehicle. Unit: Pixel/s.

**qreal vehiHeadwayFront(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the time gap to the preceding vehicle. Unit: seconds.

**qreal vehiDistRear(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the distance to the following vehicle. Unit: Pixel.

**qreal vehiSpeedRear(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the speed of the following vehicle. Unit: Pixel/s.

**qreal vehiHeadwaytoRear(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the time gap to the following vehicle. Unit: seconds.

**qreal vehiDistLLaneFront(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the distance to the left front vehicle. Unit: Pixel.

**qreal vehiSpeedLLaneFront(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the speed of the left front vehicle. Unit: Pixel.

**qreal vehiDistLLaneRear(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the distance to the left rear vehicle. Unit: Pixel.

**qreal vehiSpeedLLaneRear(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the speed of the left rear vehicle. Unit: Pixel.

**qreal vehiDistRLaneFront(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the distance to the right front vehicle. Unit: Pixel.

**qreal vehiSpeedRLaneFront(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the speed of the right front vehicle. Unit: Pixel.

**qreal vehiDistRLaneRear(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the distance to the rear-right vehicle. Unit: Pixel.

**qreal vehiSpeedRLaneRear(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the speed of the rear-right vehicle. Unit: Pixel.

**void setDynaInfo(void\* pDynaInfo)**

Set dynamic information.

**void\* dynaInfo()**

Get dynamic information.

**QList\<QPointF\> lLaneObjectVertex(UnitOfMeasure unit = UnitOfMeasure::Default)**

Obtain the set of interior points along the centerline of a lane or lane connection. Unit: Pixel.

**IRouting\* routing()**

Current path.

**QPicture picture()**

Retrieve the vehicle image.

**QPolygonF boundingPolygon()**

Obtain the polygon constituted by the four corners of the vehicle as determined by its orientation and length.

**void setTag(long tag)**

Set the state represented by a label.

**long tag()**

Get the state represented by a label.

**void setTextTag(QString text)**

Set text information for temporarily saving data during runtime to facilitate development.

**QString textTag()**

Text information temporarily saved during runtime for development convenience.

**void setJsonInfo(QJsonObject info)**

Set JSON-formatted data.

**QJsonObject jsonInfo()**

Return JSON-formatted data.

**QVariant jsonProperty(QString propName)**

Return JSON field value.

**void setJsonProperty(QString key，QVariant value)**

Set JSON data attribute.

#### 3.4.13.2. Vehicle Driving Behavior (IVehicleDriving)

Header file: ivehicledriving.h

Vehicle driving behavior interface that enables control of vehicle lane changes to the left or right, vehicle angles, as well as vehicle speed, coordinate position, and other parameters. **After obtaining the vehicle object `vehicle`, invoke methods through `vehicle->vehicleDriving()->xxx()`.**

**IVehicle\* vehicle()**

Current driving vehicle.

**long getRandomNumber()**

Retrieve a random number.

**bool nextPoint()**

Compute the next position, encompassing processes such as calculating vehicle neighbor relationships, determining whether a bus is entering or leaving a station, lane changes, acceleration, speed, travel distance, car-following type, trajectory type, and so forth.

**long zeroSpeedInterval()**

Duration during which the current vehicle speed remains zero. Unit: ms.

**bool isHavingDeciPointOnLink()**

Indicates whether the vehicle is currently on a road segment and at a decision point.

**int followingType()**

Type of the leading vehicle, i.e., the type of the vehicle ahead of the current vehicle, classified as: 0: Stopped, 1: Normal, 5: Abrupt Deceleration, 6: Abrupt Acceleration, 7: Merging, 8: Crossing, 9: Cooperative Deceleration, 10: Cooperative Acceleration, 11: Deceleration Awaiting Turn, 12: Acceleration Awaiting Turn.

**bool isOnRouting()**

Indicates whether the vehicle is currently on a path.

**void stopVehicle()**

Stop operation and remove the vehicle from the road network.

**qreal angle()**

Rotation angle. Unit: degrees. North is 0°, clockwise.

**void setAngle(qreal angle)**

Set the vehicle's rotation angle.

Parameters: 

[ in ] angle: Rotation angle, 360 degrees for a full circle.

**QVector3D euler(bool bPositive = false)**

Returns the vehicle's Euler angles.

Parameters: 

[ in ] bPositive: Indicates if the heading direction is calculated forward. If bPositive is false, calculation is performed in the reverse direction.

**qreal desirSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

Gets the desired speed, Unit: pixel/s.

**ISection\* getCurrRoad()**

Returns the current road segment or connection segment.

**ISection\* getNextRoad()**

Returns the next road segment or connection segment.

**int differToTargetLaneNumber()**

Difference from the target lane number; a nonzero value indicates a forced lane change intention. A positive value denotes left lane change intent, a negative value denotes right lane change intent, and the absolute value specifies the required number of forced lane changes.

**void toLeftLane(bool bFource = false)**

Left lane change.

Parameters: 

[ in ] bForce: Specifies whether to force the lane change. Default is false.

Example:

```cpp
// Control the vehicle to change lanes to the left
vehicle->vehicleDriving()->toLeftLane();
```

**void toRightLane(bool bFource = false)**

Right lane change.

Parameters: 

[ in ] bForce: Specifies whether to force the lane change. Default is false.

Example:

```cpp
// Control the vehicle to change lanes to the right
vehicle->vehicleDriving()->toRightLane();
```

**int laneNumber()**

Current lane number, with 0 representing the rightmost lane.

**void initTrace()**

Initialize the trajectory.

**void setTrace(QList\<QPointF\>& lPoint，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set the trajectory point set. Unit: Pixel.

Parameters: 

[ in ] lPoint: Set of trajectory point coordinates.

**void calcTraceLength()**

Calculate the trajectory length.

**int tracingType()**

Return the trajectory type, categorized as: 0: Car-following, 1: Left lane change, 2: Right lane change, 3: Left virtual lane change, 4: Right virtual lane change, 5: Left turn waiting, 6: Right turn waiting, 7: Bay entry, 8: Bay exit.

**void setTracingType(int type)**

Set the trajectory type.

**void setLaneNumber(int number)**

Set the current lane number.

Parameters: 

[ in ] number: Lane number.

**qreal currDistanceInRoad(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get the traveled distance on the current road segment or connection segment. Unit: Pixel.

**void setCurrDistanceInRoad(qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set the distance traveled on the current road segment or connection segment. Unit: pixel.

Parameters: 

[ in ] dist: Distance.

**void setVehiDrivDistance(qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set total mileage traveled. Unit: pixel.

Parameters: 

[ in ] dist: Total mileage.

**qreal getVehiDrivDistance(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get total mileage traveled. Unit: pixel.

**qreal currDistanceInSegment(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get distance traveled on the current subsection. Unit: pixel.

**void setCurrDistanceInSegment(qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set distance traveled on the current subsection. Unit: pixel.

Parameters: 

[ in ] dist: Distance.

**void setSegmentIndex(int index)**

Set subsection index.

**void setCurrDistanceInTrace(qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set traveled distance along the curved trajectory. Unit: pixel.

Parameters: 

[ in ] dist: Distance.

**void setX(qreal posX，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set X coordinate. Unit: pixel.

Parameters: 

[ in ] posX: X coordinate.

**void setY(qreal posY，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set Y coordinate. Unit: pixel.

Parameters: 

[ in ] posY: Vertical coordinate.

**void setV3z(qreal v3z，UnitOfMeasure unit = UnitOfMeasure::Default)**

Set elevation coordinate. Unit: pixel.

Parameters: 

[ in ] v3z: Elevation coordinate.

**QList\<QPointF\> changingTrace(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get lane change decision point set. Unit: pixel.

**qreal changingTraceLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

Get lane change length. Unit: pixel.

**qreal distToStartPoint(bool fromVehiHead = false，bool bOnCentLine = true，UnitOfMeasure unit = UnitOfMeasure: : Default)**

Get distance from the start point on the lane or lane connection. Unit: pixel.

Parameters: 

[ in ] fromVehiHead: Whether to calculate from the vehicle front.

[ in ] bOnCentLine: Whether currently on the center line.

**qreal distToEndpoint(bool fromVehiHead = false，bool bOnCentLine = true，UnitOfMeasure unit = UnitOfMeasure: : Default)**

Get distance to the terminal point on the lane or lane connection. Unit: pixel.

Parameters: 

[ in ] fromVehiHead: Whether to calculate from the vehicle front.

[ in ] bOnCentLine: Whether currently on the center line.

**bool setRouting(IRouting\* pRouting)**

Set path. The externally set path may not necessarily contain decision points and may be created temporarily. If the vehicle is not on this path, setting will fail and return false.

Example:

```cpp
// 1. Use existing decision point vehicle routing
IRouting* routing1 = netiface->findRouting(1);
vehicle->vehicleDriving()->setRouting(routing1);

// 2. Create vehicle routing not bound to decision points
QList<int> linkIdList = {8, 16, 25};
QList<ILink*> linkList;
for (int linkId : linkIdList) 
{
    linkList.append(netiface->findLink(linkId));
}
IRouting* routing2 = netiface->createRouting(linkList);
vehicle->vehicleDriving()->setRouting(routing2);
```

**IRouting\* routing()**

Current path.

**bool moveToLane(ILane\* pLane，qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

Move the vehicle to another lane. Unit: Pixel.

Parameters: 

[ in ] pLane: Target lane.

[ in ] dist: Distance from the start point of the target lane.

**bool moveToLaneConnector(ILaneConnector\* pLaneConnector，qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

Move the vehicle to another lane connection. Unit: Pixel.

Parameters: 

[ in ] pLaneConnector: Target lane connection.

[ in ] dist: Distance from the start point of the target lane connection.

**bool move(ILaneObject\* pILaneObject，qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

Move the vehicle to another lane or lane connection. Unit: Pixel.

Parameters: 

[ in ] pILaneObject: Target lane or lane connection.

[ in ] dist: Distance from the target start point.

Example:

```cpp
// Get lane object
lane = netiface->findLane(6);
// Position, unit: m
dist = 50;
// Move vehicle to specified lane and position, achieving teleportation of vehicle location
vehicle->vehicleDriving()->move(lane, dist, UnitOfMeasure::Metric);
```

#### 3.4.13.3. Pedestrian (IPedestrian)

Header file: IPedestrian.h

**long getId() const**

Retrieve pedestrian ID.

**qreal getRadius() const**

Retrieve pedestrian radius, Unit: m.

**qreal getWeight() const**

Retrieve pedestrian mass, Unit: kg.

**QString getColor() const**

Retrieve pedestrian color in RGB format, e.g.: "#EE0000".

**QPointF getPos() const**

Retrieve pedestrian current position, Unit: m.

**qreal getAngle() const**

Retrieve pedestrian current angle in the Qt coordinate system, where the positive x-axis is 0 and counterclockwise is positive.

**QVector2D getDirection() const**

Retrieve pedestrian current 2D directional vector.

**qreal getElevation() const**

Retrieve pedestrian current elevation, Unit: m.

**QVector2D getSpeed() const**

Retrieve pedestrian current velocity, Unit: m/s.

**qreal getDesiredSpeed() const**

Retrieve pedestrian desired speed, Unit: m/s.

**qreal getMaxSpeed() const**

Retrieve pedestrian maximum speed limit, Unit: m/s.

**QVector2D getAcce() const**

Retrieve pedestrian current acceleration, Unit: m/s².

**qreal getMaxAcce() const**

Obtain the maximum acceleration limit of pedestrians, unit: m/s².

**QVector3D getEuler() const**

Obtain the pedestrian Euler angles.

**QVector3D getSpeedEuler() const**

Obtain the pedestrian velocity Euler angles.

**QVector2D getWallFDirection() const**

Obtain the unit vector in the wall direction.

**IPedestrianRegion\* getRegion() const**

Obtain the current domain where the pedestrian is located.

**long getPedestrianTypeId() const**

Obtain the pedestrian type ID.

**void stop()**

Stop the simulation; the current pedestrian will be removed in the next simulation batch, releasing resources.

<div style="page-break-after: always;"></div>

# 4. High-Frequency Interfaces

This section provides frequently used interface code examples for TESS NG secondary development.



## 4.1. Road Network Modeling

### 4.1.1. Creating Road Segments and Connection Segments

The code for creating road segments and connection segments is shown below. **Moreover, the open-source road network editing tool pytessng (implemented using TESS NG Python secondary development) supports importing data from OpenDrive, shape, OpenStreetMap, and other formats to build road networks. For detailed instructions, please refer to [pytessng · PyPI](https://pypi.org/project/pytessng/) .**

```cpp
// ==================== Create Links ====================
// Create the first link: Cao'an Highway
QPointF startPoint = QPointF(-300, 0);
QPointF endPoint = QPointF(300, 0);
QList linkPoints = {startPoint, endPoint};
ILink* link1 = netiface->createLink(linkPoints, 7, "曹安公路", true, UnitOfMeasure::Metric);
if (link1) 
{
    // Lane list
    QList<ILane*> lanes = link1->lanes();
    // Create dispatch point on the current link
    IDispatchPoint* dp = netiface->createDispatchPoint(link1);
    if (dp)
    {
        // Set dispatch interval, including vehicle composition, time interval, and number of dispatches
        dp->addDispatchInterval(1, 2, 28);
    }
}

// Create the second link
startPoint = QPointF(-300, -25);
endPoint = QPointF(300, -25);
linkPoints = {startPoint, endPoint};
ILink* link2 = netiface->createLink(linkPoints, 3, "次干道", true, UnitOfMeasure::Metric);
if (link2)
{
    // Create dispatch point on the current link
    IDispatchPoint* dp = netiface->createDispatchPoint(link2);
    if (dp)
    {
        // Set dispatch interval, including vehicle composition, time interval, and number of dispatches
        dp->addDispatchInterval(1, 3600, 3600);
    }
    // Set the outer lane as a bus lane
    QList<ILane*> lanes = link2->lanes();
    ILane* lane = lanes[0];
    lane->setLaneType("公交专用道");
}

// Create the third link
startPoint = QPointF(-300, 25);
endPoint = QPointF(-150, 25);
linkPoints = {startPoint, endPoint};
ILink* link3 = netiface->createLink(linkPoints, 3, "link3", true, UnitOfMeasure::Metric);
if (link3)
{
    // Create dispatch point on the current link
    IDispatchPoint *dp = netiface->createDispatchPoint(link3);
    if (dp)
    {
        // Set dispatch interval, including vehicle composition, time interval, and number of dispatches
        dp->addDispatchInterval(1, 3600, 3600);
    }
}

// Create the fourth link
startPoint = QPointF(-50, 25);
endPoint = QPointF(50, 25);
linkPoints = {startPoint, endPoint};
ILink* link4 = netiface->createLink(linkPoints, 3, "link4", true, UnitOfMeasure::Metric);

// Create the fifth link
startPoint = QPointF(150, 25);
endPoint = QPointF(300, 25);
linkPoints = {startPoint, endPoint};
ILink* link5 = netiface->createLink(linkPoints, 3, "自定义限速路段", true, UnitOfMeasure::Metric);
if (link5)
{
    // Set link speed limit, unit: km/h
    link5->setLimitSpeed(30);
}

// Create the sixth link
startPoint = QPointF(-300, 50);
endPoint = QPointF(300, 50);
linkPoints = {startPoint, endPoint};
ILink* link6 = netiface->createLink(linkPoints, 3, "动态发车路段", true, UnitOfMeasure::Metric);
if (link6)
{
    // Set link speed limit, unit: km/h
    link6->setLimitSpeed(80);
}

// Create the seventh link
startPoint = QPointF(-300, 75);
endPoint = QPointF(-250, 75);
linkPoints = {startPoint, endPoint};
ILink* link7 = netiface->createLink(linkPoints, 3, "link7", true, UnitOfMeasure::Metric);
if (link7)
{
    // Set link speed limit, unit: km/h
    link7->setLimitSpeed(80);
}

// Create the eighth link
startPoint = QPointF(-50, 75);
endPoint = QPointF(300, 75);
linkPoints = {startPoint, endPoint};
ILink* link8 = netiface->createLink(linkPoints, 3, "link8", true, UnitOfMeasure::Metric);
if (link8)
{
    // Set link speed limit, unit: km/h
    link8->setLimitSpeed(80);
}

// Create the first connector, connecting link3 and link4
QList<int> fromLaneNumbers = {1, 2, 3};
QList<int> toLaneNumbers = {1, 2, 3};
if (link3 && link4)
{
    IConnector* conn1 = netiface->createConnector(link3->id(), link4->id(), fromLaneNumbers, toLaneNumbers, "连接段1");
}

// Create the second connector, connecting link4 and link5
if (link4 && link5)
{
    IConnector* conn2 = netiface->createConnector(link4->id(), link5->id(), fromLaneNumbers, toLaneNumbers, "连接段2");
}

// Create the third connector, connecting link7 and link8
if (link7 && link8)
{
    IConnector* pConn3 = netiface->createConnector(link7->id(), link8->id(), fromLaneNumbers, toLaneNumbers, "动态发车连接段");
}
```

### 4.1.2. Creating Various Data Collection Devices

Various data collection devices include data collectors, queue counters, and travel time detectors. The code for creating them is as follows.

```cpp
// ==================== Create Data Collector ====================
// Get lane object
ILane* lane = netiface->findLane(1);
// Position, unit: m
qreal dist = 50;
// Create data collector on the link
IVehicleDrivInfoCollector* collector = netiface->createVehiCollectorOnLink(lane, dist, UnitOfMeasure::Metric);

// Get lane connector object
ILaneConnector* laneConnector = netiface->findLaneConnector(1, 4);
// Position, unit: m
qreal dist = 50;
// Create data collector on the connector
IVehicleDrivInfoCollector* collector = netiface->createVehiCollectorOnConnector(laneConnector, dist, UnitOfMeasure::Metric);

// ==================== Create Queue Counter ====================
// Get lane object
ILane* lane = netiface->findLane(1);
// Position, unit: m
qreal dist = 80;
// Create queue counter on the link
IVehicleQueueCounter* counter = netiface->createVehiQueueCounterOnLink(lane, dist, UnitOfMeasure::Metric);

// Get lane connector object
laneConnector* = netiface->findLaneConnector(1, 4);
// Position, unit: m
double dist = 80;
// Create queue counter on the connector
IVehicleQueueCounter* counter = netiface->createVehiQueueCounterOnConnector(laneConnector, dist, UnitOfMeasure::Metric);

// ==================== Create Travel Time Detector ====================
// Get start link object
ILink* startLink = netiface->findLink(1);
// Get end link object
ILink* endLink = netiface->findLink(2);
// Detector start position on the start link, unit: m
qreal startDist = 10;
// Detector end position on the end link, unit: m
qreal endDist = 90;
// Create travel time detector with start on link and end on link
QList<IVehicleTravelDetector*> detectors = netiface->createVehicleTravelDetector_link2link(startLink, endLink, startDist, endDist, UnitOfMeasure::Metric);

// Get start link object
ILink* startLink = netiface->findLink(1);
// Get end lane connector object
ILaneConnector* endLaneConnector = netiface->findLaneConnector(1, 4);
// Detector start position on the start link, unit: m
qreal startDist = 10;
// Detector end position on the end lane connector, unit: m
qreal endDist = 10;
// Create travel time detector with start on link and end on connector
QList<IVehicleTravelDetector*> detectors = netiface->createVehicleTravelDetector_link2conn(startLink, endLaneConnector, startDist, endDist, UnitOfMeasure::Metric);

// Get start lane connector object
ILink* startLaneConnector = netiface->findLaneConnector(1, 4);
// Get end link object
ILaneConnector* endLink = netiface->findLink(2);
// Detector start position on the start lane connector, unit: m
qreal startDist = 10;
// Detector end position on the end link, unit: m
qreal endDist = 90;
// Create travel time detector with start on connector and end on link
QList<IVehicleTravelDetector*> detectors = netiface->createVehicleTravelDetector_conn2link(startLaneConnector, endLink, startDist, endDist, UnitOfMeasure::Metric);

// Get start lane connector object
ILaneConnector* startLaneConnector = netiface->findLaneConnector(1, 4);
// Get end link object
ILaneConnector* endLaneConnector = netiface->findLaneConnector(4, 7);
// Detector start position on the start lane connector, unit: m
qreal startDist = 10;
// Detector end position on the end lane connector, unit: m
qreal endDist = 90;
// Create travel time detector with start on connector and end on connector
QList<IVehicleTravelDetector*> detectors = netiface->createVehicleTravelDetector_conn2conn(startLaneConnector, endLaneConnector, startDist, endDist, UnitOfMeasure::Metric);
```

### 4.1.3. Creating Guidance Arrows

The code for creating guidance arrows is as follows.

```cpp
ILane* lane = netiface->findLane(4);
if (lane)
{
    qreal length = 4;
    qreal distToTerminal = 10;
    Online::GuideArrowType arrowType = Online::GuideArrowType::StraightRight;
	IGuidArrow* guidArrow = netiface->createGuidArrow(lane, length, distToTerminal, arrowType, UnitOfMeasure::Metric);
}
```

### 4.1.4. Creating Bus Stops and Routes

The code for creating bus stops and bus routes is as follows.

```cpp
// Create bus station
ILane* lane = netiface->findLane(1);
IBusStation* busStation = netiface->createBusStation(lane, 30, 50, "公交站1", UnitOfMeasure::Metric);
// Set station type 1: curb type, 2: bay type
busStation.setType(1);

// Create bus line
ILink* link1 = netiface->findLink(1);
ILink* link2 = netiface->findLink(2);
QList<ILink*> links = {link1, link2};
IBusLine* busLine = netiface->createBusLine(links);

// Associate bus line with bus station
bool result = netiface->addBusStationToLine(busLine, busStation);
// Association successful
if (result)
{
    // Get all bus stations on the bus line
    QList<IBusStationLine*> stationLineList = busLine->stationLines();
    // Get the first bus station
    IBusStationLine* stationLine = stationLineList[0];
    // Set vehicle parking time, unit: s
    stationLine->setBusParkingTime(20);
}
```

### 4.1.5. Creating Various Event Zones

Various event zones include Accident Zone, Construction Zone, Restricted Area, and Reconstruction Detour. The code for creating them is as follows.

```cpp
// ==================== Create Accident Zone ====================
// Build parameters
Online::DynaAccidentZoneParam param;
// Accident zone name
param.name = "事故区";
// Road ID
param.roadID = 1;
// Position, distance from the start of the link or connector, unit: m
param.location = 100;
// Length, unit: m
param.length = 50;
// Lane number list, starting from 0, continuous and ordered
param.mlFromLaneNumber.append(0);
// Start time, unit: s
param.startTime= 10
// Duration, unit: s
param.duration = 600
// Adjacent lane speed limit, unit: km/h
param.limitSpeed = 40
// Create accident zone
IAccidentZone* accidentZone = netiface->createAccidentZone(param, UnitOfMeasure::Metric);

// ==================== Create Construction Zone ====================
// Build parameters
Online::DynaRoadWorkZoneParam param;
// Construction zone name
param.name = "施工区";
// Road ID
param.roadID = 1;
// Position, distance from the start of the link or connector, unit: m
param.location = 200;
// Length, unit: m
param.length = 50;  // Length
param.upCautionLength = 70;  // Advance warning length
param.upTransitionLength = 50;  // Transition zone length
param.upBufferLength = 50;  // Buffer zone length
param.downTransitionLength = 40;  // Downstream transition zone length
param.downTerminationLength = 40;  // Termination zone length
// Lane number list, starting from 0, continuous and ordered
param.mlFromLaneNumber.append(0);
// Start time, unit: s
param.startTime = 0;
// Duration, unit: s
param.duration = 3600;
// Adjacent lane speed limit, unit: km/h
param.limitSpeed = 40;
// Create construction zone
IRoadWorkZone* roadWorkZone = netiface->createRoadWorkZone(param, UnitOfMeasure::Metric);

// ==================== Create Restricted Zone ====================
// Build parameters
Online::DynaLimitedZoneParam param;
// Restricted zone name
param.name = "限行区";
// Road ID
param.roadID = 1;
// Position, distance from the start of the link or connector, unit: m
param.location = 200;
// Length, unit: m
param.length = 50;
// Lane number list, starting from 0, continuous and ordered
param.mlFromLaneNumber.append(0);
// Start time, unit: s
param.startTime = 0;
// Duration, unit: s
param.duration = 3600;
// Adjacent lane speed limit, unit: km/h
param.limitSpeed = 40;
// Create restricted zone
ILimitedZone* limitedZone = netiface->createLimitedZone(param, UnitOfMeasure::Metric);

// ==================== Create Reconstruction Lane Borrowing ====================
// Build parameters
Online::DynaReconstructionParam param;
// Construction zone ID
param.roadWorkZoneId = rwzId;
// Link ID being borrowed
param.beBorrowedLinkId = 2;
// Number of lanes being borrowed
param.borrowedNum = 1;
// Passageway length, unit: m
param.passagewayLength = 80;
// Passageway speed limit, unit: m/s
param.passagewayLimitedSpeed = 40 / 3.6;
// Create reconstruction lane borrowing
IReconstruction* reconstruction = netiface->createReconstruction(param, UnitOfMeasure::Metric);
```



## 4.2. Demand Modeling

### 4.2.1. Setting Departure

Departures can be **configured in bulk via departure points before the simulation** or **individual vehicles can be dynamically created during the simulation process**.

(1) Prior to starting the simulation, the code for creating vehicle types, vehicle compositions, departure points, and departure flow rates is as follows.

```cpp
// ==================== Create Vehicle Type ====================
// Build parameters
_VehicleType vehicleType = _VehicleType();
vehicleType.vehicleTypeName = "新建车型1";  // Vehicle type name
vehicleType.Length = 4.5;  // Length, unit: m
vehicleType.lengthSD = 0.5;  // Length standard deviation, unit: m
vehicleType.width = 2;  // Width, unit: m
vehicleType.widthSD = 0.2;  // Width standard deviation, unit: m
vehicleType.avgSpeed = 60;  // Desired speed, unit: km/h
vehicleType.speedSD = 10;  // Desired speed standard deviation, unit: km/h
vehicleType.avgAcce = 4;  // Desired acceleration, unit: m/s²
vehicleType.acceSD = 0.5;  // Desired acceleration standard deviation, unit: m/s²
vehicleType.avgDece = 6;  // Desired deceleration, unit: m/s²
vehicleType.deceSD = 0.5;  // Desired deceleration standard deviation, unit: m/s²
vehicleType.maxAcce = 5.5;  // Maximum acceleration, unit: m/s²
vehicleType.maxDece = 7.5;  // Maximum deceleration, unit: m/s²
vehicleType.maxSpeed = 80;  // Maximum speed, unit: km/h
vehicleType.commercialVehicle = false;  // Whether it is a commercial vehicle
vehicleType.maxPassengerCapacity = 1;  // Maximum passenger capacity, unit: persons
// Create vehicle type
bool result = netiface->createVehicleType(vehicleType);
qDebug() << "创建车型是否成功：" << result;

// ==================== Create Vehicle Composition ====================
// Build vehicle type proportion list
QList<Online::VehiComposition> vehiTypeProportionList = {
    Online::VehiComposition(1, 0.3),  // Passenger car, proportion 0.3
    Online::VehiComposition(2, 0.2),  // Coach, proportion 0.2
    Online::VehiComposition(3, 0.1),  // Bus, proportion 0.1
    Online::VehiComposition(4, 0.4)   // Truck, proportion 0.4
};
// Create vehicle composition
int vehiCompositionId = netiface->createVehicleComposition("动态创建车型组成", vehiTypeProportionList);

// ==================== Create Dispatch Point ====================
// Get link object
ILink* link = netiface->findLink(1);
// Create dispatch point
IDispatchPoint* dp = netiface->createDispatchPoint(link);
if (dp)
{
    // Add dispatch interval, including vehicle composition, time interval, and number of dispatches
    dp->addDispatchInterval(1, 600, 300);
    dp->addDispatchInterval(1, 600, 400);
}
```

(2) During the simulation, without using departure points, the code for creating a single vehicle at a specified location is as follows.

```cpp
// ==================== Create Vehicle on Link ====================
// Build parameters
Online::DynaVehiParam dvp1;
// Vehicle type ID
dvp1.vehiTypeCode = 1;
// Link ID
dvp1.roadId = 4;
// Lane number
dvp1.laneNumber = 0;
// Position, unit: m
dvp1.dist = m2p(50);
// Speed, unit: m/s
dvp1.speed = m2p(20);
// Color
dvp1.color = "#00AFF0";
// Create vehicle dynamically
IVehicle* vehicle1 = simuiface->createGVehicle(dvp1);
if (vehicle1)
{
    qDebug() << "在路段上创建了车辆，其ID为：" << vehicle1.id();
}

// ==================== Create Vehicle on Connector ====================
// Build parameters
Online::DynaVehiParam dvp2;
// Vehicle type ID
dvp2.vehiTypeCode = 1;
// Connector ID
dvp2.roadId = 4;
// Lane number of upstream link
dvp2.laneNumber = 0;
// Lane number of downstream link
dvp2.toLaneNumber = 0;
// Position, unit: m
dvp2.dist = m2p(50);
// Speed, unit: m/s
dvp2.speed = m2p(20);
// Color
dvp2.color = "#00AFF0";
// Create vehicle dynamically
IVehicle* vehicle2 = simuiface->createGVehicle(dvp2);
if (vehicle2)
{
    qDebug() << "在连接段上创建了车辆，其ID为：" << vehicle2.id();
}
```

### 4.2.2. Setting Paths

Paths can be configured either by flow ratio allocation based on decision points **before or during the simulation** or by **directly specifying the travel route for an individual vehicle**.	

(1) Prior to starting the simulation, the code for creating decision points and updating their paths along with associated flow ratios is as follows.

```cpp
// ============================== Create Decision Point ==============================
ILink* link = netiface->findLink(1);
qreal location = 50;
QString decisionPointName = "新建决策点";
IDecisionPoint* decisionPoint = netiface->createDecisionPoint(link, location, decisionPointName, UnitOfMeasure::Metric);

// ==================== Create Vehicle Routing for Decision Point ====================
// Link ID list
QList<int> linkIdList1 = {1, 2};
QList<int> linkIdList2 = {1, 3};
QList<int> linkIdList3 = {1, 4};

// Build link object list
QList<ILink*> linkList1;
for (int linkId : linkIdList1) {
    linkList1.append(netiface->findLink(linkId));
}
QList<ILink*> linkList2;
for (int linkId : linkIdList2) {
    linkList2.append(netiface->findLink(linkId));
}
QList<ILink*> linkList3;
for (int linkId : linkIdList3) {
    linkList3.append(netiface->findLink(linkId));
}

// Create vehicle routing for decision point
IRouting* routing1 = netiface->createDeciRouting(decisionPoint, linkList1);
IRouting* routing2 = netiface->createDeciRouting(decisionPoint, linkList2);
IRouting* routing3 = netiface->createDeciRouting(decisionPoint, linkList3);

// ==================== Update Decision Point Path Flow Ratio Configuration ====================
// Initialize left, straight, and right flow ratio objects
_RoutingFLowRatio flowRatioLeft;
flowRatioLeft.RoutingFLowRatioID = 1;
flowRatioLeft.routingID = routing1->id();
flowRatioLeft.startDateTime = 0;
flowRatioLeft.endDateTime = 999999;
flowRatioLeft.ratio = 2.0;

_RoutingFLowRatio flowRatioStraight;
flowRatioStraight.RoutingFLowRatioID = 2;
flowRatioStraight.routingID = routing2->id();
flowRatioStraight.startDateTime = 0;
flowRatioStraight.endDateTime = 999999;
flowRatioStraight.ratio = 3.0;

_RoutingFLowRatio flowRatioRight;
flowRatioRight.RoutingFLowRatioID = 3;
flowRatioRight.routingID = routing3->id();
flowRatioRight.startDateTime = 0;
flowRatioRight.endDateTime = 999999;
flowRatioRight.ratio = 1.0;

// Initialize decision point data
_DecisionPoint decisionPointData;
decisionPointData.deciPointID = decisionPoint->id();
decisionPointData.deciPointName = decisionPoint->name();
QPointF decisionPointPos;
if (decisionPoint->link()->getPointByDist (decisionPoint->distance(), decisionPointPos)) 
{
    decisionPointData.X = decisionPointPos.x();
    decisionPointData.Y = decisionPointPos.y();
    decisionPointData.Z = decisionPoint->link()->z();
}

// Construct flow ratio list
QList<_RoutingFLowRatio> flowRatioList = {flowRatioLeft, flowRatioStraight, flowRatioRight};

// Update the path flow ratio configuration of the decision point
IDecisionPoint* updatedDecisionPoint = netiface->updateDecipointPoint(decisionPointData, flowRatioList);
```

(2) During the simulation, the code for dynamically modifying path flow ratios of existing decision points is as follows.

```cpp
// MySimulator.cpp

QList<Online::DecipointFlowRatioByInterval> MySimulator::calcDynaFlowRatioParameters()
{
	QList<Online::DecipointFlowRatioByInterval> lDecipointFLowRatioByInterval;
	// Current simulation calculation batch
	long batchNumber = simuiface->batchNumber();
	// Modify the flow ratios of various paths at a decision point when calculating batch 20
	if (batchNumber == 20)
	{
		// Vehicle distribution ratios for various paths at a decision point during a certain period
		Online::DecipointFlowRatioByInterval dfi = Online::DecipointFlowRatioByInterval();
		// Decision point ID
		dfi.deciPointID = 1;
		// Start time in seconds
		dfi.startDateTime = 1;
		// End time in seconds
		dfi.endDateTime = 999999;
		// Path flow ratios
		Online::RoutingFlowRatio rfr1 = Online::RoutingFlowRatio(1, 3);
		Online::RoutingFlowRatio rfr2 = Online::RoutingFlowRatio(2, 4);
		Online::RoutingFlowRatio rfr3 = Online::RoutingFlowRatio(3, 3);
		dfi.mlRoutingFlowRatio << rfr1;
		dfi.mlRoutingFlowRatio << rfr2;
		dfi.mlRoutingFlowRatio << rfr3;
		lDecipointFLowRatioByInterval << dfi;
	}
	return lDecipointFLowRatioByInterval;
}
```

(3) During the simulation process, the code for setting Paths for Vehicles is as follows.

```cpp
// 1. Use existing decision point vehicle routing
IRouting* routing1 = netiface->findRouting(1);
vehicle->vehicleDriving()->setRouting(routing1);

// 2. Create vehicle routing not bound to decision points
QList<int> linkIdList = {8, 16, 25};
QList<ILink*> linkList;
for (int linkId : linkIdList) 
{
    linkList.append(netiface->findLink(linkId));
}
IRouting* routing2 = netiface->createRouting(linkList);
vehicle->vehicleDriving()->setRouting(routing2);
```




## 4.3. Signal Control

### 4.3.1. Creating Signal Controllers, Signal Control Schemes, Traffic Signal Phases, and Traffic Signals

Before starting the simulation, Signal Controllers, Signal Control Schemes, Traffic Signal Phases, and Traffic Signals can be created sequentially. During creation, the binding relationships are simultaneously established: **Traffic Signal → Traffic Signal Phase → Signal Control Scheme → Signal Controller**, as shown in the following code.

```cpp
// ==================== Create Signal Controller (usually one intersection corresponds to one signal controller) ====================
// Signal controller name
QString signalControllerName = "双龙大道-吉印大道交叉口";
// Create signal controller
ISignalController* signalController = netiface->createSignalController(signalControllerName);

// ==================== Create Signal Control Plan (one signal controller can be configured with multiple signal control plans for different time periods) ====================
// Get signal controller object
ISignalController* signalController = netiface->findSignalControllerByID(1);
// Signal control plan name
QString signalPlanName = "平峰方案";
// Cycle length, unit: s
int cycleTime = 120;
// Phase offset, unit: s
int phaseDifference = 0;
// Start time, unit: s
int startTime = 0;
// End time, unit: s
int endTime = 3600;
// Create signal control plan
ISignalPlan* signalPlan = netiface->createSignalPlan(signalController, signalPlanName, cycleTime, phaseDifference, startTime, endTime);

// ==================== Create Signal Phase (one signal control plan needs to assign phases to different directions/turns) ====================
// Get signal timing plan
ISignalPlan* signalPlan = netiface->findSignalPlanByID(1);
// Phase name
QString signalPhaseName = "东西直行";
// Build color object list
QString<QString> colors = {"R", "G", "Y", "R"};
QList<int> intervals = {30, 26, 3, 61};
QList<Online::ColorInterval> colorIntervalList;
for (int i = 0; i < colors.size(); ++i) 
{
    colorIntervalList.append(Online::ColorInterval(colors[i], intervals[i]));
}
// Create signal phase
ISignalPhase* signalPhase = netiface->createSignalPlanSignalPhase(signalPlan, signalPhaseName, colorIntervalList);

// ==================== Create Signal Lamp (one phase controls signal lamps on multiple lanes) ====================
// Get phase object
ISignalPhase* signalPhase = netiface->findSignalPhase(1);
// Signal lamp name
QString signalLampName = "东直1";
// Lane ID
long laneId = 1;
// Downstream lane ID
long toLaneId = -1;
// Position, unit: m
qreal distance = m2p(50);
// Create signal lamp
ISignalLamp* signalLamp = netiface->createSignalLamp(signalPhase, signalLampName, laneId, toLaneId, distance);
```

### 4.3.2. Controlling Traffic Signal Colors

Light colors can be modified at two levels of granularity: by **Signal Control Phase** or by **individual Traffic Signal**.

(1) The code for modifying light colors and durations by Signal Control Phase, applicable before and during the simulation, is as follows.

```cpp
// Build color and duration object list
QList<Online::ColorInterval> colorObjList = {
    Online::ColorInterval("R", 10),  // Red, duration 10
    Online::ColorInterval("G", 60),  // Green, duration 60
    Online::ColorInterval("Y", 3),  // Yellow, duration 3
    Online::ColorInterval("R", 17)  // Red, duration 17
};
// Find signal phase with ID 7
auto signalPhase = netiface->findSignalPhase(7);
if (signalPhase) 
{
    // Set color list
    signalPhase->setColorList(colorObjList);
}
```

After completing the creation of Signal Controllers, Signal Control Schemes, Traffic Signal Phases, and Traffic Signals within the Road Network, if it is necessary to modify the Signal Control Scheme of an individual intersection during the Simulation Process, please refer to the example code below. Before use, it is required to pre-record the Phase IDs corresponding to each Phase.

```cpp
// Define phase data structure
struct PhaseData {
    int signalPhaseId;
    QList<int> intervals;
};

void MySimulator::afterOneStep() 
{
    // Get current simulation time, unit: ms
    long simuTime = simuiface->simuIntervalScheming();
    
    // When reaching specified time
    if (simuTime == 60 * 1000) 
    {
        // Signal phase mapping for a single intersection
        QMap<QString, PhaseData> signalIntervalMapping = {
            {"东西直行",  {1, {0, 31, 3, 86}}},
            {"东西左转",  {2, {35, 21, 3, 61}}},
            {"南北直行",  {3, {60, 31, 3, 26}}},
            {"南北左转",  {4, {95, 21, 3, 1}}}
        };

        // Set according to signal phases
        for (auto it = signalIntervalMapping.begin(); it != signalIntervalMapping.end(); ++it) 
        {
            const PhaseData& phaseData = it.value();
            // Get signal phase ID
            long signlPhaseId = phaseData.signalPhaseId;
            // Get signal phase object
            ISignalPhase* signalPhase = netiface->findSignalPhase(signlPhaseId);
            if (!signalPhase) 
            {
                continue;
            }
            // Build color and duration list
            QList<Online::ColorInterval> colorList = {
                Online::ColorInterval("R", phaseData.intervals[0]),  // Red
                Online::ColorInterval("G", phaseData.intervals[1]),  // Green
                Online::ColorInterval("Y", phaseData.intervals[2]),  // Yellow
                Online::ColorInterval("R", phaseData.intervals[3])   // Red
            };
            // Set new duration scheme for signal phase
            signalPhase->setColorList(colorList);
        }
    }
}
```

(2) During the Simulation Process, the code to directly modify the light color of a single Traffic Signal is as follows. Since this operation fundamentally corrects or overrides results already computed by TESS NG, such adjustments **take effect only within the current frame**. This means that **the setting cannot be applied only once at a specific moment when the condition is met; instead, the operation must be continuously executed throughout the entire time interval during which the condition holds**.

```cpp
// MySimulator.cpp

bool MySimulator::calcLampColor(ISignalLamp* pSignalLamp) 
{
    // Get current simulation time, unit: ms
    long simuTime = simuiface->simuIntervalScheming();
    // If signal lamp ID is 1, set it to green
	if (pSignalLamp->id() == 1 && simuTime >= 60 * 1000 && simuTime < 90 * 1000) 
    {
		pSignalLamp->setLampColor("G");
		return true;
	}
	return false;
}
```



## 4.4 Vehicle Control

### 4.4.1 Setting Vehicle Desired Speed

The code for setting the vehicle's desired speed during the simulation process is as follows.

```cpp
// Set the vehicle's desired speed, unit: pixels/s
vehicle->setDesirSpeed(m2p(80 / 3.6))
```

### 4.4.2 Setting Vehicle Speed

The code for setting the vehicle speed during the simulation process is as follows.

```cpp
// MySimulator.cpp

// Unit: m/s
bool MySimulator::reSetSpeed(IVehicle* pIVehicle, qreal &inOutSpeed, UnitOfMeasure* unit)
{
    if (pIVehicle->id() == 100001)
    {
        // Directly specify the vehicle speed
        inOutSpeed = 80 / 3.6;
        return true;
    }
    return false;
}
```

### 4.4.3 Setting Vehicle Acceleration

The code for setting the vehicle acceleration is as follows.

```cpp
// MySimulator.cpp

// This function is called before TESS NG calculates acceleration, unit: m/s²
bool MySimulator::calcAcce(IVehicle* pIVehicle, qreal &acce, UnitOfMeasure* unit)
{
    if (pIVehicle->roadName() == "曹安公路")
    {
        // Calculate acceleration directly based on different speeds
        if (pIVehicle->currSpeed() > 20/3.6)
        {
            acce = -3;
            return true;
        }
        else if (pIVehicle->currSpeed() > 10/3.6)
        {
            acce = -1;
            return true;
        }
    }
    return false;
}

// This function is called after TESS NG calculates acceleration, unit: m/s²
bool MySimulator::reSetAcce(IVehicle* pIVehicle, qreal &inOutAcce, UnitOfMeasure* unit)
{
    if (pIVehicle->roadName() == "曹安公路")
    {
        // Modify the calculated acceleration based on different speeds
        if (pIVehicle->currSpeed() > 20/3.6)
        {
            acce += -3;
            return true;
        }
        else if (pIVehicle->currSpeed() > 10/3.6)
        {
            acce += -1;
            return true;
        }
    }
    return false;
}
```

### 4.4.4 Setting Vehicle Lane Change

The code to control the vehicle to change lanes to the left or right is as follows.

```cpp
// control vehicle to left lane
vehicle->vehicleDriving()->toLeftLane();

// control vehicle to right lane
vehicle->vehicleDriving()->toRightLane();
```

The code to revoke the vehicle lane change is as follows.

```cpp
// MySimulator.cpp

bool MySimulator::reCalcDismissChangeLane(IVehicle* pIVehicle)
{
	// When the distance to the end of the link is less than 50m, cancel all free lane changes to achieve the effect of prohibiting free lane changes
    if (pIVehicle->vehicleDriving()->distToEndpoint(true, true, UnitOfMeasure::Metric) < 50)
    {
        return true;
    }
    return false;
}
```

### 4.4.5 Setting Vehicle Lane Restriction

The code for setting vehicle lane restriction is as follows.

```cpp
// MySimulator.cpp

QList<int> MySimulator::calcLimitedLaneNumber(IVehicle* pIVehicle)
{
    // If the vehicle is on a link and its length is greater than 8m, prohibit it from entering the innermost lane 
    if (pIVehicle->roadIsLink() && (pIVehicle->length(UnitOfMeasure::Metric) > 8)) 
    {
        int limitLaneNumber = pIVehicle->lane()->link()->laneCount();
        return QList<int>() << limitLaneNumber;
    }
    return QList<int>();
}
```

### 4.4.6 Setting Vehicle Path

The code for setting the vehicle path is as follows.

```cpp
// 1. Use existing decision point vehicle routing
IRouting* routing1 = netiface->findRouting(1);
vehicle->vehicleDriving()->setRouting(routing1);

// 2. Create vehicle routing not bound to decision points
QList<int> linkIdList = {8, 16, 25};
QList<ILink*> linkList;
for (int linkId : linkIdList) 
{
    linkList.append(netiface->findLink(linkId));
}
IRouting* routing2 = netiface->createRouting(linkList);
vehicle->vehicleDriving()->setRouting(routing2);
```

### 4.4.7. Setting Vehicle Car-following Parameters

The code for setting vehicle car-following parameters is as follows. **Currently, only the parameters of the IDM car-following model can be modified.**

```cpp
// Set the vehicle's desired acceleration, unit: pixels/s²
vehicle->setDesirAcce(m2p(5.5));

// Set the vehicle's maximum deceleration, unit: pixels/s²
vehicle->setMaxDece(m2p(7.5));

// Set the vehicle's safe time headway, unit: s
vehicle->vehicleDriving()->setSafeTimeInterval(1.5);

// Set the vehicle's stopping distance, unit: pixels
vehicle->vehicleDriving()->setStoppingDistance(m2p(2));
```

### 4.4.8. Setting Vehicle Jump

The code for setting vehicle jumps is as follows.

```cpp
// Target point
QPointF targetPoint = QPointF(50, 50);
// Project the target point to lanes within a certain range to obtain location information sequence
QList<Online::Location> locations = netiface->locateOnCrid(targetPoint, 9, UnitOfMeasure::Metric);  // Need to execute netiface->buildNetGrid(10) first before using
// If lane objects are located
if (!locations.empty())
{
    Online::Location location = locations[0];
    // Lane object
    ILaneObject* laneObj = location.pLaneObject;
    // Position, unit: m
    qreal dist = location.distToStart;

    // Move vehicle to specified lane and position, achieving teleportation of vehicle location
    vehicle->vehicleDriving()->move(laneObj, dist, UnitOfMeasure::Metric);
}
```

### 4.4.9. Setting Vehicle Information and Visualization

The code for setting vehicle information is as follows.

```cpp
// MySimulator.cpp

QString MySimulator::vehiRunInfo(IVehicle* pIVehicle)
{
    return QString("车辆当前在ID=%1的道路上").arg(pIVehicle->roadId());
}
```

The code for setting vehicle color is as follows.

```cpp
// 设置车辆颜色为蓝色
vehicle->setColor("#00AFF0");
```

The code for setting vehicle visualization is as follows.

```cpp
// MySimulator.cpp

void MySimulator::rePaintVehicle(Tessng::IVehicle* pIVehicle, QPainter* painter)
{
    // Add vehicle name label on the vehicle body
    QString label = pIVehicle->name();

    // Create QFont object, set font family and size
    QFont font("Arial", 1);
    // Set font to non-bold
    font.setBold(false);

    // Create QFontMetrics object to get font metrics information
    QFontMetrics fontMetrics(font);
    // Get the bounding rectangle of the text
    QRect boundingRect = fontMetrics.boundingRect(label);
    // Calculate text position
    qreal newX = -boundingRect.center().x() - pIVehicle->width() * 0.5;
    qreal newY = -boundingRect.center().y();
    QPointF position(newX, newY);

    // Create QPainterPath object to draw text
    QPainterPath textPath;
    // Add text to the path
    textPath.addText(position, font, label);
    
    // Set pen scaling ratio
    painter->scale(1, 1);
    // Fill path to draw text
    painter->fillPath(textPath, QColor("#c94f4f"));
}
```



## 4.5. Simulation Control

### 4.5.1. Setting Simulation Parameters

The code for setting simulation parameters prior to starting the simulation is as follows.

```cpp
// MySimulator.cpp

// Set the following parameters before starting the simulation
void MySimulator::beforeStart(bool &keepOn)
{
    // Set simulation acceleration multiple
    simuiface->setAcceMultiples(5);
    // Set simulation duration, unit: s
    simuiface->setSimuIntervalScheming(3600);
    // Set simulation accuracy
    simuiface->setSimuAccuracy(10);
    // Set random seed
    simuiface->setRandSeed(42);
    // Set whether to record vehicle trajectory
    simuiface->setIsRecordTrace(True);
    // Set whether to record pedestrian trajectory
    simuiface->setIsRecordPedestrianTrace(True);
}
```

### 4.5.2. Starting, Pausing, and Stopping the Simulation

The code for starting, pausing, and stopping the simulation is as follows.

```cpp
// Start simulation, usually written in afterLoadNet or afterStop
if (!simuiface->isRunning() || simuiface->isPausing())
{
    simuiface->startSimu();
}

// Pause simulation, usually written in afterOneStep
if (simuiface->isRunning())
{
    simuiface->pauseSimu();
}

// Stop simulation, usually written in afterOneStep
if (simuiface->isRunning())
{
    simuiface->stopSimu();
}
```

### 4.5.3. Consecutive Multiple Simulations

The code for executing consecutive multiple simulations is as follows.

```cpp
// MySimulator.h

class MySimulator : public CustomerSimulator
{
public:
	MySimulator();
	~MySimulator();

	// TESS NG calls this method after simulation starts
	void afterStart() override;
    // TESS NG calls this method after each calculation cycle, core logic implementation
	void afterOneStep() override;
	// TESS NG calls this method after simulation ends
	void afterStop() override;

private:
	// Represents the network sub-interface of TESS NG
	NetInterface* netiface;
	// Represents the simulation sub-interface of TESS NG
	SimuInterface* simuiface;

	// Current simulation count
	int currentSimuCount = 0;
	// Maximum simulation count
	int maxSimuCount = 10;
};


// MySimulator.cpp

void MySimulator::afterStart()
{
    // Increment simulation count by one
	currentSimuCount += 1;
}

void MySimulator::afterOneStep()
{
    // Current simulation time, unit: ms
    long simuTime = self.simuiface.simuTimeIntervalWithAcceMutiples();
    if (simuTime > 600 * 1000)
    {
        // Stop simulation
        simuiface->stopSimu();
    }
}

void MySimulator::afterStop()
{
    // Not yet reached maximum simulation count
    if (currentSimuCount < maxSimuCount)
    {
        // Start simulation
        simuiface->startSimu();
    }
}
```



## 4.6. Data Output

### 4.6.1. Output of Road Network Geometric Linear Data

The road network consists of road segments and connection segments, where road segments are composed of lanes, and connection segments consist of lane connections. Road segments, lanes, and lane connections each contain sequences of breakpoints defining the centerline, left boundary, and right boundary, along which vehicles travel. The code to retrieve breakpoint data for road segments, lanes, and lane connections is as follows.

```cpp
// Get the breakpoint coordinates of the centerline, left edge and right edge of a specific link
ILink* link = netiface->findLink(1);
QList<QVector3D> linkCenterPoints = link->centerBreakPoint3Ds(UnitOfMeasure::Metric);
QList<QVector3D> linkLeftPoints = link->leftBreakPoint3Ds(UnitOfMeasure::Metric);
QList<QVector3D> linkRightPoints = link->rightBreakPoint3Ds(UnitOfMeasure::Metric);

// Get the breakpoint coordinates of the centerline, left edge and right edge of a specific lane
ILane* lane = netiface->findLane(1);
QList<QVector3D> laneCenterPoints = lane->centerBreakPoint3Ds(UnitOfMeasure::Metric);
QList<QVector3D> laneLeftPoints = lane->leftBreakPoint3Ds(UnitOfMeasure::Metric);
QList<QVector3D> laneRightPoints = lane->rightBreakPoint3Ds(UnitOfMeasure::Metric);
        
// Get the breakpoint coordinates of the centerline, left edge and right edge of a specific lane connector
ILaneConnector* laneConnector = netiface->findLaneConnector(1, 4);
QList<QVector3D> laneConnectorCenterPoints = laneConnector->centerBreakPoint3Ds(UnitOfMeasure::Metric);
QList<QVector3D> laneConnectorLeftPoints = laneConnector->leftBreakPoint3Ds(UnitOfMeasure::Metric);
QList<QVector3D> laneConnectorRightPoints = laneConnector->rightBreakPoint3Ds(UnitOfMeasure::Metric);
```

### 4.6.2. Output of Vehicle Trajectory Data

During the simulation process, the code to retrieve vehicle data for a specific simulation frame is as follows.

```cpp
// Get the list of currently running vehicles
QList<IVehicle*> allVehicles = simuiface->allVehiStarted();
for (IVehicle* vehicle : allVehicles) 
{
    qDebug() << "车辆ID：" << vehicle->id();
    qDebug() << "车辆名称：" << vehicle->name();
    qDebug() << "车辆类型编码：" << vehicle->vehicleTypeCode();
    qDebug() << "车辆类型名称：" << vehicle->vehicleTypeName();
    qDebug() << "车辆长度：" << vehicle->length(UnitOfMeasure::Metric) << " m";

    qDebug() << "车辆当前横坐标：" << vehicle->pos(UnitOfMeasure::Metric).x() << " m";
    qDebug() << "车辆当前纵坐标：" << vehicle->pos(UnitOfMeasure::Metric).y() << " m";
    qDebug() << "车辆当前高程：" << vehicle->v3z() << " m";
    qDebug() << "车辆当前所在道路ID：" << vehicle->roadId();
    qDebug() << "车辆当前所在道路名称：" << vehicle->roadName();
    qDebug() << "车辆当前是否在路段：" << (vehicle->roadIsLink() ? "是" : "否");
    qDebug() << "车辆当前所在车道ID：" << vehicle->laneId();
    if (vehicle->roadIsLink()) 
    {
        qDebug() << "车辆当前所在车道序号：" << vehicle->vehicleDriving()->laneNumber();
    }
    qDebug() << "车辆当前与车道起点的间距：" << vehicle->vehicleDriving()->distToStartPoint(true, true, UnitOfMeasure::Metric)  << " m";
    
    qDebug() << "车辆当前速度：" << vehicle->currSpeed(UnitOfMeasure::Metric) * 3.6 << " km/h";
    qDebug() << "车辆当前期望速度：" << vehicle->vehicleDriving()->desirSpeed(UnitOfMeasure::Metric) * 3.6 << " km/h";
    qDebug() << "车辆当前加速度：" << vehicle->acce(UnitOfMeasure::Metric) << " m/s²";
    qDebug() << "车辆当前朝向角：" << vehicle->angle() << " °";
}
```

### 4.6.3. Output Traffic Signal Data

The following code demonstrates how to obtain traffic signal data for a specific simulation frame during the simulation process.

```cpp
QList<Online::SignalPhaseColor> allSignalPhaseColor = simuiface->getSignalPhasesColor();
for (auto signalPhaseColor: allSignalPhaseColor)
{
    qDebug() << "信号机ID：" << signalPhaseColor.signalGroupId;
    qDebug() << "信控相位ID：" << signalPhaseColor.phaseId;
    qDebug() << "信控相位序号：" << signalPhaseColor.phaseNumber;
    qDebug() << "当前颜色：" << signalPhaseColor.color;
    qDebug() << "当前颜色的设置时间(ms)：" << signalPhaseColor.mrIntervalSetted;
    qDebug() << "当前颜色的已持续时间(ms)：" << signalPhaseColor.mrIntervalByNow;
}
```

### 4.6.4. Output Data from Various Collection Devices

Various data collection devices include data collectors, queue counters, and travel time detectors. During the simulation process, the code to acquire their sample data and aggregated data is as follows. Note that **aggregated data can only be obtained in the simulation frame at the end of the aggregation period**.

```cpp
// ==================== Sample Data of Data Collectors ====================
QList<Online::VehiInfoCollected> allVehiInfoCollected = simuiface->getVehisInfoCollected();
for (auto vehiInfo: allVehiInfoCollected)
{
    qDebug() << "采集器ID：" << vehiInfo.collectorId;
    qDebug() << "仿真时间(s)：" << vehiInfo.simuInterval;
    qDebug() << "车辆ID：" << vehiInfo.vehiId;
}

// ==================== Aggregated Data of Data Collectors ====================
QList<Online::VehiInfoAggregated> allVehiInfoAggregated = simuiface->getVehisInfoAggregated();
for (auto vehiInfoAgg: allVehiInfoAggregated)
{
    qDebug() << "采集器ID：" << vehiInfoAgg.collectorId;
    qDebug() << "时间段ID：" << vehiInfoAgg.timeId;
    qDebug() << "起始时间(s)：" << vehiInfoAgg.fromTime;
    qDebug() << "结束时间(s)：" << vehiInfoAgg.toTime;
    qDebug() << "车辆数(veh)：" << vehiInfoAgg.vehiCount;
    qDebug() << "平均速度(km/h)：" << vehiInfoAgg.avgSpeed;
    qDebug() << "平均占有率：" << vehiInfoAgg.occupancy;
}

// ==================== Sample Data of Queue Counters ====================
QList<Online::VehiQueueCounted> allVehiQueueCounted = simuiface->getVehisQueueCounted();
for (auto vehiQueue: allVehiQueueCounted)
{
    qDebug() << "计数器ID：" << vehiQueue.counterId;
    qDebug() << "仿真时间(s)：" << vehiQueue.simuTime;
    qDebug() << "排队车辆数(veh)：" << vehiQueue.vehiCount;
    qDebug() << "排队长度(m)：" << vehiQueue.queueLength;
}

// ==================== Aggregated Data of Queue Counters ====================
QList<Online::VehiQueueAggregated> allVehiQueueAggregated = simuiface->getVehisQueueAggregated();
for (auto vehiQueueAgg: allVehiQueueAggregated)
{
    qDebug() << "计数器ID：" << vehiQueueAgg.counterId;
    qDebug() << "时间段ID：" << vehiQueueAgg.timeId;
    qDebug() << "起始时间(s)：" << vehiQueueAgg.fromTime;
    qDebug() << "结束时间(s)：" << vehiQueueAgg.toTime;
    qDebug() << "平均排队车辆数(veh)：" << vehiQueueAgg.avgVehiCount;
    qDebug() << "平均排队长度(m)：" << vehiQueueAgg.avgQueueLength;
    qDebug() << "最大排队长度(m)：" << vehiQueueAgg.maxQueueLength;
    qDebug() << "最小排队长度(m)：" << vehiQueueAgg.minQueueLength;
}

// ==================== Sample Data of Travel Time Detectors ====================
QList<Online::VehiTravelDetected> allVehiTravelDetected = simuiface->getVehisTravelDetected();
for (auto vehiTravel: allVehiTravelDetected)
{
    qDebug() << "检测器ID：" << vehiTravel.detectedId;
    qDebug() << "车辆ID：" << vehiTravel.vehiId;
    qDebug() << "行驶时间(s)：" << vehiTravel.travelTime;
    qDebug() << "行驶距离(m)：" << vehiTravel.travelDistance;
    qDebug() << "延误(s)：" << vehiTravel.delay;
}

// ==================== Aggregated Data of Travel Time Detectors ====================
QList<Online::VehiTravelAggregated> allVehiTravelAggregated = simuiface->getVehisTravelAggregated();
for (auto vehiTravelAgg: allVehiTravelAggregated)
{
    qDebug() << "检测器ID：" << vehiTravelAgg.detectedId;
    qDebug() << "时间段ID：" << vehiTravelAgg.timeId;
    qDebug() << "起始时间(s)：" << vehiTravelAgg.fromTime;
    qDebug() << "结束时间(s)：" << vehiTravelAgg.toTime;
    qDebug() << "车辆数：" << vehiTravelAgg.vehiCount;
    qDebug() << "平均行程时间(s)：" << vehiTravelAgg.avgTravelTime;
    qDebug() << "平均行程距离(m)：" << vehiTravelAgg.avgTravelDistance;
    qDebug() << "平均延误(s)：" << vehiTravelAgg.avgDelay;
}
```

<div style="page-break-after: always;"></div>

# 5. Industry Cases

The industry cases implemented based on TESS NG secondary development are listed in the table below. Complete source code is available in the [GitHub](https://github.com/jIDa-traffic/TESSNG_SecondaryDev) repository or the [Gitee](https://gitee.com/jidatraffic/tessng-secondary-doc) repository.

|       Category       | Function Item                           |
| :--------------: | :------------------------------- |
|       Expressway       | Construction Zone Simulation                       |
|                  | Accident and Incident Simulation                   |
|                  | Lane Speed Limit Management                     |
|                  | Lane Closure Simulation                     |
|                  | Hard Shoulder and Emergency Lane Opening             |
|                  | Ramp Signal Control                     |
|                  | Congestion Warning                         |
|                  | Expressway Control Pre-evaluation System               |
|                  | Expressway Parameter Calibration                 |
|       Urban       | Single-point Signal Adaptive Control                   |
|                  | Intersection Lane Channelization Modification, Reversible Lane |
|                  | Corridor Coordination                         |
|                  | Vehicle Route Guidance                     |
|                  | Congestion Warning                         |
|                  | Lane Control Simulation                     |
|                  | Vehicle Accident Simulation                     |
|                  | Vehicle Speed Guidance (VMS Information Board)        |
|                  | Urban Road Parameter Calibration                 |
|                  | Public Transport Signal Priority                     |
|   V2X Autonomous Driving   | V2X Intersection                        |
|                  | Speed Guidance                         |
|                  | Vehicle Platooning                     |
| Autonomous Driving Joint Simulation | Carla Integration                        |
|                  | prescan Integration                      |
|                  | scanner Integration                      |
|                  | Traffic Digital Twin: Integration with UE5 and Unity   |
|                  | Autonomous Driving Test Scenario Design             |

<div style="page-break-after: always;"></div>

# 6. Notes

## 6.1. Software Activation

Users must activate TESS NG Secondary Development upon first use. Trial users follow the same activation procedure as first-time users, using the JIDaTraffic_key in the Cert folder of the installation package.

The software trial period lasts 30 days. After expiration, Secondary Development interfaces remain accessible, but custom Plugins will be disabled. Commercial edition users have no restrictions.



## 6.2. Unit of Measurement

Since TESS NG is developed based on the Qt framework, and Qt's graphics system uses pixels as the fundamental unit, its coordinate system inherently differs from the physical units (such as meters) used in the real world. Qt's drawing operations, interface layouts, and interactive responses are all centered around pixel dimensions, by default using screen pixels as the reference for rendering and positioning, which does not directly correspond to the physical scale of real-world space.	

Therefore, in TESS NG secondary development, whether it concerns the dimension definitions of road network elements, the calculation and mapping of vehicle positions, or the drawing of custom graphics and coordinate parsing for interactive operations, special attention must be given to the conversion logic between **pixels and metric units**. By default, 1 pixel corresponds to 1 meter; however, if the pixel ratio is modified due to operations such as importing base maps, unit conversion can be performed using the following methods:

- Metric to Pixel conversion: qreal m2p(qreal value)
- Pixel to Metric conversion: qreal p2m(qreal value)

​	Furthermore, some methods within plugins and interfaces include the **UnitOfMeasure unit** parameter, whose default value is `UnitOfMeasure::Default` (i.e., pixel units). Passing `UnitOfMeasure::Metric` indicates the use of metric units (supporting both read and write operations). For instance, `vehicle->currSpeed()` returns the vehicle speed in pixel units, whereas `vehicle->currSpeed(UnitOfMeasure::Metric)` returns the vehicle speed in metric units. It should be noted that since the `unit` parameter typically appears at the end of the method parameter list, **if this parameter is to be explicitly specified, all preceding parameters with default values must also be explicitly provided.** This rule is stated here uniformly and will not be reiterated in interface details.



## 6.3. Coordinate System

Since TESS NG is developed based on the Qt framework, its coordinate system design directly follows Qt's core convention — Qt employs a coordinate system with the **y-axis pointing downward** to accommodate screen display and graphical rendering logic (screen pixels typically use the top-left corner as the origin, with the y-axis positive direction downward), where the origin is normally located at the top-left corner of the canvas/window, the x-axis extends horizontally to the right, and the y-axis vertically downward.

Therefore, during TESS NG secondary development, all contexts involving coordinate computations, graphical rendering (such as Road Network Element positioning, Vehicle location marking, and custom graphics rendering), as well as mouse interaction and positioning, must adhere to this **y-axis downward** coordinate system convention. Particular attention must be paid to differences in coordinate axis directions when performing data transformation and position mapping with real geographic coordinate systems (typically with the y-axis pointing upwards) or custom coordinate systems, to avoid graphical displacement, position calculation errors, and other issues caused by coordinate system misinterpretation.



## 6.4. Dependency Header File Inclusion

​	It is generally necessary to include required dependency header files at the beginning of the file; the specific headers to include depend on the functionality of the code. An example is provided below.

```cpp
#include "MySimulator.h"
#include "tessinterface.h"
#include "netinterface.h"
#include "simuinterface.h"
#include "ilink.h"
#include "ILane.h"
#include "ivehicle.h"
#include "ivehicledriving.h"
```



## 6.5. Sub-Plugin Operation Rules

​	Within simulation plugins, adjustments to vehicle acceleration, desired speed, travel speed, steering angle, and traffic signal color settings essentially override or correct results already computed by TESS NG; therefore, such adjustments **take effect only within the current simulation frame**. This means that operations such as traffic signal color settings **cannot be performed only once at a specific moment when the conditions are met, but must be continuously applied throughout the entire time interval during which the conditions are satisfied**.

<div style="page-break-after: always;"></div>

# 7. FAQ List

### 1. Why does the secondary development code I wrote in MySimulator’s built-in functions fail to take effect?

**Answer:** This may be due to the expiration of the trial period, resulting in the system lacking authorization to load plugins, thereby preventing the execution of custom code.

