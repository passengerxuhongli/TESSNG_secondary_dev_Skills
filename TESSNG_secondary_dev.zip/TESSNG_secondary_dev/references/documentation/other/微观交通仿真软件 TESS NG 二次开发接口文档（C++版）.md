# 微观交通仿真软件 TESS NG 二次开发接口文档（C++版）

[TOC]

<div style="page-break-after: always;"></div>

# 1.简介

## 1.1.相关链接

* [上海济达交通科技有限公司官网](https://jidatraffic.com/#/home)
* [TESSNG 二次开发 官网文档](http://jidatraffic.com:82/)
* [TESS NG 二次开发 GitHub地址](https://github.com/jIDa-traffic/TESSNG_SecondaryDev)
* [TESS NG 二次开发 Gitee地址](https://gitee.com/jidatraffic/tessng-secondary-doc)



## 1.2.研发背景

​	**国产微观交通仿真软件 TESS NG** 融合了交通工程、软件工程与系统仿真等交叉学科的最新技术研发而成，具有以下显著特点：完全自主知识产权、便捷高效的建模能力、开放的外部接口模块，以及可定制化的用户服务等。

　　在功能扩展和项目建设过程中，TESS NG 通过强化设计，将大量功能的实现进行高度抽象，并将这些抽象逻辑与核心功能深度融合。抽象逻辑进一步细化为接口方法，而具体的接口实现则交由用户根据实际应用场景来完成。在这一架构设计下，TESS NG 已成功开发出车路协同、在线仿真、微宏观一体化仿真等插件模块，相关接口的设计与应用也日臻成熟。

　　TESS NG 的二次开发能力通过用户编写代码与软件进行交互实现，从而扩展功能与定制场景。用户不仅可以实现高度自动化和个性化的仿真业务，还能够构建符合特定需求的交通数字孪生和科研实验环境，这也是开展交通研究与应用的重要途径之一。

　　目前，TESS NG 的二次开发支持 **C++、Python 和 Java** 三种编程语言，三种语言的接口名称完全一致。



## 1.3.应用场景

​	TESS NG 的二次开发功能支持丰富多样的仿真场景构建，其可实现的应用场景广泛，包括但不限于以下表格所涵盖的内容。

| 序号 |     分类     |       场景       |                             应用                             |
| :--: | :----------: | :--------------: | :----------------------------------------------------------: |
|  1   |   城市仿真   |     信号控制     |                     单点webster信控算法                      |
|  2   |              |     公交优先     |                         干线绿波算法                         |
|  3   |              |   车辆路径诱导   | 通过调整车流在决策点的路径比例完成诱导<br/>对诱导点位下游道路排队长度的评价分析 |
|  4   |   高速仿真   |     匝道信控     |                  上匝道 ALINEA 信控算法应用                  |
|  5   |              |   车道限速管控   |                  高速公路车道限速动态化管理                  |
|  6   |              |   应急事件处理   |                    车辆事故与事件仿真模拟                    |
|  7   |              |     道路施工     |                        三类施工区仿真                        |
|  8   |     教学     | 连续交叉速度引导 |                     绿波车速诱导策略应用                     |
|  9   |              |    交通流还原    |                 高快速路跟驰换道模型参数标定                 |
|  10  |              |   AI 算法预研    |             基于强化学习的快速路可变限速优化研究             |
|  11  |   路网构建   |     路网编辑     |          路网、路段、连接段等仿真元素的增删改查操作          |
|  12  |              |     信控编辑     |         信号灯、灯组的增删改查及双环结构信控加载支持         |
|  13  |              |     需求编辑     | 发车点流量加载配置<br/>单车指定位置加载设置<br/>车辆组成自定义<br/>决策点与路径比例的增删改查 |
|  14  | 仿真过程控制 |     流程控制     | 仿真的开始、暂停、恢复与关闭操作<br/>仿真快照功能应用<br/>仿真信息、路网信息、车辆信息的获取<br/>车辆轨迹平面坐标与地理坐标转换<br/>加速度、仿真精度、随机种子等参数设置 |
|  15  |              |     动作控制     | 限速区、事故区、施工区的设置<br/>车辆移动、信息修改、变道及航向角调整<br/>信号灯颜色、路径、相位信息更新<br/>车道启闭、路方案、路径信息管理<br/>跟驰模型、换道模型参数修改 |
|  16  |              |     仿真输出     | 检测器与采集器的设置<br/>按指定时间频率输出数据<br/>检测器、采集器与仿真路网绑定关系获取<br/>车辆轨迹输出<br/>仿真路网结构化数据输出 |
|  17  | 交互界面开发 |      菜单栏      |      支持用户新增自定义菜单，达成与 TESS NG 软件的交互       |
|  18  |              |      工具栏      |     支持用户新增自定义工具栏，达成与 TESS NG 软件的交互      |



## 1.4.接口架构

​	TESS NG 通过实现 TessInterface 及其三个子接口，将自身主要功能暴露给用户，用户启动 TESS NG 后可以获取 TESS NG 的顶层接口，再通过顶层接口获取三个子接口，调用子接口方法。TESS NG 加载插件后可以调用插件实现的接口方法，用户可以在插件方法中通过 TessInterface 及其子接口控制仿真运行，及仿真过程中车辆驾驶行为、信号灯色、路径车辆分配等等。

​	二次开发的整体架构如下图所示。

<img src="http://129.211.28.237:5566/document/images/0_interface_architecture" alt="二次开发整体架构图" style="zoom: 50%;" />



## 1.5.更新日志

**【 2025-01-21 】**

- TESSNG内核由V3.1升级到V4.0，二次开发版本可使用V4.0专业版基础功能

- 【新增】ISignalPlan 信控方案接口，支持多时段信控方案，替代原有的ISignalGroup接口。

- 【新增】ISignalLamp 信号灯接口，支持创建信号灯并关联信号机。

- 【新增】ICrosswalkSignalLamp 行人信号灯接口，支持创建信号灯并关联信号机。

- 【新增】IRoadWorkZone 占道施工接口，支持创建施工区。

- 【新增】IAccIDentZone 事故区接口升级，包含IAccIDentZoneInterval事故时段，可创建多时段不同参数的事故区。

- 【新增】ILimitedZone 限制区，其本身为借道施工的一部分，可不直接使用，但用户也可以用它做一些自定义的限制形式的区域。

- 【新增】IReconstruction 借道施工（改扩建），可精细化生成，控制改扩建路网。

- 【新增】IReduceSpeedArea 新增限速区接口，可支持分时段IReduceSpeedInterval分车型IReduceSpeedVehiType进行车道限速。

- 【新增】新增收费站系列接口，包括收费车道ITollLane，收费决策点ITollDecisionPoint，收费路径ITollRouting，收费站停车点ITollPoint。

- 【新增】停车场系列接口，包括停车位IParkingStall，停车区域IParkingRegion，停车决策点IParkingDecisionPoint，停车路径IParkingRouting。

- 【新增】节点构建及路径重构接口IJunction，包括自动计算节点流向，输入观测值进行路径重构。

- 【新增】行人面域接口包括：行人面域基类IPedestrian，障碍物面域IObstacleRegion，行人上下客面域IPassengerRegion，椭圆面域。IPedestrianEllipseRegion，扇形面域IPedestrianFanShapeRegion，多边形面域IPedestrianPolygonRegion，矩形面域IPedestrianRectRegion，三角形面域IPedestrianTriangleRegion。

- 【新增】行人人行道面域IPedestrianSIDeWalkRegion接口。

- 【新增】行人人行横道（斑马线）IPedestrianCrossWalkRegion接口。

- 【新增】行人楼梯面域IPedestrianStairRegion接口。

- 【新增】行人人行横道信号灯接口ICrosswalkSignalLamp。

- 【新增】行人路径系列接口，包括：行人路径IPedestrianPath，行人路径途经点IPedestrianPathPoint。

- 【新增】NetInterface类下新增IJunction节点对象的增删改查，新增行人面域，路径的增删改查，新增事故区，施工区，改扩建，限速区，信号灯，信号机，信控方案，星空相位的增删改查，新增停车场，收费站的增删改查。

- 【新增】SimuInterface类下新增获取行人状态，运动中行人信息的接口，新增单步仿真的接口。

- 【优化】统一接口的单位，V3系列默认像素制，V4常用的速度，长度等概念改为米制单位，并提供unitOfMeasure参数显示指定单位类型，从而避免繁琐的m2p，p2m的转化。

  

**【 2025-09-30 】**

- 【新增】设置车辆安全时距和停车距离的接口 setSafeTimeInterval 和 setStoppingDistance。
- 【新增】读取和设置是否输出信号灯头数据的接口 isRecordSignalLampStatus 和 setIsRecordSignalLampStatus。
- 【移除】变道相关弃用的插件函数 reSetChangeLaneFreelyParam 和 isPassbyEventZone。

<div style="page-break-after: always;"></div>

# 2.快速入门

​	本节提供快速上手指南，通过安装运行、示例讲解和注意事项，读者可以迅速理解如何在本地环境中构建并运行 TESS NG 的 C++ API 示例。这些内容为后续的插件开发与接口调用奠定实践基础，帮助开发者先跑通流程，再逐步深入功能扩展。



## 2.1.安装运行（Windows）

#### <span style="color: green;">Step1：下载示例代码包</span>

1. 在 [济达交通官网](https://www.jidatraffic.com/#/simulation) 下载 TESS NG 最新版本；

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_01" alt="图1" style="zoom: 60%;" />

2. 安装完成后，在软件目录的 **`SecondDev`** 文件夹中，可找到名为 **`TESS_CppAPI_EXAMPLE`** 的 C++ 版示例代码包。

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_02" alt="图2" style="zoom: 60%;" />

#### <span style="color: green;">Step2：配置开发环境</span>

1. **安装Qt**：

   - 访问 [Qt 官方下载页面](https://download.qt.io/archive/qt/5.12/5.12.2/)，下载 Qt 5.12.x 版本的安装包，即 `qt-opensource-windows-x86-5.12.2.exe` 文件；
   - 双击下载完成的 `qt-opensource-windows-x86-5.12.2.exe` 文件，启动安装程序；
   - 点击 “Next” 进入 Qt 账户登录界面，输入 Qt 账户的账号和密码（若无账户可先行注册），再点击 “Next“；
   - 跟随安装向导依次点击 “下一步”，可根据需求选择自定义安装目录，务必勾选 “MSVC 2017 64-bit” 组件，等待安装进度完成。

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_03" alt="图3" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_04" alt="图4" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_05" alt="图5" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_06" alt="图6" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_07" alt="图7" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_08" alt="图8" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_09" alt="图9" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_10" alt="图10" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_11" alt="图11" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_12" alt="图12" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_13" alt="图13" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_14" alt="图14" style="zoom: 60%;" />

2. **配置环境变量**：

   - 安装完成后，需手动将 Qt 的 `bin` 目录添加至系统环境变量 `Path` 中（示例路径：`D:/Qt/5.12.2/msvc2019_64/bin`）。

3. **验证安装结果**：

   - 配置完成后，按下 `Win + R`，输入 `cmd` 打开系统终端；
   - 执行 `qmake -v` 命令，若输出类似 `QMake version 3.1` 和 `Using Qt version 5.15.2 in D:/Qt/5.15.2/msvc2019_64/lib` 的版本信息，说明安装和配置成功。

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_15" alt="图15" style="zoom: 60%;" />


#### <span style="color: green;">Step3：选择并配置 IDE</span>

- 推荐使用 **Visual Studio** 或 **Visual Studio Code（VS Code）**，若使用 Visual Studio，操作流程如下：

1. **安装 Visual Studio**：

   - 访问 [Visual Studio官网](https://visualstudio.microsoft.com/zh-hans/downloads/)，下载适用于 Windows 系统的安装包（推荐版本为 2017 及以上）；
   - 双击下载完成的 `VisualStudioSetup.exe` 文件，启动安装程序；
   - 等待安装程序加载准备完毕后，进入 “工作负荷” 选择界面，**必须勾选 “使用 C++ 的桌面开发” 模块**（该模块包含编译 C++ 项目所需的核心工具链，如 MSVC 编译器、CMake 等），其他非必要组件可暂不勾选以节省安装空间，同时可根据需求自定义安装路径；
   - 点击”安装“按钮，等待安装进度完成。
   
   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_16" alt="图16" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_17" alt="图17" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_18" alt="图18" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_19" alt="图19" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_20" alt="图20" style="zoom: 60%;" />

#### <span style="color: green;">Step4：运行示例项目</span>

1. **启动代码**：
   
   - 启动 Visual Studio， 可选通过 Microsoft 或 GitHub 账户登录，或者选择“跳过并稍后添加账户”；
   - 在“开始使用”页面，点击“打开本地文件夹”，选择并打开 `TESS_CppAPI_EXAMPLE` 文件夹（或通过顶部菜单栏 “文件> 打开 > CMake” 路径，定位至 `TESS_CppAPI_EXAMPLE` 项目文件夹，选择其中的 **`CMakeLists.txt`** 文件，以 “CMake 项目” 格式打开）；
   - 在右侧（也可能是左侧） “解决方案资源管理器 - 文件夹视图” 中，右键单击 **`CMakeLists.txt`** 文件，选择 **“设置为启动项”**，可见上方工具栏的启动项已经变为 `CMakeLists.txt`；
   - 点击上方工具栏的 “运行” 按钮（绿色三角图标），或按下快捷键 `F5`，即可以 Debug 模式启动程序。
   
   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_21" alt="图21" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_22" alt="图22" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_23" alt="图23" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_24" alt="图24" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_25" alt="图25" style="zoom: 60%;" />
   
2. **软件激活**：
   - 首次启动时会弹出 TESS NG 软件激活窗口，按提示完成激活（需使用有效授权）；
   - 激活成功后关闭弹窗，再次点击 “运行” 按钮，即可正常启动示例项目。

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_26" alt="图26" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/cpp_2_1_27" alt="图27" style="zoom: 60%;" />



## 2.2.示例讲解

#### <span style="color: dodgerblue;">Note 1：目录结构及说明</span>

​	`TESS_CppAPI_EXAMPLE` 遵循 C++ 项目标准工程化结构，区分编译输出、头文件、源文件与库文件目录，适配多编译模式（Debug/Release），各目录及文件说明如下：

- **bin**：编译产物（可执行文件）输出根目录，按编译模式区分子目录
  - **Debug**：Debug 编译模式下的可执行文件输出目录（含调试信息，用于开发调试阶段）
  - **Release**：Release 编译模式下的可执行文件输出目录（无调试信息，体积更小、运行效率更高，用于正式部署）
- **build**：编译过程文件（如中间目标文件、CMake 缓存文件等）输出根目录，按编译模式区分
  - **Debug**：Debug 模式下的编译中间文件目录（如 `.obj`、`.pdb` 等，不直接用于运行，仅为编译过程产物）
  - **Release**：Release 模式下的编译中间文件目录，功能同 Debug 子目录，适配 Release 编译流程

- **include**：项目头文件（`.h`）统一存放目录，包含自定义插件、核心模块的接口声明，供源文件引用
- **lib**：依赖库文件存放根目录，按编译模式区分 Debug/Release 版本库
  - **Debug**：Debug 模式下的依赖库文件（如 `.lib`），用于 Debug 版本项目的编译链接
  - **Release**：Release 模式下的依赖库文件，用于 Release 版本项目的编译链接

- **src**：项目源文件（`.cpp`/`.h`）存放目录，按功能模块拆分文件。
  - **main.cpp**：项目主入口源文件，负责初始化 TESS NG 实例并启动程序
  - **MyPlugin.h / MyPlugin.cpp**：自定义插件的头文件与源文件，负责初始化插件
  - **MyNet.h / MyNet.cpp**：自定义路网插件的头文件与源文件，可以在路网加载前后执行自定义操作，控制路网元素的绘制
  - **MySimulator.h / MySimulator.cpp**：自定义仿真插件的头文件与源文件，可以在仿真前后以及仿真过程中执行自定义操作，既能全局控制仿真的启停逻辑，也能精细化干预单个车辆的驾驶行为
  - **MyGUI.h / MyGUI.cpp / MyGUI.ui**：自定义界面的头文件、源文件及 UI 设计文件，用于扩展 TESS NG 交互界面（如新增按钮、弹窗、数据展示面板等）

- **CMakeLists.txt**：C++ 项目编译配置文件，定义编译规则（如源文件路径、依赖库引用、编译模式参数等），支持跨平台编译，是 IDE（如 Visual Studio）识别项目的核心配置文件

#### <span style="color: dodgerblue;">Note 2：插件注册机制与仿真控制逻辑</span>

​	很多 TESS NG 初用者常会困惑：自己编写的自定义插件代码是如何被 TESS NG 调用的？结合项目主入口文件`main.cpp`的实现逻辑，可清晰理解这一过程，同时需明确仿真场景的核心开发思路，具体说明如下：

1. 先解答核心疑问：**自定义代码如何被 TESS NG 调用？**关键在于 `main.cpp` 中 `gpTessInterface->loadPluginFromMem(pPlugin)` 这行代码。它是连接用户自定义插件与 TESS NG 仿真核心的 “桥梁”，`gpTessInterface`（TESS NG 提供的接口）的`loadPluginFromMem`方法，会将用户通过 `auto *pPlugin = new MyPlugin()`创建的自定义插件实例（`MyPlugin`是用户编写的插件类，封装了所有自定义逻辑），通过 TESS NG 底层接口注册到仿真核心。注册完成后，TESS NG 会在仿真运行的关键节点（如仿真启动、每一步仿真推进、仿真结束等），自动调用 `MyPlugin` 及其子插件 `MyNet` 和 `MySimulator` 中用户重写的钩子方法，无需手动编写 “调用代码”，从而实现功能拓展。
2. 再明确仿真场景开发的核心思路：初用者易陷入 “如何把 TESS NG 仿真嵌入自己计算代码” 的误区，正确做法是 “**将自定义计算代码嵌入 TESS NG 仿真流程**”。TESS NG 已提供成熟的仿真框架（如路网加载、仿真推进、界面交互等基础能力），`main.cpp`的核心作用就是 “配置并启动这个框架”。用户无需自己搭建仿真框架，只需将计算代码（如自定义车辆行为、数据采集、特殊场景触发逻辑等）封装到 `MyPlugin` 及其子插件 `MyNet` 和 `MySimulator` 的特定方法中（例如 TESS NG 提供的每步仿真触发方法 `afterOneStep`、仿真启动触发方法 `afterStart`），待 `gpTessInterface->loadPluginFromMem` 完成插件注册后，这些逻辑会被 TESS NG 自动嵌入仿真流程，随仿真推进执行。

​	主入口源文件为main.cpp，代码如下：

```cpp
#include "MyPlugin.h"

#include <QtWidgets/QApplication>
#include <QMainWindow>
#include <QTextCodec>
#include <QLibrary>

int main(int argc, char *argv[])
{
	// 创建 Qt 应用程序实例
	QApplication a(argc, argv);
	QMainWindow *pWindow = tessng();
	if (pWindow)
	{
		// 创建自定义插件类实例
		auto *pPlugin = new MyPlugin();
		pPlugin->init();
		// 加载插件
		gpTessInterface->loadPluginFromMem(pPlugin);

		// 显示窗口并运行事件循环
		pWindow->showMaximized();
		int result = a.exec();

		// 清理资源
		pWindow->deleteLater();
		return result;
	}
	return 0;
}
```

#### <span style="color: dodgerblue;">Note 3：修改启动路网</span>

​	在 `TESSNG.exe` 同级目录下（需区分 Debug 模式与 Release 模式对应的路径），新建文本文件并命名为 `config.json`，在该文件中新增两个配置属性：

- `"__netfilepath"`：用于指定 TESS NG 启动时默认加载的路网文件路径；

- `"__simuafterload"`：用于指定 TESS NG 加载路网文件后是否立即开启仿真。

  例如：


```json
{
	"__netfilepath": "C:/TESSNG_4.1.0/Examles/杭州武林门区域路网公交优先方案.tess",	
	"__simuafterload": true
}
```

#### <span style="color: dodgerblue;">Note 4：路网元素的增删查改及属性操作</span>

​	可通过 `netiface` 接口实现对路网元素（如路段、连接段等）的**新增、删除、查询、修改**，同时获取路网元素对象后，支持对其属性进行**查询**与**修改**。

- 以下示例为：路网元素的增删查改（通过 `netiface` 接口）。

```cpp
// 1. 查询所有路段：获取当前路网中所有路段的列表
QList<ILink*> links = netiface->links();

// 2. 按ID查询指定路段：获取ID为1的路段（若不存在则返回nullptr）
ILink* link = netiface->findLink(1);

// 3. 新增路段：传入路段顶点坐标（linkPoints）、车道数（7）、路段名称（"曹安公路"），创建并返回新路段对象
QList<QPointF> linkPoints = {QPointF(-300, 0), QPointF(300, 0)};
ILink* link1 = netiface->createLink(linkPoints, 7, "曹安公路", true, UnitOfMeasure::Metric);

// 4. 删除路段：传入需删除的路段对象（link1），从路网中移除该路段
netiface->removeLink(link1);
```

- 以下示例为：路网元素属性的查询与修改（通过元素对象）。


```cpp
// 1. 属性查询：获取路段link1的相关属性
int laneCount = link1->laneCount();  // 查询路段车道数（返回整数，如3）
qreal laneLength = link1->length();  // 查询路段长度（返回浮点数，单位：m）

// 2. 属性修改：修改路段link1的名称与限速
link1->setName("曹安公路");  // 设置路段名称为"曹安公路"
link1->setLimitSpeed(80);  // 设置路段限速为80km/h
```

#### <span style="color: dodgerblue;">Note 5：路网加载前后的自定义操作</span>

​	在自定义路网插件（`MyNet` 类）中，可通过重写 `beforeLoadNet` 和 `afterLoadNet` 方法，实现**路网加载前的预处理**与**路网加载后的后续操作**。

- 以下示例为：路网加载完成后，先判断当前路网是否存在路段；若不存在，则调用自定义方法 `createNetwork()` 创建基础路网（含路段、连接段、发车点等）。

```cpp
// MyNet.cpp：自定义路网插件的实现文件
void MyNet::afterLoadNet()
{
    // 1. 查询当前路网中的路段总数
    int linkCount = netiface->linkCount();

    // 2. 若路网中无路段（linkCount == 0），则执行自定义路网创建逻辑
    if (linkCount == 0)
    {
        // 自定义方法：内部实现路段、连接段、发车点的创建逻辑
        createNetwork();
    }
}
```

#### <span style="color: dodgerblue;">Note 6：路网元素的显示控制</span>

​	在自定义路网插件（`MyNet` 类）中，可通过重写 `labelNameAndFont` 方法实现对路网元素（如路段、连接段）标签的精细化显示控制 —— 包括标签内容（显示名称 / ID / 不显示）、字体大小的自定义，满足不同场景下的路网可视化需求。

- 以下示例为：名称为“曹安公路”的路段的标签显示路段名称，其它路段标签显示ID，连接段标签则都显示名称。

```cpp
// MyNet.cpp：自定义路网插件的实现文件
void MyNet::labelNameAndFont(int itemType, long itemId, int &outPropName, qreal &outFontSize)
{
    // 1. 仿真正在运行时，路段、车道不绘制标签，避免干扰仿真观察
    if (!simuiface->isRunning())
    {
        outPropName = GraphicsItemPropName::None;  // 不显示任何标签
        return;  // 直接返回，无需执行后续逻辑
    }

    // 2. 默认配置：标签显示元素ID，字体大小为6米
    outPropName = GraphicsItemPropName::Id;
    outFontSize = 6;

    // 3. 连接段特殊配置：全部显示名称（无论ID，统一以名称标识）
    if (itemType == NetItemType::GConnectorType)
    {
        outPropName = GraphicsItemPropName::Name;
    }
    // 4. 路段特殊配置：仅ID为1、5、6的路段显示名称，其余显示ID
    else if (itemType == NetItemType::GLinkType)
    {
        if (itemId == 1 || itemId == 5 || itemId == 6)
        {
            outPropName = GraphicsItemPropName::Name;
        }
    }
}
```

#### <span style="color: dodgerblue;">Note 7：仿真信息的查询和修改</span>

​	可通过 `simuiface` 接口实现对**仿真核心参数**的查询与修改，包括仿真时长、精度、倍速等。

```cpp
// 1. 仿真信息查询：获取当前仿真的关键参数
long simuInterval = simuiface->simuIntervalScheming();  // 查询预设仿真总时长（单位：s）
int simuAccuracy = simuiface->simuAccuracy();  // 查询仿真精度
int simuMultiples = simuiface->acceMultiples();  // 查询仿真倍速
long simuTime = simuiface->simuTimeIntervalWithAcceMutiples();  // 查询当前已仿真时间（单位：ms）

// 2. 仿真信息修改：设置仿真的关键参数
simuiface->setSimuIntervalScheming(3600);  // 设置仿真总时长为3600s
simuiface->setSimuAccuracy(1);  // 设置仿真精度为1
simuiface->setAcceMultiples(5);  // 设置仿真倍速为5
```

#### <span style="color: dodgerblue;">Note 8：仿真车辆的增删查及属性操作</span>	

​	可通过 `simuiface` 接口实现对**仿真车辆**的新增、删除、查询，同时支持获取车辆对象后，查询其所有属性，并修改**静态属性**（不随仿真动态变化的属性，如长度、最大速度）。

- 以下示例为：仿真车辆的增删查改（通过 `simuiface` 接口）。

```cpp
// 1. 查询车辆：获取指定范围的车辆列表
QList<IVehicle*> allVehicles = simuiface->allVehiStarted();  // 获取当前所有已启动的车辆
QList<IVehicle*> linkVehicles = simuiface->vehisInLink(1);  // 获取当前在ID为1的路段上行驶的车辆

// 2. 新增车辆：在指定路段动态创建车辆（需先配置车辆参数 DynaVehiParam）
Online::DynaVehiParam dvp;  // 车辆动态参数对象
dvp.vehiTypeCode = qrand() % 4 + 1;  // 随机设置车辆类型编码（1-4，对应不同车型）
dvp.roadId = 6;  // 指定车辆初始所在路段ID（此处为6）
dvp.laneNumber = qrand() % 3;  // 随机设置初始车道号（0-2，对应路段的第1-3车道）
dvp.dist = 50;  // 车辆在路段上的初始距离（距路段起点50m）
dvp.speed = 20;  // 车辆初始速度（单位：m/s）
dvp.color = "#00AFF0";  // 车辆显示颜色
// 调用接口创建车辆，返回新车辆对象（若创建失败则返回nullptr）
IVehicle* vehicle1 = simuiface->createGVehicle(dvp);
// 判断车辆是否创建成功
if (vehicle1 != nullptr)
{
    qDebug() << "在路段上创建了车辆，车辆ID：" << vehicle1->id();
}

// 3. 删除车辆：停止指定车辆（vehicle1）的行驶并从仿真中移除
simuiface->stopVehicleDriving(vehicle1);
```

- 以下示例为：车辆属性的查询与静态修改（通过车辆对象）。


```cpp
// 1. 属性查询：获取车辆vehicle的相关属性
QString roadName = vehicle->roadName();  // 车辆所在路段名或连接段名
qreal speed = vehicle->currSpeed();  // 获取车辆的当前速度，单位：m/s

// 2. 属性修改：修改车辆vehicle的长度与限速
vehicle->setLength(5);  // 修改车辆的长度，单位：m
vehicle->setMaxSpeed(80/3.6);  // 修改车辆的最大速度，单位：m/s
```

#### <span style="color: dodgerblue;">Note 9：仿真车辆的动态属性修改</span>

​	车辆的**动态属性**（如实时速度、加速度，随仿真过程动态变化）无法直接通过车辆对象修改，需在**自定义仿真插件（`MySimulator` 类）** 中，重写特定对象方法实现 —— 本质是对 TESS NG 实时计算的动态数值进行修正或覆盖。

- 以下示例为：在 `reSetSpeed` 方法中，根据车辆 ID 和所在路段，强制指定部分车辆的实时速度（使 ID 2~N 的车辆跟随 ID 1 的车辆速度）。

```cpp
// MySimulator.cpp：自定义仿真插件的实现文件
bool MySimulator::reSetSpeed(IVehicle *pIVehicle, qreal &inOutSpeed)
{
    // 1. 处理车辆ID（取余避免ID过长，仅保留后5位）
    long tmpVehicleId = pIVehicle->id() % 100000;

    // 2. 获取车辆当前所在路段名称
    QString roadName = pIVehicle->roadName();

    // 3. 仅对"曹安公路"上的车辆执行速度控制逻辑
    if (roadName == "曹安公路")
    {
        // 若为ID=1的车辆：记录其当前速度（作为基准速度）
        if (tmpVehicleId == 1)
        {
            planeSpeed = pIVehicle->currSpeed();
        }
        // 若为ID 2~squareVehiCount的车辆：强制将其速度设为基准速度
        else if (tmpVehicleId >= 2 && tmpVehicleId <= squareVehiCount)
        {
            // 覆盖TESS NG计算的速度值
            inOutSpeed = planeSpeed;
            // 返回true表示速度修改生效
            return true;
        }
    }
    // 返回false表示不修改速度，使用TESS NG默认计算值
    return false;
}
```

#### <span style="color: dodgerblue;">Note 10：特定仿真时机的自定义操作</span>

​	在自定义仿真插件（`MySimulator` 类）中，可通过重写 TESS NG 提供的特定方法，在**不同仿真节点触发自定义逻辑**：既支持在**仿真全局时机**（如仿真启动前、结束后）执行操作，也支持在**车辆特定行为时机**（如车辆创建、车辆移除、车辆换道前）触发逻辑，满足精细化的仿真定制需求。

- 通过重写 `beforeStart`（仿真启动前）和 `afterStop`（仿真结束后）方法，可实现仿真全局的预处理与后处理，例如初始化仿真参数、循环启动仿真、导出仿真结果等。以下示例为：仿真结束后，判断累计仿真次数是否 ≤ 3；若满足条件，则自动重新启动仿真（实现循环仿真）。

```cpp
// MySimulator.cpp：自定义仿真插件的实现文件
void MySimulator::afterStop()
{
    // 1. simuCount为自定义变量，用于统计累计仿真次数
    if (simuCount <= 3)
    {
        // 2. 调用接口重新启动仿真
        simuiface->startSimu();
    }
}
```

- 通过重写与车辆行为绑定的方法，可在车辆满足特定条件时触发逻辑，例如车辆创建后初始化属性、车辆移除后记录数据等。以下示例为：在仿真车辆创建后，根据车辆 ID 设置车辆的车型、位置和长度。

```cpp
// MySimulator.cpp：自定义仿真插件的实现文件
void MySimulator::initVehicle(IVehicle *pIVehicle)
{
    // 1. 获取当前车辆的基础信息（所在路段名称、路段ID）
    QString roadName = pIVehicle->roadName();  // 车辆当前所在路段/连接段的名称
    long roadId = pIVehicle->roadId();  // 车辆当前所在路段/连接段的ID

    // 2. 仅对「曹安公路」上的车辆执行特殊定制逻辑
    if (roadName == "曹安公路")
    {
        // 处理车辆ID：取余100000，剔除首位数（首位数通常关联车辆来源，如发车点、公交线路）
        long tmpVehicleId = pIVehicle->id() % 100000;

        // 3. 针对特定ID的车辆，设置专属车型与初始位置
        if (tmpVehicleId == 1)
        {
            // 将ID=1的车辆设置为「12号车型」
            pIVehicle->setVehiType(12);
            // 初始化车辆的初始车道、位置和速度
            pIVehicle->initLane(3, m2p(105), 0);
        }
        // 中间可补充其他ID车辆的定制逻辑，如tmpVehicleId=2、3等

        // 4. 针对ID 23~28的车辆，设置特定长度
        if (tmpVehicleId >= 23 && tmpVehicleId <= 28)
        {
            pIVehicle->setLength(m2p(4.5), true);
        }
    }
}
```

<div style="page-break-after: always;"></div>

# 3.接口详情

​	本节将首先介绍**全局配置参数（config.json）**，然后依次介绍**插件（Plugin）**、**接口（Interface）** 和 **对象（Object）**三个层次的内容，帮助读者从整体到细节逐步理解 TESS NG 的二次开发模式。



## 3.1.全局配置参数

​	TESS NG 可识别的全局配置参数 config.json 如下: 

```json
{
	"__netfilepath": "xxx.tess", 		
	"__simuafterload": false, 
	"__timebycpu": false, 
	"__writesimuresult": true, 
	"__custsimubysteps": false,
    "__allowspopup": false
}
```

**__netfilepath**

​	 指定 TESSNG 启动后加载的路网文件路径，支持绝对路径或相对路径。若文件不存在，将默认打开空白路网。

**__simuafterload**

​	指定TESSNG加载路网文件后是否自动启动仿真，默认为 false。 

**__timebycpu**

​	指定仿真周期的时间计算依据：基于 CPU 时钟的现实时长，或基于仿真精度的时长，默认为 false。在线仿真且算力紧张时，可尝试将此属性设为 true。

**__writesimuresult**

​	控制是否输出仿真结果，默认为 true。若设为 false，仿真结束后不写入结果文件，且仿真过程中，车辆驶出路网一段时间后会被回收到可用队列，以减少内存占用。

**__custsimubysteps**

​	设置 TESSNG 调用插件方法的频次依据，默认为 false。设为 false 时，每个计算周期调用一次（不依据插件端设置的频次）；设为 true 时，将依据插件设置的频次调用其实现的方法。

**__allowspopup**

​	控制是否允许弹出提示弹窗，以避免阻塞程序运行，默认为 true。



## 3.2.插件

​	通常，软件的功能拓展通过定义插件接口并由用户实现插件来完成。TESS NG亦采用此模式，其包含顶级插件接口TessPlugin，以及CustomerNet、CustomerSimulator、CustomerGui三个子插件接口。与仅能调用接口方法而无法改变内部运行逻辑的TessInterface接口不同，用户通过实现TessPlugin及其子接口的方法，能够深入TESS NG的内部运行过程，在路网加载、仿真过程、窗体交互等环节施加影响，进而改变其运行逻辑，实现更深层次的功能拓展。这三个子插件的所有方法均提供默认实现，用户可通过需求选择性实现部分或全部方法。

​	由于插件接口方法的调用场景与目的存在差异，为统一对插件接口方法的理解，多数方法采用如下结构形式：

```cpp
bool method(type &outParam) 
{
    outParam = 1;
	return true;
}
```

​	TESS NG调用这些方法时遵循如下逻辑：**若返回值为false，则视为用户无响应，将忽略该调用；若返回值为true，表明用户有响应，此时将通过参数outParam的值进行后续处理**。以示例中的场景为例：当曹安公路上的车辆排成队列时，需对飞机后方的车辆重新设置速度，使其与飞机保持一致，此时，CustomerSimulator的子类MySimulator可通过实现 `reSetSpeed` 方法来达成这一需求。

```cpp
bool MySimulator::reSetSpeed(IVehicle *pIVehicle, qreal &inOutSpeed)
{
	long tmpVehicleId = pIVehicle->id() % 100000;
	QString roadName = pIVehicle->roadName();
	if (roadName == "曹安公路")
	{
		if (tmpVehicleId == 1)
		{
			planeSpeed = pIVehicle->currSpeed();
		}
		else if (tmpVehicleId >= 2 && tmpVehicleId <= squareVehiCount)
		{
			inOutSpeed = planeSpeed;
			return true;
		}
	}
	return false;
}
```

​	TESS NG在计算车辆的速度后会调用插件的reSetSpeed方法，如果该方法返回true，视插件对此方法作出响应，这时再用outSpeed值取代原先计算的车速。TESS NG调用插件 `reSetSpeed` 方法的过程如下：

```cpp
if (gpTessPlugin && gpTessPlugin->customerSimulator())
{
   qreal outSpeed = mrCurrSpeed；
   if (gpTessPlugin->customerSimulator()->reSetSpeed(mpGVehicle，outSpeed))
   {
       mrCurrSpeed = outSpeed；
   }
}
```

### 3.2.1.顶级插件（TessPlugin）

​	头文件：Plugin / tessplugin.h

​	TessPlugin是用户开发的顶级插件接口，下面有三个子插件接口：CustomerNet、CustomerSimulator、CustomerGui，用户通过实现这三个子插件分别在路网、仿真过程、窗体三个方面与TESSNG进行交互。

**void init()**

​	插件初始化，可在此实现方法里实例化CustomerNet、CustomerSimulator、CustomerGui三个类的子类。

**CustomerNet\* customerNet()**

​	返回customerNet对象。

**CustomerSimulator\* customerSimulator()**

​	返回CustomerSimulator对象。

**CustomerGui\* customerGui()**

​	返回CustomerGui对象。


### 3.2.2.路网插件（CustomerNet）

​	头文件：Plugin / customernet.h	

​	CustomerNet是TessPlugin的子插件接口，用户通过实现该插件，可以在路网加载前后执行自定义操作，控制路网元素的绘制，并定义视窗事件的响应逻辑。

#### 3.2.2.1.路网加载

**void beforeLoadNet()**

​	加载路网前调用，用户可以通过此方法在加载路网前作必要的初始化准备工作。

**void afterLoadNet()**

​	加载路网后调用。

示例：

```cpp
void MyNet::afterLoadNet()
{
    // 获取路段数
    int linkCount = netiface->linkCount();
    // 如果路网上没有路段，则调用自定义的创建路网的方法
    if (linkCount == 0)
    {
        createNetwork();
    }
}
```

#### 3.2.2.2.路网元素绘制

**bool isPermitForCustDraw()**

​	是否允许调用客户绘制。本方法的目的是减少不必要的代码调用，消除对运行效率的负面影响。

返回：

​	是否绘制，true表示绘制，false表示不绘制，默认为true。

**bool isDrawLinkCenterLine(long linkId)**

​	是否绘制路段中心线。

参数：

​	[ in ] linkID：路段ID。

返回：

​	是否绘制，true表示绘制，false表示不绘制，默认为true。

示例：

```cpp
bool MyNet::isDrawLinkCenterLine(long linkId)
{
    // ID为1的路段不绘制中心线
    return linkId != 1;
}
```

**bool isDrawLinkCorner(long linkId)**

​	是否绘制路段四个拐角的圆形和正方型。

参数：

​	[ in ] linkID：路段ID。

返回：

​	是否绘制，true表示绘制，false表示不绘制，默认为true。

**bool isDrawLaneCenterLine(long laneId)**

​	是否绘制车道中心线。

参数：

​	[ in ] laneID：车道ID。

返回：

​	是否绘制，true表示绘制，false表示不绘制，默认为false。

**bool linkType(QList\<QString\> &lType)**

​	路段类型。

参数：

​	[ in ] lType：用户定义的路段类型列表。

返回：

​	是否自定义。

**bool laneType(QList\<QString\> &lType)**

​	车道类型。

参数：

​	[ in ] lType：用户定义的车道类型列表。

返回：

​	是否自定义。

**bool paint(int itemType，long itemID，QPainter\* painter)**

​	绘制路网元素。

参数：

​	[ in ] itemType：路网元素类型。

​	[ in ] itemID：路网元素ID。

​	[ in ] painter：QPainter对象。

返回：

​	如果返回true，TESSNG认为插件已绘制，TESSNG不再绘制，否则TESSNG进行绘制。

**bool paintLaneObject(ILaneObject\* pILaneObj，QPainter\* painter)**

​	绘制车道或车道连接。

参数：

​	[ in ] pILaneObj：车道或车道连接。

​	[ in ] painter：QPainter对象。

返回：

​	如果返回true，TESSNG认为插件已绘制，TESSNG不再绘制，否则TESSNG进行绘制。

**bool linkBuildGLanes(ILink\* pILink)**

​	创建车道。

参数：

​	[ in ] pILink：路段对象。

返回：

​	如果返回true，TESSNG认为插件已创建了车道，TESSNG不再创建。

**bool linkBrushColor(long linkID，QColor& color)**

​	路段笔刷颜色。

参数：

​	[ in ] linkID：路段ID。

​	[ out ] color：QColor对象。

返回：

​	true表示用color颜色绘制路段。

示例：

```cpp
bool MyNet::linkBrushColor(long linkID，QColor& color)
{
	// 指定路段设置为红色
    QSet<long> targetLinkIds = {1, 2, 3};
    if (targetLinks.contains(linkId)) 
    {
        color.setNamedColor("#FF0000");
        return true;
    }
    return false;
}
```

**bool laneBrushAndPen(long laneID，QBrush &brush，QPen &pen)**

​	通过指定车道ID设置绘制车道的笔刷。

参数：

​	[ in ] laneID：车道ID。

​	[ out ] brush：QBrush 对象。

​	[ out ] pen：QPen 对象。

返回：

​	true表示用brush及pen参数绘制ID等于laneID的车道。

**bool connectorAreaBrushColor(long connAreaID，QColor& color)**

​	面域笔刷颜色。

参数：

​	[ in ] connAreaID：面域ID。

​	[ out ] color：笔刷颜色。

返回：

​	true表示TESSNG用color绘制面域。

**void labelNameAndFont(int itemType，long itemID，GraphicsItemPropName &outPropName，qreal &outFontSize)**

​	通过路网元素类型及ID确定用标签用ID或名称作为绘制内容。

参数：

​	[ in ] itemType：路段元素类型。

​	[ in ] itemID：路网元素ID。

​	[ out ] outPropName：枚举值。如果赋值GraphicsItemPropName::ID，则用ID作为绘制内容，如果赋值GraphicsItemPropName::Name，则用路网元素名作为绘制内容。

​	 [ out ] outFontSize：字体大小。单位：m。

返回：	

​	true表示通过设定的outPropName 值确定用ID或名称绘制标签，并且用指定大小绘制。

示例：

```cpp
bool MyNet::labelNameAndFont(int itemType，long itemID，GraphicsItemPropName &outPropName，qreal &outFontSize) 
{
    // 如果仿真正在进行，路段和车道都不绘制标签
	if (simuiface->isRunning())
	{
		outPropName = GraphicsItemPropName::None;
        return;
	}

	// 默认绘制ID
	outPropName = GraphicsItemPropName::Id;
	// 标签大小为6m
	outFontSize = 6;

	// 如果是连接段一律绘制名称
	if (itemType == NetItemType::GConnectorType)
	{
		outPropName = GraphicsItemPropName::Name;
	}
	// 如果是路段，则根据ID判断是否绘制名称
	else if (itemType == NetItemType::GLinkType)
	{
		if (itemId == 1 || itemId == 5 || itemId == 6)
		{
			outPropName = GraphicsItemPropName::Name;
		}
	}
}
```

#### 3.2.2.3.视窗事件响应

**void afterViewMousePressEvent(QMouseEvent\* event)**

​	用于实现鼠标点击后的自定义响应逻辑。

参数：

​	[ in ] event：鼠标事件对象。

示例：

```cpp
void MyNet::afterViewMousePressEvent(QMouseEvent* event)
{
    // 获取鼠标坐标
    QPoint mousePos = event->pos();
    // 转为仿真场景坐标
    QPointF scenePos = netiface.graphicsView()->mapToScene(mousePos);
    qreal x = scenePos.x();
    qreal y = scenePos.y();
}
    
```

**void afterViewMouseReleaseEvent(QMouseEvent\* event)**

​	用于实现鼠标释放后的自定义响应逻辑。

参数：

​	[ in ] event：鼠标事件对象。

**void afterViewMouseDoubleClickEvent(QMouseEvent\* event)**

​	用于实现鼠标双击后的自定义响应逻辑。

参数：

​	[ in ] event：鼠标事件对象。

**void afterViewMouseMoveEvent(QMouseEvent\* event)**

​	用于实现鼠标移动后的自定义响应逻辑。

参数：

​	[ in ] event：鼠标事件对象。

**void afterViewWheelEvent(QWheelEvent\* event)**

​	用于实现鼠标滚动后的自定义响应逻辑。

参数：

​	[ in ] event：鼠标滚轮事件对象。

**void afterViewKeyReleaseEvent(QKeyEvent\* event)**

​	用于实现键盘释放后的自定义响应逻辑。

参数：

​	[ in ] event：键盘事件对象。

**void afterViewResizeEvent(QResizeEvent\* event)**

​	用于实现屏幕缩放后的自定义响应逻辑。

参数：

​	[ in ] event：屏幕缩放事件对象。

**void afterViewScrollContentsBy(int dx，int dy)**

​	用于实现视窗滚动条移动后的自定义响应逻辑。

参数：

​	[ in ] dx：水平方向的滚动偏移量，大于0时表示向左滚动。单位：像素。

​	[ in ] dy：垂直方向的滚动偏移量，大于0时表示向上滚动。单位：像素。

### 3.2.3.仿真插件（CustomerSimulator）

​	头文件：Plugin / customersimulator.h

​	CustomerSimulator是TessPlugin子插件接口，用户通过实现该插件，可以在仿真前后以及仿真过程中执行自定义操作，既能全局控制仿真的启停逻辑，也能精细化干预单个车辆的驾驶行为。

#### 3.2.3.1.仿真启停

**void beforeStart(bool &keepOn)**

​	用于实现启动仿真前的自定义操作。如果需要，用户可通过设置keepOn为false来放弃仿真。

参数：

​	[ out ] keepOn：是否继续，默认为true。

**void afterStart()**

​	用于实现启动仿真后的自定义操作。

**void afterStop()**

​	用于实现结束仿真后的自定义操作。

示例：

```cpp
void MySimulator::afterStop()
{
    // 如果仿真次数不足3次，则重启仿真
	if (simuCount <= 3)
	{
		simuiface->startSimu();
	}
}
```

**void afterOneStep ()**

​	用于实现完成一帧仿真后的自定义操作。这个时候所有车辆都完成同一个批次的计算。通常在这个方法中获取车辆轨迹、检测器数据、进行必要的小计等。在这个方法中进行的计算基本不影响仿真结果的一致性，但效率不高，如果计算量大对仿真效率会有影响。

**void duringOneStep()**

​	该方法在各个工作线程进行同一批次的计算过程中调用，这时存在部分车辆计算完成，部分车辆仍在计算过程中。这个方法中的计算不够安全，但效率较高。

**bool calcSimuConfig(Online::SimuConfig& config)**

​	计算仿真参数 。

参数：

​	[ out ] config：仿真参数信息。

返回：

​	true表示用config中的参数更新仿真参数。如果仿真已启动，仿真精度及线程数不能更新，仿真时长及加速倍数可以更新。

#### 3.2.3.2.车辆控制

**void initVehicle(IVehicle\* pIVehicle)**

​	用于实现车辆创建后的自定义操作。用户可以在这个方法里对车辆的车道序号、起始位置、车辆大小进行初始化。

参数：

​	[ in ] pIVehicle：车辆对象。

示例：

```cpp
void MySimulator::initVehicle(IVehicle* pIVehicle)
{
	// 如果是小客车，则设为蓝色
    if (pIVehicle->vehicleTypeCode() == 1)
    {
        pIVehicle->setColor("#00AFF0");
    }
}
```

**bool isStopDriving(IVehicle\* pIVehicle)**

​	用于判断是否要停止车辆的运行。

参数：

​	[ in ] pIVehicle：车辆对象。

返回：

​	true表示将停止该车辆运行，移出路网。

示例：

```cpp
bool MySimulator::isStopDriving(IVehicle* pIVehicle)
{
    // 如果车辆进入12号路段，则移除
    if (pIVehicle->roadIsLink() && pIVehicle->roadId() == 12)
    {
        return true;
    }
    return false;
}
```

**void beforeStopVehicle(IVehicle\* pIVehicle)**

​	用于实现车辆移除前的自定义操作。

参数：

​	[ in ] pIVehicle：车辆对象。 

**void afterStopVehicle(IVehicle\* pIVehicle)**

​	用于实现车辆移除后的自定义操作。

参数：

​	[ in ] pIVehicle：车辆对象。

**void afterStep (IVehicle\* pIVehicle)**

​	用于实现车辆完成一帧仿真后的自定义操作。可以在此获取车辆当前信息，如当前道路、位置、方向角、速度、期望速度、前后左右车辆等。

参数：

​	[ in ] pIVehicle：车辆对象。

**bool calcAcce(IVehicle\* pIVehicle，qreal &acce)**

**bool calcAcce(IVehicle\* pIVehicle，qreal &acce，UnitOfMeasure\* unit)**

​	计算车辆的加速度。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ out ] acce：车辆加速度。单位：像素/s²。

返回：	

​	如果返回true，则将acce作为当前加速度。

示例：

```cpp
bool MySimulator::calcAcce(IVehicle* pIVehicle, qreal &acce, UnitOfMeasure* unit)
{
    if (pIVehicle->roadName() == "曹安公路")
    {
        // 根据速度不同，直接计算加速度
        if (pIVehicle->currSpeed() > 20/3.6)
        {
            acce = -3;
            return true;
        }
        else if (pIVehicle->currSpeed() > 10/3.6)
        {
            acce = -1;
            return true;
        }
    }
    return false;
}
```

**bool reSetAcce(IVehicle\* pIVehicle，qreal &inOutAcce)**

**bool reSetAcce(IVehicle\* pIVehicle，qreal &inOutAcce，UnitOfMeasure\* unit)**

​	重新计算车辆的加速度。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in, out ] inOutAcce：车辆加速度。单位：像素/s²。

返回：

​	如果返回true，则将inOutAcce作为当前加速度。

示例：

```cpp
bool MySimulator::reSetAcce(IVehicle* pIVehicle, qreal &inOutAcce, UnitOfMeasure* unit)
{
    if (pIVehicle->roadName() == "曹安公路")
    {
        // 根据速度不同，对已计算出的加速度进行修正
        if (pIVehicle->currSpeed() > 20/3.6)
        {
            acce += -3;
            return true;
        }
        else if (pIVehicle->currSpeed() > 10/3.6)
        {
            acce += -1;
            return true;
        }
    }
    return false;
}
```

**bool reCalcdesirSpeed(IVehicle\* pIVehicle，qreal &inOutDesirSpeed)**

**bool reCalcdesirSpeed(IVehicle\* pIVehicle，qreal &inOutDesirSpeed，UnitOfMeasure\* unit)**

​	重新计算车辆的期望速度。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in, out ] inOutDesirSpeed：车辆期望速度。单位：像素/s²。

返回：

​	如果返回true，则将inOutDesirSpeed作为期望速度。

**bool calcMaxLimitedSpeed(IVehicle\* pIVehicle，qreal &inOutLimitedSpeed)**

**bool calcMaxLimitedSpeed(IVehicle\* pIVehicle，qreal &inOutLimitedSpeed，UnitOfMeasure\* unit)**

​	重新计算车辆的当前最大限速。在没有插件干预的情况下，车辆速度大于道路限度时按道路最大限速行驶，在此方法的干预下，可以提高限速，让车辆大于道路限速行驶。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in, out ] inOutLimitedSpeed：车辆最大限速，单位：像素/秒。

返回：

​	如果返回true，则将inOutLimitedSpeed作为当前道路最大限速。

**bool calcSpeedLimitByLane(ILink\* pILink，int laneNumber，qreal& outSpeed)**

**bool calcSpeedLimitByLane(ILink\* pILink，int laneNumber，qreal& outSpeed，UnitOfMeasure\* unit)**

​	由车道确定的限制车速。

参数：

​	[ in ] pILink：路段对象。

​	[ in ] laneNumber：laneNumber：车道序号，最右侧编号为0。

​	[ in, out ] outSpeed：车辆限速。单位：km/h。

返回：	

​	如果返回true，则将outSpeed作为车道限速。

**bool reSetSpeed(IVehicle\* pIVehicle，qreal &inOutSpeed)**

**bool reSetSpeed(IVehicle\* pIVehicle，qreal &inOutSpeed，UnitOfMeasure\* unit)**

​	重新计算车辆的速度。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in, out ] inOutSpeed：车辆速度。单位：像素/s。

返回：

​	如果返回true，则将inOutSpeed作为车辆当前速度。

示例：

```cpp
bool MySimulator::reSetSpeed(IVehicle* pIVehicle, qreal &inOutSpeed, UnitOfMeasure* unit)
{
    if (pIVehicle->id() == 100001)
    {
        // 直接指定车辆的速度
        inOutSpeed = 80 / 3.6;
        return true;
    }
    return false;
}
```

**bool reCalcAngle(IVehicle\* pIVehicle，qreal &inOutAngle)**

​	重新计算车辆的角度。北向为0度，顺时针。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in, out ] inOutAngle：车辆角度。单位：角度。

返回：

​	如果返回true，则将inOutAngle作为车辆当前角度。


**bool reSetFollowingType(IVehicle\* pIVehicle，int& outTypeValue)**

​	重新设置车辆的跟驰类型。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ out ] outTypeValue：跟驰类型。0：停车，1：正常，5：急减速，6：急加速，7：汇入，8：穿越，9：协作减速，10：协作加速，11：减速待转，12：加速待转。

返回：	

​	如果返回true，则将outTypeValue作为车辆的跟驰类型。

**bool reSetFollowingParam(IVehicle\* pIVehicle，qreal &inOutSafeInterval，qreal &inOutSafeDistance)**

**bool reSetFollowingParam(IVehicle\* pIVehicle，qreal &inOutSafeInterval，qreal &inOutSafeDistance，UnitOfMeasure\* unit)**

​	重新设置车辆的跟驰模型的安全间距和安全时距。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in, out ] inOutSafeInterval：安全时距，单位：秒。

​	[ in, out ] inOutSafeDistance：安全间距，单位：像素。

返回：

​	如果返回true，则将inOutSafeInterval作为车辆的安全时距，将inOutSafeDistance作为车辆的安全间距。

**QList\<Online::FollowingModelParam\> reSetFollowingParams()**

​	重新设置车辆的跟驰模型参数，使用得到跟驰模型数据取代当前仿真正在采用的跟驰模型，影响所有车辆。

返回：

​	跟驰参数列表，可对机动车和非机车的跟驰参数重新设置，**设置以后会一直被采用**，直到被新的参数所代替。

**bool reSetDistanceFront(IVehicle\* pIVehicle，qreal& distance，qreal& s0)**

**bool reSetDistanceFront(IVehicle\* pIVehicle，qreal& distance，qreal& s0，UnitOfMeasure\* unit)**

​	重新设置车辆的前车间距和停车距离。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in, out ] distance：当前车辆与前车的距离。单位：像素。

​	[ in, out ] s0：停车距离。单位：像素。

返回：

​	如果返回true，则将distance作为车辆的前车距，将s0作为车辆的停车距离。

**bool calcChangeLaneSafeDist(IVehicle\* pIVehicle，qreal& dist)**

**bool calcChangeLaneSafeDist(IVehicle\* pIVehicle，qreal& dist，UnitOfMeasure\* unit)**

​	计算车辆的安全变道距离。

参数：

​	[ in ] pIVehicle：车辆，计算该车辆安全变道距离。

​	[ in, out ] dist：安全变道距离。单位：像素。

返回：

​	如果返回true，则将dist作为车辆的安全变道距离。

**bool reCalcToLeftLane(IVehicle\* pIVehicle)**

​	计算是否要左强制变道，仅在TESSNG判定无需执行向左强制变道时生效，不能阻止TESSNG对车辆向左强制变道的控制。

参数：

​	[ in ] pIVehicle：车辆对象。

返回：

​	如果返回true，则控制车辆向左强制变道。

**bool reCalcToRightLane(IVehicle\* pIVehicle)**

​	计算是否要右强制变道，仅在TESSNG判定无需执行向右强制变道时生效，不能阻止TESSNG对车辆向右强制变道的控制。

参数：

​	[ in ] pIVehicle：车辆对象。

返回：

​	如果返回true，则控制车辆向右强制变道。

**void beforeToLeftFreely(IVehicle\* pIVehicle，bool &bKeepOn)**

​	TESSNG计算是否向左自由变道前的处理。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in, out ] bKeepOn：是否继续，如果被赋值为false，则TESSNG不再计算是否可以向左自由变道。

**void beforeToRightFreely(IVehicle\* pIVehicle，bool& bKeepOn)**

​	TESSNG计算是否向右自由变道前的处理。

​	[ in ] pIVehicle：车辆对象。

​	[ in, out ] bKeepOn：是否继续，如果被赋值为false，则TESSNG不再计算是否可以向右自由变道。

**bool reCalcToLeftFreely(IVehicle\* pIVehicle)**

​	重新计算车辆是否要向左自由变道，仅在TESSNG判定无需执行向左自由变道时生效，不能阻止TESSNG对车辆向左自由变道的控制。

参数：

​	[ in ] pIVehicle：车辆对象。

返回：

​	如果返回true，则控制车辆向左自由变道。

**bool reCalcToRightFreely(IVehicle\* pIVehicle)**

​	重新计算车辆是否要向右自由变道，仅在TESSNG判定无需执行向右自由变道时生效，不能阻止TESSNG对车辆向右自由变道的控制。

参数：

​	[ in ] pIVehicle：车辆对象。

返回：

​	如果返回true，则控制车辆向右自由变道。

**bool reCalcDismissChangeLane(IVehicle\* pIVehicle)**

​	重新计算车辆是否撤销变道。

参数：

​	[ in ] pIVehicle：车辆对象。

返回：

​	如果返回true，且当前变道完成度不超过三分之一，则撤销当前变道行为。

示例：

```cpp
bool MySimulator::reCalcDismissChangeLane(IVehicle* pIVehicle)
{
	// 距离路段终点小于50m时撤销一切自由变道，达到禁止自由变道的效果
    if (pIVehicle->vehicleDriving()->distToEndpoint(true, true, UnitOfMeasure::Metric) < 50)
    {
        return true;
    }
    return false;
}
```

**QList\<int\> calcLimitedLaneNumber(IVehicle\* pIVehicle)**

​	计算限制车道序号：如管制、危险等，最右侧编号为0。

参数：

​	[ in ] pVehicle：车辆对象。

返回：

​	车道序号序列，保存车辆不可以驶入的车道序号。

示例：

```cpp
QList<int> MySimulator::calcLimitedLaneNumber(IVehicle* pIVehicle)
{
    // 如果车辆在路段上且车辆长度大于8m，则禁止驶入最内侧车道
    if (pIVehicle->roadIsLink() && (pIVehicle->length(UnitOfMeasure::Metric) > 8)) 
    {
        int limitLaneNumber = pIVehicle->lane()->link()->laneCount();
        return QList<int>() << limitLaneNumber;
    }
    return QList<int>();
}
```

**QList\<ILaneConnector\*\> candIDateLaneConnectors(IVehicle\* pIVehicle，QList\<ILaneConnector\*\> lInLC)**

​	计算当车辆离开路段时后续可经过的车道连接，用户可以从可通行的车道连接序列中筛选或重新计算。如果车辆有路径，则忽略。

参数：

​	[ in ] pVehicle：车辆对象。

​	[ in ] lInLC：已计算出的当前车道可达的所有车道连接。

返回：

​	后续可达的车道连接序列。

**ILaneConnector\* candIDateLaneConnector(IVehicle\* pIVehicle，ILaneConnector\* pCurrLaneConnector)**

​	计算车辆后续要走的车道连接，此时车辆正跨出当前路段，将驶到pCurrLaneConnector上。此方法可以改变后续车道连接。如果返回的车道连接为空，TESSNG会忽略此方法的调用。如果返回的车道连接不在原有路径上，或者此方法设置了新路径且新路径不经过返回的车道连接，TESSNG调用此方法后会将路径设为空。

参数：

​	[ in ] pVehicle：车辆对象。

​	[ in ] pCurrLaneConnector：已计算出的当前车道要走的车道连接。

返回：

​	重新设置的车道连接。

**void beforeNextPoint(IVehicle\* pIVehicle，bool &keepOn)**

​	计算车辆移动到下一点前的操作，用户可以通过此方法让TESSNG放弃对指定车辆到下一点的计算。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ out ] keepOn：是否继续，如果keepOn赋值为false，TESSNG放弃移动到下一点的计算，但不移出路网。

**void beforeMergingToLane(IVehicle\* pIVehicle，bool &keepOn)**

​	在车道连接上汇入车道前的计算，可以让TESS NG放弃汇入计算，以便于用户实现自己的汇入逻辑。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ out ] keepOn：是否放弃，如果keepOn赋值为false，TESSNG放弃汇入。

**void beforeNextRoad(IVehicle\* pIVehicle，QGraphicsItem\*& pRoad，bool& keepOn)**

​	计算下一道路前的处理。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in ] pRoad：暂不使用的参数。

​	[ in, out ] keepOn：是否继续计算，如果keepOn赋值为false，TESSNG不再计算后续道路。

**void afterCalcTracingType(IVehicle\* pIVehicle)**

​	计算跟驰类型后的处理。

参数：

​	[ in ] pIVehicle：车辆对象。

**void busArriving(IVehicle\* pIVehicle，IBusStationLine\* pStationLine，int alightingCount，int alightingTime，int boardingCount，int boardingTime)**

​	公交到站后的处理。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in ] pStationLine：站点线路。

​	[ in ] alightingCount：下客人数。单位：人。

​	[ in ] alightingTime：下客所需总时间。单位：s。

​	[ in ] boardingCount：上客人数。单位：人。

​	[ in ] boardingTime：上客所需总时间。单位：s。

**void leaveForNextLaneObj(IVehicle\* pIVehicle, ILaneObject\* pCurrLaneObj, ILaneObject\* pNextLaneObj)**

​	车辆即将跨道路时调用。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in ] pCurrLaneObj：当前车道对象。

​	[ in ] pNextLaneObj：即将进入的车道对象。

**bool travelOnChangingTrace(IVehicle\* pIVehicle)**

​	车辆行驶在变道轨迹上时调用。

参数：

​	[ in ] pIVehicle：车辆对象。

**bool leaveOffChangingTrace(IVehicle\* pIVehicle, qreal differ, qreal& s)**

​	车辆驶出变道轨迹时调用。

参数：

​	[ in ] pIVehicle：车辆对象。

**bool isCalcVehicleVector3D()**

​	是否计算车辆3D属性，如欧拉角等。

返回：

​	如果返回true，表示需要计算车辆的3D属性。

**QVector3D calcVehicleEuler(IVehicle\* pIVehicle，bool bPosIDire = true)**

​	计算车辆的欧拉角。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in ] bPosIDire：车头方向是否正向计算，如果bPosIDire为false则反向计算。

返回：

​	车辆的欧拉角。

**QString vehiRunInfo(IVehicle\* pIVehicle)**

​	控制车辆运行状态弹窗中的文本框的文本信息。在仿真过程中选中某辆车，且按下Ctrl+i可弹窗车辆运行状态弹窗。

返回：

​	显示在车辆运行状态弹窗中的文本框的文本信息。

示例：

```cpp
QString MySimulator::vehiRunInfo(IVehicle* pIVehicle)
{
    return QString("车辆当前在ID=%1的道路上").arg(pIVehicle->roadId());
}
```

**bool boundingRect(IVehicle\* pIVehicle，QRectF& outRect) const**

​	获取车辆边界矩形。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ out ] outRect：车辆边界矩形。

**bool shape(IVehicle\* pIVehicle，QPainterPath& outShape) const**

​	获取车辆图形路径。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ out ] outShape：车辆形状路径。

**bool paintVehicle(IVehicle\* pIVehicle，QPainter\* painter)**

​	绘制车辆。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in ] painter：QPainter对象。

返回：	

​	如果返回true，TESSNG认为用户已经绘制车辆，TESSNG不再绘制车辆。

**bool paintVehicleWithRotation(IVehicle\* pIVehicle，QPainter\* painter，qreal& inOutRotation)**

​	绘制车辆，绘制前将车辆对象旋转指定角度。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in ] painter：QPainter对象。

​	[ in ] inOutRotation：旋转的角度。单位：度。

返回：

​	如果返回true，TESSNG认为用户已经绘制车辆，TESSNG不再绘制车辆。

**void rePaintVehicle(IVehicle\* pIVehicle，QPainter\* painter)**

​	添加TESSNG绘制车辆后的自定义绘制内容。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in ] painter：QPainter对象。

示例：

```cpp
void MySimulator::rePaintVehicle(Tessng::IVehicle* pIVehicle, QPainter* painter)
{
    // 在车身上添加车辆名称标签
    QString label = pIVehicle->name();

    // 创建QFont对象，设置字体和字号
    QFont font("Arial", 1);
    // 设置字体为非粗体
    font.setBold(false);

    // 创建QFontMetrics对象，获取字体度量信息
    QFontMetrics fontMetrics(font);
    // 获取文本的边界矩形
    QRect boundingRect = fontMetrics.boundingRect(label);
    // 计算文本位置
    qreal newX = -boundingRect.center().x() - pIVehicle->width() * 0.5;
    qreal newY = -boundingRect.center().y();
    QPointF position(newX, newY);

    // 创建QPainterPath对象绘制文本
    QPainterPath textPath;
    // 将文本添加到路径中
    textPath.addText(position, font, label);
    
    // 设置画笔缩放比例
    painter->scale(1, 1);
    // 填充路径绘制文本
    painter->fillPath(textPath, QColor("#c94f4f"));
}
```

#### 3.2.3.3.信号灯控制

**bool beforeCalcLampColor(bool& keepOn)**

​	用于实现计算信号灯色前的自定义操作。

参数：

​	[ in, out ] 是否继续计算。

返回：	

​	如果返回true，且keepOn被赋值为false，则TESSNG不再计算信号灯色。

**bool calcLampColor(ISignalLamp\* pSignalLamp)**

​	计算信号灯的灯色。

参数：

​	[ in ] pSignalLamp：信号灯对象。

返回：

​	如果返回true，表明用户已修改了信号灯颜色，TESS NG不再计算灯色。

示例：

```cpp
bool MySimulator::calcLampColor(ISignalLamp* pSignalLamp) 
{
    // 若信号灯ID为1，则设为绿色
	if (pSignalLamp->id() == 1) 
    {
		pSignalLamp->setLampColor("G");
		return true;
	}
	return false;
}
```

#### 3.2.3.4.其他

**void beforeCreateGVehiclesForBusLine(IBusLine\* pBusLine，bool& keepOn)**

​	用于实现创建公交车辆前的自定义操作。

参数：

​	[ in ] pBusLine：公交线路。

​	[ in, out ] keepOn：是否继续执行创建公交车辆。

返回：

​	如果返回true，且keepOn被赋值为false，则TESSNG不再创建公交车辆。

**QList\<Online::DecipointFlowRatioByInterval\> calcDynaFlowRatioParameters()**

​	计算动态流量分配信息。

返回：

​	决策点流量分配信息序列。

示例：

```cpp
QList<Online::DecipointFlowRatioByInterval> MySimulator::calcDynaFlowRatioParameters()
{
	QList<Online::DecipointFlowRatioByInterval> lDecipointFLowRatioByInterval;
	// 当前仿真计算批次
	long batchNumber = simuiface->batchNumber();
	// 在计算第20批次时修改某决策点各路径流量比
	if (batchNumber == 20)
	{
		// 一个决策点某个时段各路径车辆分配比
		Online::DecipointFlowRatioByInterval dfi = Online::DecipointFlowRatioByInterval();
		// 决策点编号
		dfi.deciPointID = 1;
		// 起始时间 单位：秒
		dfi.startDateTime = 1;
		// 结束时间 单位：秒
		dfi.endDateTime = 999999;
		// 路径流量比
		Online::RoutingFlowRatio rfr1 = Online::RoutingFlowRatio(1, 3);
		Online::RoutingFlowRatio rfr2 = Online::RoutingFlowRatio(2, 4);
		Online::RoutingFlowRatio rfr3 = Online::RoutingFlowRatio(3, 3);
		dfi.mlRoutingFlowRatio << rfr1;
		dfi.mlRoutingFlowRatio << rfr2;
		dfi.mlRoutingFlowRatio << rfr3;
		lDecipointFLowRatioByInterval << dfi;
	}
	return lDecipointFLowRatioByInterval;
}
```

**QList\<Online::DispatchInterval\> calcDynaDispatchParameters()**

​	计算动态发车信息。

返回：

​	动态发车信息序列。

示例：

```cpp
QList<Online::DispatchInterval> MySimulator::calcDynaDispatchParameters()
{
    // 发车点ID
	di.dispatchId = 1;
    // 开始时间，单位：s
	di.fromTime = 0;
    // 结束时间，单位：s
	di.toTime = 300;
    // 车辆数
	di.vehiCount = 300;
    // 车辆组成列表
	di.mlVehicleConsDetail << Online::VehiComposition(1, 60) << Online::VehiComposition(2, 40);
    QList<Online::DispatchInterval> lDispatchInterval;
	lDispatchInterval << di;
	return lDispatchInterval;
}
```



## 3.3.接口

​	与侧重 “流程扩展与逻辑干预”的插件不同，接口聚焦于**“数据交互与状态调控”**，其包含顶级接口TessInterface ，以及NetInterface、SimuInterface、GuiInterface三个子接口，为用户提供了路网、仿真、窗体三类核心信息的获取与设置能力，用户可通过它直接读取路网的拓扑结构、仿真的实时参数（如时间步长、车辆总数）、窗体的显示配置（如尺寸、视图缩放比例），也能主动修改这些信息以调整系统基础状态。

​	顶级接口对象具备全局变量的特性，可在代码的任意位置进行实例化。不过，从代码可维护性与使用便捷性的角度出发，我们更建议在**构造函数**中完成各接口的初始化操作，例如：

```cpp
// MySimulator.h
class MySimulator : public QObject, public CustomerSimulator
{
private:
	// 代表TESS NG 的路网子接口
	NetInterface* netiface;
	// 代表TESS NG 的仿真子接口
	SimuInterface* simuiface;
    // 代表TESS NG 的界面子接口
    GuiInterface* guiInterface;
}

// MySimulator.cpp
MySimulator::MySimulator()
{
	netiface = gpTessInterface->netiface();
	simuiface = gpTessInterface->simuiface();
    guiInterface = gpTessInterface->guiInterface();
}
```

### 3.3.1.顶级接口（TessInterface）

​	头文件：tessinterface.h

​	TessInterface 是TESSN对外暴露的顶级接口，下面有三个子接口：NetInterface、SimuInterface、GuiInterface，分别用于访问或控制路网、仿真过程和用户交互界面。

**QJsonObject config()**

​	获取json对象，其中保存了config.json配置文件中的信息，每次加载路网时会重新加载配置信息。

**void setConfigProperty(QString key，QVariant value)**

​	设置配置属性。

**bool loadPluginFromMem()**

​	加载插件。

**void releasePlugins()**

​	卸载插件。

**NetInterface\* netiface()**

​	返回用于访问控制路网的接口NetInterface。

示例：

```cpp
netiface = gpTessInterface->netiface();
```

**SimuInterface\* simuiface()**

​	返回用于控制仿真过程的接口SimuInterface。

示例：

```cpp
simuiface = gpTessInterface->simuiface();
```

**GuiInterface\* guiInterface()**

​	返回用于访问控制用户介面的接口GuiInterface。

示例：

```cpp
guiInterface = gpTessInterface->guiInterface();
```

### 3.3.2.路网接口（NetInterface）

​	头文件：netinterface.h

​	NetInterface是TessInterface的子接口，用于访问、控制路网元素的接口，通过这个接口可以对路段和连接段等路网元素进行查询、创建、删除和更改。

#### 3.3.2.1.路网

**QString netFilePath()**

​	获取路网文件全路径名，如果是专业数据保存的路网，返回的是路网ID。

示例：

```cpp
QString netFilePath = netiface->netFilePath();
```

**void saveRoadNet()**

​	保存当前路网文件。

**void openNetFle(QString filePath)**

​	打开路网文件。

参数：

​	[ in ] filePath：路网文件全路径名。

**bool createEmptyNetFile(QString filePath，long dbver = 5)**

​	创建空白路网。

参数：

​	[ in ] filePath：空白路网全路径名。

​	[ in ] dbver：数据库版本。

**void openNetByNetId(long netId)**

​	从专业数据库加载路网。

**IRoadNet\* netAttrs()**

​	获取路网属性对象。

**IRoadNet\* roadNet()**

​	获取路网属性对象。同netAttrs。

**IRoadNet\* setNetAttrs (QString name，QString sourceType = QString("TESSNG")，QPointF centerPoint = QPointF()，QString backgroundUrl = QString()，QJsonObject otherAttrsJson = QJsonObject())**

​	设置路网基本信息。

参数：

​	[ in ] name：路网名称。

​	[ in ] sourceType：数据来源分类，默认为 "TESSNG"，表示路网由TESSNG软件直接创建。取值"OPENDRIVE"，表示路网是经过opendrive路网导入而来。

​	[ in ] centerPoint：中心点坐标所在路网，默认为(0，0)，用户也可以将中心点坐标保存到otherAttrsJson字段里。

​	[ in ] backgroundUrl：底图路径。

​	[ in ] otherAttrsJson：保存在json对象中的其它属性，如大地坐标等信息。

返回：

​	路网属性对象。

**QGraphicsScene\* graphicsScene()**

​	获取场景对象。

**QGraphicsView\* graphicsView()**

​	获取视图对象。

**qreal sceneScale()**

​	获取场景中的像素比。单位：m/像素。

**qreal sceneWidth(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取场景宽度。单位：像素。

**qreal sceneHeigth(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取场景高度。单位：像素。

**QByteArray backgroundMap()**

​	获取背景图字节。

**QRectF boundingRect()**

​	获取路网边界。

**long getIDByItemName(QString name)**

​	通过路网元素名获取自增ID。

参数：

​	[ in ] name：路网元素名。

**bool initSequence(QString schemaName = QString())**

​	初始化数据库序列，对保存路网的专业数据库序列进行初始化，目前支持PostgreSql。

参数：

​	[ in ] schemaName：数据库的schema名称。

#### 3.3.2.2.道路

**QList\<ISection\*\> sections()**

​	获取所有道路。

#### 3.3.2.3.路段

**int linkCount()**

​	获取路段数。

**QList\<long\> linkIds()**

​	获取路段路段ID序列。

**QList\<ILink\*\> links()**

​	获取路段对象序列。

示例：

```cpp
for (auto link : netiface->links()) 
{
    qDebug() << link->id();
}
```

**ILink\* findLink(long id)**

​	通过路段ID获取路段对象。

**QList\<QPointF\> linkCenterPoints(long linkID，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取指定路段中心线断点序列。单位：像素。

参数：

​	[ in ] linkID：指定路段ID。

**ILink\* createLink(QList\<QPointF\> lCenterPoint，int laneCount，QString linkName = QString()，bool bAddToScene = true，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	创建路段。单位：像素。

参数：

​	[ in ] lCenterPoint：路段中心线断点序列。

​	[ in ] laneCount：车道数。

​	[ in ] linkName：路段名称。

​	[ in ] bAddToScene：是否添加到场景。

返回：

​	路段对象。

示例：

```cpp
QList<QPointF> linkPoints2D = {QPointF(-300, 0), QPointF(300, 0)};
ILink* link = netiface->createLink(linkPoints2D, 7, "曹安公路", true, UnitOfMeasure::Metric);
```

**ILink\* createLink3D(QList\<QVector3D\> lCenterV3，int laneCount，QString linkName = QString()，bool bAddToScene = true，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	创建3D路段。单位：像素。

参数：

​	[ in ] lCenterV3：路段中心线三维断点集。

​	[ in ] laneCount：车道数。

​	[ in ] linkName：路段名称。

​	[ in ] bAddToScene：是否添加到场景。

​	[ in ] unit：单位参数，默认为Default，Metric表示米制单位，Default表示无单位限制。

返回：

​	路段对象。

示例：

```cpp
QList<QVector3D> linkPoints3D = {QVector3D(-300, 0, 10), QVector3D(300, 0, 20)};
ILink* link = netiface->createLink3D(linkPoints3D, 7, "曹安公路", true, UnitOfMeasure::Metric);
```

**ILink\* createLinkWithLaneWidth(QList\<QPointF\> lCenterPoint，QList\<qreal\> lLaneWidth，QString linkName = QString()，bool bAddToScene = true，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	创建指定车道宽度的路段。单位：像素。

参数：

​	[ in ] lCenterPoint：路段中心线断点序列。

​	[ in ] lLaneWidth：车道宽度列表。

​	[ in ] linkName：路段名称。

​	[ in ] bAddToScene：是否添加到场景。

返回：

​	路段对象。

示例：

```cpp
QList<QPointF> linkPointsWithWidth = {QPointF(-300, 0), QPointF(300, 0)};
QList<double> laneWidthList = {1, 3.5, 3.5, 3.5};
ILink* link = netiface->createLinkWithLaneWidth(linkPointsWithWidth, laneWidthList, "曹安公路", true, UnitOfMeasure::Metric);
```

**ILink\* createLink3DWithLaneWidth(QList\<QVector3D\> lCenterV3，QList\<qreal\> lLaneWidth，QString linkName = QString()，bool bAddToScene = true，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	创建指定车道宽度的3D路段。单位：像素。

参数：

​	[ in ] lCenterV3：路段中心线三维断点序列。

​	[ in ] lLaneWidth：车道宽度列表。

​	[ in ] linkName：路段名称。

​	[ in ] bAddToScene：是否添加到场景。

返回：

​	路段对象。

示例：

```cpp
QList<QVector3D> linkPoints3DWithWidth = {QVector3D(-300, 0, 10), QVector3D(300, 0, 20)};
ILink* link = netiface->createLink3DWithLaneWidth(linkPoints3DWithWidth, laneWidthList, "曹安公路", true, UnitOfMeasure::Metric);
```

**ILink\* createLink3DWithLanePoints(QList\<QVector3D\> lCenterLineV3，QList<\QMap\<QString, QList\<QVector3D\>\>\> lanesWithPoints，QString linkName = QString()，bool bAddToScene = true，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	创建指定车道断点的3D路段。单位：像素。

参数：

​	[ in ] lCenterLineV3：路段中心线三维断点序列。

​	[ in ] lanesWithPoints：车道点集的集合。

​	[ in ] linkName：路段名称。

​	[ in ] bAddToScene：是否添加到场景。

返回：

​	路段对象。

示例：

```cpp
// 路段中心线
QList<QVector3D> linkPoints = {QVector3D(-300, 0, 10), QVector3D(300, 0, 20)};

// 各车道的左中右线
QList<QMap<QString, QList<QVector3D>>> lanesPoints = {
    {
        {"left", {QVector3D(-300, 0, 10), QVector3D(300, 0, 20)}},
        {"center", {QVector3D(-300, 1.75, 10), QVector3D(300, 1.75, 20)}},
        {"right", {QVector3D(-300, 3.5, 10), QVector3D(300, 3.5, 20)}}
    },
    {
        {"left", {QVector3D(-300, -3.5, 10), QVector3D(300, -3.5, 20)}},
        {"center", {QVector3D(-300, -1.75, 10), QVector3D(300, -1.75, 20)}},
        {"right", {QVector3D(-300, 0, 10), QVector3D(300, 0, 20)}}
    }
};
    
ILink* link = netiface->createLink3DWithLanePoints(linkPoints, lanesPoints, "曹安公路", true, UnitOfMeasure::Metric);
```

**ILink\* createLink3DWithLanePointsAndAttrs(QList\<QVector3D\> lCenterLineV3，QList\<QMap\<QString, QList\<QVector3D\>\>\> lanesWithPoints，QList\<QString\> lLaneType，QList\<QJsonObject\> lAttr，QString linkName = QString()，bool bAddToScene = true，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	创建指定车道断点和属性的3D路段。单位：像素。

参数：

​	[ in ] lCenterLineV3：路段中心线三维断点序列。

​	[ in ] lanesWithPoints：车道点集的集合。

​	[ in ] lLaneType：车道类型序列。

​	[ in ] lAttr：车道附加属性序列。

​	[ in ] linkName：路段名称。

​	[ in ] bAddToScene：是否添加到场景。

返回：

​	路段对象。

**void removeLink(ILink\* pLink)**

​	移除路段。

参数：

​	[ in ] pLink：路段对象。

示例：

```cpp
// 移除ID为1的路段
link = netiface->findLink(1);
netiface->removeLink(link);
```

**ILink\* updateLink(\_Link link，QList\<\_Lane\> lLane = QList\<\_Lane\>()，QList\<QPointF\> lPoint = QList\<QPointF\>()，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	更新路段。单位：像素。

参数：

​	[ in ] link：路段基本信息。

​	[ in ] lLane：车道列表。

​	[ in ] lPoint：断点列表。

返回：

​	更新后的路段对象。

**void moveLinks(QList\<ILink\*\> lLink，QPointF offset，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	移动路段及相关连接段。单位：像素。

参数：

​	[ in ] lLink：路段对象序列。

​	[ in ] offset：偏移量。

示例：

```cpp
// 获取所有路段
QList<ILink*> links = netiface->links();
// 移动所有路段
netiface->moveLinks(links, QPointF(100, 100));
```

**bool judgeLinkToCross(long linkId)**

​	判断路段下游是否进入交叉口，以面域是否存在多连接段，以及当前路段与后续路段之间的角度为依据。

参数：

​	[ in ] linkID：路段ID。

返回：

​	路段下游是否进入交叉口。

#### 3.3.2.4.车道

**ILane\* findLane(long id)**

​	通过车道ID获取车道对象。

**QList\<QPointF\> laneCenterPoints(long laneID，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取指定ID的车道中心线断点序列。单位：像素。

参数：

​	[ in ] laneID：车道ID。

返回：

​	指定车道的中心线断点序列。

#### 3.3.2.5.连接段

**int connectorCount()**

​	获取连接段数。

**QList\<long\> connectorIds()**

​	获取连接段ID序列。

**QList\<IConnector\*\> connectors()**

​	获取连接段对象序列。

**IConnector\* findConnector(long id)**

​	通过连接段ID获取连接段对象。

**IConnector\* findConnectorByLinkIds(long fromLinkID，long toLinkId)**

​	通过上游路段ID和下游路段ID获取连接段对象。

**IConnector\* createConnector(long fromLinkID，long toLinkID，QList\<int\> lFromLaneNumber，QList\<int\> lToLaneNumber，QString connName = QString()，bool bAddToScene = true)**

​	创建连接段。

参数：

​	[ in ] fromLinkID：上游路段ID。

​	[ in ] toLinkID：下游路段ID。

​	[ in ] lFromLaneNumber：上游路段车道序号序列。

​	[ in ] LToLaneNumber：下游车道序号序列。

​	[ in ] connName：连接段名，默认为空，将以两条路段的ID连接起来作为名称。

​	[ in ] bAddToScene：创建后是否放入路网场景，默认为true。

返回：

​	连接段对象。

示例：

```cpp
// 创建连接路段1和路段2的连接段
QList<int> fromLaneNumbers = {1, 2, 3};
QList<int> toLaneNumbers = {1, 2, 3};
IConnector* connector = netiface->createConnector(1，2，lFromLaneNumber，lToLaneNumber，"连接段1")；
}
```

**IConnector\* createConnector3DWithPoints(long fromLinkID，long toLinkID，QList\<int\> lFromLaneNumber，QList\<int\> lToLaneNumber，QList\<QMap\<QString, QList\<QVector3D\>\>\> laneConnectorWithPoints，QString connName = QString()，bool bAddToScene = true，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	创建指定断点的3D连接段。单位：像素。

参数：

​	[ in ] fromLinkID：上游路段ID。

​	[ in ] toLinkID：下游路段ID。

​	[ in ] lFromLaneNumber：上游路段车道序号列表。

​	[ in ] lToLaneNumber：下游路段车道序号列表。

​	[ in ] laneConnectorWithPoints：车道连接点集的集合。

​	[ in ] connName：连接段名称。

​	[ in ] bAddToScene：是否添加到场景。

返回：

​	连接段对象。

**void removeConnector(IConnector\* pConnector)**

​	移除连接段。

参数：

​	[ in ] pConnector：连接段对象。

**IConnector\* updateConnector(\_Connector connector)**

​	更新连接段。单位：像素。

参数：

​	[ in ] connector：连接段基本信息。

返回：

​	连接段对象。

#### 3.3.2.6.车道连接

**ILaneConnector\* findLaneConnector(long id)**

​	通过车道连接ID获取车道连接对象。

**ILaneConnector\* findLaneConnector(long fromLaneID，long toLaneId)**

​	通过上游车道ID和下游车道ID获取车道连接对象。

**QList\<Online::CrossPoint\> crossPoints(ILaneConnector\* pLaneConnector)**

​	当前车道连接穿过其它车道连接形成的交叉点序列。

参数：

​	[ in ] pLaneConnector：车道连接对象。

返回：

​	交叉点序列。

#### 3.3.2.7.连接段面域

**QList\<IConnectorArea\*\> allConnectorArea()**

​	获取所有连接段面域对象序列。

**IConnectorArea\* findConnectorArea(long id)**

​	通过面域ID获取面域对象。

#### 3.3.2.8.路网网格

**void buildNetGrid(qreal width，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	路网网格化。

参数：

​	[ in ] width：单元格宽度。单位：像素。

**QList\<ISection\*\> findSectionOn1Cell(QPointF point，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	通过point获取所在单元格所有道路。

参数：

​	[ in ] point：获取点坐标。单位：像素。

返回：

​	道路对象序列。

**QList\<ISection\*\> findSectionOn4Cell(QPointF point，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	通过point获取最近4个单元格所有道路。

参数：

​	[ in ] point：获取点坐标。单位：像素。

返回：

​	道路对象序列。

**QList\<ISection\*\> findSectionOn9Cell(QPointF point，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	通过point获取最近9个单元格所有道路。

参数：

​	[ in ] point：获取点坐标。单位：像素。

返回：

​	道路对象序列。

**QList\<Online::Location\> locateOnCrid(QPointF point，int cellCount = 1，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	point周围若干个单元格里获取车道基类对象。

参数：

​	[ in ] point：获取点坐标。单位：像素。

​	[ in ] cellCount：单元格数，小于1时默认为1，大于1小于4时默认为4，大于4时默认为9。

返回：	

​	定位信息序列，按最短距离从小到大排序。

示例：

```cpp
// 目标点
QPointF targetPoint(50, 50);
// 将目标点投影到附近一定范围内的车道上，获取定位信息序列
QList<Online::Location> locations = netiface->locateOnCrid(targetPoint, 9, UnitOfMeasure::Metric);  // 使用前需要先执行netiface->buildNetGrid(10);
for (auto location: locations) 
{
    qDebug() << "车道/车道连接ID为：" << location.pLaneObject->id();
    qDebug() << "投影点为：(" << location.point.x() << ", " << location.point.y() << ")";
    qDebug() << "目标点与投影点的间距为：" << location.leastDist << " m";
    qDebug() << "投影点与车道起点的间距为：" << location.distToStart << " m";
    qDebug() << "投影点在所在车道的分段序号为：" << location.segmIndex;
}
```

**QList\<Online::Location\> locateOnSections(QPointF point，QList\<ISection\*\> lSection，qreal referDistance = 0，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	通过point对道路列表中每一个道路所有车道求最短距离。

参数：

​	[ in ] point：获取点坐标。单位：像素。

​	[ in ] lSection：道路列表。

​	[ in ] referDistance：LaneObject上与point最近的点到LaneObject起点距离，只为提高计算效率，默认值为0。

返回：

​	定位信息序列，按最短距离从小到大排序。

#### 3.3.2.9.车型

**bool createVehicleType(\_VehicleType \_vt)**

​	创建车型。

参数：

​	[ in ] vt：车辆类型数据。需要指定与现有车型不同的车型名称，否则会创建失败。新创建车型的编码将自动设置为当前最大编码值加 1。

返回：

​	是否创建成功。

示例：

```cpp
// 构建参数
_VehicleType vehicleType = _VehicleType();
vehicleType.vehicleTypeName = "新建车型1";  // 车型名称
vehicleType.Length = 4.5;  // 长度，单位：m
vehicleType.lengthSD = 0.5;  // 长度标准差，单位：m
vehicleType.width = 2;  // 宽度，单位：m
vehicleType.widthSD = 0.2;  // 宽度标准差，单位：m
vehicleType.avgSpeed = 60;  // 期望速度，单位：km/h
vehicleType.speedSD = 10;  // 期望速度标准差，单位：km/h
vehicleType.avgAcce = 4;  // 期望加速度，单位：m/s²
vehicleType.acceSD = 0.5;  // 期望加速度标准差，单位：m/s²
vehicleType.avgDece = 6;  // 期望减速度，单位：m/s²
vehicleType.deceSD = 0.5;  // 期望减速度标准差，单位：m/s²
vehicleType.maxAcce = 5.5;  // 最大加速度，单位：m/s²
vehicleType.maxDece = 7.5;  // 最大减速度，单位：m/s²
vehicleType.maxSpeed = 80;  // 最大速度，单位：km/h
vehicleType.commercialVehicle = false;  // 是否是营运车辆
vehicleType.maxPassengerCapacity = 1;  // 核载人数，单位：人
// 创建车型
bool result = netiface->createVehicleType(vehicleType);
qDebug() << "创建车型是否成功：" << result;
```

#### 3.3.2.10.车辆组成

**long createVehicleComposition(QString name，QList\<Online::VehicleComposition\> lVehiComp)**

​	创建车型组成。

参数：

​	[ in ] name：车型组成名。

​	[ in ] lVehiComp：不同车型占比序列。

返回：

​	车型组成ID，但如果车型组成名已存在或相关车型编码不存在或相关车型占比小于0则返回-1。

示例：

```cpp
// 构建车辆类型比例列表
QList<Online::VehiComposition> vehiTypeProportionList = {
    Online::VehiComposition(1, 0.3),  // 小客车，占比0.3
    Online::VehiComposition(2, 0.2),  // 大客车，占比0.2
    Online::VehiComposition(3, 0.1),  // 公交车，占比0.1
    Online::VehiComposition(4, 0.4)   // 货车，占比0.4
};

// 创建车辆组成
int vehiCompositionId = netiface->createVehicleComposition("动态创建车型组成", vehiTypeProportionList);
```

**bool removeVehicleComposition(long vehiCompId)**

​	移除车型组成。

参数：

​	[ in ] vehiCompID：车型组成ID。

#### 3.3.2.11.发车点

**QList\<IDispatchPoint\*\> dispatchPoints()**

​	获取所有发车点序列。

**IDispatchPoint\* findDispatchPoint(long id)**

​	通过发车点ID获取发车点。

**IDispatchPoint\* createDispatchPoint(ILink\* pLink，QString dpName = QString()，bool bAddToScene = true)**

​	创建发车点。

参数：

​	[ in ] pLink：路段，在其上创建发车点。

​	[ in ] dpName：发车点名称，默认为空，将以发车点ID作为名称。

​	[ in ] bAddToScene：创建后是否放入路网场景，默认为true。

示例：

```cpp
// 获取路段对象
ILink* link = netiface->findLink(1);
// 创建发车点
IDispatchPoint* dp = netiface->createDispatchPoint(link);
if (dp)
{
    // 添加发车间隔，含车型组成、时间间隔、发车数
    dp->addDispatchInterval(1, 600, 300);
    dp->addDispatchInterval(1, 600, 400);
}
```

**bool removeDispatchPoint(IDispatchPoint\* pDispPoint)**

​	移除发车点。

参数：

​	[ in ] pDispPoint：发车点对象。

#### 3.3.2.12.决策点

**QList< IDecisionPoint\* > decisionPoints()**

​	获取所有决策点序列。

**IDecisionPoint\* findDecisionPoint(long id)**

​	通过决策点ID获取决策点。

**IDecisionPoint\* createDecisionPoint(ILink\* pLink，qreal distance，QString name = QString()，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	创建决策点。

参数：

​	[ in ] pLink：决策点所在的路段。

​	[ in ] distance：决策点距离路段起点的距离。单位：像素。

​	[ in ] name：决策点的名称。

返回：

​	决策点对象。

示例：

```cpp
ILink* link = netiface->findLink(1);
qreal location = 50;
QString decisionPointName = "新建决策点";
IDecisionPoint* decisionPoint = netiface->createDecisionPoint(link, location, decisionPointName, UnitOfMeasure::Metric);
```

**IDecisionPoint\* updateDecipointPoint(\_DecisionPoint deciPoint，QList\<\_RoutingFLowRatio\> lFlowRatio = QList\<\_RoutingFLowRatio\>())**

​	更新决策点及其各路径不同时间段流量比。

参数：

​	[ in ] deciPoint：决策点数据。

​	[ in ] lFlowRatio：各路径按时间段流量比的数据集合。


返回：

​	决策点对象。

示例：

```cpp
// 初始化左、直、右流量比对象
_RoutingFLowRatio flowRatioLeft;
flowRatioLeft.RoutingFLowRatioID = 1;
flowRatioLeft.routingID = decisionRouting1->id();
flowRatioLeft.startDateTime = 0;
flowRatioLeft.endDateTime = 999999;
flowRatioLeft.ratio = 2.0;

_RoutingFLowRatio flowRatioStraight;
flowRatioStraight.RoutingFLowRatioID = 2;
flowRatioStraight.routingID = decisionRouting2->id();
flowRatioStraight.startDateTime = 0;
flowRatioStraight.endDateTime = 999999;
flowRatioStraight.ratio = 3.0;

_RoutingFLowRatio flowRatioRight;
flowRatioRight.RoutingFLowRatioID = 3;
flowRatioRight.routingID = decisionRouting3->id();
flowRatioRight.startDateTime = 0;
flowRatioRight.endDateTime = 999999;
flowRatioRight.ratio = 1.0;

// 初始化决策点数据
_DecisionPoint decisionPointData;
decisionPointData.deciPointID = decisionPoint->id();
decisionPointData.deciPointName = decisionPoint->name();
QPointF decisionPointPos;
if (decisionPoint->link()->getPointByDist (decisionPoint->distance(), decisionPointPos)) 
{
    decisionPointData.X = decisionPointPos.x();
    decisionPointData.Y = decisionPointPos.y();
    decisionPointData.Z = decisionPoint->link()->z();
}

// 构造流量比列表
QList<_RoutingFLowRatio> flowRatioList = {flowRatioLeft, flowRatioStraight, flowRatioRight};

// 更新决策点的路径流量比配置
IDecisionPoint* updatedDecisionPoint = netiface->updateDecipointPoint(decisionPointData, flowRatioList);
```

#### 3.3.2.13.车辆路径

**IRouting\* findRouting(long id)**

​	通过路径ID获取路径对象。

**IRouting\* createRouting(QList\<ILink\*\> lILink)**

​	创建路径，不与决策点绑定。

参数：

​	[ in ] lILink：路段对象序列，需要是不间断的。

返回：

​	路径对象。

示例：

```cpp
// 路段ID列表
QList<int> linkIdList = {1, 2, 3, 4};
// 构建路段对象列表
QList<Link*> linkList;
for (int linkId : linkIdList) {
    linkList.append(netiface->findLink(linkId));
}
// 创建车辆路径
IRouting* routing = netiface->createRouting(linkList);
```

**IRouting\* createDeciRouting(IDecisionPoint\* pDeciPoint，QList\<ILink\*\> lILink)**

​	为决策点添加车辆路径。

参数：

​	[ in ] pDeciPoint：决策点对象。

​	[ in ] lILink：路段对象序列，需要从决策点所在路段开始，且是不间断的。

返回：

​	路径对象。

**bool removeDeciRouting(IDecisionPoint\* pDeciPoint，IRouting\* pRouting)**

​	移除决策点的车辆路径。

参数：

​	[ in ] pDeciPoint：决策点对象。

​	[ in ] pRouting：路径对象。

返回：

​	是否移除成功。

**IRouting\* shortestRouting(ILink\* pFromLink，ILink\* pToLink)**

​	计算两路段之间的最短路径。

参数：

​	[ in ] pFromLink：起始路段。

​	[ in ] pToLink：目标路段。

返回：	

​	路径对象。

#### 3.3.2.14.信号机

**int signalControllerCount()**

​	获取信号机数量。

**QList\<long\> signalControllerIds()**

​	获取信号机ID序列。

**QList\<ISignalController\*\> signalControllers()**

​	获取所有信号机对象序列。

**ISignalController\* findSignalControllerById(long id)**

​	通过ID获取信号机对象。

**ISignalController\* findSignalControllerByName(QString name)**

​	通过名称获取信号机对象，如果同名返回第一个。

**ISignalController\* createSignalController(QString name)**

​	创建信号机。

参数：

​	[ in ] name：信号机名称。

返回：

​	信号机对象。

示例：

```cpp
// 信号机名称
QString signalControllerName = "双龙大道-吉印大道交叉口";
// 创建信号机
ISignalController* signalController = netiface->createSignalController(signalControllerName);
```

#### 3.3.2.15.信号控制方案

**int signalPlanCount()**

​	获取信控方案组数。

**QList\<long\> signalPlanIds()**

​	获取信控方案ID序列。

**QList\<ISignalPlan\*\> signalPlans()**

​	获取信控方案对象序列。

**ISignalPlan\* findSignalPlanById(long id)**

​	通过ID获取信控方案对象。

**ISignalPlan\* findSignalPlanByName(QString name)**

​	通过名称获取信控方案对象。

**ISignalPlan\* createSignalPlan(ISignalController\* pITrafficLight，QString name，int cycle，int phasedifference，int startTime，int endTime)**

​	创建信控方案。

参数：

​	[ in ] pITrafficLight：信号机对象。

​	[ in ] name：方案名称。

​	[ in ] cycle：周期时长。

​	[ in ] phasedifference：相位差。

​	[ in ] startTime：起始时间。

​	[ in ] endTime：结束时间。

返回：

​	信控方案对象。

示例：

```cpp
// 获取信号机对象
ISignalController* signalController = netiface->findSignalControllerByID(1);
// 信控方案名称
QString signalPlanName = "平峰方案";
// 周期时长，单位：s
int cycleTime = 120;
// 相位差，单位：s
int phaseDifference = 0;
// 起始时间，单位：s
int startTime = 0;
// 结束时间，单位：s
int endTime = 3600;
// 创建信控方案
ISignalPlan* signalPlan = netiface->createSignalPlan(signalController, signalPlanName, cycleTime, phaseDifference, startTime, endTime);
```

#### 3.3.2.16.信号灯相位

**ISignalPhase\* findSignalPhase(long id)**

​	通过信号灯相位ID获取信号灯相位对象。

**ISignalPhase* createSignalPlanSignalPhase(ISignalPlan* SignalPlan, QString name, QList\<Online::ColorInterval\> lColor)**

创建信号灯相位。

参数：

​	[ in ] SignalPlan：信控方案对象。

​	[ in ] name：相位名称。

​	[ in ] lColor：灯色对象列表。

返回：

​	信号灯相位对象。

示例：

```cpp
// 获取信号配时方案
ISignalPlan* signalPlan = netiface->findSignalPlanByID(1);
// 相位名称
QString signalPhaseName = "东西直行";
// 构建灯色对象列表
QString<QString> colors = {"R", "G", "Y", "R"};
QList<int> intervals = {30, 26, 3, 61};
QList<Online::ColorInterval> colorIntervalList;
for (int i = 0; i < colors.size(); ++i) 
{
    colorIntervalList.append(Online::ColorInterval(colors[i], intervals[i]));
}
// 创建信号灯相位
ISignalPhase* signalPhase = netiface->createSignalPlanSignalPhase(signalPlan, signalPhaseName, colorIntervalList);
```

**void removeSignalPhase(ISignalPlan\* pPlan，long phaseId)**

​	移除已有信号灯相位，相位移除后，原相位序列自动重排。

参数：

​	[ in ] pPlan：信控方案对象。

​	[ in ] phaseID：将要移除的相位ID。

#### 3.3.2.17.信号灯灯头

**int signalLampCount()**

​	获取信号灯数。

**QList\<long\> signalLampIds()**

​	获取信号灯ID序列。

**QList\<ISignalLamp\*\> signalLamps()**

​	获取信号灯对象序列。

**ISignalLamp\* findSignalLamp(long id)**

​	通过信号灯ID获取信号灯对象。

**ISignalLamp\* createSignalLamp(ISignalPhase\* pPhase，QString name，long laneID，long toLaneID，qreal distance)**

​	创建信号灯。

参数：

​	[ in ] pPhase：相位对象。

​	[ in ] name：信号灯名称。

​	[ in ] laneID：信号灯所在车道ID，或所在车道连接上游车道ID。

​	[ in ] toLaneID：信号灯所在车道连接下游车道ID。

​	[ in ] distance：信号灯距车道或车道连接起点距离。单位：像素。

返回：

​	信号灯对象。

示例：

```cpp
// 获取相位对象
ISignalPhase* signalPhase = netiface->findSignalPhase(1);
// 信号灯名称
QString signalLampName = "东直1";
// 车道ID
long laneId = 1;
// 下游车道ID
long toLaneId = -1;
// 位置，单位：m
qreal distance = m2p(50);
// 创建信号灯
ISignalLamp* signalLamp = netiface->createSignalLamp(signalPhase, signalLampName, laneId, toLaneId, distance);
```

**ISignalLamp\* createTrafficSignalLamp(ISignalController\* pTrafficLight，QString name，long laneID，long toLaneID，qreal distance)**

​	创建信号灯。

参数：

​	[ in ] pTrafficLight：信号机。

​	[ in ] name：信号灯名称。

​	[ in ] laneID：信号灯所在车道ID，或所在车道连接上游车道ID。

​	[ in ] toLaneID：信号灯所在车道连接下游道ID。

​	[ in ] distance：信号灯距车道或车道连接起点距离。单位：像素。

返回：

​	信号灯对象。

**void addSignalPhaseToLamp(int SignalPhaseID，ISignalLamp\* signalLamp)**

​	信号灯添加绑定的相位。

参数：

​	[ in ] SignalPhaseID：信号相位ID。

​	[ in ] signalLamp：信号灯对象。

**void removeSignalPhaseFromLamp(int SignalPhaseID，ISignalLamp\* signalLamp)**

​	信号灯移除某个绑定的相位，如果相位列表只存在一个相位则将关联的相位设置为空。

参数：

​	[ in ] SignalPhaseID：信号相位ID。

​	[ in ] signalLamp：信号灯对象。

**void transferSignalPhase(ISignalPhase\* pFromISignalPhase，ISignalPhase\* pToISignalPhase，ISignalLamp\* signalLamp)**

​	信号灯更换绑定的相位，但不允许跨越信号机。

参数：

​	[ in ] pFromISignalPhase：原相位。

​	[ in ] pToISignalPhase：目标相位。

​	[ in ] signalLamp：信号灯对象。

#### 3.3.2.18.数据采集器

**QList\<IVehicleDrivInfoCollector\*\> vehiInfoCollectors()**

​	获取所有数据采集器对象序列。

**IVehicleDrivInfoCollector\* findVehiInfoCollector(long id)**

​	通过ID获取数据采集器对象。

**IVehicleDrivInfoCollector\* createVehiCollectorOnLink(ILane\* pLane，qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	在路段的车道上创建数据采集器。

参数：

​	[ in ] pLane：车道对象。

​	[ in ] dist：距车道起点距离。单位：像素。

返回：

​	数据采集器对象。

示例：

```cpp
// 获取车道对象
ILane* lane = netiface->findLane(1);
// 位置，单位：m
qreal dist = 50;
// 在路段上创建数据采集器
IVehicleDrivInfoCollector* collector = netiface->createVehiCollectorOnLink(lane, dist, UnitOfMeasure::Metric);
```

**IVehicleDrivInfoCollector\* createVehiCollectorOnConnector(ILaneConnector\* pLaneConnector，qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	在连接段的车道连接上创建数据采集器。

参数：

​	[ in ] pLaneConnector：车道连接对象。

​	[ in ] dist：距车道连接起点距离。单位：像素。

返回：

​	数据采集器对象。

示例：

```cpp
// 获取车道连接对象
ILaneConnector* laneConnector = netiface->findLaneConnector(1, 4);
// 位置，单位：m
qreal dist = 50;
// 在连接段上创建数据采集器
IVehicleDrivInfoCollector* collector = netiface->createVehiCollectorOnConnector(laneConnector, dist, UnitOfMeasure::Metric);
```

**bool removeVehiCollector(IVehicleDrivInfoCollector\* pCollector)**

​	移除车辆信息采集器。

参数：

​	[ in ] pCollector：车辆信息采集器对象。

返回：

​	是否移除成功。

#### 3.3.2.19.排队计数器

**QList\<IVehicleQueueCounter\*\> vehiQueueCounters()**

​	获取所有排队计数器对象序列。

**IVehicleQueueCounter\* findVehiQueueCounter(long id)**

​	通过ID获取排队计数器对象。

**IVehicleQueueCounter\* createVehiQueueCounterOnLink(ILane\* pLane，qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	在路段的车道上创建车辆排队计数器。

参数：

​	[ in ] pLane：车道对象。

​	[ in ] dist：距车道起点距离。单位：像素。

返回：

​	排队计数器对象。

示例：

```cpp
// 获取车道对象
ILane* lane = netiface->findLane(1);
// 位置，单位：m
qreal dist = 80;
// 在路段上创建排队计数器
IVehicleQueueCounter* counter = netiface->createVehiQueueCounterOnLink(lane, dist, UnitOfMeasure::Metric);
```

**IVehicleQueueCounter\* createVehiQueueCounterOnConnector(ILaneConnector\* pLaneConnector，qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	在连接段的车道连接上创建车辆排队计数器。

参数：

​	[ in ] pLaneConnector：车道连接对象。

​	[ in ] dist：距车道连接起点距离。单位：像素。

返回：

​	排队计数器对象。

示例：

```cpp
// 获取车道连接对象
laneConnector* = netiface->findLaneConnector(1, 4);
// 位置，单位：m
double dist = 80;
// 在连接段上创建排队计数器
IVehicleQueueCounter* counter = netiface->createVehiQueueCounterOnConnector(laneConnector, dist, UnitOfMeasure::Metric);
```

#### 3.3.2.20.行程时间检测器

**QList\<IVehicleTravelDetector\*\> vehiTravelDetectors()**

​	获取所有车辆行程时间检测器对象序列。

**IVehicleTravelDetector\* findVehiTravelDetector(long id)**

​	通过ID获取车辆行程时间检测器对象。

**QList\<IVehicleTravelDetector\*\> createVehicleTravelDetector_link2link(ILink\* pStartLink，ILink\* pEndLink，qreal dist1，qreal dist2，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	创建路段到路段的行程时间检测器。

参数：

​	[ in ] pStartLink：起始路段对象。

​	[ in ] pEndLink：终止路段对象。

​	[ in ] dist1：检测器起点距路段起始点距离。单位：像素。

​	[ in ] dist2：检测器终点距路段起始点距离。单位：像素。

示例：

```cpp
// 获取起始路段对象
ILink* startLink = netiface->findLink(1);
// 获取终止路段对象
ILink* endLink = netiface->findLink(2);
// 检测器起点在起始路段的位置，单位：m
qreal startDist = 10;
// 检测器终点在终止路段的位置，单位：m
qreal endDist = 90;
// 创建起点在路段、终点也在路段的行程时间检测器
QList<IVehicleTravelDetector*> detectors = netiface->createVehicleTravelDetector_link2link(startLink, endLink, startDist, endDist, UnitOfMeasure::Metric);
```

**QList\<IVehicleTravelDetector\*> createVehicleTravelDetector_link2conn(ILink\* pStartLink，ILaneConnector\* pEndLaneConnector，qreal dist1，qreal dist2，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	创建路段到连接段的行程时间检测器。

参数：

​	[ in ] pStartLink：起始路段对象。

​	[ in ] pEndLaneConnector：终止车道连接对象。

​	[ in ] dist1：检测器起点距路段起始点距离。单位：像素。

​	[ in ] dist2：检测器终点距车道连接起始点距离。单位：像素。

返回：

​	行程时间检测器对象。

示例：

```cpp
// 获取起始路段对象
ILink* startLink = netiface->findLink(1);
// 获取终止车道连接对象
ILaneConnector* endLaneConnector = netiface->findLaneConnector(1, 4);
// 检测器起点在起始路段的位置，单位：m
qreal startDist = 10;
// 检测器终点在终止车道连接的位置，单位：m
qreal endDist = 10;
// 创建起点在路段、终点在连接段的行程时间检测器
QList<IVehicleTravelDetector*> detectors = netiface->createVehicleTravelDetector_link2conn(startLink, endLaneConnector, startDist, endDist, UnitOfMeasure::Metric);
```

**QList\<IVehicleTravelDetector\*\> createVehicleTravelDetector_conn2link(ILaneConnector\* pStartLaneConnector，ILink\* pEndLink，qreal dist1，qreal dist2，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	创建连接段到路段的行程时间检测器。

参数：

​	[ in ] pStartLaneConnector：起始车道连接对象。

​	[ in ] pEndLink：终止路段对象。

​	[ in ] dist1：检测器起点距车道连接起始点距离。单位：像素。

​	[ in ] dist2：检测器终点距路段起始点距离。单位：像素。

返回：

​	行程时间检测器对象。

示例：

```cpp
// 获取起始车道连接对象
ILink* startLaneConnector = netiface->findLaneConnector(1, 4);
// 获取终止路段对象
ILaneConnector* endLink = netiface->findLink(2);
// 检测器起点在起始车道连接的位置，单位：m
qreal startDist = 10;
// 检测器终点在终止路段的位置，单位：m
qreal endDist = 90;
// 创建起点在连接段、终点在路段的行程时间检测器
QList<IVehicleTravelDetector*> detectors = netiface->createVehicleTravelDetector_conn2link(startLaneConnector, endLink, startDist, endDist, UnitOfMeasure::Metric);
```

**QList\<IVehicleTravelDetector\*\> createVehicleTravelDetector_conn2conn(ILaneConnector\* pStartLaneConnector，ILaneConnector\* pEndLaneConnector，qreal dist1，qreal dist2，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	创建连接段到连接段的行程时间检测器。

参数：

​	[ in ] pStartLaneConnector：起始车道连接对象。

​	[ in ] pEndLaneConnector：终止车道连接对象。

​	[ in ] dist1：检测器起点距车道连接起始点距离。单位：像素。

​	[ in ] dist2：检测器终点距车道连接起始点距离。单位：像素。

返回：

​	行程时间检测器对象。

示例：

```cpp
// 获取起始车道连接对象
ILaneConnector* startLaneConnector = netiface->findLaneConnector(1, 4);
// 获取终止路段对象
ILaneConnector* endLaneConnector = netiface->findLaneConnector(4, 7);
// 检测器起点在起始车道连接的位置，单位：m
qreal startDist = 10;
// 检测器终点在终止车道连接的位置，单位：m
qreal endDist = 90;
// 创建起点在连接段、终点也在连接段的行程时间检测器
QList<IVehicleTravelDetector*> detectors = netiface->createVehicleTravelDetector_conn2conn(startLaneConnector, endLaneConnector, startDist, endDist, UnitOfMeasure::Metric);
```

#### 3.3.2.21.导向箭头

**int guidArrowCount()**

​	获取导向箭头数。

**QList\<long\> guidArrowIds()**

​	获取导向箭头ID序列。

**QList\<IGuidArrow\*\> guidArrows()**

​	获取导向箭头对象序列。

**IGuidArrow\* findGuidArrow(long id)**

​	通过导向箭头ID获取导向箭头对象。

**IGuidArrow\* createGuidArrow(ILane\* pLane，qreal length，qreal distToTerminal，Online::GuideArrowType arrowType，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	创建导向箭头。

参数：

​	[ in ] pLane：车道对象。

​	[ in ] length：长度。单位：像素。

​	[ in ] distToTerminal：到车道终点距离。单位：像素。

​	[ in ] arrowType：箭头类型。

返回：

​	导向箭头对象。

示例：

```cpp
ILane* lane = netiface->findLane(4);
if (lane)
{
    qreal length = 4;
    qreal distToTerminal = 10;
    Online::GuideArrowType arrowType = Online::GuideArrowType::StraightRight;
	IGuidArrow* guidArrow = netiface->createGuidArrow(lane, length, distToTerminal, arrowType, UnitOfMeasure::Metric);
}
```

**void removeGuidArrow(IGuidArrow\* pArrow)**

​	移除导向箭头。

参数：

​	[ in ] pArrow：导向箭头对象。

#### 3.3.2.22.公交线路

**QList\<IBusLine\*\> buslines()**

​	获取公交线路对象序列。

**IBusLine\* findBusline(long buslineId)**

​	通过公交线路ID获取公交线路。

**IBusLine\* findBuslineByFirstLinkId(long linkId)**

​	通过公交线路起始路段ID获取公交线路。

**IBusLine\* createBusLine(QList\<ILink\*\> lLink)**

​	创建公交线路，lLink列表中相邻两路段可以是路网上相邻两路段，也可以不相邻，如果不相邻，TESSNG会在它们之间创建一条最短路径。如果lLink列表中相邻路段在路网上不相邻并且二者之间不存在最短路径，则相邻的第二条路段及后续路段无效。

参数：
	[ in ] lLink，公交线路经过的路段对象序列。

返回：

​	公交线路对象。

示例：

```cpp
ILink* link1 = netiface->findLink(1);
ILink* link2 = netiface->findLink(2);
QList<ILink*> links = {link1, link2};
IBusLine* busLine = netiface->createBusLine(links);
```

**bool removeBusLine(IBusLine\* pBusLine)**

​	移除公交线路。

参数：

​	[ in ] pBusLine：公交线路对象。

#### 3.3.2.23.公交站点

**QList\<IBusStation\*\> busStations()**

​	获取公交站点对象序列。

**IBusStation\* findBusStation(long stationId)**

​	通过公交站点ID获取公交站点对象。

**IBusStation\* createBusStation(ILane\* pLane，qreal length，qreal dist，QString name = QString()，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	创建公交站点。

参数：

​	[ in ] pLane：车道对象。

​	[ in ] length：站点长度。单位：像素。

​	[ in ] dist：站点起始点距车道起点距离。单位：像素。

​	[ in ] name：站点名称。	

返回：

​	公交站点对象。

示例：

```cpp
ILane* lane = netiface->findLane(1);
IBusStation* busStation = netiface->createBusStation(lane, 30, 50, "公交站1", UnitOfMeasure::Metric);
// 设置站点类型 1：路边式、2：港湾式
busStation.setType(1);
```

**bool removeBusStation(IBusStation\* pStation)**

​	移除公交站点。

参数：

​	[ in ] pStation：公交站点对象。

#### 3.3.2.24.公交线路-站点

**QList\<IBusStationLine\*\> findBusStationLineByStationId(long stationId)**

​	通过公交站点ID获取公交线路-站点对象。

**bool addBusStationToLine(IBusLine\* pBusLine，IBusStation\* pStation)**

​	将公交站点关联到公交线路上。

参数：

​	[ in ] pBusLine：公交线路对象。

​	[ in ] pStation：公交站点对象。

**bool removeBusStationFromLine(IBusLine\* pBusLine，IBusStation\* pStation)**

​	将公交站点与公交线路的关联关系解除。

参数：

​	[ in ] pBusLine：公交线路对象。

​	[ in ] pStation：公交站点对象。

#### 3.3.2.25.事故区

**QList\<IAccidentZone\*\> accidentZones()**

​	获取所有事故区对象。

**IAccidentZone\* findAccidentZone(long accidentZoneId)**

​	通过事故区ID获取事故区对象。

**IAccidentZone\* createAccidentZone(Online::DynaAccidentZoneParam param)**

​	创建事故区。

参数：

​	[ in ] param：动态事故区信息。

返回：

​	事故区对象。

示例：

```cpp
// 构建参数
Online::DynaAccidentZoneParam param;
// 事故区名称
param.name = "事故区";
// 道路ID
param.roadID = 1;
// 位置，距路段或连接段起点距离，单位：m
param.location = 100;
// 长度，单位：m
param.length = 50;
// 车道序号列表，从0开始，连续有序
param.mlFromLaneNumber.append(0);
// 开始时间，单位：s
param.startTime= 10
// 持续时间，单位：s
param.duration = 600
// 相邻车道限速，单位：km/h
param.limitSpeed = 40
// 创建事故区
IAccidentZone* accidentZone = netiface->createAccidentZone(param, UnitOfMeasure::Metric);
```

**void removeAccidentZone(IAccidentZone\* pIAccidentZone)**

​	移除事故区。

参数：

​	[ in ] pIAccidentZone：事故区对象。

#### 3.3.2.26.施工区

**QList\<IRoadWorkZone\*\> roadWorkZones()**

​	获取所有施工区对象序列。

**IRoadWorkZone\* findRoadWorkZone(long roadWorkZoneId)**

​	通过施工区ID获取施工区对象。

**IRoadWorkZone\* createRoadWorkZone(Online::DynaRoadWorkZoneParam param，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	创建施工区。

参数：

​	[ in ] param：施工区参数。单位：像素。

返回：

​	施工区对象。

示例：

```cpp
// 构建参数
Online::DynaRoadWorkZoneParam param;
// 施工区名称
param.name = "施工区";
// 道路ID
param.roadID = 1;
// 位置, 距离路段或连接段起点距离, 单位：m
param.location = 200;
// 长度, 单位：m
param.length = 50;  // 长度
param.upCautionLength = 70;  // 提前警示长度
param.upTransitionLength = 50;  // 过渡区长度
param.upBufferLength = 50;  // 缓冲区长度
param.downTransitionLength = 40;  // 下游过渡区长度
param.downTerminationLength = 40;  // 终止区长度
// 车道序号列表，从0开始，连续有序
param.mlFromLaneNumber.append(0);
// 开始时间，单位：s
param.startTime = 0;
// 持续时间，单位：s
param.duration = 3600;
// 相邻车道限速，单位：km/h
param.limitSpeed = 40;
// 创建施工区
IRoadWorkZone* roadWorkZone = netiface->createRoadWorkZone(param, UnitOfMeasure::Metric);
```

**void removeRoadWorkZone(IRoadWorkZone\* pIRoadWorkZone)**

​	移除施工区。

参数：

​	[ in ] pIRoadWorkZone：施工区对象。

**bool updateRoadWorkZone(Online::DynaRoadWorkZoneParam param，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	更新施工区。

参数：

​	[ in ] param：施工区参数。单位：像素。

#### 3.3.2.27.限行区

**QList\<ILimitedZone\*\> limitedZones()**

​	获取所有限行区对象序列。

**ILimitedZone\* findLimitedZone(long limitedZoneId)**

​	通过限行区ID获取限行区对象。

**ILimitedZone\* createLimitedZone(Online::DynaLimitedZoneParam param，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	创建限行区。

参数：

​	[ in ] param：限行区参数。单位：像素。

返回：

​	限行区对象。

示例：

```cpp
// 构建参数
Online::DynaLimitedZoneParam param;
// 限行区名称
param.name = "限行区";
// 道路ID
param.roadID = 1;
// 位置, 距离路段或连接段起点距离, 单位：m
param.location = 200;
// 长度, 单位：m
param.length = 50;
// 车道序号列表，从0开始，连续有序
param.mlFromLaneNumber.append(0);
// 开始时间，单位：s
param.startTime = 0;
// 持续时间，单位：s
param.duration = 3600;
// 相邻车道限速，单位：km/h
param.limitSpeed = 40;
// 创建限行区
ILimitedZone* limitedZone = netiface->createLimitedZone(param, UnitOfMeasure::Metric);
```

**void removeLimitedZone(ILimitedZone\* pILimitedZone)**

​	移除限行区。

参数：

​	[ in ] pILimitedZone：限行区对象。

**bool updateLimitedZone(Online::DynaLimitedZoneParam param，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	更新限行区。

参数：

​	[ in ] param：限行区参数。单位：像素。

#### 3.3.2.28.改扩建借道

**QList\<IReconstruction\*\> reconstructions()**

​	获取所有改扩建对象。

**IReconstruction\* findReconstruction(long reconstructionId)**

​	通过改扩建ID获取改扩建对象。

**IReconstruction\* createReconstruction(Online::DynaReconstructionParam param，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	创建改扩建。

参数：

​	[ in ] param：改扩建参数。单位：像素。

返回：

​	改扩建对象。

示例：

```cpp
// 构建参数
Online::DynaReconstructionParam param;
// 施工区ID
param.roadWorkZoneId = rwzId;
// 被借道的路段ID
param.beBorrowedLinkId = 2;
// 被借道的车道数量
param.borrowedNum = 1;
// 保通开口长度，单位：m
param.passagewayLength = 80;
// 保通开口限速，单位：m/s
param.passagewayLimitedSpeed = 40 / 3.6;
// 创建改扩建借道
IReconstruction* reconstruction = netiface->createReconstruction(param, UnitOfMeasure::Metric);
```

**void removeReconstruction(IReconstruction\* pIReconstruction)**

​	移除改扩建。

参数：

​	[ in ] pIReconstruction：改扩建对象。

**bool updateReconStruction(Online::DynaReconstructionParam param，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	更新改扩建。

参数：

​	[ in ] param：改扩建参数。单位：像素。

**qreal reCalcPassagewayLength(Online::DynaReconstructionParam param，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	重新计算保通开口长度，可通过保通详细参数计算出保通开口长度。

参数：

​	[ in ] param：改扩建参数。单位：像素。

返回：

​	保通开口长度。

#### 3.3.2.29.限速区

**QList\<IReduceSpeedArea\*\> reduceSpeedAreas()**

​	获取所有限速区对象序列。

**IReduceSpeedArea\* findReduceSpeedArea(long id)**

​	通过限速区ID获取限速区对象。

**IReduceSpeedArea\* createReduceSpeedArea(Online::DynaReduceSpeedAreaParam param)**

​	创建限速区。

参数：

​	[ in ] param：限速区参数。单位：像素。

返回：

​	限速区对象。

**void removeReduceSpeedAea(IReduceSpeedArea\* pIReduceSpeedArea)**

​	移除限速区。

参数：

​	[ in ] pIReduceSpeedArea：限速区对象。

**bool updateReduceSpeedArea(Online::DynaReduceSpeedAreaParam param)**

​	更新限速区。

参数：

​	[ in ] param：限速区参数。单位：像素。

#### 3.3.2.30.行人类型

**QList\<IPedestrianType\> pedestrianTypes()**

​	获取所有行人类型对象序列。

#### 3.3.2.31.行人组成

**QList\<Online::Pedestrian::PedestrianComposition\> pedestrianCompositions()**

​	获取所有行人组成信息序列。

**long createPedestrianComposition(QString name，QMap\<int, qreal\> mpCompositionRatio)**

​	创建行人组成。

参数：

​	[ in ] name：组成名称。

​	[ in ] mpCompositionRatio：组成明细，key为行人类型编码，value为行人类型占比。

返回：

​	行人组成ID，如果创建失败返回-1。

**bool removePedestrianComposition(long compositionId)**

​	移除行人组成。

参数：

​	[ in ] compositionID：行人组成ID。

**bool updatePedestrianComposition(long compositionID，QMap\<int, qreal\> mpCompositionRatio)**

​	更新行人组成。

参数：

​	[ in ] compositionID：行人组成ID。

​	[ in ] mpCompositionRatio：组成明细，key为行人类型编码，value为行人类型占比。

返回：

​	是否更新成功。

#### 3.3.2.32.行人面域层级

**QList\<Online::Pedestrian::LayerInfo\> layerInfos()**

​	获取所有层级信息。

**Online::Pedestrian::LayerInfo addLayerInfo(QString name，qreal height，bool visible，bool locked)**

​	新增层级，返回新增的层级信息。

参数：

​	[ in ] name：层级名称。

​	[ in ] height：层级高度。

​	[ in ] visible：是否可见。

​	[ in ] locked：是否锁定，锁定后面域不可以修改。

**void removeLayerInfo(long layerId)**

​	删除某个层级，会删除层级当中的所有元素。

参数：

​	[ in ] layerID：层级ID。

**bool updateLayerInfo(long layerID，QString name，qreal height，bool visible，bool locked)**

​	更新层级信息。

参数：

​	[ in ] layerID：层级ID。

​	[ in ] name：层级名称。

​	[ in ] height：层级高度。

​	[ in ] visible：是否可见。

​	[ in ] locked：是否锁定，锁定后面域不可以修改。

返回：

​	是否更新成功。

#### 3.3.2.33.行人面域

**QList\<IPedestrianRegion\*\> pedestrianRegions()**

​	获取所有行人面域对象序列。

**QList\<IPedestrianRectRegion\*\> pedestrianRectRegions()**

​	获取所有矩形面域对象序列。

**QList\<IPedestrianTriangleRegion\*\> pedestrianTriangleRegions()**

​	获取所有三角形面域对象序列。

**QList\<IPedestrianEllipseRegion\*\> pedestrianEllipseRegions()**

​	获取所有椭圆形面域对象序列。

**QList\<IPedestrianFanShapeRegion\*\> pedestrianFanShapeRegions()**

​	获取所有扇形面域对象序列。

**QList\<IPedestrianPolygonRegion\*\> pedestrianPolygonRegions()**

​	获取所有多边形面域对象序列。

**QList\<IPedestrianSIDeWalkRegion\*\> pedestrianSIDeWalkRegions()**

​	获取所有人行道对象序列。

**QList\<IPedestrianCrossWalkRegion\*\> pedestrianCrossWalkRegions()**

​	获取所有人行横道对象序列。

**IPedestrianRegion\* findPedestrianRegion(long id)**

​	通过行人面域ID获取行人面域对象。

**IPedestrianRectRegion\* findPedestrianRectRegion(long id)**

​	通过行人面域ID获取矩形面域对象。

**IPedestrianEllipseRegion\* findPedestrianEllipseRegion(long id)**

​	通过行人面域ID获取椭圆形面域对象。

**IPedestrianTriangleRegion\* findPedestrianTriangleRegion(long id)**

​	通过行人面域ID获取三角形面域对象。

**IPedestrianFanShapeRegion\* findPedestrianFanShapeRegion(long id)**

​	通过行人面域ID获取扇形面域对象。

**IPedestrianPolygonRegion\* findPedestrianPolygonRegion(long id)**

​	通过行人面域ID获取多边形面域对象。

**IPedestrianSIDeWalkRegion\* findPedestrianSIDeWalkRegion(long id)**

​	通过行人面域ID获取人行道对象。

**IPedestrianCrossWalkRegion\* findPedestrianCrossWalkRegion(long id)**

​	通过行人面域ID获取人行横道对象。

**IPedestrianRectRegion\* createPedestrianRectRegion(QPointF startPoint，QPointF endPoint)**

​	创建矩形行人面域。

参数：

​	[ in ] startPoint：左上角坐标。

​	[ in ] endPoint：右下角坐标。

返回	

​	矩形行人面域对象。

**IPedestrianTriangleRegion\* createPedestrianTriangleRegion(QPointF startPoint，QPointF endPoint)**

​	创建三角形行人面域。

参数：

​	[ in ] startPoint：左上角坐标。

​	[ in ] endPoint：右下角坐标。

返回：

​	三角形行人面域对象。

**IPedestrianEllipseRegion\* createPedestrianEllipseRegion(QPointF startPoint，QPointF endPoint)**

​	创建椭圆行人面域。

参数：

​	[ in ] startPoint：左上角坐标。

​	[ in ] endPoint：右下角坐标。

返回：	

​	椭圆行人面域对象。

**IPedestrianFanShapeRegion\* createPedestrianFanShapeRegion(QPointF startPoint，QPointF endPoint)**

​	创建扇形行人面域。

参数：

​	[ in ] startPoint：圆心坐标。

​	[ in ] endPoint：外半径终点坐标。

返回：

​	扇形行人面域对象。

**IPedestrianPolygonRegion\* createPedestrianPolygonRegion(QPolygonF polygon)**

​	创建多边形行人面域。

参数：

​	[ in ] polygon：多边形顶点。

返回：

​	多边形行人面域对象。

**IPedestrianSIDeWalkRegion\* createPedestrianSIDeWalkRegion(QList\<QPointF\> vertexs)**

​	创建人行道。

参数：

​	[ in ] vertexs：顶点列表。

返回：	

​	人行道对象。

**IPedestrianCrossWalkRegion\* createPedestrianCrossWalkRegion(QPointF startPoint，QPointF endPoint)**

​	创建人行横道。

参数：

​	[ in ] startPoint：左上角坐标。

​	[ in ] endPoint：右下角坐标。

返回：

​	人行横道对象。

**IPedestrianStairRegion\* createPedestrianStairRegion(QPointF startPoint，QPointF endPoint)**

​	创建楼梯。

参数：

​	[ in ] startPoint：起点坐标。

​	[ in ] endPoint：终点坐标。

返回：	

​	楼梯对象。

**void removePedestrianRectRegion(IPedestrianRectRegion\* pIPedestrianRectRegion)**

​	删除矩形行人面域。

参数：

​	[ in ] pIPedestrianRectRegion：矩形行人面域对象。

**void removePedestrianTriangleRegion(IPedestrianTriangleRegion\* pIPedestrianTriangleRegion)**

​	删除三角形行人面域。

参数：

​	[ in ] pIPedestrianTriangleRegion：三角形行人面域对象。

**void removePedestrianEllipseRegion(IPedestrianEllipseRegion\* pIPedestrianEllipseRegion)**

​	删除椭圆行人面域。

参数：

[ in ] pIPedestrianEllipseRegion：椭圆行人面域对象。

**void removePedestrianFanShapeRegion(IPedestrianFanShapeRegion\* pIPedestrianFanShapeRegion)**

​	删除扇形行人面域。

参数：

​	[ in ] pIPedestrianFanShapeRegion：扇形行人面域对象。

**void removePedestrianPolygonRegion(IPedestrianPolygonRegion\* pIPedestrianPolygonRegion)**

​	删除多边形行人面域。

参数：

​	[ in ] pIPedestrianPolygonRegion：多边形行人面域对象。

**void removePedestrianSIDeWalkRegion(IPedestrianSIDeWalkRegion\* pIPedestrianSIDeWalkRegion)**

​	删除人行道。

参数：

​	[ in ] pIPedestrianSIDeWalkRegion：人行道对象。

**void removePedestrianCrossWalkRegion(IPedestrianCrossWalkRegion\* pIPedestrianCrossWalkRegion)**

​	删除人行横道。

参数：

​	[ in ] pIPedestrianCrossWalkRegion：人行横道对象。

**void removePedestrianStairRegion(IPedestrianStairRegion\* pIPedestrianStairRegion)**

​	删除楼梯。

参数：

​	[ in ] pIPedestrianStairRegion：楼梯对象。

#### 3.3.2.34.行人发生点

**QList\<IPedestrianPathPoint\*\> pedestrianPathStartPoints()**

​	获取所有行人发生点对象序列。

**IPedestrianPathPoint\* findPedestrianPathStartPoint(long id)**

​	通过行人发生点ID获取行人发生点对象。

**Online::Pedestrian::PedestrianPathStartPointConfigInfo findPedestrianStartPointConfigInfo(long id)**

​	通过行人发生点ID获取行人发生点配置信息。

**IPedestrianPathPoint\* createPedestrianPathStartPoint(QPointF scenePos)**

​	创建行人发生点。

参数：

​	[ in ] scenePos：场景坐标。

返回：	

​	行人发生点对象。

**void removePedestrianPathStartPoint(IPedestrianPathPoint\* pIPedestrianPathStartPoint)**

​	删除行人发生点。

参数：

​	[ in ] pIPedestrianPathStartPoint：行人发生点对象。

**bool updatePedestrianStartPointConfigInfo(Online::Pedestrian::PedestrianPathStartPointConfigInfo info)**

​	更新行人发生点配置信息。

参数：

​	[ in ] info：行人发生点配置信息。

返回：	

​	是否更新成功。

#### 3.3.2.35.行人结束点

**QList\<IPedestrianPathPoint\*\> pedestrianPathEndPoints()**

​	获取所有行人结束点对象序列。

**IPedestrianPathPoint\* findPedestrianPathEndPoint(long id)**

​	通过ID获取行人结束点对象。

**IPedestrianPathPoint\* createPedestrianPathEndPoint(QPointF scenePos)**

​	创建行人结束点。

参数：

​	[ in ] scenePos：场景坐标。

返回：

​	行人结束点对象。

**void removePedestrianPathEndPoint(IPedestrianPathPoint\* pIPedestrianPathEndPoint)**

​	删除行人结束点。

参数：

​	[ in ] pIPedestrianPathEndPoint：行人结束点对象。

#### 3.3.2.36.行人决策点

**QList\<IPedestrianPathPoint\*\> pedestrianPathDecisionPoints()**

​	获取所有行人决策点对象序列。

**IPedestrianPathPoint\* findPedestrianDecisionPoint(long id)**

​	通过行人决策点ID获取行人决策点对象。

**Online::Pedestrian::PedestrianDecisionPointConfigInfo findPedestrianDecisionPointConfigInfo(long id)**

​	通过行人决策点ID获取行人决策点配置信息。

**IPedestrianPathPoint\* createPedestrianDecisionPoint(QPointF scenePos)**

​	创建行人决策点。

参数：

​	[ in ] scenePos：场景坐标。

返回：

​	行人决策点对象。

**void removePedestrianDecisionPoint(IPedestrianPathPoint\* pIPedestrianDecisionPoint)**

​	删除行人决策点。

参数：

​	[ in ] pIPedestrianDecisionPoint：行人决策点对象。

**bool updatePedestrianDecisionPointConfigInfo(Online::Pedestrian::PedestrianDecisionPointConfigInfo info)**

​	更新行人决策点配置信息。

参数：

​	[ in ] info：行人决策点配置信息。

返回：	

​	是否更新成功。

#### 3.3.2.37.行人路径

**QList\<IPedestrianPath\*\> pedestrianPaths()**

​	获取所有行人路径对象序列，包括局部路径。

**IPedestrianPath\* findPedestrianPath(long id)**

​	通过行人路径ID获取行人路径，包括局部路径。

**IPedestrianPath\* createPedestrianPath(IPedestrianPathPoint\* pStartPoint，IPedestrianPathPoint\* pEndPoint，QList\<QPointF\> mIDdlePoints)**

​	创建行人路径（或行人局部路径）。

参数：

​	[ in ] pStartPoint：行人发生点（或行人决策点）。

​	[ in ] pEndPoint：行人结束点。

​	[ in ] mIDdlePoints：一组中间必经点。

返回：	

​	行人路径对象。

**void removePedestrianPath(IPedestrianPath\* pIPedestrianPath)**

​	删除行人路径。

参数：

​	[ in ] pIPedestrianPath：行人路径对象。

#### 3.3.2.38.行人信号灯

**QList\<ICrosswalkSignalLamp\*\> crosswalkSignalLamps()**

​	获取所有人行横道红绿灯对象序列。

**ICrosswalkSignalLamp\* findCrosswalkSignalLamp(long id)**

​	通过ID获取人行横道红绿灯对象。

**void addCrossWalkSignalPhaseToLamp(int SignalPhaseID，ISignalLamp\* signalLamp)**

​	添加行人信号灯。

参数：

​	[ in ] SignalPhaseID：信号相位ID。

​	[ in ] signalLamp：信号灯对象。

**ICrosswalkSignalLamp\* createCrossWalkSignalLamp(ISignalController\* pTrafficLight，QString name，long crosswalkID，QPointF scenePos，bool isPositive)**

​	创建人行横道信号灯。

参数：

​	[ in ] pTrafficLight：信号机对象。

​	[ in ] name：信号灯名称。

​	[ in ] crosswalkID：人行横道ID。

​	[ in ] scenePos：位于人行横道内的场景坐标。

​	[ in ] isPositive：信号灯管控方向是否为正向。

返回：

​	人行横道信号灯对象。

**void removeCrossWalkSignalLamp(ICrosswalkSignalLamp\* pICrosswalkSignalLamp)**

​	删除人行横道信号灯。

参数：

​	[ in ] pICrosswalkSignalLamp：人行横道信号灯对象。

#### 3.3.2.39.停车场停车时距分布

**QList\<Online::ParkingLot::DynaParkingTimeDis\> parkingTimeDis()**

​	获取停车场停车时距分布列表。

**Online::ParkingLot::DynaParkingTimeDis createParkingTimeDis(const Online::ParkingLot::DynaParkingTimeDis& param)**

​	创建停车场停车时距分布。

参数：

​	[ in ] param：停车时距分布参数。

**void removeParkingTimeDis(long id)**

​	移除停车场停车时距分布。

参数：

​	[ in ] ID：停车时距分布ID。

**Online::ParkingLot::DynaParkingTimeDis updateParkingTimeDis(const Online::ParkingLot::DynaParkingTimeDis& param)**

​	更新停车场停车时距分布。

参数：

​	[ in ] param：停车时距分布参数。

#### 3.3.2.40.停车区域

**QList\<IParkingRegion\*\> parkingRegions()**

​	获取所有停车区序列。

**IParkingRegion\* findParkingRegion(long id)**

​	通过停车区域ID获取停车区域。

**IParkingRegion\* createParkingRegion(const Online::ParkingLot::DynaParkingRegion& param)**

​	创建停车区域。

参数：

​	[ in ] param：动态停车区信息。

**void removeParkingRegion(IParkingRegion\* pIParkingRegion)**

​	移除停车区域。

参数：

​	[ in ] pIParkingRegion：停车区域对象。

**void removeParkingRegionById(long id)**

​	通过停车区域ID移除停车区域。

参数：

​	[ in ] ID：停车区域ID。

**IParkingRegion\* updateParkingRegion(const Online::ParkingLot::DynaParkingRegion& param)**

​	更新停车区域。

参数：

​	[ in ] param：动态停车区域信息。

#### 3.3.2.41.停车路径决策点

**QList\<IParkingDecisionPoint\*\> parkingDecisionPoints()**

​	获取所有停车路径决策点序列。

**IParkingDecisionPoint\* findParkingDecisionPoint(long id)**

​	通过停车路径决策点ID获取停车路径决策点对象。

**IParkingDecisionPoint\* createParkingDecisionPoint(ILink\* pLink，qreal distance，QString name = QString())**

​	创建停车路径决策点。

参数：

​	[ in ] pLink：决策点所在的路段。

​	[ in ] distance：决策点距离路段起点的距离。单位：像素。

​	[ in ] name：决策点名称。

**void removeParkingDecisionPoint(IParkingDecisionPoint\* pIParkingDecisionPoint)**

​	移除停车路径决策点。

参数：

​	[ in ] pIParkingDecisionPoint：停车路径决策点对象。

**void removeParkingDecisionPointById(long id)**

​	通过停车路径决策点ID移除停车路径决策点。

参数：

​	[ in ] ID：停车路径决策点ID。

#### 3.3.2.42.停车路径

**IParkingRouting\* createParkingRouting(IParkingDecisionPoint\* pDeciPoint，IParkingRegion\* pIParkingRegion)**

​	创建停车路径。

参数：

​	[ in ] pDeciPoint：停车决策点。

​	[ in ] pIParkingRegion：停车区域。

**void removeParkingRouting(IParkingRouting\* pIParkingRouting)**

​	移除停车路径。

参数：

​	[ in ] pIParkingRouting：停车决策点对象。

**void removeParkingRoutingById(long id)**

​	通过停车路径ID移除停车路径。

参数：

​	[ in ] ID：停车决策点ID。

#### 3.3.2.43.收费站停车时距分布

**QList\<Online::TollStation::DynaTollParkingTimeDis\> tollParkingTimeDis()**

​	获取收费站停车时距分布序列。

**Online::TollStation::DynaTollParkingTimeDis createTollParkingTimeDis(const Online::TollStation::DynaTollParkingTimeDis& param)**

​	创建收费站停车时距分布。

参数：

​	[ in ] param：停车时距分布参数。

**void removeTollParkingTimeDis(long id)**

​	移除收费站停车时距分布。

参数：

​	[ in ] ID：停车时距分布ID。

**Online::TollStation::DynaTollParkingTimeDis updateTollParkingTimeDis(const Online::TollStation::DynaTollParkingTimeDis& param)**

​	更新收费站停车时距分布。

参数：

​	[ in ] param：停车时距分布参数。

#### 3.3.2.44.收费车道

**QList\<ITollLane\*\> tollLanes()**

​	获取所有收费车道对象序列。

**ITollLane\* findTollLane(long id)**

​	通过收费车道ID获取收费车道对象。

**ITollLane\* createTollLane(const Online::TollStation::DynaTollLane& param)**

​	创建收费车道。

参数：

​	[ in ] param：动态收费车道信息。

**void removeTollLane(ITollLane\* pITollLane)**

​	移除收费车道。

参数：

​	[ in ] pITollLane：收费车道对象。

**void removeTollLaneById(long id)**

​	通过收费车道ID移除收费车道。

参数：

​	[ in ] ID：收费车道ID。

**ITollLane\* updateTollLane(const Online::TollStation::DynaTollLane& param)**

​	更新收费车道。

参数：

​	[ in ] param：动态收费车道信息。

#### 3.3.2.45.收费路径决策点

**QList\<ITollDecisionPoint\*\> tollDecisionPoints()**

​	获取所有收费路径决策点列表。

**ITollDecisionPoint\* findTollDecisionPoint(long id)**

​	通过ID获取收费路径决策点。

**ITollDecisionPoint\* createTollDecisionPoint(ILink\* pLink，qreal distance，QString name = QString())**

​	创建收费路径决策点。

参数：

​	[ in ] pLink：决策点所在路段。

​	[ in ] distance：决策点距离路段起点的距离。单位：像素。

​	[ in ] name：决策点名称。

**void removeTollDecisionPoint(ITollDecisionPoint\* pITollDecisionPoint)**

​	移除收费路径决策点。

参数：

​	[ in ] pITollLane：收费路径决策点对象。

**void removeTollDecisionPointById(long id)**

​	通过收费路径决策点ID移除收费路径决策点。

参数：

​	[ in ] ID：收费路径决策点ID。

#### 3.3.2.46.收费路径

**ITollRouting\* createTollRouting(ITollDecisionPoint\* pDeciPoint，ITollLane\* pITollLane)**

​	创建收费路径。

参数：

​	[ in ] pDeciPoint：收费决策点。

​	[ in ] pITollLane：收费车道。

**void removeTollRouting(ITollRouting\* pITollRouting)**

​	移除收费路径。

参数：

​	[ in ] pITollRouting：收费路径对象。

**void removeTollRoutingById(long id)**

​	通过ID移除收费路径。

参数：

​	[ in ] ID：收费路径ID。

#### 3.3.2.47.节点

**QMap\<long, IJunction\*\> getAllJunctions()**

​	获取所有节点对象序列。

**IJunction\* findJunction(long junctionId)**

​	通过ID获取节点对象。

**IJunction\* createJunction(QPointF startPoint，QPointF endPoint，QString name)**

​	创建节点。

参数：

​	[ in ] startPoint：左上角起始点坐标。

​	[ in ] endPoint：右下角终点坐标。

​	[ in ] name：节点名称。

返回：

​	节点对象。

**bool removeJunction(long junctionId)**

​	删除节点。

参数：

​	[ in ] junctionID：节点ID。

返回：

​	是否移除成功。

**bool updateJunctionName(long junctionID，QString name)**

​	更新节点名称。

参数：

​	[ in ] junctionID：节点ID。

​	[ in ] name：新的节点名称。

**QHash\<long, QHash\<long, Online::Junction::FlowTurning\>\> getJunctionFlows(long junctionId)**

​	获取节点流向信息。

参数：

​	[ in ] junctionID：节点ID。

返回：

​	节点流向信息映射表。

**bool updateFlow(long timeID，long junctionID，long turningID，long inputFlowValue)**

​	更新流向流量。

参数：

​	[ in ] timeID：时间段ID。

​	[ in ] junctionID：节点ID。

​	[ in ] turningID：转向ID。

​	[ in ] inputFlowValue：输入流量值(veh/h)。

返回：

​	是否更新成功。

**bool updateFlowAlgorithmParams(double theta，double bpra，double bprb，long maxIterateNum，bool useNewPath)**

​	更新流量算法参数。

参数：

​	[ in ] theta：参数θ(0.01-1)。

​	[ in ] bpra：BPR路阻参数A(0.05-0.5)。

​	[ in ] bprb：BPR路阻参数B(1-10)。

​	[ in ] maxIterateNum：最大迭代次数(1-5000)。

​	[ in ] useNewPath：是否重新构建静态路径。

返回：

​	是否更新成功。

**bool updatePathBuildParams(bool deciPointPosFlag，bool laneConnectorFlag，long minPathNum = 3)**

​	更新路径构建参数。

参数：

​	[ in ] deciPointPosFlag：是否考虑决策点位置。

​	[ in ] laneConnectorFlag：是否考虑车道连接。

​	[ in ] minPathNum：最小路径数量(默认3)。

返回：

​	是否更新成功。

**QMap\<QPair\<long, long\>, QVector\<QList\<ILink\*\>\>\> buildAndApplyPaths()**

​	构建并应用路径。

返回：

​	路径结果信息映射表。

**QHash\<long, QList\<Online::Junction::FlowTurning\>\> calculateFlows()**

​	计算并应用流量结果。

返回：

​	时间段ID到流量计算结果的映射表。

#### 3.3.2.48.节点时间段

**QList\<Online::Junction::FlowTimeInterval\> getFlowTimeIntervals()**

​	获取所有节点时间段。

**Online::Junction::FlowTimeInterval addFlowTimeInterval()**

​	添加节点时间段。

返回：

​	节点时间段信息。

**bool deleteFlowTimeInterval(long timeId)**

​	删除节点时间段。

参数：

​	[ in ] timeID：节点时间段ID。

返回：

​	是否删除成功。

**Online::Junction::FlowTimeInterval updateFlowTimeInterval(long timeID，long startTime，long endTime)**

​	更新时间段。

参数：

​	[ in ] timeID：节点时间段ID。

​	[ in ] startTime：开始时间。单位：s。

​	[ in ] endTime：结束时间。单位：s。

### 3.3.3.仿真接口（SimuInterface）

​	头文件：simuinterface.h

​	SimuInterface是TessInterface的子接口，通过此接口可以启动、暂停、停止仿真，可以设置仿真精度，获取仿真过程中的车辆对象、车辆状态，获取几种检测器检测到的样本数据和集计数据等。

#### 3.3.3.1.仿真配置

**long simuIntervalScheming()**

​	获取仿真时长。单位：s。

**void setSimuIntervalScheming(long interval)**

​	设置仿真时长。设置值为0时表示不限时长。单位：s。

**int simuAccuracy()**

​	获取仿真精度。

**void setSimuAccuracy(int accuracy)**

​	设置仿真精度，即每秒计算次数。

**int acceMultiples()**

​	获取仿真加速倍数。

**void setAcceMultiples(int multiples)**

​	设置仿真加速倍数。


**bool byCpuTime()**

​	仿真时间是否由现实时间确定。一个计算周期存在两种时间，一种是现实经历的时间，另一种是由仿真精度决定的仿真时间，如果仿真精度为每秒20次，仿真一次相当于仿真了50毫秒。默认情况下，一个计算周期的仿真时间是由仿真精度决定的。在线仿真时如果算力不够，按仿真精度确定的仿真时间会与现实时间存在时差。

**void setByCpuTime(bool bByCpuTime)**

​	设置是否由现实时间确定仿真时间，如果设为true，每个仿真周期现实经历的时间作为仿真时间，这样仿真时间与现实时间相吻合。

**bool isRecordTrace()**

​	获取是否记录车辆轨迹。

**void setIsRecordTrace(bool bRecord)**

​	设置是否记录车辆轨迹。

**void setThreadCount(int count)**

​	设置工作线程数。

**long batchNumber()**

​	获取当前仿真批次。

**qreal batchIntervalReally()**

​	获取当前批次实际时间。单位：ms。

**long simuTimeIntervalWithAcceMutiples()**

​	获取获取当前已仿真时间。单位：ms。

**qint64 startMSecsSinceEpoch()**

​	获取仿真开始的现实时间。单位：ms。

**qint64 stopMSecsSinceEpoch()**

​	仿真结束的现实时间。单位：ms。

#### 3.3.3.2.仿真状态

**bool isRunning()**

​	获取仿真是否在运行状态。

**bool isPausing()**

​	获取仿真是否在暂停状态。

**void startSimu()**

​	启动仿真。

**void pauseSimu()**

​	暂停仿真。

**void stopSimu()**

​	停止仿真。

**void pauseSimuOrNot()**

​	暂停或恢复仿真。如果当前处于仿真运行状态，此方法暂停仿真，如果当前处于暂停状态，此方法继续仿真。

#### 3.3.3.3.车辆

**long vehiCountTotal()**

​	获取车辆总数，包括已创建尚未进入路网的车辆、正在运行的车辆、已驶出路网的车辆。

**long vehiCountRunning()**

​	获取当前时间正在运行的车辆数。

**IVehicle\* getVehicle(long vehiId)**

​	通过车辆ID获取车辆对象。

**QList\<IVehicle\*\> allVehicle()**

​	获取所有车辆对象序列。

**QList\<IVehicle\*\> allVehiStarted()**

​	获取当前时间所有正在运行的车辆对象序列。

示例：

```cpp
// 获取当前正在运行的车辆列表
QList<IVehicle*> allVehicles = simuiface->allVehiStarted();
for (IVehicle* vehicle : allVehicles) 
{
    qDebug() << "车辆ID：" << vehicle->id();
    qDebug() << "车辆名称：" << vehicle->name();
    qDebug() << "车辆类型编码：" << vehicle->vehicleTypeCode();
    qDebug() << "车辆类型名称：" << vehicle->vehicleTypeName();
    qDebug() << "车辆长度：" << vehicle->length(UnitOfMeasure::Metric) << " m";

    qDebug() << "车辆当前横坐标：" << vehicle->pos(UnitOfMeasure::Metric).x() << " m";
    qDebug() << "车辆当前纵坐标：" << vehicle->pos(UnitOfMeasure::Metric).y() << " m";
    qDebug() << "车辆当前高程：" << vehicle->v3z() << " m";
    qDebug() << "车辆当前所在道路ID：" << vehicle->roadId();
    qDebug() << "车辆当前所在道路名称：" << vehicle->roadName();
    qDebug() << "车辆当前是否在路段：" << (vehicle->roadIsLink() ? "是" : "否");
    qDebug() << "车辆当前所在车道ID：" << vehicle->laneId();
    if (vehicle->roadIsLink()) 
    {
        qDebug() << "车辆当前所在车道序号：" << vehicle->vehicleDriving()->laneNumber();
    }
    qDebug() << "车辆当前与车道起点的间距：" << vehicle->vehicleDriving()->distToStartPoint(true, true, UnitOfMeasure::Metric)  << " m";
    
    qDebug() << "车辆当前速度：" << vehicle->currSpeed(UnitOfMeasure::Metric) * 3.6 << " km/h";
    qDebug() << "车辆当前期望速度：" << vehicle->vehicleDriving()->desirSpeed(UnitOfMeasure::Metric) * 3.6 << " km/h";
    qDebug() << "车辆当前加速度：" << vehicle->acce(UnitOfMeasure::Metric) << " m/s²";
    qDebug() << "车辆当前朝向角：" << vehicle->angle() << " °";
}
```

**QList\<IVehicle\*\> vehisInLink(long linkId)**

​	获取当前时间指定ID的路段上的车辆对象序列。

**QList\<IVehicle\*\> vehisInLane(long laneId)**

​	获取当前时间指定ID的车道上的车辆对象序列。

**QList\<IVehicle\*\> vehisInConnector(long connectorId)**

​	获取当前时间指定ID的连接段上的车辆对象序列。

**QList\<IVehicle\*\> vehisInLaneConnector(long connectorID，long fromLaneID，long toLaneId)**

​	获取当前时间指定连接段ID、上游车道ID和下游车道ID的车道连接上的车辆对象序列。

参数：

​	[ in ] connectorID：连接段ID。

​	[ in ] fromLaneID：上游车道ID。

​	[ in ] toLaneID：下游车道ID。

返回：

​	车辆对象序列。

**QList\<Online::VehicleStatus\> getVehisStatus(long batchNumber = 0，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取当前时间所有正在运行的车辆状态。

参数：

​	[ in ] batchNumber：批次号。

返回：

​	车辆状态序列。

**QList\<Online::VehiclePosition\> getVehiTrace(long vehiID，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取指定车辆的运行轨迹。单位：像素。

参数：

​	[ in ] vehiID：车辆ID。

返回：

​	车辆轨迹点位序列。

**IVehicle\* createGVehicle(Online::DynaVehiParam dynaVehi)**

​	创建车辆。

参数：

​	[ in ] dynaVehi：动态车辆信息。

返回：

​	车辆对象。

```cpp
// 在路段上创建车辆
// 构建参数
Online::DynaVehiParam dvp1;
// 车型ID
dvp1.vehiTypeCode = 1;
// 路段ID
dvp1.roadId = 4;
// 车道序号
dvp1.laneNumber = 0;
// 位置，单位：m
dvp1.dist = m2p(50);
// 速度，单位：m/s
dvp1.speed = m2p(20);
// 颜色
dvp1.color = "#00AFF0";
// 动态创建车辆
IVehicle* vehicle1 = simuiface->createGVehicle(dvp1);
if (vehicle1)
{
    qDebug() << "在路段上创建了车辆，其ID为：" << vehicle1.id();
}

// 在连接段上创建车辆
// 构建参数
Online::DynaVehiParam dvp2;
// 车型ID
dvp2.vehiTypeCode = 1;
// 连接段ID
dvp2.roadId = 4;
// 上游路段的车道序号
dvp2.laneNumber = 0;
// 下游路段的车道序号
dvp2.toLaneNumber = 0;
// 位置，单位：m
dvp2.dist = m2p(50);
// 速度，单位：m/s
dvp2.speed = m2p(20);
// 颜色
dvp2.color = "#00AFF0";
// 动态创建车辆
IVehicle* vehicle2 = simuiface->createGVehicle(dvp2);
if (vehicle2)
{
    qDebug() << "在连接段上创建了车辆，其ID为：" << vehicle2.id();
}
```

**IVehicle\* createBus(IBusLine\* pBusLine，qreal startSimuDateTime)**

​	创建公交车。

参数：

​	[ in ] pBusLine：公交线路对象。

​	[ in ] startSimuDateTime：发车时间。单位：ms。

#### 3.3.3.4.行人

**QList\<IPedestrian\*\> allPedestrianStarted()**

​	获取所有正在运行的行人对象序列。

**QList\<Online::Pedestrian::PedestrianStatus\> getPedestriansStatusByRegionId(long regionId)**

​	通过行人面域ID获取当前时间面域上所有行人的状态信息。

参数：

​	[ in ] regionID：面域ID。

返回：

​	行人状态信息序列。

#### 3.3.3.5.信号灯

**QList\<Online::SignalPhaseColor\> getSignalPhasesColor()**

​	获取当前时间所有信号控制相位的颜色。

返回：

​	相位颜色序列。

示例：

```cpp
QList<Online::SignalPhaseColor> allSignalPhaseColor = simuiface->getSignalPhasesColor();
for (auto signalPhaseColor: allSignalPhaseColor)
{
    qDebug() << "信号机ID：" << signalPhaseColor.signalGroupId;
    qDebug() << "信控相位ID：" << signalPhaseColor.phaseId;
    qDebug() << "信控相位序号：" << signalPhaseColor.phaseNumber;
    qDebug() << "当前颜色：" << signalPhaseColor.color;
    qDebug() << "当前颜色的设置时间(ms)：" << signalPhaseColor.mrIntervalSetted;
    qDebug() << "当前颜色的已持续时间(ms)：" << signalPhaseColor.mrIntervalByNow;
}
```

#### 3.3.3.6.数据采集器

**QList\<Online::VehiInfoCollected\> getVehisInfoCollected()**

​	获取当前时间完成穿越数据采集器的所有车辆信息。

示例：

```cpp
QList<Online::VehiInfoCollected> allVehiInfoCollected = simuiface->getVehisInfoCollected();
for (auto vehiInfo: allVehiInfoCollected)
{
    qDebug() << "采集器ID：" << vehiInfo.collectorId;
    qDebug() << "仿真时间(s)：" << vehiInfo.simuInterval;
    qDebug() << "车辆ID：" << vehiInfo.vehiId;
}
```

**QList\<Online::VehiInfoAggregated\> getVehisInfoAggregated()**

​	获取最近集计时间段内数据采集器采集的集计数据。

示例：

```cpp
QList<Online::VehiInfoAggregated> allVehiInfoAggregated = simuiface->getVehisInfoAggregated();
for (auto vehiInfoAgg: allVehiInfoAggregated)
{
    qDebug() << "采集器ID：" << vehiInfoAgg.collectorId;
    qDebug() << "时间段ID：" << vehiInfoAgg.timeId;
    qDebug() << "起始时间(s)：" << vehiInfoAgg.fromTime;
    qDebug() << "结束时间(s)：" << vehiInfoAgg.toTime;
    qDebug() << "车辆数(veh)：" << vehiInfoAgg.vehiCount;
    qDebug() << "平均速度(km/h)：" << vehiInfoAgg.avgSpeed;
    qDebug() << "平均占有率：" << vehiInfoAgg.occupancy;
}
```

#### 3.3.3.7.排队计数器

**QList\<Online::VehiQueueCounted\> getVehisQueueCounted()**

​	获取当前时间排队计数器计数的车辆排队信息。

示例：

```cpp
QList<Online::VehiQueueCounted> allVehiQueueCounted = simuiface->getVehisQueueCounted();
for (auto vehiQueue: allVehiQueueCounted)
{
    qDebug() << "计数器ID：" << vehiQueue.counterId;
    qDebug() << "仿真时间(s)：" << vehiQueue.simuTime;
    qDebug() << "排队车辆数(veh)：" << vehiQueue.vehiCount;
    qDebug() << "排队长度(m)：" << vehiQueue.queueLength;
}
```

**QList\<Online::VehiQueueAggregated\> getVehisQueueAggregated()**

​	获取最近集计时间段内排队计数器采集的集计数据。

示例：

```cpp
QList<Online::VehiQueueAggregated> allVehiQueueAggregated = simuiface->getVehisQueueAggregated();
for (auto vehiQueueAgg: allVehiQueueAggregated)
{
    qDebug() << "计数器ID：" << vehiQueueAgg.counterId;
    qDebug() << "时间段ID：" << vehiQueueAgg.timeId;
    qDebug() << "起始时间(s)：" << vehiQueueAgg.fromTime;
    qDebug() << "结束时间(s)：" << vehiQueueAgg.toTime;
    qDebug() << "平均排队车辆数(veh)：" << vehiQueueAgg.avgVehiCount;
    qDebug() << "平均排队长度(m)：" << vehiQueueAgg.avgQueueLength;
    qDebug() << "最大排队长度(m)：" << vehiQueueAgg.maxQueueLength;
    qDebug() << "最小排队长度(m)：" << vehiQueueAgg.minQueueLength;
}
```

**bool queueRecently(long queueCounterID，qreal& queueLength，int& vehiCount，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	指定排队计算器最近一次排队长度和排队车辆数。

参数：

​	[ in ] queueCounterID：排队计数器ID。

​	[ out ] queueLength：排队长度。

​	[ out ] vehiCount：排队车辆数。

返回：

​	是否获取成功。

#### 3.3.3.8.行程时间检测器

**QList\<Online::VehiTravelDetected\> getVehisTravelDetected()**

​	获取当前时间行程时间检测器完成的行程时间检测信息。

示例：

```cpp
QList<Online::VehiTravelDetected> allVehiTravelDetected = simuiface->getVehisTravelDetected();
for (auto vehiTravel: allVehiTravelDetected)
{
    qDebug() << "检测器ID：" << vehiTravel.detectedId;
    qDebug() << "车辆ID：" << vehiTravel.vehiId;
    qDebug() << "行驶时间(s)：" << vehiTravel.travelTime;
    qDebug() << "行驶距离(m)：" << vehiTravel.travelDistance;
    qDebug() << "延误(s)：" << vehiTravel.delay;
}
```

**QList\<Online::VehiTravelAggregated\> getVehisTravelAggregated()**

​	获取最近集计时间段内行程时间检测器采集的集计数据。

示例：

```cpp
QList<Online::VehiTravelAggregated> allVehiTravelAggregated = simuiface->getVehisTravelAggregated();
for (auto vehiTravelAgg: allVehiTravelAggregated)
{
    qDebug() << "检测器ID：" << vehiTravelAgg.detectedId;
    qDebug() << "时间段ID：" << vehiTravelAgg.timeId;
    qDebug() << "起始时间(s)：" << vehiTravelAgg.fromTime;
    qDebug() << "结束时间(s)：" << vehiTravelAgg.toTime;
    qDebug() << "车辆数：" << vehiTravelAgg.vehiCount;
    qDebug() << "平均行程时间(s)：" << vehiTravelAgg.avgTravelTime;
    qDebug() << "平均行程距离(m)：" << vehiTravelAgg.avgTravelDistance;
    qDebug() << "平均延误(s)：" << vehiTravelAgg.avgDelay;
}
```

### 3.3.4.界面接口（GuiInterface）

​	头文件：guiinterface.h	

​	GuiInterface是TessInterface的子接口，通过此接口可以访问控制TESSNG的主窗体、菜单栏、工具栏和状态栏等，使用户可以在主窗体上创建菜单、自定义窗体等。

#### 3.3.4.1.窗体

**QMainWindow\* mainWindow()**

​	获取TESSNG的主窗体。

#### 3.3.4.2.菜单栏

**QMenuBar\* menuBar()**

​	获取TESSNG的菜单栏容器。


#### 3.3.4.3.工具栏

**QToolBar\* addToolBar(const QString& name)**

​	新增自定义工具栏。

参数：

​	[ in ] name：工具栏名称。

返回：

​	工具栏对象。

**QToolBar\* insertToolBar(QToolBar* before，const QString& name)**

​	在指定工具栏前插入新工具栏。

参数：

​	[ in ] before：要在其前插入新工具栏的已有工具栏。

​	[ in ] name：工具栏名称。

返回：

​	工具栏对象。



## 3.4.对象

​	TESS NG中的对象可分为**路网对象**和**仿真对象**，其中，路网对象包括：路段、连接段等，仿真对象包括：车辆和行人。

### 3.4.1.路网

#### 3.4.1.1.路网（IRoadNet）

​	头文件: IRoadNet.h

​	路网基本信息接口，设计此接口的目的是为了TESS NG在导入外源路网时能够保存这些路网的属性，如路网中心点坐标、路网大地坐标等。

**long id()**

​	获取路网ID，即路网编辑弹窗中的编号。

**QString netName()**

​	获取路网名称。

**QString url()**

​	源数据路径，可以是本地文件，可以是网络地址。

**QString type()**

​	来源分类: "TESSNG"表示TESSNG自建；"OpenDrive"表示由OpenDrive数据导入；"GeoJson"表示由geojson数据导入。

**QString bkgUrl()**

​	获取背景路径。

**QString explain()**

​	获取路网说明。

**QJsonObject otherAttrs()**

​	其它属性json数据。

**QPointF centerPoint(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取路网中心点位置。单位：像素。

#### 3.4.1.2.道路基类（ISection）

​	头文件: ISection.h

​	道路基类是路段和连接段的基类。

**int gtype()**

​	类型，GLinkType 或 GConnectorType。GLinkType代表路段、GConnectorType代表连接段。

**bool isLink()**

​	是否是路段。

**long id()**

​	获取ID，如果是Link，id是Link的ID，如果是连接段，id是连接段ID。

**long sectionId()**

​	获取ID，如果是Link，id是Link的ID，如果是连接段，id是连接段ID+10000000，从而区分路段与连接段。

**QString name()**

​	获取Section名称，路段名或连接段名。

**void setName(QString name)**

​	设置Section名称。

**qreal v3z(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取Section高程。单位：像素。

**qreal length(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取Section长度。单位：像素。

**QList\<ILaneObject\*\> laneObjects()**

​	车道与车道连接的父类接口列表。

**ISection\* fromSection(long id)**

​	通过ID获取上游Section。如果当前是路段，id 为 0 返回nullptr，否则返回上游指定ID的连接段；如果当前是连接段，id 为 0 返回上游路段，否则返回nullptr。

**ISection\* toSection(long id)**

​	通过ID获取下游 Sction。如果当前是路段，id 为 0 返回nullptr，否则返回下游指定ID的连接段；如果当前是连接段，id 为 0 返回下游路段，否则nullptr。

**void setOtherAttr(QJsonObject otherAttr)**

​	设置路段或连接段其它属性。

**ILink\* castToLink()**

​	转换成ILink，如果当前为连接段则nullptr。

**IConnector\* castToConnector()**

​	转换成IConnector，如果当前为路段则返回nullptr。

**QPolygonF polygon()**

​	获取Section的多边型轮廓顶点构成的多边形。

#### 3.4.1.3.路段（ILink）

​	头文件: ilink.h

**int gtype()**

​	类型，返回GLinkType。

**long id()**

​	获取路段ID。

**qreal length(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取路段长度。单位：像素。

**qreal width(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取路段宽度。单位：像素。

**qreal z(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取路段高程。单位：像素。

**qreal v3z(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取路段高程，过载ISection的方法。单位：像素。

**QString name()**

​	获取路段名称。

**void setName(QString name)**

​	设置路段名称。

**QString linkType()**

​	获取路段类型，如: 城市主干道、城市次干道、人行道等。

**void setType(QString type)**

​	设置路段类型，路段类型有10种，分别为: 高速路、城市快速路、匝道、城市主要干道、次要干道、地方街道、非机动车道、人行道、公交专用道和机非共享。

**int laneCount()**

​	获取车道数。

**double limitSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取路段最高限速。单位: km/h。

**void setLimitSpeed(qreal speed，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置路段最高限速。单位: km/h。

参数: 

​	[ in ] speed: 限速值。

**qreal minSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取路段最低限速。单位: km/h。

**QList\<ILane\*\> lanes()**

​	车道接口列表。

**QList\<ILaneObject\*\> laneObjects()**

​	车道及车道连接的接口列表。

**QList\<QPointF\> centerBreakPoints(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取路段中心线断点集。单位：像素。

**QList\<QPointF\> leftBreakPoints(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取路段左侧线断点集。单位：像素。

**QList\<QPointF\> rightBreakPoints(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取路段右侧线断点集。单位：像素。

**QList< QVector3D\> centerBreakPoint3Ds(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取路段中心线三维断点集。单位：像素。

**QList\<QVector3D\> leftBreakPoint3Ds(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取路段左侧线三维断点集。单位：像素。

**QList\<QVector3D\> rightBreakPoint3Ds(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取路段右侧线三维断点集。单位：像素。

**QList\<IConnector\*\> fromConnectors()**

​	获取上游连接段列表。

**QList\<IConnector\*\> toConnectors()**

​	获取下游连接段列表。

**void setOtherAttr(QJsonObject otherAttr)**

​	设置路段其它属性。

**QJsonObject otherAttr()**

​	获取路段其它属性。

**void setLaneTypes(QList\<QString\> lType)**

​	设置车道属性，属性类型包括: "机动车道"、"机非共享"、"非机动车道"、"公交专用道"，车道顺序从右到左。

**void setLaneOtherAtrrs(QList\<QJsonObject\> lAttrs)**

​	设置车道其它属性。

**qreal distToStartPoint(const QPointF p，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	中心线上一点到起点距离。单位：像素。

参数: 

​	[ in ] p: 当前点坐标。

**bool getPointByDist(qreal dist，QPointF& outPoint，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	求中心线起点向前延伸dist距离后所在点，如果目标点不在中心线上返回false，否则返回true。单位：像素。

参数: 

​	[ in ] dist: 中心线起点向前延伸的距离。

​	[ out ] outPoint: 中心线起点向前延伸dist距离后所在点。

示例:

```cpp
// 获取距离路段起点一定距离的点位坐标
QPointF outPoint;
bool result = link->getPointByDist(50，outPoint, UnitOfMeasure::Metric);
if(result)
{
    qreal x = outPoint.x();
    qreal y = outPoint.y();
}
```

**bool getPointAndIndexByDist(qreal dist，QPointF& outPoint，int& outIndex，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	求中心线起点向前延伸dist距离后所在点及分段序号，如果目标点不在中心线上返回false，否则返回true。单位：像素。

参数: 

​	[ in ] dist: 中心线起点向前延伸的距离。

​	[ out ] outPoint: 中心线起点向前延伸dist距离后所在点。

​	[ out ] outIndex: 中心线起点向前延伸dist距离后所在分段序号。

**QPolygonF polygon()**

​	获取路段的多边型轮廓顶点。

#### 3.4.1.4.连接段（IConnector）

​	头文件: IConnector.h

**int gtype()**

​	类型，连接段类型为GConnectorType。

**long id()**

​	获取连接段ID。

**qreal length(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取连接段长度。单位：像素。

**qreal z(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取连接段高程。单位：像素。

**qreal v3z(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取连接段高程。单位：像素。

**QString name()**

​	获取连接段名称。

**void setName(QString name)**

​	设置连接段名称。

**ILink\* fromLink()**

​	获取起始路段。

**ILink\* toLink()**

​	获取目标路段。

**qreal limitSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取连接段最高限速。单位: km/h。

**qreal minSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取连接段最低限速。单位: km/h。

**QList\<ILaneConnector\*\> laneConnectors()**

​	获取车道连接列表。

**QList\<ILaneObject\*\> laneObjects()**

​	车道及车道连接的接口列表。

**void setLaneConnectorOtherAtrrs(QList\<QJsonObject\> lAttrs)**

​	设置包含的车道连接其它属性。

**void setOtherAttr(QJsonObject otherAttr)**

​	设置连接段其它属性。

**QPolygonF polygon()**

​	获取连接段的多边型轮廓顶点。

#### 3.4.1.5.车道基类（ILaneObject）

​	头文件: ILaneObject.h

​	车道基类是车道和车道连接的父类。

**int gtype()**

​	类型，GLaneType或GLaneConnectorType。

**bool isLane()**

​	是否是车道。

**long id()**

​	获取ID，如果是Lane，id是Lane的ID，如果是车道连接，id是车道连接ID。

**qreal length(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取长度。单位：像素。

**ISection\* section()**

​	获取所属的ISection。

**ILaneObject\* fromLaneObject(long id)**

​	通过ID获取上游 LaneObject。如果当前是车道，id 为 0 返回nullptr，否则返回上游指定ID的车道连接；如果当前是连接段，id 为 0 返回上游车道，否则返回nullptr。

**ILaneObject\* toLaneObject(long id)**

​	通过ID获取下游 LaneObject。如果当前是车道，id 为 0 返回nullptr，否则返回下游指定ID的车道连接；如果当前是连接段，id 为 0 返回下游车道，否则返回nullptr。

**QList\<QPointF\> centerBreakPoints(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取中心线断点集。单位：像素。

**QList\<QPointF\> leftBreakPoints(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取左侧线断点集。单位：像素。

**QList\<QPointF\> rightBreakPoints(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取右侧线断点集。单位：像素。

**QList\<QVector3D\> centerBreakPoint3Ds(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取中心线三维断点集。单位：像素。

**QList\<QVector3D\> leftBreakPoint3Ds(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取左侧线三维断点集。单位：像素。

**QList\<QVector3D\> rightBreakPoint3Ds(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取右侧线三维断点集。单位：像素。

**QList\<QVector3D\> leftBreak3DsPartly(QPointF fromPoint，QPointF toPoint，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取左侧部分三维断点集。单位：像素。

参数: 

​	[ in ] fromPoint: 中心线上某一点作为起点。

​	[ in ] toPoint: 中心线上某一点作为终点。

**QList\<QVector3D\> rightBreak3DsPartly(QPointF fromPoint，QPointF toPoint，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取右侧部分三维断点集。单位：像素。

参数: 

​	[ in ] fromPoint: 中心线上某一点作为起点。

​	[ in ] toPoint: 中心线上某一点作为终点。

**qreal distToStartPoint(const QPointF p，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	中心线上一点到起点距离。单位：像素。

参数: 

​	[ in ] p: 当前点坐标。

**qreal distToStartPointWithSegmIndex(const QPointF p，int segmIndex = 0，bool bOnCentLine = true，UnitOfMeasure unit = UnitOfMeasure: : Default)**

​	中心线上一点到起点距离，附加条件是该点所在车道上的分段序号。单位：像素。

参数: 

​	[ in ] p: 当前点坐标。

​	[ in ] segmIndex: 该点所在车道上的分段序号。

​	[ in ] bOnCentLine: 是否在中心线上。

**bool getPointAndIndexByDist(qreal dist，QPointF& outPoint，int& outIndex，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	求中心线起点向前延伸dist距离后所在点及分段序号，如果目标点不在中心线上返回false，否则返回true。单位：像素。

参数: 

​	[ in ] dist: 中心线起点向前延伸的距离。

​	[ out ] outPoint: 中心线起点向前延伸dist距离后所在点。

​	[ out ] outIndex: 中心线起点向前延伸dist距离后所在分段序号。

**bool getPointByDist(qreal dist，QPointF& outPoint，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	求中心线起点向前延伸dist距离后所在点，如果目标点不在中心线上返回false，否则返回true。单位：像素。

参数: 

​	[ in ] dist: 中心线起点向前延伸的距离。

​	[ out ] outPoint: 中心线起点向前延伸dist距离后所在点。

**void setOtherAttr(QJsonObject attr)**

​	设置车道或车道连接其它属性。

**ILane\* castToLane()**

​	将ILaneObject转换为ILane，如果当前ILaneObject是车道连接则返回nullptr。

**ILaneConnector\* castToLaneConnector()**

​	将ILaneObject转换为ILaneConnector，如果当前ILaneObject是车道则返回nullptr。

#### 3.4.1.6.车道（ILane）

​	头文件: ILane.h

**int gtype()**

​	类型，车道类型为GLaneType。

**long id()**

​	获取车道ID。

**ILink\* link()**

​	获取车道所在路段。

**ISection\* section()**

​	获取车道所属Section。

**qreal length(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取车道长度。单位：像素。

**qreal width(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取车道宽度。单位：像素。

**int number()**

​	获取车道序号，从0开始（自外侧往内侧，即自右向左依次编号）。

**QString actionType()**

​	获取车道的行为类型。

**QList\<ILaneConnector\*\> fromLaneConnectors()**

​	获取上游车道连接列表。

**QList\<ILaneConnector\*\> toLaneConnectors()**

​	获取下游车道连接列表。

**QList\<QPointF\> centerBreakPoints(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取车道中心线断点集。单位：像素。

**QList\<QPointF\> leftBreakPoints(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取车道左侧线断点集。单位：像素。

**QList\<QPointF\> rightBreakPoints(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取车道右侧线断点集。单位：像素。

**QList\<QVector3D\> centerBreakPoint3Ds(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取车道中心线三维断点集。单位：像素。

**QList\<QVector3D\> leftBreakPoint3Ds(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取车道左侧线三维断点集。单位：像素。

**QList\<QVector3D\> rightBreakPoint3Ds(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取车道右侧线三维断点集。单位：像素。

**QList\<QVector3D\> leftBreak3DsPartly(QPointF fromPoint，QPointF toPoint，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取左侧部分三维断点集。单位：像素。

参数: 

​	[ in ] fromPoint: 中心线上某一点作为起点。

​	[ in ] toPoint: 中心线上某一点作为终点。

**QList\<QVector3D\> rightBreak3DsPartly(QPointF fromPoint，QPointF toPoint，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取右侧部分三维断点集。单位：像素。

参数: 

​	[ in ] fromPoint: 中心线上某一点作为起点。

​	[ in ] toPoint: 中心线上某一点作为终点。

**qreal distToStartPoint(const QPointF p，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	中心线上一点到起点距离。单位：像素。

参数: 

​	[ in ] p: 当前点坐标。

**qreal distToStartPointWithSegmIndex(const QPointF p，int segmIndex = 0，bool bOnCentLine = true，UnitOfMeasure unit = UnitOfMeasure: : Default)**

​	中心线上一点到起点距离，附加条件是该点所在车道上的分段序号。单位：像素。

参数: 

​	[ in ] p: 当前中心线上该点坐标。

​	[ in ] segmIndex: 该点所在车道上的分段序号。

​	[ in ] bOnCentLine: 是否在中心线上。

**bool getPointAndIndexByDist(qreal dist，QPointF& outPoint，int& outIndex，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	求中心线起点向前延伸dist距离后所在点及分段序号，如果目标点不在中心线上返回false，否则返回true。单位：像素。

参数: 

​	[ in ] dist: 中心线起点向前延伸的距离。

​	[ out ] outPoint: 中心线起点向前延伸dist距离后所在点。

​	[ out ] outIndex: 中心线起点向前延伸dist距离后所在分段序号。

**bool getPointByDist(qreal dist，QPointF& outPoint，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	求中心线起点向前延伸dist距离后所在点，如果目标点不在中心线上返回false，否则返回true。单位：像素。

参数: 

​	[ in ] dist: 中心线起点向前延伸的距离。

​	[ out ] outPoint: 中心线起点向前延伸dist距离后所在点。

示例:

```cpp
// 获取距离路段起点一定距离的点位坐标
QPointF outPoint;
bool result = lane->getPointByDist(50，outPoint, UnitOfMeasure::Metric);
if(result)
{
    qreal x = outPoint.x();
    qreal y = outPoint.y();
}
```

**void setOtherAttr(QJsonObject attr)**

​	设置车道其它属性。

**void setLaneType(QString type)**

​	设置车道类型。

参数: 

​	[ in ] type: 车道类型，选下列几种类型其中一种: "机动车道"、"机非共享"、"非机动车道"、"公交专用道"。

示例:

```cpp
// 设置车道类型
lane->setLaneType("机动车道");
```

**QPolygonF polygon()**

​	获取车道的多边型轮廓顶点。

#### 3.4.1.7.车道连接（ILaneConnector）

​	头文件: ILaneConnector.h

**int gtype()**

​	类型，GLaneType或GLaneConnectorType，车道连接段为GLaneConnectorType。

**long id()**

​	获取车道连接ID。

**IConnector\* connector()**

​	获取车道连接所在连接段。

**ISection\* section()**

​	获取车道所属Section。

**ILane\* fromLane()**

​	上游车道。

**ILane\* toLane()**

​	下游车道。

**qreal length(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取车道连接长度。单位：像素。

**QList\<QPointF\> centerBreakPoints(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取车道连接中心线断点集。单位：像素。

**QList\<QPointF\> leftBreakPoints(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取车道连接左侧线断点集。单位：像素。

**QList\<QPointF\> rightBreakPoints(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取车道连接右侧线断点集。单位：像素。

**QList\<QVector3D\> centerBreakPoint3Ds(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取车道连接中心线三维断点集。单位：像素。

**QList\<QVector3D\> leftBreakPoint3Ds(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取车道连接左侧线三维断点集。单位：像素。

**QList\<QVector3D\> rightBreakPoint3Ds(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取车道连接右侧线三维断点集。单位：像素。

**QList\<QVector3D\> leftBreak3DsPartly(QPointF fromPoint，QPointF toPoint，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取车道连接左侧部分三维断点集。单位：像素。

参数: 

​	[ in ] fromPoint: 中心线上某一点作为起点。

​	[ in ] toPoint: 中心线上某一点作为终点。

**QList\<QVector3D\> rightBreak3DsPartly(QPointF fromPoint，QPointF toPoint，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取车道连接右侧部分三维断点集。单位：像素。

参数: 

​	[ in ] fromPoint: 中心线上某一点作为起点。

​	[ in ] toPoint: 中心线上某一点作为终点。

**qreal distToStartPoint(const QPointF p，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	中心线上一点到起点距离。单位：像素。

参数: 

​	[ in ] p: 当前点坐标。

**qreal distToStartPointWithSegmIndex(const QPointF p，int segmIndex，bool bOnCentLine，UnitOfMeasure unit = UnitOfMeasure: : Default)**

​	中心线上一点到起点距离，附加条件是该点所在车道上的分段序号。单位：像素。

参数: 

​	[ in ] p: 当前点坐标。

​	[ in ] segmIndex: 分段序号。

​	[ in ] bOnCentLine: 是否在中心线上。

**bool getPointAndIndexByDist(qreal dist，QPointF& outPoint，int& outIndex，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	求中心线起点向前延伸dist距离后所在点及分段序号，如果目标点不在中心线上返回false，否则返回true。单位：像素。

参数: 

​	[ in ] dist: 中心线起点向前延伸的距离。

​	[ out ] outPoint: 中心线起点向前延伸dist距离后所在点。

​	[ out ] outIndex: 中心线起点向前延伸dist距离后所在分段序号。

**bool getPointByDist(qreal dist，QPointF& outPoint，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	求中心线起点向前延伸dist距离后所在点，如果目标点不在中心线上返回false，否则返回true。单位：像素。

参数: 

​	[ in ] dist: 中心线起点向前延伸的距离。

​	[ out ] outPoint: 中心线起点向前延伸dist距离后所在点。

**void setOtherAttr(QJsonObject attr)**

​	设置车道连接其它属性。

#### 3.4.1.8.连接段面域（IConnectorArea）

​	头文件: IConnectorArea.h

**long id()**

​	面域ID，面域是指若干Connector重叠形成的区域。

**QList\<IConnector\*\> allConnector()**

​	面域相关所有连接段。

**QPointF centerPoint(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取面域中心点位置。单位：像素。

### 3.4.2.发车点

#### 3.4.2.1.发车点（IDispatchPoint）

​	头文件: IDispatchPoint.h

**long id()**

​	获取发车点ID。

**QString name()**

​	获取发车名称。

**ILink\* link()**

​	获取发车点所在路段。

**long addDispatchInterval(long vehiCompId，int interval，int vehiCount)**

​	为发车点增加发点间隔。

参数: 

​	[ in ] vehiCompId: 车型组成ID。

​	[ in ] interval: 时间段。单位: s。

​	[ in ] vehiCount: 发车数。

返回值: 

​	发车间隔ID。

**void setDynaModified(bool bModified)**

​	设置是否被动态修改，默认情况下发车信息被动态修改后，整个文件不能保存，以免破坏原有发车设置。

**QPolygonF polygon()**

​	获取发车点多边型轮廓的顶点。

### 3.4.3.决策点和车辆路径

#### 3.4.3.1.决策点（IDecisionPoint）

​	头文件: IDecisionPoint.h

**long id()**

​	决策点ID。

**QString name()**

​	决策点名称。

**ILink\* link()**

​	决策点所在路段。

**qreal distance(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取距路段起点距离。单位：像素。

**QList\<IRouting\*\> routings()**

​	相关决策路径。

**void setDynaModified(bool bModified)**

​	设置是否被动态修改，默认情况下发车信息被动态修改后，整个文件不能保存，以免破坏原有发车设置。

参数: 

​	[ in ] bModified: 是否被动态修改，true为被动态修改，false为未被动态修改。

**QPolygonF polygon()**

​	决策点多边型轮廓的顶点。

#### 3.4.3.2.车辆路径（IRouting）

​	头文件: IRouting.h

**long id()**

​	路径ID。

**qreal calcuLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	计算路径长度。单位：像素。

**QList\<ILink\*\> getLinks()**

​	获取路段序列。

**long deciPointId()**

​	所属决策点ID。

**bool contain(ISection\* pRoad)**

​	通过所给道路判断是否在当前路径上。

参数: 

​	[ in ] pRoad: 路段或连接段。

**ISection\* nextRoad(ISection\* pRoad)**

​	通过所给道路求下一条道路。

参数: 

​	[ in ] pRoad: 路段或连接段。

### 3.4.4.信号控制

#### 3.4.4.1.信号机（ISignalController）

​	头文件: ITrafficLight.h

**long id()**

​	获取信号机ID。

**QString name()**

​	获取信号机名称。

**void setName(const QString& name)**

​	设置信号机名称。

参数: 

​	[ in ] name: 新名称。

**void addPlan(ISignalPlan\* plan)**

​	添加信控方案。

参数: 

​	[ in ] plan: 信控方案。

**void removePlan(ISignalPlan\* plan)**

​	移除信控方案。

参数: 

​	[ in ] plan: 要移除的信控方案。

**QList\<ISignalPlan\*\> plans()**

​	获取所有信控方案。

**bool isValid()**

​	检查信号机的有效性。

#### 3.4.4.2.信号控制方案（ISignalPlan）

​	头文件: ISignalPlan.h

**long id()**

​	获取ID。

**QString Name()**

​	获取灯组名。

**QString trafficName()**

​	获取信控方案名称。

**int cycleTime()**

​	获取信号周期。单位: s。

**long fromTime()**

​	获取起始时间。单位: s。

**long toTime()**

​	获取结束时间。单位: s。

**QList\<ISignalPhase\*\> phases()**

​	获取相位列表。

**void setName(QString name)**

​	设置信控方案名称。

参数: 

​	[ in ] name: 新名称。

**void setcycleTime(int period)**

​	设置信号周期。单位: s。

参数: 

​	[ in ] period: 信号周期。单位: s。

**void setFromTime(long time)**

​	设置起始时间。单位: s。

参数: 

​	[ in ] time: 起始时间。单位: s。

**void setToTime(long time)**

​	设置结束时间。单位: s。

参数: 

​	[ in ] time: 结束时间。单位: s。

#### 3.4.4.3.信号灯相位（ISignalPhase）

​	头文件: ISignalPhase.h

**long id()**

​	相位ID。

**QString phaseName()**

​	相位名称。

**QList\<Online::ColorInterval\> listColor()**

​	获取相位灯色列表。

**void setColorList(QList\<Online::ColorInterval\> lColor)**

​	设置信号灯列表。

参数: 

​	[ in ] lColor: 灯色时长信息，包含信号灯颜色和信号灯时长。

示例:

```cpp
// 构建灯色和时长对象列表
QList<Online::ColorInterval> colorObjList = {
    Online::ColorInterval("R", 10),   // 红色，时长10
    Online::ColorInterval("G", 60),   // 绿色，时长60
    Online::ColorInterval("Y", 3),    // 黄色，时长3
    Online::ColorInterval("R", 17)    // 红色，时长17
};
// 查找ID为7的信号灯相位
auto signalPhase = netiface->findSignalPhase(7);
if (signalPhase) 
{
    // 设置灯色列表
    signalPhase->setColorList(colorObjList);
}
```

**int cycleTime()**

​	获取相位周期。单位: s。

**Online::SignalPhaseColor phaseColor()**

​	获取当前相位灯色。

**ISignalPlan\* signalPlan()**

​	获取相位所在信控方案。

**QList\<ISignalLamp\*\> signalLamps()**

​	获取相关信号灯列表。

**void setPhaseName(QString name)**

​	设置相位名称。

参数: 

​	[ in ] name: 新名称。

#### 3.4.4.4.信号灯灯头（ISignalLamp）

​	头文件: isignallamp.h

**long id()**

​	获取信号灯ID。

**void setSignalPhase(ISignalPhase\* pPhase)**

​	设置相位，所设相位可以是其它信号灯组的相位。

参数: 

​	[ in ] pPhase: 相位。

**void setPhaseNumber(int num)**

​	设置相位序号，序号从1开始，如果num序号大于相位总数不进行设置。

**void setLampColor(QString colorStr)**

​	设置信号灯颜色。

参数: 

​	[ in ] colorStr: 字符串表达的颜色，有四种可选，分别是"红"、"绿"、"黄"、"灰"，或者是"R"、"G"、"Y"、"grey"。 

**QString color()**

​	获取信号灯色，"R"、“G”、“Y”、“gray”分别表示"红"、"绿"、"黄"、"灰"。

**QString name()**

​	获取信号灯名称。

**void setName(QString name)**

​	设置信号灯名称。

**void setDistToStart(qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置信号灯距路段起点距离。单位：像素。

参数: 

​	[ in ] dist: 距离值。

**ISignalPlan\* signalPlan()**

​	获取信控方案。

**ISignalPhase\* signalPhase()**

​	获取相位。

**ILaneObject\* laneObject()**

​	获取所在车道或车道连接。

**QPolygonF polygon()**

​	获取信号灯多边型轮廓的顶点。

**qreal angle()**

​	获取信号灯角度。

### 3.4.5.采集设备

#### 3.4.5.1.数据采集器（IVehicleDrivInfoCollector）

​	头文件: IVehicleDrivInfoCollector.h

**long id()**

​	获取采集器ID。

**QString collName()**

​	获取采集器名称。

**bool onLink()**

​	是否在路段上，如果true则connector()返回nullptr。

**ILink\* link()**

​	采集器所在路段。

**IConnector\* connector()**

​	采集器所在连接段。

**ILane\* lane()**

​	如果采集器在路段上返回所在车道，否则返回nullptr。

**ILaneConnector\* laneConnector()**

​	如果采集器在连接段上则返回车道连接，否则返回nullptr。

**qreal distToStart(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取采集器距路段起点距离。单位：像素。

**QPointF point(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取采集器位置坐标。单位：像素。

**long fromTime()**

​	采集器工作起始时间。单位: s。

**long toTime()**

​	采集器工作停止时间。单位: s。

**long aggregateInterval()**

​	集计数据时间间隔。单位: s。

**void setName(QString name)**

​	设置采集器名称。

**void setDistToStart(qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置采集器距路段起点距离。单位：像素。

参数: 

​	[ in ] dist: 距离值。

**void setFromTime(long time)**

​	设置采集器工作起始时间。单位: s。

参数: 

​	[ in ] time: 工作起始时间。单位: s。

**void setToTime(long time)**

​	设置采集器工作结束时间。单位: s。

参数: 

​	[ in ] time: 工作结束时间。单位: s。

**void setAggregateInterval(int interval)**

​	设置采集器集计数据时间间隔。单位: s。

**QPolygonF polygon()**

​	获取采集器的多边型轮廓顶点。

#### 3.4.5.2.排队计数器（IVehicleQueueCounter）

​	头文件: IVehicleQueueCounter.h

**long id()**

​	获取计数器ID。

**QString counterName()**

​	获取计数器名称。

**bool onLink()**

​	是否在路段上，如果true则connector()返回nullptr。

**ILink\* link()**

​	计数器所在路段。

**IConnector\* connector()**

​	计数器所在连接段。

**ILane\* lane()**

​	如果计数器在路段上返回所在车道，否则返回nullptr。

**ILaneConnector\* laneConnector()**

​	如果计数器在连接段上返回车道连接，否则返回nullptr。

**qreal distToStart(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取计数器距路段起点距离。单位：像素。

**QPointF point(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取计数器位置坐标。单位：像素。

**long fromTime()**

​	计数器工作起始时间。单位: s。

**long toTime()**

​	计数器工作停止时间。单位: s。

**long aggregateInterval()**

​	计数集计数据时间间隔。单位: s。

**void setName(QString name)**

​	设置计数器名称。

参数: 

​	[ in ] name: 计数器名称。

**void setDistToStart(qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置计数器距路段起点距离。单位：像素。

参数: 

​	[ in ] dist: 距离值。

**void setFromTime(long time)**

​	设置工作起始时间。单位: s。

**void setToTime(long time)**

​	设置工作结束时间。单位: s。

**void setAggregateInterval(int interval)**

​	设置集计数据时间间隔。单位: s。

**QPolygonF polygon()**

​	获取计数器的多边型轮廓顶点。

#### 3.4.5.3.行程时间检测器（IVehicleTravelDetector）

​	头文件: IVehicleTravelDetector.h

**long id()**

​	获取检测器ID。

**QString detectorName()**

​	获取检测器名称。

**bool isStartDetector()**

​	是否检测器起始点。

**bool isOnLink_startDetector()**

​	检测器起点是否在路段上，如果否，则起点在连接段上。

**bool isOnLink_endDetector()**

​	检测器终点是否在路段上，如果否，则终点在连接段上。

**ILink\* link_startDetector()**

​	如果检测器起点在路段上则返回起点所在路段，否则返回nullptr。

**ILaneConnector\* laneConnector_startDetector()**

​	如果检测器起点在连接段上返回起点车道连接，否则返回nullptr。

**ILink\* link_endDetector()**

​	如果检测器终点在路段上返回终点所在路段，否则返回nullptr。

**ILaneConnector\* laneConnector_endDetector()**

​	如果检测器终点在连接段上返回终点车道连接，否则返回nullptr。

**qreal distance_startDetector(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取起点检测器距路段起点距离。单位：像素。

**qreal distance_endDetector(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取终点检测器距路段起点距离。单位：像素。

**QPointF point_startDetector(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取起点检测器位置坐标。单位：像素。

**QPointF point_endDetector(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取终点检测器位置坐标。单位：像素。

**long fromTime()**

​	检测器工作起始时间。单位: s。

**long toTime()**

​	检测器工作停止时间。单位: s。

**long aggregateInterval()**

​	集计数据时间间隔。单位: s。

**void setName(QString name)**

​	设置检测器名称。

**void setDistance_startDetector(qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置起点检测器距路段起点距离。单位：像素。

参数: 

​	[ in ] dist: 距离值。

**void setDistance_endDetector(qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置终点检测器距路段起点距离。单位：像素。

参数: 

​	[ in ] dist: 距离值。

**void setFromTime(long time)**

​	设置检测器工作起始时间。单位: s。

参数: 

​	[ in ] time: 工作起始时间。单位: s。

**void setToTime(long time)**

​	设置检测器工作结束时间。单位: s。

参数: 

​	[ in ] time: 工作结束时间。单位: s。

**void setAggregateInterval(int interval)**

​	设置检测器集计数据时间间隔。单位: s。

参数: 

​	[ in ] interval: 集计数据时间间隔。单位: s。

**QPolygonF polygon_startDetector()**

​	获取行程时间检测器起始点多边型轮廓的顶点。

**QPolygonF polygon_endDetector()**

​	获取行程时间检测器终止点多边型轮廓的顶点。

### 3.4.6.导向箭头

#### 3.4.6.1.导向箭头（IGuidArrow）

​	头文件: IGuidArrow.h

**long id()**

​	获取导向箭头ID。

**ILane\* lane()**

​	获取导向箭头所在的车道。

**qreal length(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取导向箭头长度。单位：像素。

**qreal distToTerminal(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取导向箭头到终点距离。单位：像素。

**Online::GuideArrowType arrowType()**

​	获取导向箭头的类型，导向箭头的类型分为: 直行、左转、右转、直行或左转、直行或右转、直行左转或右转、左转或右转、掉头、直行或掉头和左转或掉头。

**QPolygonF polygon()**

​	获取导向箭头的多边型轮廓的顶点。

### 3.4.7.公交系统

#### 3.4.7.1.公交线路（IBusLine）

​	头文件: IBusLine.h

**long id()**

​	获取公交线路ID。

**QString name()**

​	线路名称。

**qreal length(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取公交线路长度。单位：像素。

**int dispatchFreq()**

​	发车间隔。单位: s。

**int dispatchStartTime()**

​	发车开始时间。单位: s。

**int dispatchEndTime()**

​	发车结束时间。单位: s。

**qreal desirSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取公交线路期望速度。单位: 像素/s。

**int passCountAtStartTime()**

​	起始载客人数。

**QList\<ILink\*\> links()**

​	公交线路经过的路段。

**QList\<IBusStation\*\> stations()**

​	线路所有站点。

**QList\<IBusStationLine\*\> stationLines()**

​	公交站点线路，当前线路相关站点的上下客等参数。

**void setName(QString name)**

​	设置线路名称。

**void setDispatchFreq(int freq)**

​	设置当前公交线路的发车间隔。单位: s。

参数: 

​	[ in ] freq: 发车间隔。单位: s。

**void setDispatchStartTime(int startTime)**

​	设置当前公交线路上的公交首班车辆的开始发车时间。单位: s。

参数: 

​	[ in ] startTime: 开始发车时间。单位: s。

**void setDispatchEndTime(int endTime)**

​	设置当前公交线路上的公交末班车辆的结束发车时间。单位: s。

参数: 

​	[ in ] endTime: 结束发车时间。单位: s。

**void setDesirSpeed(qreal speed，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置当前公交线路的期望速度。单位: 像素/s。

参数: 

​	[ in ] speed: 速度值。

**void setPassCountAtStartTime(int count)**

​	设置起始载客人数。

#### 3.4.7.2.公交站点（IBusStation）

​	头文件: IBusStation.h

**long id()**

​	获取公交站点ID。

**QString name()**

​	获取公交站点名称。

**int laneNumber()**

​	获取公交站点所在车道序号。

**qreal x(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取站点X坐标。单位：像素。

**qreal y(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取站点Y坐标。单位：像素。

**qreal length(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取站点长度。单位：像素。

**int stationType()**

​	站点类型，1: 路边式、2: 港湾式。

**ILink\* link()**

​	公交站点所在路段。

**ILane\* lane()**

​	公交站点所在车道。

**qreal distance(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取站点距路段起点距离。单位：像素。

**void setName(QString name)**

​	设置站点名称。

参数: 

​	[ in ] name: 新名称。

**void setDistToStart(qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置站点距路段起点距离。单位：像素。

参数: 

​	[ in ] dist: 距离值。

**void setLength(qreal length，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置站点长度。单位：像素。

参数: 

​	[ in ] length: 长度值。

**void setType(int type)**

​	设置站点类型。

参数: 

​	[ in ] type: 站点类型，1 路侧式、2 港湾式。

**QPolygonF polygon()**

​	公交站点多边型轮廓的顶点。

#### 3.4.7.3.公交站点-线路（IBusStationLine）

​	头文件: IBusStationLine.h

**long id()**

​	获取公交"站点-线路"ID。

**long stationId()**

​	公交站点ID。

**long lineId()**

​	公交线路ID。

**int busParkingTime()**

​	车辆停靠时间。单位: s。

**qreal getOutPercent()**

​	下客百分比。

**qreal getOnTimePerPerson()**

​	平均每位乘客上车时间。单位: s。

**qreal getOutTimePerPerson()**

​	平均每位乘客下车时间。单位: s。

**void setBusParkingTime(int time)**

​	设置车辆停靠时间。

参数: 

​	[ in ] time: 车辆停靠时间。单位: s。

**void setGetOutPercent(qreal percent)**

​	设置下客百分比。

参数: 

​	[ in ] percent: 下客百分比。

**void setGetOnTimePerPerson(qreal time)**

​	设置平均每位乘客上车时间。

参数: 

​	[ in ] time: 平均每位乘客上车时间。单位: s。

**void setGetOutTimePerPerson(qreal time)**

​	设置平均每位乘客下车时间。

参数: 

​	[ in ] time: 平均每位乘客下车时间。单位: s。

### 3.4.8.事件区域

#### 3.4.8.1.事故区（IAccidentZone）

​	头文件: IAccidentZone.h

**long id()**

​	获取事故区ID。

**QString name()**

​	获取事故区名称。

**qreal location(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取事故区当前时段距所在路段起点的距离。单位：像素。

**qreal zoneLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取事故区当前时段长度。单位：像素。

**qreal limitedSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取事故区当前时段限速。单位：像素(km/h)。

**ISection\* section()**

​	获取事故区所在的路段或连接段。

**long roadId()**

​	获取事故区所在路段的ID。

**QString roadType()**

​	获取事故区所在的道路类型(路段或连接段)。

**QList\<ILaneObject\*\> laneObjects()**

​	获取事故区当前时段占用的车道列表。

**qreal controlLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取事故区当前时段控制距离（车辆距离事故区起点该距离内，强制变道）。单位：像素。

**IAccidentZoneInterval\* addAccidentZoneInterval(Online::DynaAccidentZoneIntervalParam param)**

​	添加事故时段。

参数: 

​	[ in ] param: 事故时段参数。

**void removeAccidentZoneInterval(long accidentZoneIntervalId)**

​	移除事故时段。

参数: 

​	[ in ] accidentZoneIntervalId: 事故时段ID。

**bool updateAccidentZoneInterval(Online::DynaAccidentZoneIntervalParam param)**

​	更新事故时段。

参数: 

​	[ in ] param: 事故时段参数。

**QList\<IAccidentZoneInterval\*\> accidentZoneIntervals()**

​	获取所有事故时段。

**IAccidentZoneInterval\* findAccidentZoneIntervalById(long accidentZoneIntervalId)**

​	通过ID查询事故时段。

参数: 

​	[ in ] accidentZoneIntervalId: 事故时段ID。

**IAccidentZoneInterval\* findAccidentZoneIntervalByStartTime(long startTime)**

​	通过开始时间查询事故时段。

参数: 

​	[ in ] startTime: 事故时段开始时间。

#### 3.4.8.2.事故区时段（IAccidentZoneInterval）

​	头文件: IAccidentZoneInterval.h

**long intervalId()**

​	获取事故时段ID。

**long accidentZoneId()**

​	获取所属事故区ID。

**long startTime()**

​	获取事故时段开始时间。

**long endTime()**

​	获取事故时段结束时间。

**qreal length(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取事故区在该时段的长度。单位：像素。

**qreal location(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取事故区在该时段的距起点距离。单位：像素。

**qreal limitedSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取事故区在该时段的限速。单位: 像素(km/h)。

**qreal controlLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取事故区在该时段的控制距离（车辆距离事故区起点该距离内，强制变道）。单位：像素。

**QList\<int\> laneNumbers()**

​	获取事故区在该时段的占用车道序号。

#### 3.4.8.3.施工区（IRoadWorkZone）

​	头文件: IRoadWorkZone.h

**long id()**

​	获取施工区ID。

**QString name()**

​	获取施工区名称。

**qreal location(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取施工区距所在路段起点的距离。单位：像素。

**qreal zoneLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取施工区长度。单位：像素。

**qreal limitSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取施工区限速。单位: 像素（km/h）。

**long sectionId()**

​	获取施工区所在路段或连接段的ID。

**QString sectionName()**

​	获取施工区所在路段或连接段的名称。

**QString sectionType()**

​	获取施工区所在道路的道路类型，link: 路段，connector: 连接段。

**QList\<ILaneObject\*\> laneObjects()**

​	获取施工区所占的车道列表。

**QList\<long\> laneObjectIds()**

​	获取施工区所占的车道ID列表。

**qreal upCautionLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取施工区上游警示区长度。单位：像素。

**qreal upTransitionLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取施工区上游过渡区长度。单位：像素。

**qreal upBufferLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取施工区上游缓冲区长度。单位：像素。

**qreal downTransitionLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取施工区下游过渡区长度。单位：像素。

**qreal downTerminationLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取施工区下游终止区长度。单位：像素。

**long duration()**

​	施工持续时间，自仿真过程创建后，持续时间大于此值，则移除。单位: s。

**bool isBorrowed()**

​	获取施工区是否被借道。

#### 3.4.8.4.限行区（ILimitedZone）

​	头文件: ILimitedZone.h

**long id()**

​	获取限行区ID。

**QString name()**

​	获取限行区名称。

**qreal location(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取限行区距所在路段起点的距离。单位：像素。

**qreal zoneLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取限行区长度。单位：像素。

**qreal limitSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取限行区限速，单位: 像素(km/h)。

**long sectionId()**

​	获取路段或连接段ID。

**QString sectionName()**

​	获取Section名称。

**QString sectionType()**

​	获取道路类型，"link"表示路段，"connector"表示连接段。

**QList\<ILaneObject\*\> laneObjects()**

​	获取相关车道对象列表。

**long duration()**

​	获取限行持续时间，自仿真过程创建后，持续时间大于此值则删除。单位: s。

#### 3.4.8.5.改扩建借道（IReconstruction）

​	头文件: IReconstruction.h

**long id()**

​	获取改扩建ID。

**long roadWorkZoneId()**

​	获取改扩建起始施工区ID。

**long limitedZoneId()**

​	获取被借道限行区ID。

**qreal passagewayLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取保通长度。单位：像素。

**long duration()**

​	获取改扩建持续时间。

**int borrowedNum()**

​	获取借道数量。

**qreal passagewayLimitedSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取保通开口限速。单位: 像素（km/h）。

**Online::DynaReconstructionParam dynaReconstructionParam()**

​	获取改扩建动态参数。

#### 3.4.8.6.限速区（IReduceSpeedArea）

​	头文件: IReduceSpeedArea.h

**long id()**

​	获取限速区ID。

**QString name()**

​	获取限速区名称。

**qreal location(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取距起点距离。单位：像素。

**qreal areaLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取限速区长度。单位：像素。

**long sectionId()**

​	获取路段或连接段ID。

**int laneNumber()**

​	获取车道序号。

**int toLaneNumber()**

​	获取目标车道序号。

**IReduceSpeedInterval\* addReduceSpeedInterval(Online::DynaReduceSpeedIntervalParam param)**

​	添加限速时段。

参数: 

​	[ in ] param: 限速时段参数。

**void removeReduceSpeedInterval(long id)**

​	移除限速时段。

参数: 

​	[ in ] id: 限速时段ID。

**bool updateReduceSpeedInterval(Online::DynaReduceSpeedIntervalParam param)**

​	更新限速时段。

参数: 

​	[ in ] param: 限速时段参数。

**QList\<IReduceSpeedInterval\*\> reduceSpeedIntervals()**

​	获取限速时段列表。

**IReduceSpeedInterval\* findReduceSpeedIntervalById(long id)**

​	通过ID获取限速时段。

参数: 

​	[ in ] id: 限速时段ID。

**IReduceSpeedInterval\* findReduceSpeedIntervalByStartTime(long startTime)**

​	通过起始时间获取限速时段。

参数: 

​	[ in ] startTime: 起始时间。

**QPolygonF polygon()**

​	获取多边型轮廓。

#### 3.4.8.7.限速时段（IReduceSpeedInterval）

​	头文件: IReduceSpeedInterval.h

**long id()**

​	获取限速时段ID。

**long reduceSpeedAreaId()**

​	获取所属限速区ID。

**long intervalStartTime()**

​	获取开始时间。

**long intervalEndTime()**

​	获取结束时间。

**IReduceSpeedVehiType\* addReduceSpeedVehiType(Online::DynaReduceSpeedVehiTypeParam param)**

​	添加限速车型。

参数: 

​	[ in ] param: 限速车型参数。

**void removeReduceSpeedVehiType(long id)**

​	移除限速车型。

参数: 

​	[ in ] id: 限速车型ID。

**bool updateReduceSpeedVehiType(Online::DynaReduceSpeedVehiTypeParam param)**

​	更新限速车型。

参数: 

​	[ in ] param: 限速车型参数。

**QList\<IReduceSpeedVehiType\*\> reduceSpeedVehiTypes()**

​	获取本时段限速车型及限速参数列表。

**IReduceSpeedVehiType\* findReduceSpeedVehiTypeById(long id)**

​	通过id获取限速车型。

参数: 

​	[ in ] id: 限速车型ID。

**IReduceSpeedVehiType\* findReduceSpeedVehiTypeByCode(long vehicleTypeCode)**

​	通过车型代码获取限速车型。

参数: 

​	[ in ] vehicleTypeCode: 车型代码。

#### 3.4.8.8.限速车型（IReduceSpeedVehiType）

​	头文件: IReduceSpeedVehiType.h

**long id()**

​	获取限速车型ID。

**long intervalId()**

​	获取所属限速时段ID。

**long reduceSpeedAreaId()**

​	获取所属限速区ID。

**long vehiTypeCode()**

​	获取车型编码。

**qreal averageSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取平均车速。单位: 像素/s。

**qreal speedStandardDeviation(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取车速标准差。单位: 像素/s。

### 3.4.9.行人模块

#### 3.4.9.1.障碍物面域（IObstacleRegion）

​	头文件: IObstacleRegion.h

**bool isObstacle() const**

​	获取面域是否为障碍物。

**void setObstacle(bool b)**

​	设置面域是否为障碍物。

参数: 

​	[ in ] b: 是否为障碍物。

#### 3.4.9.2.乘客面域（IPassengerRegion）

​	头文件: IPassengerRegion.h

**bool isBoardingArea() const**

​	获取面域是否为上客区域。

**void setIsBoardingArea(bool b)**

​	设置面域是否为上客区域。

**bool isAlightingArea() const**

​	获取面域是否为下客区域。

**void setIsAlightingArea(bool b)**

​	设置面域是否为下客区域。

#### 3.4.9.3.行人路径面域基类（IPedestrianPathRegionBase）

​	头文件: IPedestrianPathRegionBase.h

**long getId() const**

​	获取面域ID。

**QString getName() const**

​	获取面域名称。

**void setName(QString name)**

​	设置面域名称。

**QColor getRegionColor() const**

​	获取面域颜色。

**void setRegionColor(QColor color)**

​	设置面域颜色。

**QPointF getPosition(UnitOfMeasure unit = UnitOfMeasure::Default) const**

​	获取面域位置。单位：像素。

**void setPosition(QPointF scenePos，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**int getGType() const**

​	获取面域类型。

#### 3.4.9.4.行人面域（IPedestrianRegion）

​	头文件: IPedestrianRegion.h

**long getId() const**

​	获取面域ID。

**QString getName() const**

​	获取面域名称。

**void setName(QString name)**

​	设置面域名称。

**QColor getRegionColor() const**

​	获取面域颜色。

**void setRegionColor(QColor color)**

​	设置面域颜色。

**QPointF getPosition(UnitOfMeasure unit = UnitOfMeasure::Default) const**

​	获取面域位置。单位：像素。

**void setPosition(QPointF scenePos，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**int getGType() const**

​	获取面域类型。

**qreal getExpectSpeedFactor() const**

​	获取期望速度系数。

**void setExpectSpeedFactor(qreal val)**

​	设置期望速度系数。

参数: 

​	[ in ] val: 期望速度系数。

**qreal getElevation() const**

​	获取面域高程。

**void setElevation(qreal elevation)**

​	设置面域高程。

参数: 

​	[ in ] elevation: 高程。

**QPolygonF getPolygon() const**

​	获取面域多边形。

**long getLayerId() const**

​	获取面域所在图层ID。

**void setLayerId(long id)**

​	设置面域所在图层，如果图层ID非法，则不做任何改变。

参数: 

​	[ in ] id: 图层ID。

#### 3.4.9.5.矩形行人面域（IPedestrianRectRegion）

​	头文件: IPedestrianRectRegion.h

**long getId() const**

​	获取面域ID。

**QString getName() const**

​	获取面域名称。

**void setName(QString name)**

​	设置面域名称。

**QColor getRegionColor() const**

​	获取面域颜色。

**void setRegionColor(QColor color)**

​	设置面域颜色。

**QPointF getPosition(UnitOfMeasure unit = UnitOfMeasure::Default) const**

​	获取面域位置。单位：像素。

**void setPosition(QPointF scenePos，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**int getGType() const**

​	获取面域类型。

**qreal getExpectSpeedFactor() const**

​	获取期望速度系数。

**void setExpectSpeedFactor(qreal val)**

​	设置期望速度系数。

**qreal getElevation() const**

​	获取面域高程。

**void setElevation(qreal elevation)**

​	设置面域高程。

**QPolygonF getPolygon() const**

​	获取面域多边形。

**long getLayerId() const**

​	获取面域所在图层ID。

**void setLayerId(long id)**

​	设置面域所在图层，如果图层ID非法，则不做任何改变。

**bool isObstacle() const**

​	获取面域是否为障碍物。

**void setObstacle(bool b)**

​	设置面域是否为障碍物。

**bool isBoardingArea() const**

​	获取面域是否为上客区域。

**void setIsBoardingArea(bool b)**

​	设置面域是否为上客区域。

**bool isAlightingArea() const**

​	获取面域是否为下客区域。

**void setIsAlightingArea(bool b)**

​	设置面域是否为下客区域。

#### 3.4.9.6.三角形行人面域（IPedestrianTriangleRegion）

​	头文件: IPedestrianTriangleRegion.h

**long getId() const**

​	获取面域ID。

**QString getName() const**

​	获取面域名称。

**void setName(QString name)**

​	设置面域名称。

**QColor getRegionColor() const**

​	获取面域颜色。

**void setRegionColor(QColor color)**

​	设置面域颜色。

**QPointF getPosition(UnitOfMeasure unit = UnitOfMeasure::Default) const**

​	获取面域位置。单位：像素。

**void setPosition(QPointF scenePos，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**int getGType() const**

​	获取面域类型。

**qreal getExpectSpeedFactor() const**

​	获取期望速度系数。

**void setExpectSpeedFactor(qreal val)**

​	设置期望速度系数。

**qreal getElevation() const**

​	获取面域高程。

**void setElevation(qreal elevation)**

​	设置面域高程。

**QPolygonF getPolygon() const**

​	获取面域多边形。

**long getLayerId() const**

​	获取面域所在图层ID。

**void setLayerId(long id)**

​	设置面域所在图层，如果图层ID非法，则不做任何改变。

**bool isObstacle() const**

​	获取面域是否为障碍物。

**void setObstacle(bool b)**

​	设置面域是否为障碍物。

**bool isBoardingArea() const**

​	获取面域是否为上客区域。

**void setIsBoardingArea(bool b)**

​	设置面域是否为上客区域。

**bool isAlightingArea() const**

​	获取面域是否为下客区域。

**void setIsAlightingArea(bool b)**

​	设置面域是否为下客区域。

#### 3.4.9.7.椭圆形行人面域（IPedestrianEllipseRegion）

​	头文件: IPedestrianEllipseRegion.h

**long getId() const**

​	获取面域ID。

**QString getName() const**

​	获取面域名称。

**void setName(QString name)**

​	设置面域名称。

**QColor getRegionColor() const**

​	获取面域颜色。

**void setRegionColor(QColor color)**

​	设置面域颜色。

**QPointF getPosition(UnitOfMeasure unit = UnitOfMeasure::Default) const**

​	获取面域位置。单位：像素。

**void setPosition(QPointF scenePos，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**int getGType() const**

​	获取面域类型。

**qreal getExpectSpeedFactor() const**

​	获取期望速度系数。

**void setExpectSpeedFactor(qreal val)**

​	设置期望速度系数。

**qreal getElevation() const**

​	获取面域高程。

**void setElevation(qreal elevation)**

​	设置面域高程。

**QPolygonF getPolygon() const**

​	获取面域多边形。

**long getLayerId() const**

​	获取面域所在图层ID。

**void setLayerId(long id)**

​	设置面域所在图层，如果图层ID非法，则不做任何改变。

**bool isObstacle() const**

​	获取面域是否为障碍物。

**void setObstacle(bool b)**

​	设置面域是否为障碍物。

**bool isBoardingArea() const**

​	获取面域是否为上客区域。

**void setIsBoardingArea(bool b)**

​	设置面域是否为上客区域。

**bool isAlightingArea() const**

​	获取面域是否为下客区域。

**void setIsAlightingArea(bool b)**

​	设置面域是否为下客区域。

#### 3.4.9.8.扇形行人面域（IPedestrianFanShapeRegion）

​	头文件: IPedestrianFanShapeRegion.h

**long getId() const**

​	获取面域ID。

**QString getName() const**

​	获取面域名称。

**void setName(QString name)**

​	设置面域名称。

**QColor getRegionColor() const**

​	获取面域颜色。

**void setRegionColor(QColor color)**

​	设置面域颜色。

**QPointF getPosition(UnitOfMeasure unit = UnitOfMeasure::Default) const**

​	获取面域位置。单位：像素。

**void setPosition(QPointF scenePos，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**int getGType() const**

​	获取面域类型。

**qreal getExpectSpeedFactor() const**

​	获取期望速度系数。

**void setExpectSpeedFactor(qreal val)**

​	设置期望速度系数。

**qreal getElevation() const**

​	获取面域高程。

**void setElevation(qreal elevation)**

​	设置面域高程。

**QPolygonF getPolygon() const**

​	获取面域多边形。

**long getLayerId() const**

​	获取面域所在图层ID。

**void setLayerId(long id)**

​	设置面域所在图层，如果图层ID非法，则不做任何改变。

**bool isObstacle() const**

​	获取面域是否为障碍物。

**void setObstacle(bool b)**

​	设置面域是否为障碍物。

**bool isBoardingArea() const**

​	获取面域是否为上客区域。

**void setIsBoardingArea(bool b)**

​	设置面域是否为上客区域。

**bool isAlightingArea() const**

​	获取面域是否为下客区域。

**void setIsAlightingArea(bool b)**

​	设置面域是否为下客区域。

**qreal getInnerRadius() const**

​	获取内半径，单位: 米。

**qreal getOuterRadius() const**

​	获取外半径，单位: 米。

**qreal getStartAngle() const**

​	获取起始角度，单位: 度。

**qreal getSweepAngle() const**

​	获取扫过角度，单位: 度。

#### 3.4.9.9.多边形行人面域（IPedestrianPolygonRegion）

​	头文件: IPedestrianPolygonRegion.h

**long getId() const**

​	获取面域ID。

**QString getName() const**

​	获取面域名称。

**void setName(QString name)**

​	设置面域名称。

**QColor getRegionColor() const**

​	获取面域颜色。

**void setRegionColor(QColor color)**

​	设置面域颜色。

**QPointF getPosition(UnitOfMeasure unit = UnitOfMeasure::Default) const**

​	获取面域位置。单位：像素。

**void setPosition(QPointF scenePos，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**int getGType() const**

​	获取面域类型。

**qreal getExpectSpeedFactor() const**

​	获取期望速度系数。

**void setExpectSpeedFactor(qreal val)**

​	设置期望速度系数。

**qreal getElevation() const**

​	获取面域高程。

**void setElevation(qreal elevation)**

​	设置面域高程。

**QPolygonF getPolygon() const**

​	获取面域多边形。

**long getLayerId() const**

​	获取面域所在图层ID。

**void setLayerId(long id)**

​	设置面域所在图层，如果图层ID非法，则不做任何改变。

**bool isObstacle() const**

​	获取面域是否为障碍物。

**void setObstacle(bool b)**

​	设置面域是否为障碍物。

**bool isBoardingArea() const**

​	获取面域是否为上客区域。

**void setIsBoardingArea(bool b)**

​	设置面域是否为上客区域。

**bool isAlightingArea() const**

​	获取面域是否为下客区域。

**void setIsAlightingArea(bool b)**

​	设置面域是否为下客区域。

#### 3.4.9.10.人行道行人面域（IPedestrianSIDeWalkRegion）

​	头文件: IPedestrianSideWalkRegion.h

**long getId() const**

​	获取面域ID。

**QString getName() const**

​	获取面域名称。

**void setName(QString name)**

​	设置面域名称。

参数: 

​	[ in ] name: 新名称。

**QColor getRegionColor() const**

​	获取面域颜色。

**void setRegionColor(QColor color)**

​	设置面域颜色。

参数: 

​	[ in ] color: 面域颜色。

**QPointF getPosition(UnitOfMeasure unit = UnitOfMeasure::Default) const**

​	获取面域位置。单位：像素。

**void setPosition(QPointF scenePos，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**int getGType() const**

​	获取面域类型。

**qreal getExpectSpeedFactor() const**

​	获取期望速度系数。

**void setExpectSpeedFactor(qreal val)**

​	设置期望速度系数。

**qreal getElevation() const**

​	获取面域高程。

**void setElevation(qreal elevation)**

​	设置面域高程。

**QPolygonF getPolygon() const**

​	获取面域多边形。

**long getLayerId() const**

​	获取面域所在图层ID。

**void setLayerId(long id)**

​	设置面域所在图层，如果图层ID非法，则不做任何改变。

参数: 

​	[ in ] id: 图层ID。

**qreal getWidth() const**

​	获取人行道宽度。

**void setWidth(qreal width)**

​	设置人行道宽度。

参数: 

​	[ in ] width: 人行道宽度，单位: m。

**QList\<QGraphicsEllipseItem\*\> getVetexs() const**

​	获取人行道顶点，即初始折线顶点。

**QList\<QGraphicsEllipseItem\*\> getControl1Vetexs() const**

​	获取人行道贝塞尔曲线控制点P1。

**QList\<QGraphicsEllipseItem\*\> getControl2Vetexs() const**

​	获取人行道贝塞尔曲线控制点P2。

**QList\<QGraphicsEllipseItem\*\> getCandidateVetexs() const**

​	获取候选顶点。

**void removeVetex(int index)**

​	删除第index个顶点。

参数: 

​	[ in ] index: 顶点索引。

**void insertVetex(QPointF pos，int index)**

​	在第index个位置插入顶点，初始位置为pos。

参数: 

​	[ in ] pos: 顶点位置。

​	[ in ] index: 插入位置。

#### 3.4.9.11.人行横道行人面域（IPedestrianCrossWalkRegion）

​	头文件: IPedestrianCrossWalkRegion.h

**long getId() const**

​	获取面域ID。

**QString getName() const**

​	获取面域名称。

**void setName(QString name)**

​	设置面域名称。

参数: 

​	[ in ] name: 新名称。

**QColor getRegionColor() const**

​	获取面域颜色。

**void setRegionColor(QColor color)**

​	设置面域颜色。

参数: 

​	[ in ] color: 面域颜色。

**QPointF getPosition(UnitOfMeasure unit = UnitOfMeasure::Default) const**

​	获取面域位置。单位：像素。

**void setPosition(QPointF scenePos，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**int getGType() const**

​	获取面域类型。

**qreal getExpectSpeedFactor() const**

​	获取期望速度系数。

**void setExpectSpeedFactor(qreal val)**

​	设置期望速度系数。

**qreal getElevation() const**

​	获取面域高程。

**void setElevation(qreal elevation)**

​	设置面域高程。

**QPolygonF getPolygon() const**

​	获取面域多边形。

**long getLayerId() const**

​	获取面域所在图层ID。

**void setLayerId(long id)**

​	设置面域所在图层，如果图层ID非法，则不做任何改变。

**qreal getWidth() const**

​	获取人行横道宽度，单位: 米。

**void setWidth(qreal width)**

​	设置人行横道宽度，单位: 米。

**QLineF getSceneLine(UnitOfMeasure unit = UnitOfMeasure::Default) const**

​	获取人行横道起点到终点的线段，场景坐标系下。单位：像素。

**qreal getAngle() const**

​	获取人行横道倾斜角度。

**void setAngle(qreal angle)**

​	设置人行横道倾斜角度。

**qreal getRedLightSpeedFactor() const**

​	获取红灯清尾速度系数。

**void setRedLightSpeedFactor(qreal factor)**

​	设置红灯清尾速度系数。

**QVector2D getUnitDirectionFromStartToEnd() const**

​	获取场景坐标系下从起点到终点的单位方向向量。

**QVector2D getLocalUnitDirectionFromStartToEnd() const**

​	获取人行横道本身坐标系下从起点到终点的单位方向。

**QGraphicsEllipseItem\* getStartControlPoint() const**

​	获取起点控制点。

**QGraphicsEllipseItem\* getEndControlPoint() const**

​	获取终点控制点。

**QGraphicsEllipseItem\* getLeftControlPoint() const**

​	获取左侧控制点。

**QGraphicsEllipseItem\* getRightControlPoint() const**

​	获取右侧控制点。

**ICrosswalkSignalLamp\* getPositiveDirectionSignalLamp() const**

​	获取管控正向通行的信号灯。

**ICrosswalkSignalLamp\* getNegativeDirectionSignalLamp() const**

​	获取管控反向通行的信号灯。

**bool isPositiveTrafficLightAdded() const**

​	判断是否添加了管控正向通行的信号灯。

**bool isReverseTrafficLightAdded() const**

​	判断是否添加了管控反向通行的信号灯。

#### 3.4.9.12.楼梯行人面域（IPedestrianStairRegion）

​	头文件: IPedestrianStairRegion.h

**long getId() const**

​	获取面域ID。

**QString getName() const**

​	获取面域名称。

**void setName(QString name)**

​	设置面域名称。

**QColor getRegionColor() const**

​	获取面域颜色。

**void setRegionColor(QColor color)**

​	设置面域颜色。

**QPointF getPosition(UnitOfMeasure unit = UnitOfMeasure::Default) const**

​	获取面域位置。单位：像素。

**void setPosition(QPointF scenePos，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**int getGType() const**

​	获取面域类型。

**qreal getWidth() const**

​	获取楼梯宽度，单位: m。

**void setWidth(qreal width)**

​	设置楼梯宽度，单位: m。

**QPointF getStartPoint() const**

​	获取起始点，场景坐标系下。

**QPointF getEndPoint() const**

​	获取终止点，场景坐标系下。

**qreal getStartConnectionAreaLength() const**

​	获取起始衔接区域长度，单位: m。

**qreal getEndConnectionAreaLength() const**

​	获取终止衔接区域长度，单位: m。

**QPointF getStartRegionCenterPoint() const**

​	获取起始衔接区域中心，场景坐标系下。

**QPointF getEndRegionCenterPoint() const**

​	获取终止衔接区域中心，场景坐标系下。

**QPainterPath getStartSceneRegion() const**

​	获取起始衔接区域形状，场景坐标系下。

**QPainterPath getEndSceneRegion() const**

​	获取终止衔接区域形状，场景坐标系下。

**QPainterPath getMainQueueRegion() const**

​	获取楼梯主体形状，场景坐标系下。

**QPainterPath getFullQueueregion() const**

​	获取楼梯整体形状，场景坐标系下。

**QPolygonF getMainQueuePolygon() const**

​	获取楼梯主体多边形，场景坐标系下。

**StairType getStairType() const**

​	获取楼梯类型。

**void setStairType(StairType type)**

​	设置楼梯类型。

**long getStartLayerId() const**

​	获取起始层级。

**void setStartLayerId(long id)**

​	设置起始层级。

**long getEndLayerId() const**

​	获取终止层级。

**void setEndLayerId(long id)**

​	设置终止层级。

**qreal getTransmissionSpeed() const**

​	获取传送速度，单位: m/s。

**void setTransmissionSpeed(qreal speed)**

​	设置传送速度，单位: m/s。

**qreal getHeadroom() const**

​	获取楼梯净高。

**void setHeadroom(qreal headroom)**

​	设置楼梯净高。

**QGraphicsEllipseItem\* getStartControlPoint() const**

​	获取起点控制点。

**QGraphicsEllipseItem\* getEndControlPoint() const**

​	获取终点控制点。

**QGraphicsEllipseItem\* getLeftControlPoint() const**

​	获取左侧控制点。

**QGraphicsEllipseItem\* getRightControlPoint() const**

​	获取右侧控制点。

**QGraphicsEllipseItem\* getStartConnectionAreaControlPoint() const**

​	获取起始衔接区域长度控制点。

**QGraphicsEllipseItem\* getEndConnectionAreaControlPoint() const**

​	获取终止衔接区域长度控制点。

#### 3.4.9.13.行人路径（IPedestrianPath）

​	头文件: IPedestrianPath.h

**long getId() const**

​	获取行人路径ID。

**IPedestrianPathPoint\* getPathStartPoint() const**

​	获取行人路径起始点。

**IPedestrianPathPoint\* getPathEndPoint() const**

​	获取行人路径终点。

**QList\<IPedestrianPathPoint\*\> getPathMiddlePoints() const**

​	获取行人路径中间点。

**bool isLocalPath() const**

​	判断是否是局部路径。

#### 3.4.9.14.行人路径点（IPedestrianPathPoint）

​	头文件: IPedestrianPathPoint.h

**long getId() const**

​	获取行人路径点ID。

**QPointF getScenePos(UnitOfMeasure unit = UnitOfMeasure::Default) const**

​	获取行人路径点场景坐标系下的位置。单位：像素。

**qreal getRadius() const**

​	获取行人路径点的半径，单位: m。

#### 3.4.9.15.人行横道信号灯（ICrosswalkSignalLamp）

​	头文件: ICrosswalkSignalLamp.h

**long id()**

​	获取信号灯ID。

**void setSignalPhase(ISignalPhase\* pPhase)**

​	设置相位，所设相位可以是其它信号灯组的相位。

**void setPhaseNumber(int num)**

​	设置相位序号，序号从1开始，如果num序号大于相位总数不进行设置。

**void setLampColor(QString colorStr)**

​	设置信号灯颜色。

参数: 

​	[ in ] colorStr: 字符串表达的颜色，有四种可选，分别是"红"、"绿"、"黄"、"灰"，，或者是"R"、"G"、"Y"、"gray"。 

**QString color()**

​	获取信号灯色，"R"、“G”、“Y”、“gray”分别表示"红"、"绿"、"黄"、"灰"。

**QString name()**

​	获取信号灯名称。

**void setName(QString name)**

​	设置信号灯名称。

**void setDistToStart(qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置信号灯距路段起点距离。单位：像素。

参数: 

​	[ in ] dist: 距离值。

**ISignalPlan\* signalPlan()**

​	获取信控方案。

**ISignalPhase\* signalPhase()**

​	获取相位。

**ILaneObject\* laneObject()**

​	获取所在车道或车道连接。

**QPolygonF polygon()**

​	获取信号灯多边型轮廓的顶点。

**qreal angle()**

​	获取信号灯角度。

**IPedestrianCrossWalkRegion\* getICrossWalk() const**

​	获取所属人行横道。

### 3.4.10.停车场模块

#### 3.4.10.1.停车位（IParkingStall）

​	头文件: IParkingStall.h

**long id()**

​	获取停车位ID。

**long parkingRegionId()**

​	获取所属停车区域ID。

**IParkingRegion\* parkingRegion()**

​	获取所属停车区域。

**qreal distance()**

​	获取距路段起始位置，单位: m。

**int stallType()**

​	获取车位类型，与车辆类型编码一致。

#### 3.4.10.2.停车区域（IParkingRegion）

​	头文件: IParkingRegion.h

**long id()**

​	获取停车区域ID。

**QString name()**

​	获取停车区域名称。

**void setName(QString name)**

​	设置停车区域名称。

参数: 

​	[ in ] name: 新名称。

**QList\<IParkingStall\*\> parkingStalls()**

​	获取所有停车位。

**Online::ParkingLot::DynaParkingRegion dynaParkingRegion()**

​	获取动态停车区域信息。

#### 3.4.10.3.停车路径决策点（IParkingDecisionPoint）

​	头文件: IParkingDecisionPoint.h

**long id()**

​	获取停车决策点ID。

**QString name()**

​	获取停车决策点名称。

**ILink\* link()**

​	获取停车决策点所在路段。

**qreal distance()**

​	获取停车决策点距路段起点距离，单位: m。

**QList\<IParkingRouting\*\> routings()**

​	获取相关停车路径。

**bool updateParkDisInfo(const QList\<Online::ParkingLot::DynaParkDisInfo\>& tollDisInfoList)**

​	更新停车分配信息。

参数: 

​	[ in ] tollDisInfoList: 停车分配信息列表。

**QList\<Online::ParkingLot::DynaParkDisInfo\> parkDisInfoList()**

​	获取停车分配信息列表。

**QPolygonF polygon()**

​	获取停车决策点多边型轮廓。

#### 3.4.10.4.停车路径（IParkingRouting）

​	头文件: IParkingRouting.h

**long id()**

​	获取路径ID。

**long parkingDeciPointId()**

​	获取所属决策点ID。

**long parkingRegionId()**

​	路径到达的停车区域id。

**qreal calcuLength()**

​	计算路径长度。

**bool contain(ISection\* pRoad)**

​	通过所给道路判断是否在当前路径上。

参数: 

​	[ in ] pRoad: 路段或连接段。

**ISection\* nextRoad(ISection\* pRoad)**

​	通过所给道路求下一条道路。

参数: 

​	[ in ] pRoad: 路段或连接段。

**QList\<ILink\*\> getLinks()**

​	获取路段序列。

### 3.4.11.收费站模块

#### 3.4.11.1.收费点（ITollPoint）

​	头文件: ITollPoint.h

**long id()**

​	获取收费点ID。

**qreal distance()**

​	获取距路段起始位置，单位: m。

**long tollLaneId()**

​	获取所属收费车道ID。

**ITollLane\* tollLane()**

​	获取所属收费车道。

**bool isEnabled()**

​	获取是否启用。

**bool setEnabled(bool enabled)**

​	设置启用状态。

参数: 

​	[ in ] enabled: 是否启用。

**int tollType()**

​	获取收费类型。

**bool setTollType(int tollType)**

​	设置收费类型。

参数: 

​	[ in ] tollType: 收费类型。

**int timeDisId()**

​	获取停车时间分布ID。

**bool setTimeDisId(int timeDisId)**

​	设置停车时间分布ID。

参数: 

​	[ in ] timeDisId: 时间分布ID。

#### 3.4.11.2.收费车道（ITollLane）

​	头文件: ITollLane.h

**long id()**

​	获取收费车道ID。

**QString name()**

​	获取收费车道名称。

**qreal distance()**

​	获取距路段起始位置，单位: m。

**void setName(QString name)**

​	设置收费车道名称。

参数: 

​	[ in ] name: 收费车道新名称。

**void setWorkTime(long startTime，long endTime)**

​	设置工作时间，工作时间与仿真时间对应。

参数: 

​	[ in ] startTime: 开始时间。单位：s。

​	[ in ] endTime: 结束时间。单位：s。

**Online::TollStation::DynaTollLane dynaTollLane()**

​	获取动态收费车道信息。

**QList\<ITollPoint\*\> tollPoints()**

​	获取收费车道所有收费点。

#### 3.4.11.3.收费决策点（ITollDecisionPoint）

​	头文件: ITollDecisionPoint.h

**long id()**

​	获取收费决策点ID。

**QString name()**

​	获取收费决策点名称。

**ILink\* link()**

​	获取收费决策点所在路段。

**qreal distance()**

​	获取距路段起点距离，单位: m。

**QList\<ITollRouting\*\> routings()**

​	获取相关收费路径。

**QList\<Online::TollStation::DynaTollDisInfo\> tollDisInfoList()**

​	获取收费分配信息列表。

**void updateTollDisInfoList(const QList\<Online::TollStation::DynaTollDisInfo\>& tollDisInfoList)**

​	更新收费分配信息列表。

参数: 

​	[ in ] tollDisInfoList: 收费分配信息列表。

**QPolygonF polygon()**

​	获取收费决策点多边型轮廓。

#### 3.4.11.4.收费路径（ITollRouting）

​	头文件: ITollRouting.h

**long id()**

​	获取路径ID。

**long tollDeciPointId()**

​	获取所属收费决策点ID。

**long tollLaneId()**

​	路径到达的收费区域id。

**qreal calcuLength()**

​	计算路径长度。

**bool contain(ISection\* pRoad)**

​	通过所给道路判断是否在当前路径上。

参数: 

​	[ in ] pRoad: 路段或连接段。

**ISection\* nextRoad(ISection\* pRoad)**

​	通过所给道路求下一条道路。

参数: 

​	[ in ] pRoad: 路段或连接段。

**QList\<ILink\*\> getLinks()**

​	获取路段序列。

### 3.4.12.节点模块

#### 3.4.12.1.节点（IJunction）

​	头文件: IJunction.h

**long getId() const**

​	获取节点ID。

**QString name() const**

​	获取节点名称。

**void setName(const QString& strName)**

​	设置节点名称。

参数: 

​	[ in ] strName: 新名称。

**QList\<ILink\*\> getJunctionLinks()**

​	获取节点内的路段。

**QList\<IConnector\*\> getJunctionConnectors()**

​	获取节点内的连接段。

**QList\<Online::Junction::TurnningBaseInfo\> getAllTurnningInfo()**

​	获取节点内所有流向信息。

**Online::Junction::TurnningBaseInfo getTurnningInfo(long turningId)**

​	获取节点内指定流向信息。

### 3.4.13.车辆与行人

#### 3.4.13.1.车辆（IVehicle）

​	头文件: ivehicle.h

​	车辆接口，用于访问、控制车辆。通过此接口可以读取车辆属性，设置车辆部分属性，仿真过程读取当前道路情况、车辆前后左右相邻车辆及与它们的距离等。

**long id()**

​	车辆ID，车辆ID的组成方式为 x * 100000 + y，每个发车点的x值不一样，从1开始递增，y是每个发车点所发车辆序号，从1开始递增。第一个发车点所发车辆ID从100001开始递增，第二个发车点所发车辆ID从200001开始递增。

**ILink\* startLink()**

​	车辆进入路网时起始路段。

**long startSimuTime()**

​	车辆进入路网时起始时间。

**long roadId()**

​	车辆所在路段或连接段ID。

**void\* road()**

​	道路，如果在路段上返回ILink，如果在连接段上返回IConnector。

**ISection\* section()**

​	车辆所在的Section，即路段或连接段。

**ILaneObject\* laneObj()**

​	车辆所在的车道或车道连接。

**int segmIndex()**

​	车辆在当前LaneObject上分段序号。

**bool roadIsLink()**

​	车辆所在道路是否路段。

**QString roadName()**

​	道路名。

**qreal initSpeed(qreal speed，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	初始化车速。

参数: 

​	[ in ] speed: 初始速度值。单位: 像素/s。

**void initLane(int laneNumber，qreal dist = -1，qreal speed = -1，UnitOfMeasure unit = UnitOfMeasure: : Default)**

​	在路段上初始化车辆。

参数: 

​	[ in ] laneNumber: 车道序号。

​	[ in ] dist: 距起点距离，单位: 像素。

​	[ in ] speed: 初始速度，单位: 像素/s。

**void initLaneConnector(int laneNumber，int toLaneNumber，qreal dist = -1，qreal speed = -1，UnitOfMeasure unit = UnitOfMeasure: : Default)**

​	在连接段上初始化车辆。单位：像素。

参数: 

​	[ in ] laneNumber: 起始车道序号。

​	[ in ] toLaneNumber: 目标车道序号。

​	[ in ] dist: 距起点距离，单位: 像素。

​	[ in ] speed: 初始速度，单位: 像素/s。

**void setVehiType(int code)**

​	设置车辆类型，车辆被创建时已确定了类型，通过此方法可以改变车辆类型。

参数: 

​	[ in ] code: 车辆类型编码。

**void setColor(QString color)**

​	设置车辆颜色。

参数: 

​	[ in ] color: 颜色RGB，如: "#EE0000"。

示例：

```cpp
// 设置车辆颜色为蓝色
vehicle->setColor("#00AFF0");
```

**qreal length(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取车辆长度。单位：像素。

**void setLength(qreal len，bool bRestWidth，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置车辆长度。单位：像素。

参数: 

​	[ in ] len: 长度值，单位: 像素或米(取决于unit参数)。

​	[ in ] bRestWidth: 是否同比例约束宽度。

**long laneId()**

​	如果toLaneId() 小于等于0，那么laneId()获取的是当前所在车道ID，如果toLaneId()大于0，则车辆在车道连接上，laneId()获取的是上游车道ID。

**long toLaneId()**

​	下游车道ID。如果小于等于0，车辆在路段的车道上，否则车辆在连接段的车道连接上。

**ILane\* lane()**

​	获取当前车道，如果车辆在车道连接上，获取的是车道连接的上游车道。

**ILane\* toLane()**

​	如果车辆在车道连接上，返回车道连接的下游车道，如果当前不在车道连接上，返回nullptr。

**ILaneConnector\* laneConnector()**

​	获取当前车道连接，如果在车道上，返回nullptr。

**long currBatchNumber()**

​	当前仿真计算批次。

**int roadType()**

​	车辆所在道路类型。GLinkType代表路段、GConnectorType代表连接段。

**qreal limitMaxSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取最大限速，单位: 像素/s。

**qreal limitMinSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取最小限速，单位: 像素/s。

**long vehicleTypeCode()**

​	车辆类型编码。

**QString vehicleTypeName()**

​	获取车辆类型名，如"小客车"。

**QString name()**

​	获取车辆名称。

**IVehicleDriving\* vehicleDriving()**

​	获取车辆驾驶行为接口。

**void driving()**

​	驱动车辆。在每个运算周期，每个在运行的车辆被调用一次该方法。

**QPointF pos(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取当前位置。单位：像素。

**qreal zValue(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取当前高程。单位：像素。

**qreal acce(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取当前加速度。单位：像素。

**qreal currSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取当前速度，单位: 像素/s。

**qreal angle()**

​	当前角度，北向0度顺时针。

**bool isStarted()**

​	是否在运行，如果返回false，表明车辆已驰出路网或尚未上路。

**IVehicle\* vehicleFront()**

​	前车对象。

**IVehicle\* vehicleRear()**

​	后车对象。

**IVehicle\* vehicleLFront()**

​	左前车对象。

**IVehicle\* vehicleLRear()**

​	左后车对象。

**IVehicle\* vehicleRFront()**

​	右前车对象。

**IVehicle\* vehicleRRear()**

​	右后车对象。

**qreal vehiDistFront(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取与前车距离。单位：像素。

**qreal vehiSpeedFront(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取前车速度，单位: 像素/s。

**qreal vehiHeadwayFront(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取与前车时距，单位: 秒。

**qreal vehiDistRear(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取与后车距离。单位：像素。

**qreal vehiSpeedRear(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取后车速度，单位: 像素/s。

**qreal vehiHeadwaytoRear(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取与后车时距，单位: 秒。

**qreal vehiDistLLaneFront(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取与左前车距离。单位：像素。

**qreal vehiSpeedLLaneFront(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取左前车速度。单位：像素。

**qreal vehiDistLLaneRear(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取与左后车距离。单位：像素。

**qreal vehiSpeedLLaneRear(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取左后车速度。单位：像素。

**qreal vehiDistRLaneFront(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取与右前车距离。单位：像素。

**qreal vehiSpeedRLaneFront(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取右前车速度。单位：像素。

**qreal vehiDistRLaneRear(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取与右后车距离。单位：像素。

**qreal vehiSpeedRLaneRear(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取右后车速度。单位：像素。

**void setDynaInfo(void\* pDynaInfo)**

​	设置动态信息。

**void\* dynaInfo()**

​	获取动态信息。

**QList\<QPointF\> lLaneObjectVertex(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取车道或车道连接中心线内点集。单位：像素。

**IRouting\* routing()**

​	当前路径。

**QPicture picture()**

​	获取车辆图片。

**QPolygonF boundingPolygon()**

​	获取车辆由方向和长度决定的四个拐角构成的多边型。

**void setTag(long tag)**

​	设置标签表示的状态。

**long tag()**

​	获取标签表示的状态。

**void setTextTag(QString text)**

​	设置文本信息，用于在运行过程保存临时信息，方便开发。

**QString textTag()**

​	文本信息，运行过程临时保存的信息，方便开发。

**void setJsonInfo(QJsonObject info)**

​	设置json格式数据。

**QJsonObject jsonInfo()**

​	返回json格式数据。

**QVariant jsonProperty(QString propName)**

​	返回json字段值。

**void setJsonProperty(QString key，QVariant value)**

​	设置json数据属性。

#### 3.4.13.2.车辆驾驶行为（IVehicleDriving）

​	头文件: ivehicledriving.h

​	车辆驾驶行为接口，通过此接口可以控制车辆的左右变道、设置车辆角度，对车辆速度、坐标位置等进行控制等。**在获取车辆对象 `vehicle` 后，通过`vehicle->vehicleDriving()->xxx()` 的方式调用。**

**IVehicle\* vehicle()**

​	当前驾驶车辆。

**long getRandomNumber()**

​	获取随机数。

**bool nextPoint()**

​	计算下一点位置，过程包括计算车辆邻车关系、公交车是否进站是否出站、是否变道、加速度、车速、移动距离、跟驰类型、轨迹类型等。

**long zeroSpeedInterval()**

​	当前车速为零持续时间。单位：ms。

**bool isHavingDeciPointOnLink()**

​	当前是否在路段上且有决策点。

**int followingType()**

​	跟驰车辆的类型，即当前车辆前车的类型，分为: 0: 停车，1: 正常，5: 急减速，6: 急加速，7: 汇入，8: 穿越，9: 协作减速，10: 协作加速，11: 减速待转，12: 加速待转。

**bool isOnRouting()**

​	当前是否在路径上。

**void stopVehicle()**

​	停止运行，将车辆移出路网。

**qreal angle()**

​	旋转角。单位：角度。北向0度，顺时针。

**void setAngle(qreal angle)**

​	设置车辆旋转角。

参数: 

​	[ in ] angle: 旋转角，一周360度。

**QVector3D euler(bool bPositive = false)**

​	返回车辆欧拉角。

参数: 

​	[ in ] bPositive: 车头方向是否正向计算，如果bPosiDire为false则反向计算。

**qreal desirSpeed(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取期望速度，单位: 像素/s。

**ISection\* getCurrRoad()**

​	返回当前所在路段或连接段。

**ISection\* getNextRoad()**

​	下一路段或连接段。

**int differToTargetLaneNumber()**

​	与目标车道序号的差值，不等于0表示有强制变道意图，大于0有左变道意图，小于0有右变道意图，绝对值大于0表示需要强制变道次数。

**void toLeftLane(bool bFource = false)**

​	左变道。

参数: 

​	[ in ] bFource: 是否强制変道，默认为false。

示例：

```cpp
// 控制车辆向左变道
vehicle->vehicleDriving()->toLeftLane();
```

**void toRightLane(bool bFource = false)**

​	右变道。

参数: 

​	[ in ] bFource: 是否强制変道，默认为false。

示例：

```cpp
// 控制车辆向右变道
vehicle->vehicleDriving()->toRightLane();
```

**int laneNumber()**

​	当前车道序号，最右侧序号为0。

**void initTrace()**

​	初始化轨迹。

**void setTrace(QList\<QPointF\>& lPoint，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置轨迹点集。单位：像素。

参数: 

​	[ in ] lPoint: 轨迹点坐标集合。

**void calcTraceLength()**

​	计算轨迹长度。

**int tracingType()**

​	返回轨迹类型，分为: 0: 跟驰，1: 左变道，2: 右变道，3: 左虚拟変道，4: 右虚拟变道，5: 左转待转，6: 右转待转，7: 入湾，8: 出湾。

**void setTracingType(int type)**

​	设置轨迹类型。

**void setLaneNumber(int number)**

​	设置当前车道序号。

参数: 

​	[ in ] number: 车道序号。

**qreal currDistanceInRoad(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取当前路段或连接段已行驶距离。单位：像素。

**void setCurrDistanceInRoad(qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置当前路段或连接段已行驶距离。单位：像素。

参数: 

​	[ in ] dist: 距离。

**void setVehiDrivDistance(qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置已行驶总里程。单位：像素。

参数: 

​	[ in ] dist: 总里程。

**qreal getVehiDrivDistance(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取已行驶总里程。单位：像素。

**qreal currDistanceInSegment(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取当前分段已行驶距离。单位：像素。

**void setCurrDistanceInSegment(qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置当前分段已行驶距离。单位：像素。

参数: 

​	[ in ] dist: 距离。

**void setSegmentIndex(int index)**

​	设置分段序号。

**void setCurrDistanceInTrace(qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置曲化轨迹上行驶的距离。单位：像素。

参数: 

​	[ in ] dist: 距离。

**void setX(qreal posX，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置横坐标。单位：像素。

参数: 

​	[ in ] posX: 横坐标。

**void setY(qreal posY，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置纵坐标。单位：像素。

参数: 

​	[ in ] posY: 纵坐标。

**void setV3z(qreal v3z，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	设置高程坐标。单位：像素。

参数: 

​	[ in ] v3z: 高程坐标。

**QList\<QPointF\> changingTrace(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取变轨点集。单位：像素。

**qreal changingTraceLength(UnitOfMeasure unit = UnitOfMeasure::Default)**

​	获取变轨长度。单位：像素。

**qreal distToStartPoint(bool fromVehiHead = false，bool bOnCentLine = true，UnitOfMeasure unit = UnitOfMeasure: : Default)**

​	获取在车道或车道连接上到起点距离。单位：像素。

参数: 

​	[ in ] fromVehiHead: 是否从车头计算。

​	[ in ] bOnCentLine: 当前是否在中心线上。

**qreal distToEndpoint(bool fromVehiHead = false，bool bOnCentLine = true，UnitOfMeasure unit = UnitOfMeasure: : Default)**

​	获取在车道或车道连接上到终端距离。单位：像素。

参数: 

​	[ in ] fromVehiHead: 是否从车头计算。

​	[ in ] bOnCentLine: 当前是否在中心线上。

**bool setRouting(IRouting\* pRouting)**

​	设置路径，外界设置的路径不一定有决策点，可能是临时创建的，如果车辆不在此路径上则设置不成功并返回false。

示例：

```cpp
// 1. 使用现有的决策点的车辆路径
IRouting* routing1 = netiface->findRouting(1);
vehicle->vehicleDriving()->setRouting(routing1);

// 2. 创建不与决策点绑定的车辆路径
QList<int> linkIdList = {8, 16, 25};
QList<ILink*> linkList;
for (int linkId : linkIdList) 
{
    linkList.append(netiface->findLink(linkId));
}
IRouting* routing2 = netiface->createRouting(linkList);
vehicle->vehicleDriving()->setRouting(routing2);
```

**IRouting\* routing()**

​	当前路径。

**bool moveToLane(ILane\* pLane，qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	将车辆移到另一条车道上。单位：像素。

参数: 

​	[ in ] pLane: 目标车道。

​	[ in ] dist: 到目标车道起点距离。

**bool moveToLaneConnector(ILaneConnector\* pLaneConnector，qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	将车辆移到另一条车道连接上。单位：像素。

参数: 

​	[ in ] pLaneConnector: 目标车道连接。

​	[ in ] dist: 到目标车道连接起点距离。

**bool move(ILaneObject\* pILaneObject，qreal dist，UnitOfMeasure unit = UnitOfMeasure::Default)**

​	移动车辆到另一条车道或车道连接上。单位：像素。

参数: 

​	[ in ] pILaneObject: 目标车道或车道连接。

​	[ in ] dist: 到目标起点距离。

示例：

```cpp
// 获取车道对象
lane = netiface->findLane(6);
// 位置，单位：m
dist = 50;
// 移动车辆到指定车道和位置上，实现车辆位置的瞬移
vehicle->vehicleDriving()->move(lane, dist, UnitOfMeasure::Metric);
```

#### 3.4.13.3.行人（IPedestrian）

​	头文件: IPedestrian.h

**long getId() const**

​	获取行人ID。

**qreal getRadius() const**

​	获取行人半径，单位: m。

**qreal getWeight() const**

​	获取行人质量，单位: kg。

**QString getColor() const**

​	获取行人颜色，RGB格式，如: "#EE0000"。

**QPointF getPos() const**

​	获取行人当前位置，单位: m。

**qreal getAngle() const**

​	获取行人当前角度，Qt坐标系下，x轴正方向为0，逆时针为正。

**QVector2D getDirection() const**

​	获取行人当前二维方向向量。

**qreal getElevation() const**

​	获取行人当前高程，单位: m。

**QVector2D getSpeed() const**

​	获取行人当前速度，单位: m/s。

**qreal getDesiredSpeed() const**

​	获取行人期望速度，单位: m/s。

**qreal getMaxSpeed() const**

​	获取行人最大速度限制，单位: m/s。

**QVector2D getAcce() const**

​	获取行人当前加速度，单位: m/s²。

**qreal getMaxAcce() const**

​	获取行人最大加速度限制，单位: m/s²。

**QVector3D getEuler() const**

​	获取行人欧拉角。

**QVector3D getSpeedEuler() const**

​	获取行人速度欧拉角。

**QVector2D getWallFDirection() const**

​	获取墙壁方向单位向量。

**IPedestrianRegion\* getRegion() const**

​	获取行人当前所在面域。

**long getPedestrianTypeId() const**

​	获取行人类型ID。

**void stop()**

​	停止仿真，会在下一个仿真批次移除当前行人，释放资源。

<div style="page-break-after: always;"></div>

# 4.高频接口

​	本节提供 TESS NG 二次开发经常使用的接口代码案例。



## 4.1.路网建模

### 4.1.1.创建路段和连接段

​	创建路段和连接段的代码如下。**此外，开源路网编辑工具 pytessng （使用TESS NG Python 二次开发实现）支持支持导入 OpenDrive、shape、OpenStreetMap 等格式的数据来创建路网，具体使用方法可参考 [pytessng · PyPI](https://pypi.org/project/pytessng/)。**

```cpp
// ==================== 创建路段 ====================
// 创建第一条路段：曹安公路
QPointF startPoint = QPointF(-300, 0);
QPointF endPoint = QPointF(300, 0);
QList linkPoints = {startPoint, endPoint};
ILink* link1 = netiface->createLink(linkPoints, 7, "曹安公路", true, UnitOfMeasure::Metric);
if (link1) 
{
    // 车道列表
    QList<ILane*> lanes = link1->lanes();
    // 在当前路段创建发车点
    IDispatchPoint* dp = netiface->createDispatchPoint(link1);
    if (dp)
    {
        // 设置发车间隔，含车型组成、时间间隔、发车数
        dp->addDispatchInterval(1, 2, 28);
    }
}

// 创建第二条路段
startPoint = QPointF(-300, -25);
endPoint = QPointF(300, -25);
linkPoints = {startPoint, endPoint};
ILink* link2 = netiface->createLink(linkPoints, 3, "次干道", true, UnitOfMeasure::Metric);
if (link2)
{
    // 在当前路段创建发车点
    IDispatchPoint* dp = netiface->createDispatchPoint(link2);
    if (dp)
    {
        // 设置发车间隔，含车型组成、时间间隔、发车数
        dp->addDispatchInterval(1, 3600, 3600);
    }
    // 将外侧车道设为公交专用道
    QList<ILane*> lanes = link2->lanes();
    ILane* lane = lanes[0];
    lane->setLaneType("公交专用道");
}

// 创建第三条路段
startPoint = QPointF(-300, 25);
endPoint = QPointF(-150, 25);
linkPoints = {startPoint, endPoint};
ILink* link3 = netiface->createLink(linkPoints, 3, "link3", true, UnitOfMeasure::Metric);
if (link3)
{
    // 在当前路段创建发车点
    IDispatchPoint *dp = netiface->createDispatchPoint(link3);
    if (dp)
    {
        // 设置发车间隔，含车型组成、时间间隔、发车数
        dp->addDispatchInterval(1, 3600, 3600);
    }
}

// 创建第四条路段
startPoint = QPointF(-50, 25);
endPoint = QPointF(50, 25);
linkPoints = {startPoint, endPoint};
ILink* link4 = netiface->createLink(linkPoints, 3, "link4", true, UnitOfMeasure::Metric);

// 创建第五条路段
startPoint = QPointF(150, 25);
endPoint = QPointF(300, 25);
linkPoints = {startPoint, endPoint};
ILink* link5 = netiface->createLink(linkPoints, 3, "自定义限速路段", true, UnitOfMeasure::Metric);
if (link5)
{
    // 设置路段限速，单位：km/h
    link5->setLimitSpeed(30);
}

// 创建第六条路段
startPoint = QPointF(-300, 50);
endPoint = QPointF(300, 50);
linkPoints = {startPoint, endPoint};
ILink* link6 = netiface->createLink(linkPoints, 3, "动态发车路段", true, UnitOfMeasure::Metric);
if (link6)
{
    // 设置路段限速，单位：km/h
    link6->setLimitSpeed(80);
}

// 创建第七条路段
startPoint = QPointF(-300, 75);
endPoint = QPointF(-250, 75);
linkPoints = {startPoint, endPoint};
ILink* link7 = netiface->createLink(linkPoints, 3, "link7", true, UnitOfMeasure::Metric);
if (link7)
{
    // 设置路段限速，单位：km/h
    link7->setLimitSpeed(80);
}

// 创建第八条路段
startPoint = QPointF(-50, 75);
endPoint = QPointF(300, 75);
linkPoints = {startPoint, endPoint};
ILink* link8 = netiface->createLink(linkPoints, 3, "link8", true, UnitOfMeasure::Metric);
if (link8)
{
    // 设置路段限速，单位：km/h
    link8->setLimitSpeed(80);
}

// 创建第一条连接段，连接link3和link4
QList<int> fromLaneNumbers = {1, 2, 3};
QList<int> toLaneNumbers = {1, 2, 3};
if (link3 && link4)
{
    IConnector* conn1 = netiface->createConnector(link3->id(), link4->id(), fromLaneNumbers, toLaneNumbers, "连接段1");
}

// 创建第二条连接段，连接link4和link5
if (link4 && link5)
{
    IConnector* conn2 = netiface->createConnector(link4->id(), link5->id(), fromLaneNumbers, toLaneNumbers, "连接段2");
}

// 创建第三条连接段，连接link7和link8
if (link7 && link8)
{
    IConnector* pConn3 = netiface->createConnector(link7->id(), link8->id(), fromLaneNumbers, toLaneNumbers, "动态发车连接段");
}
```

### 4.1.2.创建各类采集设备

​	各类采集设备包括：数据采集器、排队计数器和行程时间检测器。创建它们的代码如下。

```cpp
// ==================== 创建数据采集器 ====================
// 获取车道对象
ILane* lane = netiface->findLane(1);
// 位置，单位：m
qreal dist = 50;
// 在路段上创建数据采集器
IVehicleDrivInfoCollector* collector = netiface->createVehiCollectorOnLink(lane, dist, UnitOfMeasure::Metric);

// 获取车道连接对象
ILaneConnector* laneConnector = netiface->findLaneConnector(1, 4);
// 位置，单位：m
qreal dist = 50;
// 在连接段上创建数据采集器
IVehicleDrivInfoCollector* collector = netiface->createVehiCollectorOnConnector(laneConnector, dist, UnitOfMeasure::Metric);

// ==================== 创建排队计数器 ====================
// 获取车道对象
ILane* lane = netiface->findLane(1);
// 位置，单位：m
qreal dist = 80;
// 在路段上创建排队计数器
IVehicleQueueCounter* counter = netiface->createVehiQueueCounterOnLink(lane, dist, UnitOfMeasure::Metric);

// 获取车道连接对象
laneConnector* = netiface->findLaneConnector(1, 4);
// 位置，单位：m
double dist = 80;
// 在连接段上创建排队计数器
IVehicleQueueCounter* counter = netiface->createVehiQueueCounterOnConnector(laneConnector, dist, UnitOfMeasure::Metric);

// ==================== 创建行程时间检测器 ====================
// 获取起始路段对象
ILink* startLink = netiface->findLink(1);
// 获取终止路段对象
ILink* endLink = netiface->findLink(2);
// 检测器起点在起始路段的位置，单位：m
qreal startDist = 10;
// 检测器终点在终止路段的位置，单位：m
qreal endDist = 90;
// 创建起点在路段、终点也在路段的行程时间检测器
QList<IVehicleTravelDetector*> detectors = netiface->createVehicleTravelDetector_link2link(startLink, endLink, startDist, endDist, UnitOfMeasure::Metric);

// 获取起始路段对象
ILink* startLink = netiface->findLink(1);
// 获取终止车道连接对象
ILaneConnector* endLaneConnector = netiface->findLaneConnector(1, 4);
// 检测器起点在起始路段的位置，单位：m
qreal startDist = 10;
// 检测器终点在终止车道连接的位置，单位：m
qreal endDist = 10;
// 创建起点在路段、终点在连接段的行程时间检测器
QList<IVehicleTravelDetector*> detectors = netiface->createVehicleTravelDetector_link2conn(startLink, endLaneConnector, startDist, endDist, UnitOfMeasure::Metric);

// 获取起始车道连接对象
ILink* startLaneConnector = netiface->findLaneConnector(1, 4);
// 获取终止路段对象
ILaneConnector* endLink = netiface->findLink(2);
// 检测器起点在起始车道连接的位置，单位：m
qreal startDist = 10;
// 检测器终点在终止路段的位置，单位：m
qreal endDist = 90;
// 创建起点在连接段、终点在路段的行程时间检测器
QList<IVehicleTravelDetector*> detectors = netiface->createVehicleTravelDetector_conn2link(startLaneConnector, endLink, startDist, endDist, UnitOfMeasure::Metric);

// 获取起始车道连接对象
ILaneConnector* startLaneConnector = netiface->findLaneConnector(1, 4);
// 获取终止路段对象
ILaneConnector* endLaneConnector = netiface->findLaneConnector(4, 7);
// 检测器起点在起始车道连接的位置，单位：m
qreal startDist = 10;
// 检测器终点在终止车道连接的位置，单位：m
qreal endDist = 90;
// 创建起点在连接段、终点也在连接段的行程时间检测器
QList<IVehicleTravelDetector*> detectors = netiface->createVehicleTravelDetector_conn2conn(startLaneConnector, endLaneConnector, startDist, endDist, UnitOfMeasure::Metric);
```

### 4.1.3.创建导向箭头

​	创建导向箭头的代码如下。

```cpp
ILane* lane = netiface->findLane(4);
if (lane)
{
    qreal length = 4;
    qreal distToTerminal = 10;
    Online::GuideArrowType arrowType = Online::GuideArrowType::StraightRight;
	IGuidArrow* guidArrow = netiface->createGuidArrow(lane, length, distToTerminal, arrowType, UnitOfMeasure::Metric);
}
```

### 4.1.4.创建公交站点和线路

​	创建公交站点和公交线路的代码如下。

```cpp
// 创建公交站点
ILane* lane = netiface->findLane(1);
IBusStation* busStation = netiface->createBusStation(lane, 30, 50, "公交站1", UnitOfMeasure::Metric);
// 设置站点类型 1：路边式、2：港湾式
busStation.setType(1);

// 创建公交线路
ILink* link1 = netiface->findLink(1);
ILink* link2 = netiface->findLink(2);
QList<ILink*> links = {link1, link2};
IBusLine* busLine = netiface->createBusLine(links);

// 关联公交线路和公交站点
bool result = netiface->addBusStationToLine(busLine, busStation);
// 关联成功
if (result)
{
    // 获取公交线路上的所有公交站点
    QList<IBusStationLine*> stationLineList = busLine->stationLines();
    // 获取第一个公交站点
    IBusStationLine* stationLine = stationLineList[0];
    // 设置车辆停靠时间，单位：s
    stationLine->setBusParkingTime(20);
}
```

### 4.1.5.创建各类事件区域

​	各类事件区域包括：事故区、施工区、限行区和改扩建借道。创建它们的代码如下。

```cpp
// ==================== 创建事故区 ====================
// 构建参数
Online::DynaAccidentZoneParam param;
// 事故区名称
param.name = "事故区";
// 道路ID
param.roadID = 1;
// 位置，距路段或连接段起点距离，单位：m
param.location = 100;
// 长度，单位：m
param.length = 50;
// 车道序号列表，从0开始，连续有序
param.mlFromLaneNumber.append(0);
// 开始时间，单位：s
param.startTime= 10
// 持续时间，单位：s
param.duration = 600
// 相邻车道限速，单位：km/h
param.limitSpeed = 40
// 创建事故区
IAccidentZone* accidentZone = netiface->createAccidentZone(param, UnitOfMeasure::Metric);

// ==================== 创建施工区 ====================
// 构建参数
Online::DynaRoadWorkZoneParam param;
// 施工区名称
param.name = "施工区";
// 道路ID
param.roadID = 1;
// 位置, 距离路段或连接段起点距离, 单位：m
param.location = 200;
// 长度, 单位：m
param.length = 50;  // 长度
param.upCautionLength = 70;  // 提前警示长度
param.upTransitionLength = 50;  // 过渡区长度
param.upBufferLength = 50;  // 缓冲区长度
param.downTransitionLength = 40;  // 下游过渡区长度
param.downTerminationLength = 40;  // 终止区长度
// 车道序号列表，从0开始，连续有序
param.mlFromLaneNumber.append(0);
// 开始时间，单位：s
param.startTime = 0;
// 持续时间，单位：s
param.duration = 3600;
// 相邻车道限速，单位：km/h
param.limitSpeed = 40;
// 创建施工区
IRoadWorkZone* roadWorkZone = netiface->createRoadWorkZone(param, UnitOfMeasure::Metric);

// ==================== 创建限行区 ====================
// 构建参数
Online::DynaLimitedZoneParam param;
// 限行区名称
param.name = "限行区";
// 道路ID
param.roadID = 1;
// 位置, 距离路段或连接段起点距离, 单位：m
param.location = 200;
// 长度, 单位：m
param.length = 50;
// 车道序号列表，从0开始，连续有序
param.mlFromLaneNumber.append(0);
// 开始时间，单位：s
param.startTime = 0;
// 持续时间，单位：s
param.duration = 3600;
// 相邻车道限速，单位：km/h
param.limitSpeed = 40;
// 创建限行区
ILimitedZone* limitedZone = netiface->createLimitedZone(param, UnitOfMeasure::Metric);

// ==================== 创建改扩建借道 ====================
// 构建参数
Online::DynaReconstructionParam param;
// 施工区ID
param.roadWorkZoneId = rwzId;
// 被借道的路段ID
param.beBorrowedLinkId = 2;
// 被借道的车道数量
param.borrowedNum = 1;
// 保通开口长度，单位：m
param.passagewayLength = 80;
// 保通开口限速，单位：m/s
param.passagewayLimitedSpeed = 40 / 3.6;
// 创建改扩建借道
IReconstruction* reconstruction = netiface->createReconstruction(param, UnitOfMeasure::Metric);
```



## 4.2.需求建模

### 4.2.1.设置发车

​	设置发车可在**仿真前通过发车点批量配置**，也可在**仿真过程中动态创建单车**。

​	（1）在仿真开启前，创建车型、车辆组成和发车点及发车流量的代码如下。

```cpp
// ==================== 创建车型 ====================
// 构建参数
_VehicleType vehicleType = _VehicleType();
vehicleType.vehicleTypeName = "新建车型1";  // 车型名称
vehicleType.Length = 4.5;  // 长度，单位：m
vehicleType.lengthSD = 0.5;  // 长度标准差，单位：m
vehicleType.width = 2;  // 宽度，单位：m
vehicleType.widthSD = 0.2;  // 宽度标准差，单位：m
vehicleType.avgSpeed = 60;  // 期望速度，单位：km/h
vehicleType.speedSD = 10;  // 期望速度标准差，单位：km/h
vehicleType.avgAcce = 4;  // 期望加速度，单位：m/s²
vehicleType.acceSD = 0.5;  // 期望加速度标准差，单位：m/s²
vehicleType.avgDece = 6;  // 期望减速度，单位：m/s²
vehicleType.deceSD = 0.5;  // 期望减速度标准差，单位：m/s²
vehicleType.maxAcce = 5.5;  // 最大加速度，单位：m/s²
vehicleType.maxDece = 7.5;  // 最大减速度，单位：m/s²
vehicleType.maxSpeed = 80;  // 最大速度，单位：km/h
vehicleType.commercialVehicle = false;  // 是否是营运车辆
vehicleType.maxPassengerCapacity = 1;  // 核载人数，单位：人
// 创建车型
bool result = netiface->createVehicleType(vehicleType);
qDebug() << "创建车型是否成功：" << result;

// ==================== 创建车辆组成 ====================
// 构建车辆类型比例列表
QList<Online::VehiComposition> vehiTypeProportionList = {
    Online::VehiComposition(1, 0.3),  // 小客车，占比0.3
    Online::VehiComposition(2, 0.2),  // 大客车，占比0.2
    Online::VehiComposition(3, 0.1),  // 公交车，占比0.1
    Online::VehiComposition(4, 0.4)   // 货车，占比0.4
};
// 创建车辆组成
int vehiCompositionId = netiface->createVehicleComposition("动态创建车型组成", vehiTypeProportionList);

// ==================== 创建发车点 ====================
// 获取路段对象
ILink* link = netiface->findLink(1);
// 创建发车点
IDispatchPoint* dp = netiface->createDispatchPoint(link);
if (dp)
{
    // 添加发车间隔，含车型组成、时间间隔、发车数
    dp->addDispatchInterval(1, 600, 300);
    dp->addDispatchInterval(1, 600, 400);
}
```

​	（2）在仿真过程中，不使用发车点，在指定位置创建单车的代码如下。

```cpp
// ==================== 在路段上创建车辆 ====================
// 构建参数
Online::DynaVehiParam dvp1;
// 车型ID
dvp1.vehiTypeCode = 1;
// 路段ID
dvp1.roadId = 4;
// 车道序号
dvp1.laneNumber = 0;
// 位置，单位：m
dvp1.dist = m2p(50);
// 速度，单位：m/s
dvp1.speed = m2p(20);
// 颜色
dvp1.color = "#00AFF0";
// 动态创建车辆
IVehicle* vehicle1 = simuiface->createGVehicle(dvp1);
if (vehicle1)
{
    qDebug() << "在路段上创建了车辆，其ID为：" << vehicle1.id();
}

// ==================== 在连接段上创建车辆 ====================
// 构建参数
Online::DynaVehiParam dvp2;
// 车型ID
dvp2.vehiTypeCode = 1;
// 连接段ID
dvp2.roadId = 4;
// 上游路段的车道序号
dvp2.laneNumber = 0;
// 下游路段的车道序号
dvp2.toLaneNumber = 0;
// 位置，单位：m
dvp2.dist = m2p(50);
// 速度，单位：m/s
dvp2.speed = m2p(20);
// 颜色
dvp2.color = "#00AFF0";
// 动态创建车辆
IVehicle* vehicle2 = simuiface->createGVehicle(dvp2);
if (vehicle2)
{
    qDebug() << "在连接段上创建了车辆，其ID为：" << vehicle2.id();
}
```

### 4.2.2.设置路径

​	设置路径可在**仿真开启前或仿真过程中基于决策点进行流量比例分配**，也可**直接为单个车辆指定行驶路线**。	

​	（1）在仿真开启前，创建决策点，并更新其路径和路径流量比例的代码如下。

```cpp
// ============================== 创建决策点 ==============================
ILink* link = netiface->findLink(1);
qreal location = 50;
QString decisionPointName = "新建决策点";
IDecisionPoint* decisionPoint = netiface->createDecisionPoint(link, location, decisionPointName, UnitOfMeasure::Metric);

// ==================== 创建决策点的车辆路径 ====================
// 路段ID列表
QList<int> linkIdList1 = {1, 2};
QList<int> linkIdList2 = {1, 3};
QList<int> linkIdList3 = {1, 4};

// 构建路段对象列表
QList<ILink*> linkList1;
for (int linkId : linkIdList1) {
    linkList1.append(netiface->findLink(linkId));
}
QList<ILink*> linkList2;
for (int linkId : linkIdList2) {
    linkList2.append(netiface->findLink(linkId));
}
QList<ILink*> linkList3;
for (int linkId : linkIdList3) {
    linkList3.append(netiface->findLink(linkId));
}

// 创建决策点的车辆路径
IRouting* routing1 = netiface->createDeciRouting(decisionPoint, linkList1);
IRouting* routing2 = netiface->createDeciRouting(decisionPoint, linkList2);
IRouting* routing3 = netiface->createDeciRouting(decisionPoint, linkList3);

// ==================== 更新决策点路径流量比配置 ====================
// 初始化左、直、右流量比对象
_RoutingFLowRatio flowRatioLeft;
flowRatioLeft.RoutingFLowRatioID = 1;
flowRatioLeft.routingID = routing1->id();
flowRatioLeft.startDateTime = 0;
flowRatioLeft.endDateTime = 999999;
flowRatioLeft.ratio = 2.0;

_RoutingFLowRatio flowRatioStraight;
flowRatioStraight.RoutingFLowRatioID = 2;
flowRatioStraight.routingID = routing2->id();
flowRatioStraight.startDateTime = 0;
flowRatioStraight.endDateTime = 999999;
flowRatioStraight.ratio = 3.0;

_RoutingFLowRatio flowRatioRight;
flowRatioRight.RoutingFLowRatioID = 3;
flowRatioRight.routingID = routing3->id();
flowRatioRight.startDateTime = 0;
flowRatioRight.endDateTime = 999999;
flowRatioRight.ratio = 1.0;

// 初始化决策点数据
_DecisionPoint decisionPointData;
decisionPointData.deciPointID = decisionPoint->id();
decisionPointData.deciPointName = decisionPoint->name();
QPointF decisionPointPos;
if (decisionPoint->link()->getPointByDist (decisionPoint->distance(), decisionPointPos)) 
{
    decisionPointData.X = decisionPointPos.x();
    decisionPointData.Y = decisionPointPos.y();
    decisionPointData.Z = decisionPoint->link()->z();
}

// 构造流量比列表
QList<_RoutingFLowRatio> flowRatioList = {flowRatioLeft, flowRatioStraight, flowRatioRight};

// 更新决策点的路径流量比配置
IDecisionPoint* updatedDecisionPoint = netiface->updateDecipointPoint(decisionPointData, flowRatioList);
```

​	（2）在仿真过程中，动态修改已有决策点的路径流量比例代码如下。

```cpp
// MySimulator.cpp

QList<Online::DecipointFlowRatioByInterval> MySimulator::calcDynaFlowRatioParameters()
{
	QList<Online::DecipointFlowRatioByInterval> lDecipointFLowRatioByInterval;
	// 当前仿真计算批次
	long batchNumber = simuiface->batchNumber();
	// 在计算第20批次时修改某决策点各路径流量比
	if (batchNumber == 20)
	{
		// 一个决策点某个时段各路径车辆分配比
		Online::DecipointFlowRatioByInterval dfi = Online::DecipointFlowRatioByInterval();
		// 决策点编号
		dfi.deciPointID = 1;
		// 起始时间 单位：秒
		dfi.startDateTime = 1;
		// 结束时间 单位：秒
		dfi.endDateTime = 999999;
		// 路径流量比
		Online::RoutingFlowRatio rfr1 = Online::RoutingFlowRatio(1, 3);
		Online::RoutingFlowRatio rfr2 = Online::RoutingFlowRatio(2, 4);
		Online::RoutingFlowRatio rfr3 = Online::RoutingFlowRatio(3, 3);
		dfi.mlRoutingFlowRatio << rfr1;
		dfi.mlRoutingFlowRatio << rfr2;
		dfi.mlRoutingFlowRatio << rfr3;
		lDecipointFLowRatioByInterval << dfi;
	}
	return lDecipointFLowRatioByInterval;
}
```

​	（3）在仿真过程中，给车辆设置路径的代码如下。

```cpp
// 1. 使用现有的决策点的车辆路径
IRouting* routing1 = netiface->findRouting(1);
vehicle->vehicleDriving()->setRouting(routing1);

// 2. 创建不与决策点绑定的车辆路径
QList<int> linkIdList = {8, 16, 25};
QList<ILink*> linkList;
for (int linkId : linkIdList) 
{
    linkList.append(netiface->findLink(linkId));
}
IRouting* routing2 = netiface->createRouting(linkList);
vehicle->vehicleDriving()->setRouting(routing2);
```




## 4.3.信号控制

### 4.3.1.创建信号机、信控方案、信号灯相位和信号灯

​	在仿真开启前，可以依次创建信号机、信控方案、信号灯相位、信号灯，创建过程中同步建立了绑定关系：**信号灯→信号灯相位→信控方案→信号机**，代码如下。

```cpp
// ==================== 创建信号机（通常一个交叉口对应一个信号机） ====================
// 信号机名称
QString signalControllerName = "双龙大道-吉印大道交叉口";
// 创建信号机
ISignalController* signalController = netiface->createSignalController(signalControllerName);

// ==================== 创建信控方案（一个信号机在不同时段可配置多个信控方案） ====================
// 获取信号机对象
ISignalController* signalController = netiface->findSignalControllerByID(1);
// 信控方案名称
QString signalPlanName = "平峰方案";
// 周期时长，单位：s
int cycleTime = 120;
// 相位差，单位：s
int phaseDifference = 0;
// 起始时间，单位：s
int startTime = 0;
// 结束时间，单位：s
int endTime = 3600;
// 创建信控方案
ISignalPlan* signalPlan = netiface->createSignalPlan(signalController, signalPlanName, cycleTime, phaseDifference, startTime, endTime);

// ==================== 创建信号灯相位（一个信控方案需为不同方向/转向分配相位） ====================
// 获取信号配时方案
ISignalPlan* signalPlan = netiface->findSignalPlanByID(1);
// 相位名称
QString signalPhaseName = "东西直行";
// 构建灯色对象列表
QString<QString> colors = {"R", "G", "Y", "R"};
QList<int> intervals = {30, 26, 3, 61};
QList<Online::ColorInterval> colorIntervalList;
for (int i = 0; i < colors.size(); ++i) 
{
    colorIntervalList.append(Online::ColorInterval(colors[i], intervals[i]));
}
// 创建信号灯相位
ISignalPhase* signalPhase = netiface->createSignalPlanSignalPhase(signalPlan, signalPhaseName, colorIntervalList);

// ==================== 创建信号灯（一个相位控制多条车道的信号灯） ====================
// 获取相位对象
ISignalPhase* signalPhase = netiface->findSignalPhase(1);
// 信号灯名称
QString signalLampName = "东直1";
// 车道ID
long laneId = 1;
// 下游车道ID
long toLaneId = -1;
// 位置，单位：m
qreal distance = m2p(50);
// 创建信号灯
ISignalLamp* signalLamp = netiface->createSignalLamp(signalPhase, signalLampName, laneId, toLaneId, distance);
```

### 4.3.2.控制信号灯灯色

​	可以按**信控相位**或**单个信号灯**两种粒度修改灯色设置。

​	（1）在仿真开启前或仿真过程中，按信控相位修改灯色与时长的代码如下。

```cpp
// 构建灯色和时长对象列表
QList<Online::ColorInterval> colorObjList = {
    Online::ColorInterval("R", 10),  // 红色，时长10
    Online::ColorInterval("G", 60),  // 绿色，时长60
    Online::ColorInterval("Y", 3),  // 黄色，时长3
    Online::ColorInterval("R", 17)  // 红色，时长17
};
// 查找ID为7的信号灯相位
auto signalPhase = netiface->findSignalPhase(7);
if (signalPhase) 
{
    // 设置灯色列表
    signalPhase->setColorList(colorObjList);
}
```

​	在路网中已完成信号机、信控方案、信号灯相位及信号灯的创建后，若需在仿真过程中修改单个交叉口的信控方案，可参考以下示例代码。使用前，需预先记录各相位对应的相位ID。

```cpp
// 定义相位数据结构
struct PhaseData {
    int signalPhaseId;
    QList<int> intervals;
};

void MySimulator::afterOneStep() 
{
    // 获取当前仿真时间，单位：ms
    long simuTime = simuiface->simuIntervalScheming();
    
    // 到达指定时刻
    if (simuTime == 60 * 1000) 
    {
        // 单个交叉口的信控相位映射
        QMap<QString, PhaseData> signalIntervalMapping = {
            {"东西直行",  {1, {0, 31, 3, 86}}},
            {"东西左转",  {2, {35, 21, 3, 61}}},
            {"南北直行",  {3, {60, 31, 3, 26}}},
            {"南北左转",  {4, {95, 21, 3, 1}}}
        };

        // 按信控相位设置
        for (auto it = signalIntervalMapping.begin(); it != signalIntervalMapping.end(); ++it) 
        {
            const PhaseData& phaseData = it.value();
            // 获取信控相位ID
            long signlPhaseId = phaseData.signalPhaseId;
            // 获取信控相位对象
            ISignalPhase* signalPhase = netiface->findSignalPhase(signlPhaseId);
            if (!signalPhase) 
            {
                continue;
            }
            // 构建灯色和时长列表
            QList<Online::ColorInterval> colorList = {
                Online::ColorInterval("R", phaseData.intervals[0]),  // 红色
                Online::ColorInterval("G", phaseData.intervals[1]),  // 绿色
                Online::ColorInterval("Y", phaseData.intervals[2]),  // 黄色
                Online::ColorInterval("R", phaseData.intervals[3])   // 红色
            };
            // 给信控相位设置新的时长方案
            signalPhase->setColorList(colorList);
        }
    }
}
```

​	（2）在仿真过程中，按单个信号灯直接修改灯色的代码如下。由于这种操作本质上是对 TESS NG 已计算结果的修正或覆盖，因此这类调整**仅在当前帧内生效**。这意味着，**不能仅在满足条件的某个时刻进行一次设置，而需要在整个符合条件的时间区间内持续执行设置操作**。

```cpp
// MySimulator.cpp

bool MySimulator::calcLampColor(ISignalLamp* pSignalLamp) 
{
    // 获取当前仿真时间，单位：ms
    long simuTime = simuiface->simuIntervalScheming();
    // 若信号灯ID为1，则设为绿色
	if (pSignalLamp->id() == 1 && simuTime >= 60 * 1000 && simuTime < 90 * 1000) 
    {
		pSignalLamp->setLampColor("G");
		return true;
	}
	return false;
}
```



## 4.4.车辆控制

### 4.4.1.设置车辆期望速度

​	在仿真过程中，设置车辆期望速度的代码如下。

```cpp
// 设置车辆的期望速度，单位：像素/s
vehicle->setDesirSpeed(m2p(80 / 3.6))
```

### 4.4.2.设置车辆速度

​	在仿真过程中，设置车辆速度的代码如下。

```cpp
// MySimulator.cpp

// 单位：m/s
bool MySimulator::reSetSpeed(IVehicle* pIVehicle, qreal &inOutSpeed, UnitOfMeasure* unit)
{
    if (pIVehicle->id() == 100001)
    {
        // 直接指定车辆的速度
        inOutSpeed = 80 / 3.6;
        return true;
    }
    return false;
}
```

### 4.4.3.设置车辆加速度

​	设置车辆加速度的代码如下。

```cpp
// MySimulator.cpp

// 该函数在 TESS NG 计算加速度之前计算，单位：m/s²
bool MySimulator::calcAcce(IVehicle* pIVehicle, qreal &acce, UnitOfMeasure* unit)
{
    if (pIVehicle->roadName() == "曹安公路")
    {
        // 根据速度不同，直接计算加速度
        if (pIVehicle->currSpeed() > 20/3.6)
        {
            acce = -3;
            return true;
        }
        else if (pIVehicle->currSpeed() > 10/3.6)
        {
            acce = -1;
            return true;
        }
    }
    return false;
}

// 该函数在 TESS NG 计算加速度之后计算单位：m/s²
bool MySimulator::reSetAcce(IVehicle* pIVehicle, qreal &inOutAcce, UnitOfMeasure* unit)
{
    if (pIVehicle->roadName() == "曹安公路")
    {
        // 根据速度不同，对已计算出的加速度进行修正
        if (pIVehicle->currSpeed() > 20/3.6)
        {
            acce += -3;
            return true;
        }
        else if (pIVehicle->currSpeed() > 10/3.6)
        {
            acce += -1;
            return true;
        }
    }
    return false;
}
```

### 4.4.4.设置车辆变道

​	控制车辆向左或向右变道的代码如下。

```cpp
// 控制车辆向左变道
vehicle->vehicleDriving()->toLeftLane();

// 控制车辆向右变道
vehicle->vehicleDriving()->toRightLane();
```

​	撤销车辆变道的代码如下。

```cpp
// MySimulator.cpp

bool MySimulator::reCalcDismissChangeLane(IVehicle* pIVehicle)
{
	// 距离路段终点小于50m时撤销一切自由变道，达到禁止自由变道的效果
    if (pIVehicle->vehicleDriving()->distToEndpoint(true, true, UnitOfMeasure::Metric) < 50)
    {
        return true;
    }
    return false;
}
```

### 4.4.5.设置车辆车道限行

​	设置车辆车道限行的代码如下。

```cpp
// MySimulator.cpp

QList<int> MySimulator::calcLimitedLaneNumber(IVehicle* pIVehicle)
{
    // 如果车辆在路段上且车辆长度大于8m，则禁止驶入最内侧车道
    if (pIVehicle->roadIsLink() && (pIVehicle->length(UnitOfMeasure::Metric) > 8)) 
    {
        int limitLaneNumber = pIVehicle->lane()->link()->laneCount();
        return QList<int>() << limitLaneNumber;
    }
    return QList<int>();
}
```

### 4.4.6.设置车辆路径

​	设置车辆路径的代码如下。

```cpp
// 1. 使用现有的决策点的车辆路径
IRouting* routing1 = netiface->findRouting(1);
vehicle->vehicleDriving()->setRouting(routing1);

// 2. 创建不与决策点绑定的车辆路径
QList<int> linkIdList = {8, 16, 25};
QList<ILink*> linkList;
for (int linkId : linkIdList) 
{
    linkList.append(netiface->findLink(linkId));
}
IRouting* routing2 = netiface->createRouting(linkList);
vehicle->vehicleDriving()->setRouting(routing2);
```

### 4.4.7.设置车辆跟驰参数

​	设置车辆跟驰参数的代码如下。**当前仅支持修改 IDM 跟驰模型的参数**。

```cpp
// 设置车辆的期望加速度单位：像素/s²
vehicle->setDesirAcce(m2p(5.5));

// 设置车辆最大减速度，单位：像素/s²
vehicle->setMaxDece(m2p(7.5));

// 设置车辆的安全时距，单位：s
vehicle->vehicleDriving()->setSafeTimeInterval(1.5);

// 设置车辆的停车距离，单位：像素
vehicle->vehicleDriving()->setStoppingDistance(m2p(2));
```

### 4.4.8.设置车辆跳跃

​	设置车辆跳跃的代码如下。

```cpp
// 目标点
QPointF targetPoint = QPointF(50, 50);
// 将目标点投影到附近一定范围内的车道上，获取定位信息序列
QList<Online::Location> locations = netiface->locateOnCrid(targetPoint, 9, UnitOfMeasure::Metric);  // 使用前需要先执行netiface->buildNetGrid(10);
// 如果定位到了车道对象
if (!locations.empty())
{
    Online::Location location = locations[0];
    // 车道对象
    ILaneObject* laneObj = location.pLaneObject;
    // 位置，单位：m
    qreal dist = location.distToStart;

    // 移动车辆到指定车道和位置上，实现车辆位置的瞬移
    vehicle->vehicleDriving()->move(laneObj, dist, UnitOfMeasure::Metric);
}
```

### 4.4.9.设置车辆信息和可视化

​	设置车辆信息的代码如下。

```cpp
// MySimulator.cpp

QString MySimulator::vehiRunInfo(IVehicle* pIVehicle)
{
    return QString("车辆当前在ID=%1的道路上").arg(pIVehicle->roadId());
}
```

​	设置车辆颜色的代码如下。

```cpp
// 设置车辆颜色为蓝色
vehicle->setColor("#00AFF0");
```

​	设置车辆可视化的代码如下。

```cpp
// MySimulator.cpp

void MySimulator::rePaintVehicle(Tessng::IVehicle* pIVehicle, QPainter* painter)
{
    // 在车身上添加车辆名称标签
    QString label = pIVehicle->name();

    // 创建QFont对象，设置字体和字号
    QFont font("Arial", 1);
    // 设置字体为非粗体
    font.setBold(false);

    // 创建QFontMetrics对象，获取字体度量信息
    QFontMetrics fontMetrics(font);
    // 获取文本的边界矩形
    QRect boundingRect = fontMetrics.boundingRect(label);
    // 计算文本位置
    qreal newX = -boundingRect.center().x() - pIVehicle->width() * 0.5;
    qreal newY = -boundingRect.center().y();
    QPointF position(newX, newY);

    // 创建QPainterPath对象绘制文本
    QPainterPath textPath;
    // 将文本添加到路径中
    textPath.addText(position, font, label);
    
    // 设置画笔缩放比例
    painter->scale(1, 1);
    // 填充路径绘制文本
    painter->fillPath(textPath, QColor("#c94f4f"));
}
```



## 4.5.仿真控制

### 4.5.1.设置仿真参数

​	在仿真开启前，设置仿真参数的代码如下。

```cpp
// MySimulator.cpp

// 在仿真开启前设置以下参数
void MySimulator::beforeStart(bool &keepOn)
{
    // 设置仿真倍速
    simuiface->setAcceMultiples(5);
    // 设置仿真时长，单位：s
    simuiface->setSimuIntervalScheming(3600);
    // 设置仿真精度
    simuiface->setSimuAccuracy(10);
    // 设置随机种子
    simuiface->setRandSeed(42);
    // 设置是否记录车辆轨迹
    simuiface->setIsRecordTrace(True);
    // 设置是否记录行人轨迹
    simuiface->setIsRecordPedestrianTrace(True);
}
```

### 4.5.2.启动、暂停和停止仿真

​	启动、暂停和停止仿真的代码如下。

```cpp
// 开启仿真，一般写在 afterLoadNet 或 afterStop
if (!simuiface->isRunning() || simuiface->isPausing())
{
    simuiface->startSimu();
}

// 暂停仿真，一般写在 afterOneStep
if (simuiface->isRunning())
{
    simuiface->pauseSimu();
}

// 停止仿真，一般写在 afterOneStep
if (simuiface->isRunning())
{
    simuiface->stopSimu();
}
```

### 4.5.3.连续多次仿真

​	连续多次仿真的代码如下。

```cpp
// MySimulator.h

class MySimulator : public CustomerSimulator
{
public:
	MySimulator();
	~MySimulator();

	// TESS NG 在仿真开启后调用此方法
	void afterStart() override;
    // TESS NG 在每个计算周期结束后调用此方法，核心逻辑实现
	void afterOneStep() override;
	// TESS NG 在仿真结束后调用此方法
	void afterStop() override;

private:
	// 代表TESS NG 的路网子接口
	NetInterface* netiface;
	// 代表TESS NG 的仿真子接口
	SimuInterface* simuiface;

	// 当前仿真次数
	int currentSimuCount = 0;
	// 最大仿真次数
	int maxSimuCount = 10;
};


// MySimulator.cpp

void MySimulator::afterStart()
{
    // 仿真次数加一
	currentSimuCount += 1;
}

void MySimulator::afterOneStep()
{
    // 当前仿真时间，单位：ms
    long simuTime = self.simuiface.simuTimeIntervalWithAcceMutiples();
    if (simuTime > 600 * 1000)
    {
        // 停止仿真
        simuiface->stopSimu();
    }
}

void MySimulator::afterStop()
{
    // 还没到最大仿真次数
    if (currentSimuCount < maxSimuCount)
    {
        // 开启仿真
        simuiface->startSimu();
    }
}
```



## 4.6.数据输出

### 4.6.1.输出路网几何线性数据

​	路网由路段和连接段组成，其中路段由车道构成，连接段由车道连接构成。路段、车道和车道连接均包含中心线、左边线和右边线的断点序列，车辆正是在这些由断点构成的线上行驶。获取路段、车道和车道连接断点数据的代码如下。

```cpp
// 获取某一路段的中心线、左边线和右边线的断点坐标
ILink* link = netiface->findLink(1);
QList<QVector3D> linkCenterPoints = link->centerBreakPoint3Ds(UnitOfMeasure::Metric);
QList<QVector3D> linkLeftPoints = link->leftBreakPoint3Ds(UnitOfMeasure::Metric);
QList<QVector3D> linkRightPoints = link->rightBreakPoint3Ds(UnitOfMeasure::Metric);

// 获取某一车道的中心线、左边线和右边线的断点坐标
ILane* lane = netiface->findLane(1);
QList<QVector3D> laneCenterPoints = lane->centerBreakPoint3Ds(UnitOfMeasure::Metric);
QList<QVector3D> laneLeftPoints = lane->leftBreakPoint3Ds(UnitOfMeasure::Metric);
QList<QVector3D> laneRightPoints = lane->rightBreakPoint3Ds(UnitOfMeasure::Metric);
        
// 获取某一车道连接的中心线、左边线和右边线的断点坐标
ILaneConnector* laneConnector = netiface->findLaneConnector(1, 4);
QList<QVector3D> laneConnectorCenterPoints = laneConnector->centerBreakPoint3Ds(UnitOfMeasure::Metric);
QList<QVector3D> laneConnectorLeftPoints = laneConnector->leftBreakPoint3Ds(UnitOfMeasure::Metric);
QList<QVector3D> laneConnectorRightPoints = laneConnector->rightBreakPoint3Ds(UnitOfMeasure::Metric);
```

### 4.6.2.输出车辆轨迹数据

​	在仿真过程中，获取某一帧仿真的车辆数据的代码如下。

```cpp
// 获取当前正在运行的车辆列表
QList<IVehicle*> allVehicles = simuiface->allVehiStarted();
for (IVehicle* vehicle : allVehicles) 
{
    qDebug() << "车辆ID：" << vehicle->id();
    qDebug() << "车辆名称：" << vehicle->name();
    qDebug() << "车辆类型编码：" << vehicle->vehicleTypeCode();
    qDebug() << "车辆类型名称：" << vehicle->vehicleTypeName();
    qDebug() << "车辆长度：" << vehicle->length(UnitOfMeasure::Metric) << " m";

    qDebug() << "车辆当前横坐标：" << vehicle->pos(UnitOfMeasure::Metric).x() << " m";
    qDebug() << "车辆当前纵坐标：" << vehicle->pos(UnitOfMeasure::Metric).y() << " m";
    qDebug() << "车辆当前高程：" << vehicle->v3z() << " m";
    qDebug() << "车辆当前所在道路ID：" << vehicle->roadId();
    qDebug() << "车辆当前所在道路名称：" << vehicle->roadName();
    qDebug() << "车辆当前是否在路段：" << (vehicle->roadIsLink() ? "是" : "否");
    qDebug() << "车辆当前所在车道ID：" << vehicle->laneId();
    if (vehicle->roadIsLink()) 
    {
        qDebug() << "车辆当前所在车道序号：" << vehicle->vehicleDriving()->laneNumber();
    }
    qDebug() << "车辆当前与车道起点的间距：" << vehicle->vehicleDriving()->distToStartPoint(true, true, UnitOfMeasure::Metric)  << " m";
    
    qDebug() << "车辆当前速度：" << vehicle->currSpeed(UnitOfMeasure::Metric) * 3.6 << " km/h";
    qDebug() << "车辆当前期望速度：" << vehicle->vehicleDriving()->desirSpeed(UnitOfMeasure::Metric) * 3.6 << " km/h";
    qDebug() << "车辆当前加速度：" << vehicle->acce(UnitOfMeasure::Metric) << " m/s²";
    qDebug() << "车辆当前朝向角：" << vehicle->angle() << " °";
}
```

### 4.6.3.输出信号灯数据

​	在仿真过程中，获取某一帧仿真的信号灯数据的代码如下。

```cpp
QList<Online::SignalPhaseColor> allSignalPhaseColor = simuiface->getSignalPhasesColor();
for (auto signalPhaseColor: allSignalPhaseColor)
{
    qDebug() << "信号机ID：" << signalPhaseColor.signalGroupId;
    qDebug() << "信控相位ID：" << signalPhaseColor.phaseId;
    qDebug() << "信控相位序号：" << signalPhaseColor.phaseNumber;
    qDebug() << "当前颜色：" << signalPhaseColor.color;
    qDebug() << "当前颜色的设置时间(ms)：" << signalPhaseColor.mrIntervalSetted;
    qDebug() << "当前颜色的已持续时间(ms)：" << signalPhaseColor.mrIntervalByNow;
}
```

### 4.6.4.输出各类采集设备数据

​	各类采集设备包括：数据采集器、排队计数器和行程时间检测器。在仿真过程中，获取它们的样本数据和集计数据的代码如下。其中，**集计数据仅能在集计时间段结束的那一帧仿真中获取**。

```cpp
// ==================== 数据采集器的样本数据 ====================
QList<Online::VehiInfoCollected> allVehiInfoCollected = simuiface->getVehisInfoCollected();
for (auto vehiInfo: allVehiInfoCollected)
{
    qDebug() << "采集器ID：" << vehiInfo.collectorId;
    qDebug() << "仿真时间(s)：" << vehiInfo.simuInterval;
    qDebug() << "车辆ID：" << vehiInfo.vehiId;
}

// ==================== 数据采集器的集计数据 ====================
QList<Online::VehiInfoAggregated> allVehiInfoAggregated = simuiface->getVehisInfoAggregated();
for (auto vehiInfoAgg: allVehiInfoAggregated)
{
    qDebug() << "采集器ID：" << vehiInfoAgg.collectorId;
    qDebug() << "时间段ID：" << vehiInfoAgg.timeId;
    qDebug() << "起始时间(s)：" << vehiInfoAgg.fromTime;
    qDebug() << "结束时间(s)：" << vehiInfoAgg.toTime;
    qDebug() << "车辆数(veh)：" << vehiInfoAgg.vehiCount;
    qDebug() << "平均速度(km/h)：" << vehiInfoAgg.avgSpeed;
    qDebug() << "平均占有率：" << vehiInfoAgg.occupancy;
}

// ==================== 排队计数器的样本数据 ====================
QList<Online::VehiQueueCounted> allVehiQueueCounted = simuiface->getVehisQueueCounted();
for (auto vehiQueue: allVehiQueueCounted)
{
    qDebug() << "计数器ID：" << vehiQueue.counterId;
    qDebug() << "仿真时间(s)：" << vehiQueue.simuTime;
    qDebug() << "排队车辆数(veh)：" << vehiQueue.vehiCount;
    qDebug() << "排队长度(m)：" << vehiQueue.queueLength;
}

// ==================== 排队计数器的集计数据 ====================
QList<Online::VehiQueueAggregated> allVehiQueueAggregated = simuiface->getVehisQueueAggregated();
for (auto vehiQueueAgg: allVehiQueueAggregated)
{
    qDebug() << "计数器ID：" << vehiQueueAgg.counterId;
    qDebug() << "时间段ID：" << vehiQueueAgg.timeId;
    qDebug() << "起始时间(s)：" << vehiQueueAgg.fromTime;
    qDebug() << "结束时间(s)：" << vehiQueueAgg.toTime;
    qDebug() << "平均排队车辆数(veh)：" << vehiQueueAgg.avgVehiCount;
    qDebug() << "平均排队长度(m)：" << vehiQueueAgg.avgQueueLength;
    qDebug() << "最大排队长度(m)：" << vehiQueueAgg.maxQueueLength;
    qDebug() << "最小排队长度(m)：" << vehiQueueAgg.minQueueLength;
}

// ==================== 行程时间检测器的样本数据 ====================
QList<Online::VehiTravelDetected> allVehiTravelDetected = simuiface->getVehisTravelDetected();
for (auto vehiTravel: allVehiTravelDetected)
{
    qDebug() << "检测器ID：" << vehiTravel.detectedId;
    qDebug() << "车辆ID：" << vehiTravel.vehiId;
    qDebug() << "行驶时间(s)：" << vehiTravel.travelTime;
    qDebug() << "行驶距离(m)：" << vehiTravel.travelDistance;
    qDebug() << "延误(s)：" << vehiTravel.delay;
}

// ==================== 行程时间检测器的集计数据 ====================
QList<Online::VehiTravelAggregated> allVehiTravelAggregated = simuiface->getVehisTravelAggregated();
for (auto vehiTravelAgg: allVehiTravelAggregated)
{
    qDebug() << "检测器ID：" << vehiTravelAgg.detectedId;
    qDebug() << "时间段ID：" << vehiTravelAgg.timeId;
    qDebug() << "起始时间(s)：" << vehiTravelAgg.fromTime;
    qDebug() << "结束时间(s)：" << vehiTravelAgg.toTime;
    qDebug() << "车辆数：" << vehiTravelAgg.vehiCount;
    qDebug() << "平均行程时间(s)：" << vehiTravelAgg.avgTravelTime;
    qDebug() << "平均行程距离(m)：" << vehiTravelAgg.avgTravelDistance;
    qDebug() << "平均延误(s)：" << vehiTravelAgg.avgDelay;
}
```

<div style="page-break-after: always;"></div>

# 5.行业案例

​	基于 TESS NG 二次开发实现的行业案例如下表所示，完整代码请参见 [Github](https://github.com/jIDa-traffic/TESSNG_SecondaryDev) 仓库或 [Gitee](https://gitee.com/jidatraffic/tessng-secondary-doc) 仓库。

|       大类       | 功能项                           |
| :--------------: | :------------------------------- |
|       高速       | 施工区仿真                       |
|                  | 事故，事件仿真                   |
|                  | 车道限速管控                     |
|                  | 车道关闭仿真                     |
|                  | 硬路肩，应急车道开放             |
|                  | 匝道信号控制                     |
|                  | 拥堵预警                         |
|                  | 高速管控预评价系统               |
|                  | 高快速路参数标定                 |
|       城市       | 单点信控自适应                   |
|                  | 交叉口车道车道渠化变更，可变车道 |
|                  | 干线协调                         |
|                  | 车辆路径诱导                     |
|                  | 拥堵预警                         |
|                  | 车道管控仿真                     |
|                  | 车辆事故仿真                     |
|                  | 车辆速度引导（VMS信息板）        |
|                  | 城市道路参数标定                 |
|                  | 公交信号优先                     |
|   V2X 自动驾驶   | v2x交叉口                        |
|                  | 速度引导                         |
|                  | 车辆编队行驶                     |
| 自动驾驶联合仿真 | Carla对接                        |
|                  | prescan对接                      |
|                  | scanner对接                      |
|                  | 交通数字孪生：与UE5，unity结合   |
|                  | 自动驾驶测试场景设计             |

<div style="page-break-after: always;"></div>

# 6.注意事项

## 6.1.软件激活

​	用户在首次使用 TESS NG 二次开发时也需要激活，试用版用户与首次激活软件流程相同，采用安装包的 Cert 文件夹下的 JIDaTraffic_key 激活即可。

​	软件的试用期为30天，试用期结束后，二次开发的接口（Interface）仍可用，但自定义插件（Plugin）将无法使用。商业版用户使用不受限制。



## 6.2.度量单位

​	由于 TESS NG 基于 Qt 框架开发，而 Qt 的图形系统以像素为基础单位，其坐标体系与现实世界的物理单位（如米）存在天然差异。Qt 的绘图操作、界面布局及交互响应均均围绕像素维度展开，默认以屏幕像素作为渲染和定位的基准，并不直接对应现实空间的物理尺度。	

​	因此，在 TESS NG 二次开发中，无论是路网元素的尺寸定义、车辆位置的计算映射，还是自定义图形的绘制、交互操作的坐标解析，都需要特别关注**像素与米制单位**的转换逻辑。默认情况下，1像素对应1m，但若因为导入底图等操作更改了像素比例，则可通过以下方法实现单位转换：

- 米制转换像素：qreal m2p(qreal value)
- 像素转换米制：qreal p2m(qreal value)

​	此外，插件与接口中部分方法包含 **UnitOfMeasure unit **参数，其默认值为`UnitOfMeasure::Default`（即像素单位），若传入`UnitOfMeasure::Metric`则表示采用米制单位（支持读写操作）。例如，`vehicle->currSpeed()`会返回车辆的像素单位速度，而`vehicle->currSpeed(UnitOfMeasure::Metric)`则返回车辆的米制单位速度。需要注意的是，由于`unit`参数通常位于方法参数列表的末尾，**若需显式指定该参数，则其之前所有带默认值的参数也必须显式传入对应值**。相关规则在此统一说明，接口详情中不再赘述。



## 6.3.坐标系

​	由于 TESS NG 基于 Qt 框架开发，其坐标系设计直接沿用了 Qt 的核心规则 ——Qt 为适配屏幕显示与图形渲染逻辑（屏幕像素通常以左上角为原点，向下为 y 轴正方向），采用 **y轴朝下**的坐标系（原点一般位于画布 / 窗口左上角，x 轴水平向右，y 轴垂直向下）。

​	因此，在 TESS NG 二次开发过程中，所有涉及坐标计算、图形绘制（如路网元素定位、车辆位置标注、自定义图形渲染）、鼠标交互定位等场景，均需遵循这一 **y轴朝下**的坐标系规则。尤其在与现实地理坐标系（通常 y 轴朝上）或自定义坐标体系进行数据转换、位置映射时，需特别注意坐标轴方向的差异，避免因坐标系理解偏差导致图形错位、位置计算错误等问题。



## 6.4.依赖头文件包含

​	通常需要在文件头部包含所需的依赖头文件，具体包含哪些需根据代码功能确定。示例如下。

```cpp
#include "MySimulator.h"
#include "tessinterface.h"
#include "netinterface.h"
#include "simuinterface.h"
#include "ilink.h"
#include "ILane.h"
#include "ivehicle.h"
#include "ivehicledriving.h"
```



## 6.5.子插件作用规则

​	在仿真插件中，对车辆加速度、期望速度、行驶速度、转向角度等参数的调整，以及对信号灯灯色的设置，实质上都是对 TESS NG 已计算结果的修正或覆盖，因此这类调整**仅在当前帧内生效**。这意味着像信号灯灯色设置这类操作，**不能仅在满足条件的某个时刻进行一次设置，而需要在整个符合条件的时间区间内持续设置**。

<div style="page-break-after: always;"></div>

# 7.问答列表

### 1. 为什么我在 MySimulator 自带函数中编写的二次开发代码没有生效？

**答：** 可能是由于试用期已结束，导致系统没有权限加载插件，从而使自定义代码无法执行。

