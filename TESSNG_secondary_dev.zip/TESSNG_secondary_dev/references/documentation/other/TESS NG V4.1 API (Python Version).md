# Microscopic Traffic Simulation Software TESS NG Secondary Development Interface Documentation (Python Version)

[TOC]

<div style="page-break-after: always;"></div>

# 1. Introduction

## 1.1. Related Links

* [Official Website of Shanghai Jida Traffic Technology Co., Ltd.](https://jidatraffic.com/#/home)
* [Official Documentation for TESS NG Secondary Development](http://jidatraffic.com:82/)
* [TESS NG Secondary Development GitHub Repository](https://github.com/jIDa-traffic/TESSNG_SecondaryDev)
* [TESS NG Secondary Development Gitee Repository](https://gitee.com/jidatraffic/tessng-secondary-doc)



## 1.2. Development Background

**The domestic microscopic traffic simulation software TESS NG** integrates the latest technologies from interdisciplinary fields including traffic engineering, software engineering, and system simulation. It features fully independent intellectual property rights, convenient and efficient modeling capabilities, open external interface modules, and customizable user services.

　　During the processes of functional expansion and project development, TESS NG strengthens its design by highly abstracting the implementation of numerous functions and deeply integrating these abstract logics with the core functionalities. These abstract logics are further detailed into interface methods, while the concrete implementations of these interfaces are completed by users according to actual application scenarios. Based on this architectural design, TESS NG has successfully developed plugin modules such as vehicle-road coordination, online simulation, and integrated micro-macro simulation. The design and application of the corresponding interfaces have also reached a high level of maturity.

　　TESS NG’s secondary development capability is realized through user-written code interacting with the software, thereby extending functionality and customizing scenarios. Users can not only realize highly automated and personalized simulation operations but also construct traffic digital twins and scientific experimental environments tailored to specific requirements, which constitutes a key approach for conducting transportation research and applications.

　　Currently, TESS NG supports secondary development in three programming languages: **C++**, **Python**, and **Java**, with completely consistent interface names across all languages.



## 1.3. Application Scenarios

TESS NG's secondary development functionality supports the construction of diverse simulation scenarios, with broad application scopes including, but not limited to, the contents outlined in the table below.

| Serial Number |     Category     |       Scenario       |                             Applications                             |
| :--: | :----------: | :--------------: | :----------------------------------------------------------: |
|  1   | Urban Road Simulation |     Signal Control     |                     Single-Point Webster Signal Control Algorithm                      |
|  2   |              |     Bus Priority     |                         Trunk Road Green Wave Algorithm                         |
|  3   |              |   Vehicle Route Guidance   | Inducing by adjusting the proportion of traffic flow at decision points<br/>Evaluation and analysis of queue length on downstream roads at induction points |
|  4   | Highway Simulation |     Ramp Signal Control     |                  On-Ramp ALINEA Signal Control Algorithm Application                  |
|  5   |              |   Lane Speed Limit Management   |                  Dynamic Management of Highway Lane Speed Limits                  |
|  6   |              |   Emergency Incident Handling   |                    Vehicle Accident and Incident Simulation                    |
|  7   |              |     Road Construction     |                        Simulation of Three Types of Construction Zones                        |
|  8   | Simulation Course Instruction | Continuous Intersection Speed Guidance |                     Application of Green Wave Speed Guidance Strategy                     |
|  9   |              |    Traffic Flow Reconstruction    |                 Calibration of Car-Following and Lane-Changing Model Parameters for Expressways                 |
|  10  |              |   Preliminary Research on AI Algorithms    |             Research on Variable Speed Limit Optimization for Expressways Based on Reinforcement Learning             |
|  11  | Construction of Simulation Road Network |     Road Network Editing     |          CRUD Operations for Simulation Elements Such as Road Network, Road Segment, and Connector Segment          |
|  12  |              |     Signal Control Editing     |         CRUD Operations for Traffic Signals and Signal Groups, with Support for Dual-Loop Signal Control Loading         |
|  13  |              |     Demand Editing     | Departure point traffic loading configuration<br/>Single vehicle designated location loading settings<br/>Vehicle composition customization<br/>Addition, deletion, modification, and query of decision points and path ratios |
|  14  | Simulation |     Process Control     | Start, pause, resume, and close operations of simulation<br/>Application of simulation snapshot function<br/>Acquisition of simulation information, road network information, and vehicle information<br/>Conversion of vehicle trajectory plane coordinates and geographic coordinates<br/>Parameter settings such as acceleration, simulation accuracy, and random seeds |
|  15  |              |     Action Control     | Setting of speed limit zone, accident zone, and construction zone<br/>Vehicle movement, information modification, lane change, and heading angle adjustment<br/>Update of signal light color, path, and phase information<br/>Lane opening and closing, road scheme, and path information management<br/>Parameter modification of car following model and lane changing model |
|  16  |              |     Simulation Output     | Settings of detectors and collectors<br/>Output data at specified time and frequency<br/>Obtain binding relationship between detectors, collectors and simulated road network<br/>Vehicle trajectory output<br/>Output structured data of simulated road network |
|  17  | Interactive Interface Development |      Menu Bar      |      Support for User-Added Custom Menus to Facilitate Interaction with TESS NG Software       |
|  18  |              |      Toolbar      |     Supports users in adding custom toolbars to enable interaction with TESS NG software      |



## 1.4. Interface Architecture

TESS NG exposes its core functionalities to users by implementing TessInterface and its three sub-interfaces. After launching TESS NG, users can obtain its top-level interface, then access the three sub-interfaces through this top-level interface and invoke their methods. Once plugins are loaded, TESS NG can invoke the interface methods implemented by these plugins. Users can control simulation execution, including vehicle driving behaviors, traffic signal states, and route vehicle allocation during simulation, via TessInterface and its sub-interfaces within plugin methods.

The overall architecture of the secondary development is illustrated in the figure below.

<img src="http://129.211.28.237:5566/document/images/0_interface_architecture" alt="Secondary Development Overall Architecture Diagram" style="zoom: 50%;" />



## 1.5. Update Log

**【 2025-01-21 】**

- The TESSNG kernel has been upgraded from V3.1 to V4.0; the secondary development version supports the core functionalities of the V4.0 Professional Edition.

- [New] ISignalPlan traffic signal control scheme interface, supporting multi-period traffic signal control schemes, replacing the original ISignalGroup interface.

- [New] ISignalLamp traffic signal interface, supporting the creation of traffic signals and their association with signal controllers.

- [New] ICrosswalkSignalLamp pedestrian signal interface, supporting the creation of pedestrian signals and their association with signal controllers.

- [New] IRoadWorkZone lane-occupying construction interface, supporting the creation of construction zones.

- [New] IAccIDentZone Accident Area interface upgrade, incorporating IAccIDentZoneInterval accident time periods, allowing the creation of accident areas with varied parameters for multiple time intervals.

- [New] ILimitedZone Restricted Zone, which itself forms part of lane borrowing construction and may not be used directly; however, users can employ it to define custom restriction-type areas.

- [New] IReconstruction Lane Borrowing Construction (Reconstruction and Expansion), enabling fine-grained generation and management of the reconstructed and expanded road network.

- [New] IReduceSpeedArea New Speed Limit Zone interface, supporting lane speed limits differentiated by time intervals via IReduceSpeedInterval and by vehicle type via IReduceSpeedVehiType.

- [New] Added a series of toll station interfaces, including toll lane ITollLane, toll decision point ITollDecisionPoint, toll route ITollRouting, and toll station stopping point ITollPoint.

- [New] Parking-related interfaces, including parking stall IParkingStall, parking region IParkingRegion, parking decision point IParkingDecisionPoint, and parking routing IParkingRouting.

- [New] Node construction and route reconstruction interface IJunction, featuring automatic node traffic flow calculation and route reconstruction using input observations.

- [New] Pedestrian surface area interfaces, including the pedestrian base class IPedestrian, obstacle surface area IObstacleRegion, passenger boarding/alighting surface area IPassengerRegion, and elliptical surface area. IPedestrianEllipseRegion, fan-shaped surface area IPedestrianFanShapeRegion, polygonal surface area IPedestrianPolygonRegion, rectangular surface area IPedestrianRectRegion, and triangular surface area IPedestrianTriangleRegion.

- [New] Added the IPedestrianSIDeWalkRegion interface for pedestrian sidewalk surface areas.

- [New] Added the IPedestrianCrossWalkRegion interface for pedestrian crosswalk (zebra crossing) areas.

- [New] Added the IPedestrianStairRegion interface for pedestrian stair surface areas.

- [New] Added the ICrosswalkSignalLamp interface for pedestrian crosswalk traffic signals.

- [New] Added a series of pedestrian path interfaces, including IPedestrianPath for pedestrian routes and IPedestrianPathPoint for pedestrian path waypoints.

- [New] Added create, read, update, and delete (CRUD) operations for IJunction node objects under the NetInterface class; added CRUD for pedestrian surface areas and routes; added CRUD for accident areas, construction zones, reconstruction and expansion zones, speed limit zones, traffic signals, signal controllers, traffic signal control schemes, and star phase plans; also added CRUD for parking lots and toll stations.

- [Added] New interfaces under the SimuInterface class to retrieve pedestrian status and information of pedestrians in motion, as well as a new interface for single-step simulation.

- [Optimized] Unified interface units: V3 series defaults to pixel units, while common concepts such as speed and length in V4 have been converted to metric units (meters). A unitOfMeasure parameter is also provided to explicitly specify the unit type, avoiding cumbersome m2p and p2m conversions.



**【 2025-09-30 】**

- [Added] Interfaces to set vehicle safe time interval and stopping distance: setSafeTimeInterval and setStoppingDistance.
- [Added] Interfaces to read and set whether to output traffic signal head data: isRecordSignalLampStatus and setIsRecordSignalLampStatus.
- [Removed] Deprecated plugin functions related to lane changing: reSetChangeLaneFreelyParam and isPassbyEventZone.

<div style="page-break-after: always;"></div>

# 2. Quick Start

This section provides a quick start guide that enables readers to rapidly understand how to build and run TESS NG's Python API examples within a local environment through installation and demonstrations. This content lays a practical foundation for subsequent plugin development and interface invocation, assisting developers to first complete the workflow and then progressively explore functional extensions.



## 2.1. Installation and Execution (Windows)

#### <span style="color: green;">Step 1: Download the example code package</span>

1. Download the latest version of TESS NG from the [Jida Traffic official website](https://www.jidatraffic.com/#/simulation) ;

   <img src="http://129.211.28.237:5566/document/images/python_2_1_01" alt="Figure 1" style="zoom: 60%;" />

2. After installation, you can find the Python example code package named **`TESS_PythonAPI_EXAMPLE`** in the **`SecondDev`** folder within the software directory.

   <img src="http://129.211.28.237:5566/document/images/python_2_1_02" alt="Figure 2" style="zoom: 60%;" />

#### <span style="color: green;">Step 2: Configure the Development Environment</span>

1. **Install Python**:

   - Visit the [official Python download page](https://www.python.org/ftp/python/) and navigate to the `Index of /ftp/python/` directory. To ensure compatibility with the tessng package, select and download the installer for **Python 3.6 or 3.8**;

   - For example, for version 3.6.6, enter the 3.6.6/ subdirectory and download the `python-3.6.6-amd64.exe` file;

   - Double-click the downloaded `python-3.x.x-xxx.exe` file to launch the installer;

   - It is recommended to select **“Add Python to PATH”** on the initial screen (which automatically configures the environment variables) to avoid manual configuration later;

   - If “Add Python to PATH” is not selected, you must manually add the installation directory (e.g., `C:\Python36\`) and the `Scripts` subdirectory (e.g., `C:\Python36\Scripts`) to the system environment variable `Path`;

   - You can click “Install Now” to quickly install using the default path, or select “Customize installation” to specify a custom installation path. After confirmation, click “Install” to start the installation and wait for it to complete.

      <img src="http://129.211.28.237:5566/document/images/python_2_1_03" alt="Figure 3" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_04" alt="Figure 4" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_05" alt="Figure 5" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_06" alt="Figure 6" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_07" alt="Figure 7" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_08" alt="Figure 8" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_09" alt="Figure 9" style="zoom: 60%;" />

3. **Verify Installation Results:**

   - After the installation is complete, press `Win + R` and enter `cmd` to open the system terminal.

   - Execute the commands `python --version` and `pip --version` respectively. If the output shows versions such as `Python 3.6.6` and `pip 10.0.1 from ...` (python 3.6)`, it indicates the installation was successful.

   <img src="http://129.211.28.237:5566/document/images/python_2_1_10" alt="Figure 10" style="zoom: 60%;" />

4. **Install the tessng Package:**

   - Open the system terminal, enter the command `pip install tessng`, and execute it. Wait for the package to download and install completely.
   - If prompted that the pip version is outdated, first execute `python -m pip install --upgrade pip` to update pip.
   - If the download speed is slow, you can accelerate it by using mirror sources, for example, by executing `pip install tessng -i https://mirrors.aliyun.com/pypi/simple/`;
   - Alternatively, you can visit the [official PyPI website](https://pypi.org/project/tessng/) to download the tessng wheel (.whl) installation file and perform a local installation by executing `pip install local_path\filename.whl`.

   <img src="http://129.211.28.237:5566/document/images/python_2_1_11" alt="Figure 11" style="zoom: 60%;" />


#### <span style="color: green;">Step 3: Select and configure the IDE</span>

- It is recommended to use **JetBrains PyCharm** (Community or Professional edition), following the procedure below:

1. **Install PyCharm:**

   - Visit the [official PyCharm website](https://www.jetbrains.com/pycharm/) to download the installer package compatible with the Windows operating system;
   - Double-click the downloaded `pycharm-x.x.x.exe` file to start the installer;
   - Follow the installation wizard, clicking “Next” sequentially. You may select a custom installation directory as required;
   - Click “Install” and wait for the installation to complete.

   <img src="http://129.211.28.237:5566/document/images/python_2_1_12" alt="Figure 12" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_13" alt="Figure 13" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_14" alt="Figure 14" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_15" alt="Figure 15" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_16" alt="Figure 16" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_17" alt="Figure 17" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_18" alt="Figure 18" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_19" alt="Figure 19" style="zoom: 60%;" />

2. **Configure Python Interpreter**:

   - Launch PyCharm, click the “Open” button, and select the `TESS_PythonAPI_EXAMPLE` folder to open it;
   - Navigate sequentially through the top menu: “File > Settings > Python > Interpreter”, then click “Add Interpreter > Add Local Interpreter” on the right to open the “Add Python Interpreter” window;
   - In the configuration window:
     - Select “New environment” for “Environment”;
     - Select “Virtualenv” for “Type”;
     - Choose the `python.exe` from the downloaded Python installation directory for “Base Python”;
     - Check the option “Inherit global site-packages from base interpreter”;
     - Click the “OK” button and wait for the virtual environment to be created;

   - If a `venv` folder is generated in the project directory and tessng appears in the package list, the configuration is complete.

   <img src="http://129.211.28.237:5566/document/images/python_2_1_20" alt="Figure 20" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/python_2_1_21" alt="Figure 21" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/python_2_1_22" alt="Figure 22" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/python_2_1_23" alt="Figure 23" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/python_2_1_24" alt="Figure 24" style="zoom: 60%;" />

#### <span style="color: green;">Step 4: Run the sample project</span>

1. **Startup code:**

   - In the “Project” panel on the left side of PyCharm, locate the `main.py` file under the project root directory and double-click to open its code view. Right-click anywhere in the code editor area and select “Run 'main'” to start the program.

   <img src="http://129.211.28.237:5566/document/images/python_2_1_25" alt="Figure 25" style="zoom: 60%;" />

2. **Software activation:**

   - Upon first startup, the TESS NG software activation window will appear. Follow the prompts to complete the activation (a valid license is required);
   - After successful activation, close the window and click the “Run” button again to start the sample project normally.

   <img src="http://129.211.28.237:5566/document/images/python_2_1_26" alt="Figure 26" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/python_2_1_27" alt="Figure 27" style="zoom: 60%;" />



## 2.2. Example Explanation

#### <span style="color: dodgerblue;">Note 1: Directory Structure and Description</span>

​	The `TESS_PythonAPI_EXAMPLE` employs a lightweight file organization method, with core files directly mapped to functional modules, resulting in a clear and easily accessible structure. The descriptions of each file are as follows:

- **main.py**: The project's main entry file, responsible for initializing the TESS NG instance and starting the program.
- **MyPlugin.py**: The core implementation file of the custom plugin, responsible for initializing the plugin.
- **MyNet.py**: Implementation file for the Custom Road Network Plugin, enabling the execution of custom operations before and after road network loading, as well as control over the rendering of road network elements.
- **MySimulator.py**: Implementation file for the Custom Simulation Plugin, allowing custom operations before, during, and after simulation; it provides both global control over simulation start-stop logic and fine-grained intervention in individual vehicle driving behavior.
- **MyGUI.py**: Implementation file for the Custom GUI Plugin, used to extend the TESS NG interactive interface (e.g., by adding new buttons, pop-ups, or data display panels).
- **requirements.txt**: Project environment dependency configuration file, listing the Python packages and versions required to run the examples (such as `tessng`); the environment can be quickly deployed via `pip install -r requirements.txt`. 

#### <span style="color: dodgerblue;">Note 2: Plugin Registration Mechanism and Simulation Control Logic</span>

​	Many TESS NG beginners often wonder: how does TESS NG invoke their custom plugin code? By examining the implementation logic of the project’s main entry file `main.py`, this process becomes clear. It is also essential to clarify the core development approach for the simulation scenario, described as follows:

1. To begin with, to answer the core question: **How does TESS NG invoke custom code?** The key lies in the line `factory.build(my_plugin, config)` in `main.py`. This line acts as a “bridge” connecting user-defined plugins with the TESS NG simulation core. The `build` method of `TessngFactory` (a factory class provided by TESS NG) registers the user-created plugin instance `my_plugin = MyPlugin()` (where `MyPlugin` is the user-defined plugin class encapsulating all custom logic) to the simulation core through TESS NG’s underlying interface. After registration, TESS NG automatically invokes the user-overridden hook methods in `MyPlugin` and its sub-plugins `MyNet` and `MySimulator` at critical points of simulation execution (such as simulation start, each simulation step advancement, and simulation end), without requiring manual call code, thereby enabling functional extension.
2. To clarify the core concept of simulation scenario development: Beginners often mistakenly focus on 'how to embed TESS NG simulation into their own computation code.' The correct approach is to '**embed custom computational code within the TESS NG simulation workflow**.'TESS NG provides a mature simulation framework (including fundamental capabilities such as road network loading, simulation advancement, and user interface interaction), and the core function of `main.py` is to 'configure and launch this framework.'Users do not need to construct the simulation framework themselves; they only need to encapsulate computational code (such as custom vehicle behavior, data collection, special scenario trigger logic, etc.) within specific methods of `MyPlugin` and its sub-plugins `MyNet` and `MySimulator` (e.g., the per-step simulation trigger method `afterOneStep` and the simulation start trigger method `afterStart` provided by TESS NG). After the plugin registration is completed by `factory.build`, these logics will be automatically integrated into the simulation process by TESS NG and executed throughout the simulation.

 The code for the project's main entry file `main.py` is as follows:

```python
import os
from PySide2.QtWidgets import QApplication
from tessng import TessngFactory
from MyPlugin import MyPlugin


if __name__ == "__main__":
# Create workspace folder
workspace_dir_path: str = os.path.join(os.getcwd(), "WorkSpace")
os.makedirs(workspace_dir_path, exist_ok=True)

# Build configuration
config = {
  "__netfilepath": "",                # TODO Road network file path
  "__workspace": "D:/TESSNG/V4.0.20",  # Workspace path
  "__simuafterload": True,            # Whether to automatically start the simulation after loading the road network
  "__custsimubysteps": False,         # Whether to customize the simulation function call frequency
}

# Create a Qt application instance
app = QApplication()
# Create an instance of the custom plugin class
my_plugin = MyPlugin()
# Create an instance of the TESS NG factory class
factory = TessngFactory()
# Construct the TESS NG simulation core object via the factory class
tessng = factory.build(my_plugin, config)
# Verify whether the simulation core object was created successfully
if tessng is not None:
  # Start the Qt application's event loop; after entering the event loop, the program will continuously respond to user interactions and simulation events
  app.exec_()
```

#### <span style="color: dodgerblue;">Note 3: Modify the startup road network</span>

​	Modify the `config` configuration attributes in `main.py`:

- `"__netfilepath"`: specifies the default road network file path loaded at TESS NG startup;

- `"__simuafterload"`: specifies whether TESS NG immediately starts the simulation after loading the road network file.

  For example:


```python
config = {
	"__netfilepath": "C:/TESSNG_4.1.0/Examles/Wulinmen.tess",	
	"__simuafterload": True
}
```

#### <span style="color: dodgerblue;">Note 4: Addition, Deletion, Query, and Modification of Road Network Elements and Attribute Operations</span>

​	The `netiface` interface enables **addition**, **deletion**, **query**, and **modification** of road network elements (such as road segments, connector segments, etc.). Moreover, after obtaining a road network element object, attribute **query** and **modification** are supported.

- The following example demonstrates addition, deletion, query, and modification of road network elements (via the `netiface` interface).

```python
from tessng import UnitOfMeasure

# 1. Query all links: Retrieve a list of all links currently in the road network
links = self.netiface.links()

# 2. Query a specific road segment by ID: Retrieve the link with ID = 1 (returns None if not found)
link = self.netiface.findLink(1)

# 3. Create link: Enter the vertex coordinates (link_points), number of lanes (7), and name ("Cao'an Highway") of the link, create and return a new link object
link_points = [QPointF(-300, 0), QPointF(300, 0)]
link1 = self.netiface.createLink(link_points, 7, "Caoan Highway", True, UnitOfMeasure.Metric)

# 4. Delete a link: Pass the link object to be deleted (link1) to remove it from the road network
netiface.removeLink(link1)
```

- The following example demonstrates attribute query and modification of road network elements (via element objects).


```python
# 1. Attribute query: Retrieve relevant attributes of road segment link1
lane_count = link1.laneCount()  # Query the number of lanes of the road segment (returns an integer, e.g., 3)
lane_length = link1.length()  # Query the length of the road segment (returns a floating-point number, unit: meters)

# 2. Attribute modification: Modify the name and speed limit of road segment link1
link1.setName("Caoan Highway")  # Set the road segment name to "Cao'an Highway"
link1.setLimitSpeed(80)  # Set the speed limit of the road segment to 80 km/h
```

#### <span style="color: dodgerblue;">Note 5: Custom operations before and after road network loading</span>

​	In the custom road network plugin (the `MyNet` class), the methods `beforeLoadNet` and `afterLoadNet` can be overridden to implement **preprocessing before road network loading** and **post-processing after road network loading**.

- The following example: After the road network has been loaded, first check whether any road segments exist in the current road network; If none exist, call the custom method `create_network()` to create the basic road network (including road segments, connector segments, departure points, etc.).

```python
# MyNet.py: Implementation file for the Custom Road Network Plugin
def afterLoadNet(self) -> None:
    # Retrieve the number of road segments
    link_count = self.netiface.linkCount()
    # If there are no road segments in the road network, invoke the custom method to create the road network
    if link_count == 0:
        # Custom method: Internal implementation logic for creating road segments, connector segments, and departure points
        self.create_network()
```

#### <span style="color: dodgerblue;">Note 6: Display control of road network elements</span>

​	In the Custom Road Network Plugin (class `MyNet`), overriding the `labelNameAndFont` method enables refined control over label display for road network elements (e.g., road segments, connector segments)—including customization of label content (display name / ID / none) and font size to satisfy visualization requirements under various scenarios.

- The following example demonstrates: the label of the road segment named “Cao'an Highway” displays the road segment name; other road segment labels display the ID; all connector segment labels display their name.

```python
# MyNet.py: Implementation file for the Custom Road Network Plugin
def ref_labelNameAndFont(self, itemType, itemId, ref_outPropName, ref_outFontSize) -> None:
    # 1. When the simulation is running (not paused): Labels on Road Segments and Lanes are not displayed to avoid interfering with simulation observation
   if self.simuiface.isRunning():
        ref_outPropName.value = GraphicsItemPropName.None_  # Do not display any labels
        return;  # Return immediately, no need to execute subsequent logic

    # 2. Default configuration: Labels display element ID, with a font size of 6 meters
    ref_outPropName.value = GraphicsItemPropName.Id
    ref_outFontSize.value = 6

    # 3. Connector Segment special configuration: All display the Name (regardless of ID, uniformly identified by Name)
    if itemType == NetItemType.GConnectorType:
    	ref_outPropName.value = GraphicsItemPropName.Name
    # 4. Road Segment special configuration: Only Road Segments with IDs 1, 5, and 6 display the Name; others display the ID
    elif itemType == NetItemType.GLinkType:
        if itemId == 1 or itemId == 5 or itemId == 6:
            ref_outPropName.value = GraphicsItemPropName.Name
```

#### <span style="color: dodgerblue;">Note 7: Query and modification of simulation information</span>

​	The `simuiface` interface can be used to query and modify **core simulation parameters**, including simulation duration, precision, speed multiplier, and more.

```python
# 1. Simulation Information Query: Retrieve Key Parameters of the Current Simulation
simu_interval = simuiface.simuIntervalScheming()  # Query the preset total simulation duration (Unit: s)
simu_accuracy = simuiface.simuAccuracy()  # Query simulation accuracy
simu_multiples = simuiface.acceMultiples()  # Query simulation speed multiplier
simu_time = simuiface.simuTimeIntervalWithAcceMutiples()  # Query the currently elapsed simulation time (Unit: ms)

# 2. Simulation Information Modification: Set Key Parameters of the Simulation
simuiface.setSimuIntervalScheming(3600)  # Set the total simulation duration to 3600 s
simuiface.setSimuAccuracy(1)  # Set the simulation accuracy to 1
simuiface.setAcceMultiples(5)  # Set the simulation speed multiplier to 5
```

#### <span style="color: dodgerblue;">Note 8: Addition, Deletion, Query, and Attribute Operations of Simulated Vehicles</span>

​	The `simuiface` interface enables adding, deleting, and querying **simulated vehicles**, supports retrieving all attributes of a vehicle object once obtained, and allows modification of **static attributes** (attributes that do not dynamically change during simulation, such as length and maximum speed).

- The following examples demonstrate adding, deleting, querying, and modifying simulated vehicles (via the `simuiface` interface).

```python
# 1. Query Vehicles: Retrieve the list of vehicles within a specified range
all_vehicles = simuiface.allVehiStarted()  # Retrieve all active vehicles currently in the simulation
link_vehicles = simuiface.vehisInLink(1)  # Retrieve vehicles currently traveling on the road segment with ID 1

# 2. Add Vehicle: Dynamically create a vehicle on a specified road segment (vehicle parameters must be configured first via DynaVehiParam)
dvp = Online.DynaVehiParam()  # Vehicle dynamic parameter object
dvp.vehiTypeCode = random.randint(0, 4) + 1  # Randomly set the vehicle type code (1-4, corresponding to different vehicle types)
dvp.roadId = 6  # Specify the vehicle's initial road segment ID (here, 6)
dvp.laneNumber = random.randint(0, 3)  # Randomly set the initial lane number (0-2, corresponding to lanes 1-3 of the road segment)
dvp.dist = 50  # Vehicle's initial distance along the road segment (50 m from the start of the road segment)
dvp.speed = 20  # Initial vehicle speed (Unit: m/s)
dvp.color = "#00AFF0"  # Vehicle display color
# Invoke interface to create vehicle, returns new vehicle object (returns None if creation fails)
vehicle1 = self.simuiface.createGVehicle(dvp)
# Verify if the vehicle was created successfully
if vehicle1 is not None:
	print(f"Created vehicle {vehicle1.id()} on the link.")

# 3. Delete vehicle: stop the specified vehicle (vehicle1) and remove it from the simulation
simuiface.stopVehicleDriving(vehicle1)
```

- The following example illustrates querying and static modification of vehicle attributes (via vehicle object).


```python
# 1. Attribute query: retrieve relevant attributes of the vehicle object
road_name = vehicle.roadName()  # Name of the road segment or connector segment where the vehicle is located
speed = vehicle.currSpeed()  # Get the vehicle's current speed (Unit: m/s)

# 2. Attribute modification: modify the vehicle's length and speed limit
vehicle.setLength(5);  # Modify the vehicle's length (Unit: m)
vehicle.setMaxSpeed(80/3.6);  # Modify the vehicle's maximum speed (Unit: m/s)
```

#### <span style="color: dodgerblue;">Note 9: Dynamic Attribute Modification of Simulated Vehicles</span>

​	The **dynamic attributes** of vehicles (such as real-time speed and acceleration, which change dynamically during simulation) cannot be directly modified through the vehicle object. They must be overridden in specific object methods within the **Custom Simulation Plugin (`MySimulator` class)** — essentially, this involves correcting or overriding the dynamically computed real-time values in TESS NG.

- The following example illustrates: in the `reSetSpeed` method, the real-time speed of certain vehicles is forcibly set based on their Vehicle ID and current Road Segment (causing vehicles with IDs 2 through N to follow the speed of the vehicle with ID 1).

```python
# MySimulator.py: Implementation file of the Custom Simulation Plugin
def ref_reSetSpeed(self, vehicle, ref_inOutSpeed) -> bool:
    # 1. Process Vehicle ID (apply modulus to avoid overly long IDs, retaining only the last 5 digits)
    tmp_vehicle_id = vehicle.id() % 100000

    # 2. Retrieve the current Road segment name where the Vehicle is located
    road_name = vehicle.roadName()

    # 3. Apply speed control logic exclusively to vehicles on "Cao'an Highway"
    if road_name == "Caoan Highway":
        # For Vehicle with ID=1: record its current speed as the base speed
        if tmp_vehicle_id == 1:
            self.plane_speed = vehicle.currSpeed()
       # For Vehicles with IDs from 2 to self.squareVehiCount: forcibly set their speed to the base speed
        elif 2 <= tmp_vehicle_id <= self.square_vehi_count:
           # Override the speed value calculated by TESS NG
            ref_inOutSpeed.value = self.plane_speed
           # Return True to indicate that the speed modification has taken effect
            return True
   # Return False to indicate that speed is unmodified; use TESS NG's default computed value
    return False
```

#### <span style="color: dodgerblue;">Note 10: Custom operations at specific simulation timings</span>

In the Custom Simulation Plugin (`MySimulator` class), you can override specific methods provided by TESS NG to **trigger custom logic at different simulation nodes**: supporting operations at **global simulation timings** (such as before simulation start and after simulation end), as well as triggering logic at **vehicle-specific behavior timings** (such as vehicle creation, vehicle removal, and before vehicle lane change), thereby meeting fine-grained simulation customization requirements.

- By overriding the `beforeStart` (before simulation start) and `afterStop` (after simulation end) methods, global simulation preprocessing and postprocessing can be implemented, such as initializing simulation parameters, executing simulation loops, and exporting simulation results. The following example demonstrates: after the simulation ends, it checks whether the cumulative simulation count is ≤ 3; if the condition is met, the simulation is automatically restarted (implementing loop simulation).

```python
# MySimulator.py: Implementation file of the Custom Simulation Plugin
def afterStop(self) -> None:
    # 1. simuCount is a user-defined variable used to count the cumulative simulation count.
    if self.simu_count <= 3:
        # 2. Call the interface to restart the simulation
        self.simuiface.startSimu()
```

- By overriding methods bound to vehicle behaviors, logic can be triggered when the vehicle meets specific conditions, such as initializing attributes after vehicle creation or recording data after vehicle removal. The following example demonstrates: after simulated vehicle creation, set the vehicle type, position, and length based on the vehicle ID.

```python
# MySimulator.py: Implementation file of the Custom Simulation Plugin
from tessng import m2p

def initVehicle(self, vehicle) -> None:
    # 1. Obtain basic information of the current vehicle (Road segment name, Road Segment ID)
    road_name = vehicle.roadName()  # Name of the road segment or connector segment where the vehicle is currently located
    road_id = vehicle.roadId()  # ID of the road segment or connector segment where the vehicle is currently located

    # 2. Execute special customized logic only for vehicles on 'Cao'an Highway'
   if road_name == 'Caoan Highway':
        # Process Vehicle ID: modulo 100000, remove the leading digit (the leading digit usually corresponds to the vehicle source, such as the departure point or bus route)
       tmp_vehicle_id = vehicle.id() % 100000

       # 3. For vehicles with specific IDs, set dedicated vehicle types and initial positions
        if tmp_vehicle_id == 1:
            # Set the vehicle with ID=1 to 'Vehicle Type 12'
            vehicle.setVehiType(12)
            # Initialize the vehicle’s initial lane, position, and speed
            vehicle.initLane(3, m2p(105), 0)
        # Additional customization logic for other vehicle IDs can be added here, such as tmp_vehicle_id=2, 3, etc.

        # 4. Set specific length for vehicles with IDs 23 to 28
        if tmp_vehicle_id >= 23 and tmp_vehicle_id <= 28:
            vehicle.setLength(m2p(4.5), True)
```



<div style="page-break-after: always;"></div>

# 3. Interface Details

​	This section first introduces the **Global Configuration Parameters (config.json)**, followed by a detailed explanation of the three hierarchical levels: **Plugin**, **Interface**, and **Object**, to help readers progressively comprehend TESS NG's secondary development model from a macro to micro perspective.



## 3.1. Global Configuration Parameters

​	The global configuration parameters recognized by TESS NG in config.json are as follows: 

```json
{
	"__netfilepath": "xxx.tess", 		
	"__simuafterload": false, 
	"__timebycpu": false, 
	"__writesimuresult": true, 
	"__custsimubysteps": false,
    "__allowspopup": false
}
```

**__netfilepath**

​	Specify the path of the road network file loaded upon TESS NG startup, supporting both absolute and relative paths. If the file is not found, a blank road network will be loaded by default.

**__simuafterload**

​	Specify whether TESS NG should automatically start the simulation after loading the road network file; the default value is False. 

**__timebycpu**

​	Specifies the time calculation basis for the simulation cycle: either real elapsed time based on the CPU clock or duration based on simulation accuracy; default is False. When performing online simulation under limited computing resources, this attribute may be set to True.

**__writesimuresult**

​	Controls whether simulation results are output; default is True. If set to False, result files will not be written after simulation ends, and during simulation, vehicles that have left the road network for a certain period will be recycled into the available queue to reduce memory usage.

**__custsimubysteps**

​	Sets the basis for the frequency of TESSNG calling plugin methods; default is False. When set to False, calls occur once per calculation cycle (ignoring the frequency settings on the plugin side); When set to True, the plugin's implemented methods will be called according to the frequency configured by the plugin.

**__allowspopup**

​	Controls whether popup notification dialogs are allowed to prevent blocking program execution. The default value is True.



## 3.2. Plugin

​	Typically, software functionality is extended by defining plugin interfaces that users then implement. TESS NG follows this model as well, featuring the top-level plugin interface TessPlugin, along with two sub-plugin interfaces: PyCustomerNet and PyCustomerSimulator. Unlike the TessInterface interface, which only permits calling interface methods without modifying the internal runtime logic, users implementing TessPlugin and its sub-interfaces can deeply intervene in TESS NG’s internal processes—such as road network loading, simulation procedures, and window interactions—thereby altering its operational logic and enabling more advanced functional extensions. All methods of these two sub-plugins provide default implementations; users may selectively implement some or all methods according to their requirements.

​	Due to differences in the calling scenarios and purposes of plugin interface methods, to unify the understanding of these methods, most adopt the following structural form:

```python
def ref_method(outParam: type) -> bool: 
{
    outParam.value = 1
	return True
}
```

​	When invoking these methods, TESS NG follows the logic below: **If the return value is False, it is considered that the user did not respond, and the call will be ignored; If the return value is True, it indicates the user has responded, and subsequent processing will be performed based on the value of the parameter outParam**. For example, when vehicles form a queue on Cao’an Highway, the speed of vehicles behind an aircraft needs to be reset to match that of the aircraft. In this case, a subclass MySimulator of PyCustomerSimulator can achieve this by implementing the `ref_reSetSpeed` method.

```python
def ref_reSetSpeed(self, vehicle, ref_inOutSpeed) -> bool:
    tmp_vehicle_id = vehicle.id() % 100000
    road_name = vehicle.roadName()
    if road_name == "Caoan Highway":
        if tmp_vehicle_id == 1:
            self.plane_speed = vehicle.currSpeed()
        elif 2 <= tmp_vehicle_id <= self.square_vehi_count:
            ref_inOutSpeed.value = self.plane_speed
            return True
    return False
```

After TESS NG calculates the vehicle's speed, it calls the plugin's reSetSpeed method. If this method returns True, it indicates that the plugin has handled the call, and the originally calculated speed will be replaced with the outSpeed value. The process by which TESS NG calls the plugin `reSetSpeed` method (C++ code) is as follows:

```cpp
if (gpTessPlugin && gpTessPlugin->customerSimulator())
{
   qreal outSpeed = mrCurrSpeed；
   if (gpTessPlugin->customerSimulator()->reSetSpeed(mpGVehicle，outSpeed))
   {
       mrCurrSpeed = outSpeed；
   }
}
```

### 3.2.1. Top-level Plugin (TessPlugin)

TessPlugin is the top-level plugin interface developed by users. It contains two sub-plugin interfaces: PyCustomerNet and PyCustomerSimulator. Users interact with TESS NG in two domains, the road network and the simulation process, respectively, by implementing these two sub-plugins.

**def init(self) -> None**

Plugin initialization: in this method, subclasses of the CustomerNet and CustomerSimulator classes can be instantiated.

**def customerNet(self) -> Tessng.CustomerNet**

Returns the customerNet object.

**def customerSimulator(self) -> Tessng.CustomerSimulator**

Returns the CustomerSimulator object.


### 3.2.2. Road Network Plugin (PyCustomerNet)

PyCustomerNet is a sub-plugin interface of TessPlugin. By implementing this plugin, users can perform custom operations before and after road network loading, control the rendering of road network elements, and define the response logic for viewport events.

#### 3.2.2.1. Road Network Loading

**def beforeLoadNet(self) -> None**

Called before loading the road network. Users can employ this method to perform necessary initialization before loading the road network.

**def afterLoadNet(self) -> None**

Called after loading the road network.

Example:

```python
def afterLoadNet(self) -> None:
    # Retrieve the number of road segments
    link_count = self.netiface.linkCount()
    # If there are no road segments in the road network, invoke the custom method to create the road network
    if link_count == 0:
        self.create_network()
```

#### 3.2.2.2. Road Network Element Rendering

**def isPermitForCustDraw(self) -> bool**

Indicates whether custom drawing is permitted. This method aims to reduce unnecessary code calls and eliminate adverse effects on runtime efficiency.

Return:

Whether to draw: True to draw, False not to draw; default is True.

**def isDrawLinkCenterLine(self, linkId: int) -> bool**

Whether to draw the road segment centerline.

Parameters:

[ in ] linkID: Road Segment ID.

Return:

Whether to draw: True to draw, False not to draw; default is True.

Example:

```python
def isDrawLinkCenterLine(self, linkId: int) -> bool:
    # Do not draw the centerline for the road segment with ID 1
    return link_id != 1
```

**def isDrawLinkCorner(self, linkId: int) -> bool**

Whether to draw circular and square shapes at the four corners of the road segment.

Parameters:

[ in ] linkID: Road Segment ID.

Return:

Whether to draw: True to draw, False not to draw; default is True.

**def isDrawLaneCenterLine(self, laneId: int) -> bool**

Whether to draw the lane centerline.

Parameters:

[ in ] laneID: Lane ID.

Return:

Whether to draw: True to draw, False not to draw; default is False.

**def linkType(self, list[str] lType) -> bool**

Road segment type.

Parameters:

[ in ] lType: User-defined list of road segment types.

Return:

Whether custom defined.

**def laneType(self, List[str] lType) -> bool**

Lane type.

Parameters:

[ in ] lType: User-defined list of lane types.

Return:

Whether custom defined.

**def paint(self, itemType: int, itemId: int, painter: PySide2.QtGui.QPainter) -> bool**

Draw road network elements.

Parameters:

[ in ] itemType: Road network element type.

[ in ] itemID: Road network element ID.

[ in ] painter: QPainter object.

Return:

If True is returned, TESS NG considers the plugin has completed drawing, and TESS NG will not draw further; otherwise, TESS NG proceeds with drawing.

**def paintLaneObject(self, pILaneObj: Tessng.ILaneObject, painter: PySide2.QtGui.QPainter) -> bool**

Draw lane or lane connection.

Parameters:

[ in ] pILaneObj: Lane or lane connection.

[ in ] painter: QPainter object.

Return:

If True is returned, TESS NG considers the plugin has completed drawing, and TESS NG will not draw further; otherwise, TESS NG proceeds with drawing.

**def linkBuildGLanes(self, pILink: Tessng.ILink) -> bool**

Create lane.

Parameters:

[ in ] pILink: Road segment object.

Return:

If True is returned, TESS NG considers the plugin has created the lane, and TESS NG will not create it again.

**def linkBrushColor(self, linkId: int, color: PySide2.QtGui.QColor) -> bool**

Road segment brush color.

Parameters:

[ in ] linkID: Road Segment ID.

[ out ] color: QColor object.

Return:

Returning True indicates the road segment is drawn using the specified color.

Example:

```python
from PySide2.QtGui import QColor

def linkBrushColor(self, linkId: int, color: QColor) -> bool:
    # Set the specified road segment to red
    target_link_ids = [1, 2, 3]
    if linkId in target_link_ids:
        color.setNamedColor("#FF0000")
        return True
    return False
```

**def laneBrushAndPen(self, laneId: int, brush: PySide2.QtGui.QBrush, pen: PySide2.QtGui.QPen) -> bool**

Set the brush used for drawing lanes by specifying the Lane ID.

Parameters:

[ in ] laneID: Lane ID.

[ out ] brush: QBrush object.

[ out ] pen: QPen object.

Return:

True indicates that the lane with laneID is drawn using the specified brush and pen.

**def connectorAreaBrushColor(self, connAreaId: int, color: PySide2.QtGui.QColor) -> bool**

Polygon brush color.

Parameters:

[ in ] connAreaID: Polygon ID.

[ out ] color: Brush color.

Return:

True indicates that TESSNG draws the polygon using the specified color.

**def labelNameAndFont(self, itemType: int, itemId: int, outPropName: int, outFontSize: float) -> None**

**def ref_labelNameAndFont(self, itemType: int, itemId: int, ref_outPropName: Tessng.objint, ref_outFontSize: Tessng.objreal) -> None**

Determine whether to use ID or Name as the drawing content based on the road network element type and ID.

Parameters:

[ in ] itemType: Road network element type.

[ in ] itemID: Road network element ID.

[ out ] outPropName: Enum value. If assigned GraphicsItemPropName::ID, the ID is used as the drawing content; if assigned GraphicsItemPropName::Name, the road network element Name is used as the drawing content.

​	 [out] outFontSize: Font size. Unit: m.

Return:	

​	True indicates that the label is drawn using the ID or Name according to the specified ref_PropName value, and rendered at the designated size.

Example:

```python
from tessng import objint, objreal

def ref_labelNameAndFont(self, itemType: int, itemId: int, ref_outPropName: objint, ref_outFontSize: objreal) -> None:
    # If the simulation is running, labels for both Road Segments and Lanes will not be drawn.
    if self.simuiface.isRunning():
        ref_outPropName.value = GraphicsItemPropName.None_
        return

    # Default is to display the ID.
    ref_outPropName.value = GraphicsItemPropName.Id
    # Label size is 6 m.
    ref_outFontSize.value = 6

    # For Connector Segments, always display the Name.
    if itemType == NetItemType.GConnectorType:
        ref_outPropName.value = GraphicsItemPropName.Name
    # For Road Segments, whether to display the Name is determined based on the ID.
    elif itemType == NetItemType.GLinkType:
        if itemId == 1 or itemId == 5 or itemId == 6:
            ref_outPropName.value = GraphicsItemPropName.Name
```

#### 3.2.2.3. Window Event Response

**def afterViewMousePressEvent(self, event: PySide2.QtGui.QMouseEvent) -> None**

​	Used to implement custom response logic upon mouse click.

Parameters:

​	[ in ] event: Mouse Event Object.

Example:

```python
from PySide2.QtGui import QMouseEvent

def afterViewMousePressEvent(self, event: QMouseEvent) -> None:
	# Retrieve mouse coordinates
    mouse_pos = event.pos()
    # Convert to simulation scene coordinates
    scene_pos = self.netiface.graphicsView().mapToScene(mouse_pos)
    x = scene_pos.x()
    y = scene_pos.y()
```

**def afterViewMouseReleaseEvent(self, event: PySide2.QtGui.QMouseEvent) -> None**

​	Used to implement custom response logic upon mouse release.

Parameters:

​	[ in ] event: Mouse Event Object.

**def afterViewMouseDoubleClickEvent(self, event: PySide2.QtGui.QMouseEvent) -> None**

Used to implement custom response logic following a mouse double-click.

Parameters:

​	[ in ] event: Mouse Event Object.

**def afterViewMouseMoveEvent(self, event: PySide2.QtGui.QMouseEvent) -> None**

Used to implement custom response logic following mouse movement.

Parameters:

​	[ in ] event: Mouse Event Object.

**def afterViewWheelEvent(self, event: PySide2.QtGui.QWheelEvent) -> None**

Used to implement custom response logic following mouse scrolling.

Parameters:

[ in ] event: mouse wheel event object.

**def afterViewKeyReleaseEvent(self, event: PySide2.QtGui.QKeyEvent) -> None**

Used to implement custom response logic following keyboard release.

Parameters:

[ in ] event: keyboard event object.

**def afterViewResizeEvent(self, event: PySide2.QtGui.QResizeEvent) -> None**

Used to implement custom response logic following screen zoom.

Parameters:

[ in ] event: screen zoom event object.

**def afterViewScrollContentsBy(self, dx: int, dy: int) -> None**

Used to implement custom response logic following window scrollbar movement.

Parameters:

[ in ] dx: horizontal scroll offset; a value greater than 0 indicates scrolling left. Unit: pixel.

​	[ in ] dy: Vertical scroll offset; a value greater than 0 indicates upward scrolling. Unit: pixel.

### 3.2.3. Simulation Plugin (PyCustomerSimulator)

​	PyCustomerSimulator is a TessPlugin sub-plugin interface. By implementing this plugin, users can perform custom operations before, during, and after the simulation, allowing both global control of the simulation start and stop logic and precise intervention in the driving behavior of individual vehicles.

#### 3.2.3.1. Simulation Start and Stop

**def beforeStart(self, keepOn: bool) -> None**

**def ref_beforeStart(self, ref_keepOn: Tessng.objbool) -> None**

​	Used to implement custom operations before starting the simulation. If necessary, users can abort the simulation by setting keepOn to False.

Parameters:

​	[ out ] keepOn: Whether to continue; default is True.

**def afterStart(self) -> None**

Used to implement custom operations after the simulation starts.

**def afterStop(self) -> None**

Used to implement custom operations after the simulation ends.

Example:

```python
def afterStop(self) -> None:
    # Restart the simulation if the number of runs is less than 3
    if self.simu_count <= 3:
        self.simuiface.startSimu()
```

**def afterOneStep(self) -> None**

Used to implement custom operations after completing one simulation frame. At this point, all vehicles have completed computation for the same batch. Typically, this method is used to acquire vehicle trajectories, detector data, and perform necessary subtotals. Calculations performed in this method generally do not affect the consistency of simulation results, but efficiency is relatively low; a large computational load may impact simulation performance.

**def duringOneStep(self) -> None**

This method is invoked during the computation of the same batch across various worker threads, where some vehicles have finished computation while others are still processing. Calculations in this method are less safe but offer higher efficiency.

**def calcSimuConfig(self, config: Online.SimuConfig) -> bool**

Calculate simulation parameters.

Parameters:

[ out ] config: simulation parameter information.

Return:

True indicates updating the simulation parameters using those in config. If the simulation has started, simulation accuracy and thread count cannot be updated; simulation duration and acceleration factor can be updated.

#### 3.2.3.2. Vehicle Control

**def initVehicle(self, pIVehicle: Tessng.IVehicle) -> None**

Used to implement custom operations after vehicle creation. Users can initialize the vehicle’s lane index, starting position, and vehicle size within this method.

Parameters:

[ in ] pIVehicle: vehicle object.

Example:

```python
from tessng import IVehicle

def initVehicle(self, pIVehicle: IVehicle) -> None:
    # Set to blue if it is a passenger car
	if pIVehicle.vehicleTypeCode() == 1:
		pIVehicle.setColor("#00AFF0")
```

**def isStopDriving(self, pIVehicle: Tessng.IVehicle) -> bool**

Used to determine whether to stop the vehicle’s operation.

Parameters:

[ in ] pIVehicle: vehicle object.

Return:

True indicates stopping the vehicle's operation and removing it from the road network.

Example:

```python
from tessng import IVehicle

def isStopDriving(self, pIVehicle: IVehicle) -> bool:
    # Remove the vehicle if it enters Road Segment 12.
    if pIVehicle.roadIsLink() and pIVehicle.roadId() == 12:
        return True
    return False
```

**def beforeStopVehicle(self, pIVehicle: Tessng.IVehicle) -> None**

​	Used to perform custom operations before vehicle removal.

Parameters:

[ in ] pIVehicle: vehicle object. 

**def afterStopVehicle(self, pIVehicle: Tessng.IVehicle) -> None**

​	Used to perform custom operations after vehicle removal.

Parameters:

[ in ] pIVehicle: vehicle object.

**def afterStep(self, pIVehicle: Tessng.IVehicle) -> None**

​	Used to perform custom operations after completing one simulation frame. Vehicle current information can be retrieved here, such as the current road, position, heading angle, speed, desired speed, and surrounding vehicles (front, rear, left, right).

Parameters:

[ in ] pIVehicle: vehicle object.

**def calcAcce(self, pIVehicle: Tessng.IVehicle, acce: float) -> bool**

**def calcAcce(self, pIVehicle: Tessng.IVehicle, acce: float, unit: UnitOfMeasure) -> bool**

**def ref_calcAcce(self, pIVehicle: Tessng.IVehicle, acce: Tessng.objreal) -> bool**

**def ref_calcAcce_unit(self, pIVehicle: Tessng.IVehicle, ref_acce: Tessng.objreal, ref_unit: Tessng.objUnitOfMeasure) -> bool**

​	Calculate the vehicle's acceleration.

Parameters:

[ in ] pIVehicle: vehicle object.

​	[ out ] acce: Vehicle acceleration. Unit: pixel/s².

Return:	

​	If True is returned, acce will be set as the current acceleration.

Example:

```python
from tessng import IVehicle, objreal, objUnitOfMeasure

def ref_calcAcce_unit(self, pIVehicle: IVehicle, ref_acce: objreal, ref_unit: objUnitOfMeasure) -> bool:
    if pIVehicle.roadName() == "Caoan Highway":
        # Calculate acceleration directly based on speed differences.
        if pIVehicle.currSpeed() > 20/3.6:
            ref_acce.value = -3
            return True;
        elif pIVehicle.currSpeed() > 10/3.6:
            ref_acce.value = -1
          	return True
	return False
```

**def reSetAcce(self, pIVehicle: Tessng.IVehicle, inOutAcce: float) -> bool**

**def reSetAcce(self, pIVehicle: Tessng.IVehicle, inOutAcce: float, unit: UnitOfMeasure) -> bool**

**def ref_reSetAcce(self, pIVehicle: Tessng.IVehicle, ref_inOutAcce: Tessng.objreal) -> bool**

**def ref_reSetAcce_unit(self, pIVehicle: Tessng.IVehicle, ref_inOutAcce: Tessng.objreal, ref_unit: Tessng.objUnitOfMeasure) -> bool**

​	Recalculate the vehicle's acceleration.

Parameters:

[ in ] pIVehicle: vehicle object.

​	[ in, out ] inOutAcce: Vehicle acceleration. Unit: pixel/s².

Return:

If True is returned, inOutAcce will be set as the current acceleration.

Example:

```python
from tessng import IVehicle, objreal, objUnitOfMeasure

def ref_reSetAcce_unit(self, pIVehicle: IVehicle, ref_inOutAcce: objreal, ref_unit: objUnitOfMeasure) -> bool:
    if pIVehicle.roadName() == "Caoan Highway":
        # Adjust the calculated acceleration based on the speed
        if pIVehicle.currSpeed() > 20/3.6:
            acce.value += -3
            return True
        elif pIVehicle.currSpeed() > 10/3.6:
            acce.value += -1
          	return True
	return False
```

**def reCalcdesirSpeed(self, pIVehicle: Tessng.IVehicle, inOutDesirSpeed: float) -> bool**

**def reCalcdesirSpeed(self, pIVehicle: Tessng.IVehicle, inOutDesirSpeed: float, unit: UnitOfMeasure) -> bool**

**ref_reCalcdesirSpeed(self, pIVehicle: Tessng.IVehicle, ref_desirSpeed: Tessng.objreal) -> bool**

**ref_reCalcdesirSpeed_unit(self, pIVehicle: Tessng.IVehicle, ref_inOutDesirSpeed: Tessng.objreal, ref_unit: Tessng.objUnitOfMeasure) -> bool**

Recalculate the vehicle's desired speed.

Parameters:

[ in ] pIVehicle: vehicle object.

[ in, out ] inOutDesirSpeed: Vehicle desired speed. Unit: pixel/s².

Return:

If True is returned, inOutDesirSpeed will be set as the desired speed.

**def calcMaxLimitedSpeed(self, pIVehicle: Tessng.IVehicle, inOutLimitedSpeed: float) -> bool**

**def calcMaxLimitedSpeed(self, pIVehicle: Tessng.IVehicle, inOutLimitedSpeed: float, unit: UnitOfMeasure) -> bool**

**ref_calcMaxLimitedSpeed(self, pIVehicle: Tessng.IVehicle, ref_inOutLimitedSpeed: Tessng.objreal) -> bool**

**ref_calcMaxLimitedSpeed_unit(self, pIVehicle: Tessng.IVehicle, ref_inOutLimitedSpeed: Tessng.objreal, ref_unit: Tessng.objUnitOfMeasure) -> bool**

Recalculate the vehicle's current maximum speed limit. Without plugin intervention, vehicles travel at the road's maximum speed limit when exceeding the limit. With this method's intervention, the speed limit can be increased, allowing vehicles to exceed the road speed limit.

Parameters:

[ in ] pIVehicle: vehicle object.

[ in, out ] inOutLimitedSpeed: Vehicle maximum speed limit. Unit: pixel/s.

Return:

If it returns True, inOutLimitedSpeed will be regarded as the maximum speed limit of the current road.

**def calcSpeedLimitByLane(self, pILink: Tessng.ILink, laneNumber: int, outSpeed: float) -> bool**

**def calcSpeedLimitByLane(self, pILink: Tessng.ILink, laneNumber: int, outSpeed: float, unit: UnitOfMeasure) -> bool**

**ref_calcSpeedLimitByLane(self, pILink: Tessng.ILink, laneNumber: int, ref_outSpeed: Tessng.objreal) -> bool**

**def ref_cadLimitByLane_unit(self, pILink: Tessng.ILink, laneNumber: int, ref_outSpeed: Tessng.objreal, ref_unit: Tessng.objUnitOfMeasure) -> bool**

Speed limit determined by the lane.

Parameters:

[ in ] pILink: Road segment object.

[ in ] laneNumber: Lane Index, where 0 is the rightmost lane.

[ in, out ] outSpeed: Vehicle speed limit. Unit: km/h.

Return:	

If it returns True, outSpeed will be regarded as the lane speed limit.

**def reSetSpeed(self, pIVehicle: Tessng.IVehicle, inOutSpeed: float) -> bool**

**def reSetSpeed(self, pIVehicle: Tessng.IVehicle, inOutSpeed: float, unit: UnitOfMeasure) -> bool**

**ref_reSetSpeed(self, pIVehicle: Tessng.IVehicle, ref_inOutSpeed: Tessng.objreal) -> bool**

**ref_reSetSpeed_unit(self, pIVehicle: Tessng.IVehicle, ref_inOutSpeed: Tessng.objreal, ref_unit: Tessng.objUnitOfMeasure) -> bool**

Recalculate the vehicle’s speed.

Parameters:

[ in ] pIVehicle: vehicle object.

[ in, out ] inOutSpeed: Vehicle speed. Unit: pixel/s.

Return:

If it returns True, inOutSpeed will be regarded as the current speed of the vehicle.

Example:

```python
from tessng import IVehicle, objreal, objUnitOfMeasure

def ref_reSetSpeed_unit(self, vehicle: IVehicle, ref_inOutSpeed: objreal, ref_unit: objUnitOfMeasure) -> bool:
    if vehicle.id() == 100001:
        # Directly specify the vehicle’s speed
        ref_inOutSpeed.value = 80 / 3.6;
        return True
    return False
```

**def reCalcAngle(self, pIVehicle: Tessng.IVehicle, inOutAngle: float) -> bool**

**def ref_reCalcAngle(self, pIVehicle:Tessng.IVehicle, ref_outAngle:Tessng.objreal) -> bool**

Recalculate the vehicle’s angle. North is 0 degrees, clockwise rotation.

Parameters:

[ in ] pIVehicle: vehicle object.

[ in, out ] inOutAngle: Vehicle angle. Unit: degrees.

Return:

​	If True is returned, inOutAngle will be set as the vehicle's current angle.

**def reSetFollowingType(self, pIVehicle: Tessng.IVehicle, outTypeValue: int) -> bool**

**def ref_reSetFollowingType(self, pIVehicle: Tessng.IVehicle, ref_outTypeValue: Tessng.objint) -> bool**

​	Reset the vehicle's Car-Following Type.

Parameters:

[ in ] pIVehicle: vehicle object.

​	[ out ] outTypeValue: Car-Following Type. 0: Stopped, 1: Normal, 5: Emergency Deceleration, 6: Emergency Acceleration, 7: Merging, 8: Crossing, 9: Cooperative Deceleration, 10: Cooperative Acceleration, 11: Deceleration Waiting to Turn, 12: Acceleration Waiting to Turn.

Return:	

​	If True is returned, outTypeValue will be set as the vehicle's Car-Following Type.

**def reSetFollowingParam(self, pIVehicle: Tessng.IVehicle, inOutSafeInterval: float, inOutSafeDistance: float) -> bool**

**def reSetFollowingParam(self, pIVehicle: Tessng.IVehicle, inOutSafeInterval: float, inOutSafeDistance: float, unit: UnitOfMeasure) -> bool**

**def ref_reSetFollowingParam(self, pIVehicle: Tessng.IVehicle, ref_inOutSafeInterval: Tessng.objreal, ref_inOutSafeDistance: Tessng.objreal) -> bool**

**def ref_reSetFollowingParam_unit(self, pIVehicle: Tessng.IVehicle, ref_inOutSafeInterval: Tessng.objreal, ref_inOutSafeDistance: Tessng.objreal, ref_unit: Tessng.objUnitOfMeasure) -> bool**

​	Reset the vehicle's Car-Following Model safe distance and safe time headway.

Parameters:

[ in ] pIVehicle: vehicle object.

​	[ in, out ] inOutSafeInterval: Safe time headway, Unit: seconds.

​	[ in, out ] inOutSafeDistance: Safe distance, Unit: pixel.

Return:

If the return value is True, inOutSafeInterval will be used as the vehicle's safety headway time, and inOutSafeDistance as the vehicle's safety spacing.

**def reSetFollowingParams(self) -> list[Online.FollowingModelParam]**

Reset the vehicle’s Car-Following Model parameters by replacing the current Car-Following Model used in the simulation with the obtained Car-Following Model data, affecting all vehicles.

Return:

Car-Following parameter list, allowing the reset of parameters for both motor and non-motor vehicles. **Once set, these parameters will be continuously applied** until superseded by new ones.

**def reSetDistanceFront(self, pIVehicle: Tessng.IVehicle, distance: float, s0: float) -> bool**

**def reSetDistanceFront(self, pIVehicle: Tessng.IVehicle, distance: float, s0: float, unit: UnitOfMeasure) -> bool**

**def ref_reSetDistanceFront(self, pIVehicle: Tessng.IVehicle, distance: Tessng.objreal, s0: Tessng.objreal) -> bool**

**def ref_reSetDistanceFront_unit(self, pIVehicle: Tessng.IVehicle, ref_distance: Tessng.objreal, ref_s0: Tessng.objreal, ref_unit: Tessng.objUnitOfMeasure) -> bool**

Reset the vehicle’s spacing to the preceding vehicle and stopping distance.

Parameters:

[ in ] pIVehicle: vehicle object.

[ in, out ] distance: the current distance between the vehicle and the preceding vehicle. Unit: pixel.

[ in, out ] s0: stopping distance. Unit: pixel.

Return:

If returning True, distance will be treated as the vehicle’s headway, and s0 as the vehicle’s stopping distance.

**def calcChangeLaneSafeDist(self, pIVehicle: Tessng.IVehicle, dist: float) -> bool**

**def calcChangeLaneSafeDist(self, pIVehicle: Tessng.IVehicle, dist: float, unit: UnitOfMeasure) -> bool**

**def ref_calcChangeLaneSafeDist(self, pIVehicle: Tessng.IVehicle, ref_dist: Tessng.objreal) -> bool**

**def ref_calcChangeLaneSafeDist_unit(self, pIVehicle: Tessng.IVehicle, ref_dist: Tessng.objreal, ref_unit: Tessng.objUnitOfMeasure) -> bool**

Calculate the vehicle’s safe lane-changing distance.

Parameters:

[ in ] pIVehicle: Vehicle for which to calculate the safe lane-changing distance.

[ in, out ] dist: Safe lane-changing distance. Unit: pixel.

Return:

If returning True, dist will be used as the vehicle’s safe lane-changing distance.

**def reCalcToLeftLane(self, pIVehicle: Tessng.IVehicle) -> bool**

Determine whether to enforce left mandatory lane changing; effective only when TESSNG determines no need to perform left mandatory lane changing, and cannot override TESSNG’s control over mandatory left lane changing for the vehicle.

Parameters:

[ in ] pIVehicle: vehicle object.

Return:

If returning True, enforce the vehicle to perform left mandatory lane changing.

**def reCalcToRightLane(self, pIVehicle: Tessng.IVehicle) -> bool**

Calculate whether to enforce a forced lane change to the right. This only applies when TESS NG determines that no forced lane change to the right is required and does not prevent TESS NG from controlling the vehicle’s forced lane change to the right.

Parameters:

[ in ] pIVehicle: vehicle object.

Return:

If True is returned, it commands the vehicle to perform a forced lane change to the right.

**def beforeToLeftFreely(self, pIVehicle: Tessng.IVehicle, bKeepOn: bool) -> None**

**def ref_beforeToLeftFreely(self, pIVehicle: Tessng.IVehicle, ref_keepOn: Tessng.objbool) -> None**

Pre-processing before TESS NG calculates whether to perform a left free lane changing.

Parameters:

[ in ] pIVehicle: vehicle object.

[ in, out ] bKeepOn: Indicates whether to continue; if set to False, TESS NG will cease further evaluation of the possibility of left free lane changing.

**def beforeToRightFreely(self, pIVehicle: Tessng.IVehicle, bKeepOn: bool) -> None**

**def ref_beforeToRightFreely(self, pIVehicle: Tessng.IVehicle, ref_keepOn: Tessng.objbool) -> None**

Pre-processing before TESS NG calculates whether to perform a right free lane changing.

[ in ] pIVehicle: vehicle object.

[ in, out ] bKeepOn: Indicates whether to continue; if set to False, TESS NG will cease further evaluation of the possibility of right free lane changing.

**def reCalcToLeftFreely(self, pIVehicle: Tessng.IVehicle) -> bool**

Recalculate whether the vehicle needs to perform left free lane changing; this is effective only when TESS NG determines that left free lane changing is unnecessary and cannot override TESS NG’s control of the vehicle’s left free lane changing.

Parameters:

[ in ] pIVehicle: vehicle object.

Return:

If True is returned, the vehicle will be controlled to perform left free lane changing.

**def reCalcToRightFreely(self, pIVehicle: Tessng.IVehicle) -> bool**

Recalculate whether the vehicle needs to perform right free lane changing; this is effective only when TESS NG determines that right free lane changing is unnecessary and cannot override TESS NG’s control of the vehicle’s right free lane changing.

Parameters:

[ in ] pIVehicle: vehicle object.

Return:

If True is returned, the vehicle will be controlled to perform right free lane changing.

**def reCalcDismissChangeLane(self, pIVehicle: Tessng.IVehicle) -> bool**

Recalculate whether the vehicle should cancel lane changing.

Parameters:

[ in ] pIVehicle: vehicle object.

Return:

If True is returned and the current lane changing progress does not exceed one third, the current lane changing action will be canceled.

Example:

```python
from tessng import IVehicle

def reCalcDismissChangeLane(self, pIVehicle: IVehicle) -> bool:
    # Cancel all free lane changing when the distance to the end of the road segment is less than 50 m, thereby prohibiting free lane changing
	if pIVehicle.vehicleDriving().distToEndpoint(True, True, UnitOfMeasure.Metric) < 50:
        return True
    return False
```

**def calcLimitedLaneNumber(self, pIVehicle: Tessng.IVehicle) -> list[int]**

​	Calculate restricted lane indexes: for example, controlled, hazardous, etc., with the rightmost lane numbered 0.

Parameters:

​	[ in ] pVehicle: Vehicle object.

Return:

​	Sequence of lane indexes storing lanes that the vehicle is prohibited from entering.

Example:

```python
from tessng import IVehicle

def calcLimitedLaneNumber(self, pIVehicle: IVehicle) -> list[int]:
    # If the vehicle is on the road segment and its length exceeds 8 m, entering the innermost lane is prohibited
    if pIVehicle.roadIsLink() and pIVehicle.length(UnitOfMeasure.Metric) > 8:
       limit_lane_number = pIVehicle.lane().link().laneCount()
       return [limit_lane_number]
    return []
```

**def candIDateLaneConnectors(self, pIVehicle: Tessng.IVehicle, lInLC: list[Tessng.ILaneConnector]) -> list[Tessng.ILaneConnector]**

​	Calculate the lane connections accessible after the vehicle leaves the road segment. Users may filter or recalculate from the accessible lane connection sequence. If the vehicle has a route, this calculation is ignored.

Parameters:

​	[ in ] pVehicle: Vehicle object.

​	[ in ] lInLC: The currently computed lane connections reachable from the current lane.

Return:

Sequence of reachable subsequent Lane Connections.

**def candIDateLaneConnector(self, pIVehicle: Tessng.IVehicle, pCurrLaneConnector: Tessng.ILaneConnector) -> Tessng.ILaneConnector**

Calculate the subsequent Lane Connection the vehicle will take when it is about to leave the current Road Segment and move onto pCurrLaneConnector. This method can modify the subsequent Lane Connection. If the returned Lane Connection is null, TESSNG will ignore this method call. If the returned Lane Connection is not part of the original Route, or if this method sets a new Route that does not include the returned Lane Connection, TESSNG will clear the Route after invoking this method.

Parameters:

​	[ in ] pVehicle: Vehicle object.

[ in ] pCurrLaneConnector: The currently determined Lane Connection the vehicle will take.

Return:

Reassigned Lane Connection.

**def beforeNextPoint(self, pIVehicle: Tessng.IVehicle, keepOn: bool) -> None**

**def ref_beforeNextPoint(self, pIVehicle: Tessng.IVehicle, ref_keepOn: Tessng.objbool) -> None**

Operations before the vehicle moves to the next point. Users can use this method to instruct TESSNG to skip the calculation for the specified vehicle moving to the next point.

Parameters:

[ in ] pIVehicle: vehicle object.

​	[ out ] keepOn: Indicates whether to continue; if keepOn is set to False, TESS NG abandons the calculation of moving to the next point but does not remove the vehicle from the road network.

**def beforeMergingToLane(self, pIVehicle: Tessng.IVehicle, keepOn: bool) -> None**

**def ref_beforeMergingToLane(self, pIVehicle: Tessng.IVehicle, ref_keepOn: Tessng.objbool) -> None**

​	The calculation prior to merging on the lane connection allows TESS NG to forgo the merging computation, enabling users to implement their own merging logic.

Parameters:

[ in ] pIVehicle: vehicle object.

​	[ out ] keepOn: Indicates whether to abandon; if keepOn is set to False, TESS NG abandons the merging process.

**def beforeNextRoad(self, pIVehicle: Tessng.IVehicle, pRoad: PySide2.QtWidgets.QGraphicsItem, keepOn: bool) -> None**

**def ref_beforeNextRoad(self, pIVehicle: Tessng.IVehicle, pRoad: PySide2.QtWidgets.QGraphicsItem, ref_keepOn: Tessng.objbool) -> None**

​	Processing before the calculation of the next road.

Parameters:

[ in ] pIVehicle: vehicle object.

​	[ in ] pRoad: Parameter currently not used.

​	[ in, out ] keepOn: Indicates whether to continue calculation; if keepOn is set to False, TESS NG stops calculating subsequent roads.

**def afterCalcTracingType(self, pIVehicle: Tessng.IVehicle) -> None**

Post-processing after calculating the Car-Following Type.

Parameters:

[ in ] pIVehicle: vehicle object.

**def busArriving(self, pIVehicle: Tessng.IVehicle, pStationLine: Tessng.IBusStationLine, alightingCount: int, alightingTime: int, boardingCount: int, boardingTime: int) -> None**

Post-processing after the bus arrives at the station.

Parameters:

[ in ] pIVehicle: vehicle object.

[ in ] pStationLine: Station line.

[ in ] alightingCount: Number of passengers alighting. Unit: persons.

[ in ] alightingTime: Total time required for alighting. Unit: s.

[ in ] boardingCount: Number of passengers boarding. Unit: persons.

[ in ] boardingTime: Total time required for boarding. Unit: s.

**def leaveForNextLaneObj(self, pIVehicle: Tessng.IVehicle, pCurrLaneObj: Tessng.ILaneObject, pNextLaneObj: Tessng.ILaneObject) -> None**

Called when the vehicle is about to cross a road.

Parameters:

[ in ] pIVehicle: vehicle object.

[ in ] pCurrLaneObj: Current lane object.

[ in ] pNextLaneObj: Next lane object to enter.

**def travelOnChangingTrace(self, pIVehicle: Tessng.IVehicle) -> bool**

Called when the vehicle is traveling on the lane-changing trajectory.

Parameters:

[ in ] pIVehicle: vehicle object.

**bool leaveOffChangingTrace(self, pIVehicle:Tessng.IVehicle, differ: float, s: float)**

**def ref_leaveOffChangingTrace(self, pIVehicle:Tessng.IVehicle, differ: float, ref_s: Tessng.objreal) -> bool**

Called when the vehicle leaves the lane-changing trajectory.

Parameters:

[ in ] pIVehicle: vehicle object.

**def isCalcVehicleVector3D(self) -> bool**

Whether to compute the vehicle's 3D attributes, such as Euler angles.

Return:

If True is returned, it indicates that the vehicle's 3D attributes need to be computed.

**def calcVehicleEuler(self, pIVehicle: Tessng.IVehicle, bPosIDire: bool = True) -> PySide2.QtGui.QVector3D**

Compute the vehicle's Euler angles.

Parameters:

[ in ] pIVehicle: vehicle object.

[ in ] bPosIDire: Whether to compute the vehicle's heading direction forward; if bPosIDire is False, compute it backward.

Return:

The vehicle's Euler angles.

**def vehiRunInfo(self, pIVehicle: Tessng.IVehicle) -> str**

Control the text content of the text box in the Vehicle operational status popup. During simulation, selecting a vehicle and pressing Ctrl+i will open the Vehicle operational status popup.

Return:

The text content displayed in the text box of the Vehicle operational status popup.

Example:

```python
from tessng import IVehicle

def vehiRunInfo(self, pIVehicle: IVehicle) -> str:
	return f"The vehicle is currently on the road with ID={pIVehicle.roadId()}"
```

**def boundingRect(self, pIVehicle: Tessng.IVehicle, outRect: PySide2.QtCore.QRectF) -> bool**

Retrieve the vehicle's bounding rectangle.

Parameters:

[ in ] pIVehicle: vehicle object.

[ out ] outRect: Vehicle boundary rectangle.

**def shape(self, pIVehicle: Tessng.IVehicle, outShape: PySide2.QtGui.QPainterPath) -> bool**

Obtain the vehicle graphical route.

Parameters:

[ in ] pIVehicle: vehicle object.

[ out ] outShape: Vehicle shape route.

**def paintVehicle(self, pIVehicle: Tessng.IVehicle, painter: PySide2.QtGui.QPainter) -> bool**

Draw the vehicle.

Parameters:

[ in ] pIVehicle: vehicle object.

[ in ] painter: QPainter object.

Return:	

If True is returned, TESSNG considers that the vehicle has been drawn by the user and will not draw it again.

**def paintVehicleWithRotation(self, pIVehicle: Tessng.IVehicle, painter: PySide2.QtGui.QPainter, inOutRotation: float) -> bool**

Draw the vehicle, rotating the vehicle object by the specified angle before drawing.

Parameters:

[ in ] pIVehicle: vehicle object.

[ in ] painter: QPainter object.

[ in ] inOutRotation: Rotation angle. Unit: degrees.

Return:

If True is returned, TESSNG considers that the vehicle has been drawn by the user and will not draw it again.

**def rePaintVehicle(self, pIVehicle: Tessng.IVehicle, painter: PySide2.QtGui.QPainter) -> None**

Add custom drawing content after TESSNG draws the vehicle.

Parameters:

[ in ] pIVehicle: vehicle object.

[ in ] painter: QPainter object.

Example:

```python
from PySide2.QtCore import QPointF
from PySide2.QtGui import QPainter, QFont, QPainterPath, QFontMetrics, QColor
from tessng import IVehicle

def rePaintVehicle(self, pIVehicle: IVehicle, painter: QPainter) -> None:
    # Add vehicle name label on the vehicle body.
    label: str = vehicle.name()

    # Create a QFont object and set the font and size.
    font = QFont('Arial', 1)
    # Set the font to non-bold.
    font.setBold(False)

    # Create a QFontMetrics object to obtain font metric information.
    fontMetrics = QFontMetrics(font)
    # Obtain the bounding rectangle of the text
    boundingRect = fontMetrics.boundingRect(label)
    # Compute the text position
    new_x = -boundingRect.center().x() - vehicle.width() * 0.5
    new_y = -boundingRect.center().y()
    position = QPointF(new_x, new_y)

    # Create a QPainterPath object to render the text
    textPath = QPainterPath()
    # Add the text to the path
    textPath.addText(position, font, label)
    
    # Set the pen's scaling factor
    painter.scale(1, 1)
    # Fill the path to render the text
    painter.fillPath(textPath, QColor("#c94f4f"))
```

#### 3.2.3.3. Traffic Signal Control

**def beforeCalcLampColor(self, keepOn: bool) -> bool**

**def ref_beforeCalcLampColor(self, ref_keepOn: Tessng.objbool) -> bool**

Used to perform custom operations prior to calculating the traffic signal color.

Parameters:

[ in, out ] Indicates whether to continue the calculation.

Return:	

If the function returns True and keepOn is set to False, TESS NG will cease calculating the traffic signal color.

**def calcLampColor(self, pSignalLamp: Tessng.ISignalLamp) -> bool**

Compute the color of the traffic signal.

Parameters:

[ in ] pSignalLamp: traffic signal object.

Return:

If the function returns True, it indicates the user has modified the traffic signal color, and TESS NG will no longer calculate the signal color.

Example:

```python
from tessng import ISignalLamp

def calcLampColor(self, pSignalLamp: ISignalLamp) -> bool:
    # If the traffic signal ID is 1, set it to green.
	if pSignalLamp.id() == 1: 
		pSignalLamp.setLampColor("G")
		return True
	return False
```

#### 3.2.3.4. Others

**def beforeCreateGVehiclesForBusLine(self, pBusLine: Tessng.IBusLine, keepOn: bool) -> None**

**def ref_beforeCreateGVehiclesForBusLine(self, pBusLine: Tessng.IBusLine, ref_keepOn: Tessng.objbool) -> None**

Used to implement custom operations before creating bus vehicles.

Parameters:

[ in ] pBusLine: Bus route.

[ in, out ] keepOn: Whether to continue creating bus vehicles.

Return:

If True is returned and keepOn is set to False, TESS NG will no longer create bus vehicles.

**def calcDynaFlowRatioParameters(self) -> list[Online.DecipointFlowRatioByInterval]**

Calculate dynamic traffic assignment information.

Return:

Sequence of decision point traffic assignment information.

Example:

```python
from tessng import Online

def calcDynaFlowRatioParameters(self) -> list:
    # Current simulation calculation batch.
    batch_number = self.simuiface.batchNumber()
    # Modify the flow ratio of each route at a decision point during the 20th calculation batch.
    if batch_number == 20:
        # Vehicle allocation ratio for each route at a decision point during a specific time period.
        dfi = Online.DecipointFlowRatioByInterval()
        # Decision Point ID
        dfi.deciPointID = 5
        # Start Time (Unit: seconds)
        dfi.startDateTime = 1
        # End Time (Unit: seconds)
        dfi.endDateTime = 999999
        # Route Flow Ratio
        rfr1 = Online.RoutingFlowRatio(1, 3)
        rfr2 = Online.RoutingFlowRatio(2, 4)
        rfr3 = Online.RoutingFlowRatio(3, 3)
        dfi.mlRoutingFlowRatio = [rfr1, rfr2, rfr3]
        return [dfi]
    return []
```

**def calcDynaDispatchParameters(self) -> list[Online.DispatchInterval]**

Calculate dynamic departure information.

Return:

Sequence of dynamic departure information.

Example:

```python
from tessng import Online

def calcDynaDispatchParameters(self) -> list:
    di = Online.DispatchInterval()
    # Departure Point ID
    di.dispatchId = 1
    # Start Time (Unit: s)
    di.fromTime = 0
    # End Time (Unit: s)
    di.toTime = 300
    # Number of Vehicles
    di.vehiCount = 300
    # Vehicle Composition List
    di.mlVehicleConsDetail = [
        Online.VehiComposition(1, 60),
        Online.VehiComposition(2, 40)
    ]
    return [di]
```



## 3.3. Interface

Unlike plugins that focus on 'process extension and logic intervention,' the interface emphasizes **'data interaction and state control.'** It includes the top-level interface TessInterface and three sub-interfaces: NetInterface, SimuInterface, and GuiInterface, providing users with the ability to access and configure core information related to the road network, simulation, and GUI. Through this, users can directly read the road network topology, real-time simulation parameters (such as time step and total number of vehicles), and GUI display configurations (such as size and view zoom level). Users can also actively modify this information to adjust the fundamental state of the system.

The top-level interface object has the characteristics of a global variable and can be instantiated at any location within the code. However, from the perspectives of code maintainability and usability, we recommend performing the initialization of each interface within the **constructor**, for example:

```python
# MySimulator.py
class MySimulator(PyCustomerSimulator, QObject):
    def __init__(self):
        PyCustomerSimulator.__init__(self)
        QObject.__init__(self)
        # Represents the TESS NG interface
        self.iface = tessngIFace()
        # Represents the TESS NG road network sub-interface
        self.netiface = self.iface.netInterface()
        # Represents the TESS NG simulation sub-interface
        self.simuiface = self.iface.simuInterface()
        # Represents the TESS NG GUI sub-interface
        self.guiiface = self.iface.guiInterface()
```

### 3.3.1. Top-level Interface (TessInterface)

TessInterface is the top-level interface externally exposed by TESS NG. It includes three sub-interfaces: NetInterface, SimuInterface, and GuiInterface, which are used to access or control the road network, simulation process, and user interaction interface, respectively.

**def config(self) -> dict**

Obtain a JSON object storing the information from the config.json configuration file. The configuration information is reloaded each time the road network is loaded.

**def setConfigProperty(self, key: str, value: any) -> None**

Set configuration properties.

**def loadPluginFromMem(self) -> bool**

Load a plugin.

**def releasePlugins(self) -> None**

Unload a plugin.

**def netInterface(self) -> Tessng.NetInterface**

Return the NetInterface used to access and control the road network.

Example:

```python
iface = tessngIFace()
netiface = self.iface.netInterface()
```

**def simuInterface(self) -> Tessng.SimuInterface**

Return the SimuInterface used to control the simulation process.

Example:

```python
iface = tessngIFace()
simuiface = self.iface.simuInterface()
```

**def guiInterface(self) -> Tessng.GuiInterface**

Return the GuiInterface used to access and control the user interface.

Example:

```python
iface = tessngIFace()
guiiface = self.iface.guiInterface()
```

### 3.3.2. Road Network Interface (NetInterface)

NetInterface is a sub-interface of TessInterface, used for accessing and controlling road network elements. Through this interface, elements such as road segments and connector segments can be queried, created, deleted, and modified.

#### 3.3.2.1. Road Network

**def netFilePath(self) -> str**

Retrieve the full path name of the road network file. If the road network is stored as professional data, the returned value is the road network ID.

Example:

```python
net_file_path: str = self.netiface.netFilePath()
```

**def saveRoadNet(self) -> None**

Save the current road network file.

**def openNetFle(self, filePath: str) -> None**

Open the road network file.

Parameters:

[ in ] filePath: Full path name of the road network file.

**def createEmptyNetFile(self, filePath: str, dbver: int = 5) -> bool**

Create a blank road network.

Parameters:

[ in ] filePath: Full path name of the blank road network.

[ in ] dbver: Database version.

**def openNetByNetID(self, netId: int) -> None**

Load the road network from a professional database.

**def netAttrs(self) -> Tessng.IRoadNet**

Get the road network attribute object.

**def roadNet(self) -> Tessng.IRoadNet**

Get the road network attribute object. Equivalent to netAttrs.

**def setNetAttrs(self, name: str, sourceType: str = "TESSNG", centerPoint: PySide2.QtCore.QPointF = QPointF(), backgroundUrl: str = "", otherAttrsJson: dict = QJsonObject()) -> Tessng.IRoadNet**

Set the basic information of the road network.

Parameters:

[ in ] name: Road network name.

[ in ] sourceType: Data source category, default is "TESSNG", indicating the road network is created directly by the TESSNG software. The value "OPENDRIVE" indicates that the road network is imported via OpenDRIVE.

​	[ in ] centerPoint: The road network in which the central point coordinates are located, defaulting to (0, 0). Users may also store the central point coordinates in the otherAttrsJson field.

​	[ in ] backgroundUrl: The path to the background map.

​	[ in ] otherAttrsJson: Additional attributes stored in a JSON object, such as geodetic coordinate information.

Return:

​	Road network attribute object.

**def graphicsScene(self) -> PySide2.QtWidgets.QGraphicsScene**

​	Retrieve the scene object.

**def graphicsView(self) -> PySide2.QtWidgets.QGraphicsView**

​	Retrieve the view object.

**def sceneScale(self) -> float**

​	Obtain the pixel ratio in the scene. Unit: m/pixel.

**def sceneWidth(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	Retrieve scene width. Unit: pixel.

**def sceneHeigth(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	Retrieve scene height. Unit: pixel.

**def backgroundMap(self) -> bytes**

​	Retrieve background image bytes.

**def boundingRect(self) -> PySide2.QtCore.QRectF**

​	Retrieve road network boundaries.

**def getIDByItemName(self, name: str) -> int**

​	Obtain auto-increment ID by road network element name.

Parameters:

​	[ in ] name: Road network element name.

**def initSequence(self, schemaName: str = "") -> bool**

​	Initialize database sequence for professional databases storing road networks; currently supports PostgreSQL.

Parameters:

[ in ] schemaName: The schema name of the database.

#### 3.3.2.2. Road

**def sections(self) -> list[Tessng.ISection]**

Retrieve all roads.

#### 3.3.2.3. Road Segment

**def linkCount(self) -> int**

Retrieve the number of road segments.

**def linkIds(self) -> list[int]**

Retrieve the sequence of road segment IDs.

**def links(self) -> list[Tessng.ILink]**

Retrieve the sequence of road segment objects.

Example:

```python
for link in self.netiface.links():
    print(link.id())
```

**def findLink(self, id: int) -> Tessng.ILink**

Retrieve the road segment object by road segment ID.

**def linkCenterPoints(self, linkId: int, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

Retrieve the specified road segment centerline breakpoint sequence. Unit: pixel.

Parameters:

[ in ] linkID: Specified road segment ID.

**def createLink(self, lCenterPoint: list[PySide2.QtCore.QPointF], laneCount: int, linkName: str = "", bAddToScene: bool = True, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.ILink**

Create a road segment. Unit: pixel.

Parameters:

[ in ] lCenterPoint: Road segment centerline breakpoint sequence.

[ in ] laneCount: Number of lanes.

[ in ] linkName: Road segment name.

[ in ] bAddToScene: Whether to add to the scene.

Return:

Road segment object.

Example:

```python
from PySide2.QtCore import QPointF
from tessng import UnitOfMeasure

link_points = [QPointF(-300, 0), QPointF(300, 0)]
link = self.netiface.createLink(link_points, 7, "Caoan Highway", True, UnitOfMeasure.Metric)
```

**def createLink3D(self, lCenterV3: list[PySide2.QtGui.QVector3D], laneCount: int, linkName: str = "", bAddToScene: bool = True, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.ILink**

Create 3D road segment. Unit: pixel.

Parameters:

[ in ] lCenterV3: 3D discrete point set of road segment centerline.

[ in ] laneCount: Number of lanes.

[ in ] linkName: Road segment name.

[ in ] bAddToScene: Whether to add to the scene.

[ in ] unit: unit parameter, default is Default; Metric denotes the metric system; Default indicates no unit restriction.

Return:

Road segment object.

Example:

```python
from PySide2.QtGui import QVector3D
from tessng import UnitOfMeasure

link_points = [QVector3D(-300, 0, 10), QVector3D(300, 0, 20)]
link = self.netiface.createLink3D(link_points, 7, "Caoan Highway", True, UnitOfMeasure.Metric)
```

**def createLinkWithLaneWidth(self, lCenterPoint: list[PySide2.QtCore.QPointF], lLaneWidth: list[float], linkName: str = "", bAddToScene: bool = True, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.ILink**

Create a road segment with specified lane widths. Unit: pixel.

Parameters:

[ in ] lCenterPoint: Road segment centerline breakpoint sequence.

[ in ] lLaneWidth: list of lane widths.

[ in ] linkName: Road segment name.

[ in ] bAddToScene: Whether to add to the scene.

Return:

Road segment object.

Example:

```python
from PySide2.QtCore import QPointF
from tessng import UnitOfMeasure

link_points = [QPointF(-300, 0), QPointF(300, 0)]
lane_width_list = [1, 3.5, 3.5, 3.5]
link = self.netiface.createLinkWithLaneWidth(link_points, lane_width_list, "Caoan Highway", True, UnitOfMeasure.Metric)
```

**def createLink3DWithLaneWidth(self, lCenterV3: list[PySide2.QtGui.QVector3D], lLaneWidth: list[float], linkName: str = "", bAddToScene: bool = True, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.ILink**

Create a 3D road segment with specified lane widths. Unit: pixel.

Parameters:

[ in ] lCenterV3: 3D discrete point sequence of road segment centerline.

[ in ] lLaneWidth: list of lane widths.

[ in ] linkName: Road segment name.

[ in ] bAddToScene: Whether to add to the scene.

Return:

Road segment object.

Example:

```python
from PySide2.QtGui import QVector3D
from tessng import UnitOfMeasure

link_points = [QVector3D(-300, 0, 10), QVector3D(300, 0, 20)]
lane_width_list = [1, 3.5, 3.5, 3.5]
link = self.netiface.createLink3DWithLaneWidth(link_points, 7, "Caoan Highway", True, UnitOfMeasure.Metric)
```

**def createLink3DWithLanePoints(self, lCenterLineV3: list[PySide2.QtGui.QVector3D], lanesWithPoints: list[dict[str, list[PySide2.QtGui.QVector3D]]], linkName: str = "", bAddToScene: bool = True, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.ILink**

Create a 3D road segment with specified lane discrete points. Unit: pixel.

Parameters:

[ in ] lCenterLineV3: 3D discrete point sequence of road segment centerline.

[ in ] lanesWithPoints: collection of lane point sets.

[ in ] linkName: Road segment name.

[ in ] bAddToScene: Whether to add to the scene.

Return:

Road segment object.

Example:

```python
from PySide2.QtGui import QVector3D
from tessng import UnitOfMeasure

# Road Segment Centerline
link_points = [QVector3D(-300, 0, 10), QVector3D(300, 0, 20)]

# Left, Middle, and Right Lines of Each Lane
lanes_points = [
	{
        "left": [QVector3D(-300, 0, 10), QVector3D(300, 0, 20)],
        "center": [QVector3D(-300, 1.75, 10), QVector3D(300, 1.75, 20)],
        "right": [QVector3D(-300, 3.5, 10), QVector3D(300, 3.5, 20)]
    },
    {
        "left": [QVector3D(-300, -3.5, 10), QVector3D(300, -3.5, 20)],
        "center": [QVector3D(-300, -1.75, 10), QVector3D(300, -1.75, 20)],
        "right": [QVector3D(-300, 0, 10), QVector3D(300, 0, 20)]
    }
]

link = self.netiface.createLink3DWithLanePoints(link_points, lanes_points, "Caoan Highway", True, UnitOfMeasure.Metric)
```

**def createLink3DWithLanePointsAndAttrs(self, lCenterLineV3: list[PySide2.QtGui.QVector3D], lanesWithPoints: list[dict[str, list[PySide2.QtGui.QVector3D]]], lLaneType: list[str], lAttr: list[dict], linkName: str = "", bAddToScene: bool = True, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.ILink**

​	Create a 3D road segment with specified lane breakpoints and attributes. Unit: pixel.

Parameters:

[ in ] lCenterLineV3: 3D discrete point sequence of road segment centerline.

[ in ] lanesWithPoints: collection of lane point sets.

​	[ in ] lLaneType: Sequence of lane types.

​	[ in ] lAttr: Sequence of additional lane attributes.

[ in ] linkName: Road segment name.

[ in ] bAddToScene: Whether to add to the scene.

Return:

Road segment object.

**def removeLink(self, pLink: Tessng.ILink) -> None**

​	Remove road segment.

Parameters:

​	[ in ] pLink: Road segment object.

Example:

```python
# Remove the road segment with ID = 1
link = self.netiface.findLink(1)
self.netiface.removeLink(link)
```

**def updateLink(self, link: Tessng.\_Link, lLane: list[Tessng.\_Lane] = [], lPoint: list[PySide2.QtCore.QPointF] = [], unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.ILink**

​	Update the road segment. Unit: pixel.

Parameters:

​	[ in ] link: Basic road segment information.

​	[ in ] lLane: List of lanes.

​	[ in ] lPoint: List of breakpoints.

Return:

​	Updated road segment object.

**def moveLinks(self, lLink: list[Tessng.ILink], offset: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	Move the road segment and related connector segments. Unit: pixel.

Parameters:

​	[ in ] lLink: Sequence of road segment objects.

[ in ] offset: offset value.

Example:

```python
from PySide2.QtCore import QPointF

# Retrieve all road segments
links = self.netiface.links()
# Move all road segments
self.netiface.moveLinks(links, QPointF(100, 100))
```

**def judgeLinkToCross(self, linkId: int) -> bool**

Determine whether the downstream section of the road segment enters an intersection based on the presence of multiple connector segments within the polygonal area and the angle between the current and subsequent road segments.

Parameters:

[ in ] linkID: Road Segment ID.

Return:

Indicates whether the downstream section of the road segment enters an intersection.

#### 3.3.2.4. Lane

**def findLane(self, id: int) -> Tessng.ILane**

Retrieve the Lane object by Lane ID.

**def laneCenterPoints(self, laneId: int, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

Obtain the sequence of lane centerline breakpoints for the specified ID. Unit: pixel.

Parameters:

[ in ] laneID: Lane ID.

Return:

The centerline breakpoint sequence of the specified lane.

#### 3.3.2.5. Connector Segment

**def connectorCount(self) -> int**

Retrieve the number of connector segments.

**def connectorIds(self) -> list[int]**

Retrieve the sequence of Connector Segment IDs.

**def connectors(self) -> list[Tessng.IConnector]**

Retrieve the sequence of Connector Segment objects.

**def findConnector(self, id: int) -> Tessng.IConnector**

Retrieve the Connector Segment object by Connector Segment ID.

**def findConnectorByLinkIds(self, fromLinkId: int, toLinkId: int) -> Tessng.IConnector**

Obtain the connector segment object using the upstream road segment ID and downstream road segment ID.

**def createConnector(self, fromLinkId: int, toLinkId: int, lFromLaneNumber: list[int], lToLaneNumber: list[int], connName: str = "", bAddToScene: bool = True) -> Tessng.IConnector**

Create a connector segment.

Parameters:

[ in ] fromLinkID: Upstream road segment ID.

[ in ] toLinkID: Downstream road segment ID.

[ in ] lFromLaneNumber: Sequence of lane indices for the upstream road segment.

[ in ] LToLaneNumber: Sequence of lane indices for the downstream road segment.

[ in ] connName: Name of the connector segment; defaults to empty, in which case the IDs of the two road segments are concatenated as the name.

[ in ] bAddToScene: Whether to add the connector segment to the road network scene after creation; defaults to True.

Return:

Connector segment object.

Example:

```python
# Create a connector segment linking Road Segment 1 and Road Segment 2
from_lane_numbers = [1, 2, 3]
to_lane_numbers = [1, 2, 3]
connector = self.netiface.createConnector(1, 2, from_lane_numbers, to_lane_numbers, "Connector1")
```

**def createConnector3DWithPoints(self, fromLinkId: int, toLinkId: int, lFromLaneNumber: list[int], lToLaneNumber: list[int], laneConnectorWithPoints: list[dict[str, list[PySide2.QtGui.QVector3D]]], connName: str = "", bAddToScene: bool = True, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.IConnector**

Create a 3D connector segment with specified break points. Unit: pixel.

Parameters:

[ in ] fromLinkID: Upstream road segment ID.

[ in ] toLinkID: Downstream road segment ID.

[ in ] lFromLaneNumber: List of lane indices for the upstream road segment.

[ in ] lToLaneNumber: List of downstream road segment lane indices.

[ in ] laneConnectorWithPoints: Collection of lane connection point sets.

[ in ] connName: Name of the connector segment.

[ in ] bAddToScene: Whether to add to the scene.

Return:

Connector segment object.

**def removeConnector(self, pConnector: Tessng.IConnector) -> None**

Remove the connector segment.

Parameters:

[ in ] pConnector: Connector segment object.

**def updateConnector(self, connector: Tessng.\_Connector) -> Tessng.IConnector**

Update the connector segment. Unit: pixel.

Parameters:

[ in ] connector: Basic information of the connector segment.

Return:

Connector segment object.

#### 3.3.2.6. Lane Connection

**def findLaneConnector(self, id: int) -> Tessng.ILaneConnector**

Retrieve the lane connection object by lane connection ID.

**def findLaneConnector(self, fromLaneId: int, toLaneId: int) -> Tessng.ILaneConnector**

Retrieve the lane connection object by upstream lane ID and downstream lane ID.

**def crossPoints(self, pLaneConnector: Tessng.ILaneConnector) -> list[Online.CrossPoint]**

Sequence of intersection points where the current lane connection crosses other lane connections.

Parameters:

[ in ] pLaneConnector: Lane connection object.

Return:

Sequence of intersection points.

#### 3.3.2.7. Connector Segment Area

**def allConnectorArea(self) -> list[Tessng.IConnectorArea]**

Retrieve the sequence of all connector segment polygon objects.

**def findConnectorArea(self, id: int) -> Tessng.IConnectorArea**

Retrieve polygon object by Polygon ID.

#### 3.3.2.8. Road Network Grid

**def buildNetGrID(self, width: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

Perform gridding of the road network.

Parameters:

[ in ] width: Cell width. Unit: pixel.

**def findSectionOn1Cell(self, point: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[Tessng.ISection]**

Retrieve all roads in the cell containing the specified point.

Parameters:

[ in ] point: Coordinates of the point. Unit: pixel.

Return:

Road Object Sequence.

**def findSectionOn4Cell(self, point: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[Tessng.ISection]**

Retrieve all roads in the nearest 4 cells around the point.

Parameters:

[ in ] point: Coordinates of the point. Unit: pixel.

Return:

Road Object Sequence.

**def findSectionOn9Cell(self, point: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[Tessng.ISection]**

Retrieve all roads in the nearest 9 cells around the point.

Parameters:

[ in ] point: Coordinates of the point. Unit: pixel.

Return:

Road Object Sequence.

**def locateOnCrid(self, point: PySide2.QtCore.QPointF, cellCount: int = 1, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[Online.Location]**

Retrieve lane base class objects in several cells surrounding the point.

Parameters:

[ in ] point: Coordinates of the point. Unit: pixel.

[ in ] cellCount: Number of cells. Defaults to 1 if less than 1; 4 if greater than 1 but less than 4; 9 if greater than 4.

Return:	

Position information sequence, sorted in ascending order by shortest distance.

Example:

```python
from PySide2.QtCore import QPointF
from tessng import UnitOfMeasure

# Target Point
target_point = QPointF(50, 50);
# Project the target point onto lanes within a specified nearby range to obtain the position information sequence.
locations = self.netiface.locateOnCrid(target_point, 9, UnitOfMeasure.Metric);  # Execute netiface.buildNetGrid(10) before use.
for location in locations:
    print(f"The lane/lane connector ID is: {location.pLaneObject->id()}")
    print(f"The projection point is: ({location.point.x()}, {location.point.y()})")
    print(f"The distance between the target point and the projection point is: {location.leastDist} m")
    print(f"The distance between the projection point and the starting point of the lane is: {location.distToStart} m")
    print(f"The segment number of the projection point in the lane is: {location.segmIndex}")
```

**def locateOnSections(self, point: PySide2.QtCore.QPointF, lSection: list[Tessng.ISection], referDistance: float = 0, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[Online.Location]**

Calculate the shortest distance from the point to all lanes of each road in the road list.

Parameters:

[ in ] point: Coordinates of the point. Unit: pixel.

[ in ] lSection: Road list.

[ in ] referDistance: The distance from the point nearest to LaneObject on the LaneObject, measured from the LaneObject start; used solely to improve computational efficiency, default is 0.

Return:

Position information sequence, sorted in ascending order by shortest distance.

#### 3.3.2.9. Vehicle Type

**def createVehicleType(self, \_vt: Tessng.\_VehicleType) -> bool**

Create vehicle type.

Parameters:

[ in ] vt: Vehicle type data. A vehicle type name different from existing types must be specified; otherwise, creation will fail. The code for the newly created vehicle type will be automatically assigned as the current maximum code value plus 1.

Return:

Indicates whether the creation was successful.

Example:

```python
from tessng import _VehicleType

# Construction Parameters
vehicle_type = _VehicleType()
vehicle_type.vehicleTypeName = "New type 1"  # Vehicle Type Name
vehicle_type.Length = 4.5  # Length, Unit: m
vehicle_type.lengthSD = 0.5  # Length Standard Deviation, Unit: m
vehicle_type.width = 2  # Width, Unit: m
vehicle_type.widthSD = 0.2  # Width Standard Deviation, Unit: m
vehicle_type.avgSpeed = 60  # Desired Speed, Unit: km/h
vehicle_type.speedSD = 10  # Desired Speed Standard Deviation, Unit: km/h
vehicle_type.avgAcce = 4  # Desired Acceleration, Unit: m/s²
vehicle_type.acceSD = 0.5  # Desired Acceleration Standard Deviation, Unit: m/s²
vehicle_type.avgDece = 6  # Desired Deceleration, Unit: m/s²
vehicle_type.deceSD = 0.5  # Desired Deceleration Standard Deviation, Unit: m/s²
vehicle_type.maxAcce = 5.5  # Maximum Acceleration, Unit: m/s²
vehicle_type.maxDece = 7.5  # Maximum Deceleration, Unit: m/s²
vehicle_type.maxSpeed = 80  # Maximum speed, Unit: km/h
vehicle_type.commercialVehicle = False  # Whether it is a commercial vehicle
vehicle_type.maxPassengerCapacity = 1  # Rated passenger capacity, Unit: persons
# Create vehicle type
result = self.netiface.createVehicleType(vehicle_type)
print(f"Is the creation of the vehicle type successful: {result}")
```

#### 3.3.2.10. Vehicle Composition

**def createVehicleComposition(self, name: str, lVehiComp: list[Online.VehicleComposition]) -> int**

​	Create vehicle composition.

Parameters:

​	[ in ] name: Vehicle composition name.

​	[ in ] lVehiComp: Sequence of proportions of different vehicle types.

Return:

​	Vehicle composition ID, returns -1 if the vehicle composition name already exists, or the related vehicle type code does not exist, or the related vehicle type proportion is less than 0.

Example:

```python
from tessng import Online

# Construct vehicle type proportion list
vehi_type_proportion_list = [
    Online.VehiComposition(1, 0.3),  # Passenger car, proportion 0.3
    Online.VehiComposition(2, 0.2),  # Large bus, proportion 0.2
    Online.VehiComposition(3, 0.1),  # Bus, proportion 0.1
    Online.VehiComposition(4, 0.4)   # Truck, proportion 0.4
]
# Create vehicle composition
vehi_composition_id = self.netiface.createVehicleComposition("new vehicle composition", vehi_type_proportion_list)
```

**def removeVehicleComposition(self, vehiCompId: int) -> bool**

​	Remove vehicle composition.

Parameters:

[ in ] vehiCompID: Vehicle type composition ID.

#### 3.3.2.11. Departure Point

**def dispatchPoints(self) -> list[Tessng.IDispatchPoint]**

Retrieve all departure points sequence.

**def findDispatchPoint(self, id: int) -> Tessng.IDispatchPoint**

Retrieve a departure point by its ID.

**def createDispatchPoint(self, pLink: Tessng.ILink, dpName: str = "", bAddToScene: bool = True) -> Tessng.IDispatchPoint**

Create a departure point.

Parameters:

[ in ] pLink: Road segment on which the departure point is created.

[ in ] dpName: Departure point name. Default is empty; the ID will be used as the name.

[ in ] bAddToScene: Whether to add the connector segment to the road network scene after creation; defaults to True.

Example:

```python
# Retrieve road segment object
link = self.netiface.findLink(1)
# Create departure point
dp = self.netiface.createDispatchPoint(link)
if dp is not None:
    # Add departure interval, including vehicle type composition, time interval, and departure count
    dp.addDispatchInterval(1, 600, 300)
    dp.addDispatchInterval(1, 600, 400)
```

**def removeDispatchPoint(self, pDispPoint: Tessng.IDispatchPoint) -> bool**

Remove departure point.

Parameters:

[ in ] pDispPoint: Departure point object.

#### 3.3.2.12. Decision Point

**def decisionPoints(self) -> list[Tessng.IDecisionPoint]**

Retrieve all decision points sequence.

**def findDecisionPoint(self, id: int) -> Tessng.IDecisionPoint**

Retrieve a decision point by its ID.

**def createDecisionPoint(self, pLink: Tessng.ILink, distance: float, name: str = "", unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.IDecisionPoint**

Create a Decision Point.

Parameters:

[ in ] pLink: The Road Segment where the Decision Point is located.

[ in ] distance: The distance from the start of the Road Segment to the Decision Point. Unit: pixel.

[ in ] name: The Name of the Decision Point.

Return:

Decision Point object.

Example:

```python
link = self.netiface.findLink(1)
location = 50
decision_point_name = "new decision point"
decision_point = self.netiface.createDecisionPoint(link, location, decision_point_name, UnitOfMeasure.Metric)
```

**def updateDecipointPoint(self, deciPoint: Tessng.\_DecisionPoint, lFlowRatio: list[\_RoutingFLowRatio] = []) -> Tessng.IDecisionPoint**

Update the Decision Point and the flow ratios of different Routes for various time periods.

Parameters:

[ in ] deciPoint: Decision Point data.

[ in ] lFlowRatio: Data collection of flow ratios for various Routes by time period.


Return:

Decision Point object.

Example:

```python
from tessng import _RoutingFLowRatio, _DecisionPoint

# Initialize left, straight, and right flow ratio objects
flowRatio_left = _RoutingFLowRatio()
flowRatio_left.RoutingFLowRatioID = 1
flowRatio_left.routingID = decisionRouting1.id()
flowRatio_left.startDateTime = 0
flowRatio_left.endDateTime = 999999
flowRatio_left.ratio = 2.0

flowRatio_straight = _RoutingFLowRatio()
flowRatio_straight.RoutingFLowRatioID = 2
flowRatio_straight.routingID = decisionRouting2.id()
flowRatio_straight.startDateTime = 0
flowRatio_straight.endDateTime = 999999
flowRatio_straight.ratio = 3.0

flowRatio_right = _RoutingFLowRatio()
flowRatio_right.RoutingFLowRatioID = 3
flowRatio_right.routingID = decisionRouting3.id()
flowRatio_right.startDateTime = 0
flowRatio_right.endDateTime = 999999
flowRatio_right.ratio = 1.0

# Initialize Decision Point data
decision_point_data = _DecisionPoint()
decision_point_data.deciPointID = decision_point.id()
decision_point_data.deciPointName = decision_point.name()
decisionPoint_pos = QPointF()
if decisionPoint.link().getPointByDist(decision_point.distance(), decisionPoint_pos): 
    decision_point_data.X = decisionPoint_pos.x()
    decision_point_data.Y = decisionPoint_pos.y()
    decision_point_data.Z = decision_point.link().z()

# Construct flow ratio list
flow_ratio_list = [flowRatio_left, flowRatio_straight, flowRatio_right]
# Update the flow ratio configuration of routes in the Decision Point
updated_decision_point = self.netiface.updateDecipointPoint(decision_point_data, flow_ratio_list)
```

#### 3.3.2.13. Vehicle Route

**def findRouting(self, id: int) -> Tessng.IRouting**

Retrieve the route object using the route ID.

**def createRouting(self, lILink: list[Tessng.ILink]) -> Tessng.IRouting**

Create a route without binding it to a decision point.

Parameters:

[ in ] lILink: Sequence of road segment objects, which must be continuous.

Return:

Route object.

Example:

```python
# List of Road Segment IDs
link_id_list = [1, 2, 3, 4]
# Construct the list of road segment objects
link_list = [self.netiface.findLink(link_id) for link_id in link_id_list]
# Create vehicle route
routing = self.netiface.createRouting(link_list)
```

**def createDeciRouting(self, pDeciPoint: Tessng.IDecisionPoint, lILink: list[Tessng.ILink]) -> Tessng.IRouting**

Add a vehicle route to the decision point.

Parameters:

[ in ] pDeciPoint: Decision point object.

[ in ] lILink: Sequence of road segment objects, which must start from the road segment containing the decision point and must be continuous.

Return:

Route object.

**def removeDeciRouting(self, pDeciPoint: Tessng.IDecisionPoint, pRouting: Tessng.IRouting) -> bool**

Remove the vehicle route from the decision point.

Parameters:

[ in ] pDeciPoint: Decision point object.

[ in ] pRouting: Route object.

Return:

Indicates whether the removal was successful.

**def shortestRouting(self, pFromLink: Tessng.ILink, pToLink: Tessng.ILink) -> Tessng.IRouting**

Calculate the shortest path between two road segments.

Parameters:

[ in ] pFromLink: Starting road segment.

[ in ] pToLink: Target Road Segment.

Return:	

Route object.

#### 3.3.2.14. Signal Controller

**def signalControllerCount(self) -> int**

Retrieve the number of signal controllers.

**def signalControllerIds(self) -> list[int]**

Retrieve the sequence of signal controller IDs.

**def signalControllers(self) -> list[Tessng.ISignalController]**

Retrieve the sequence of all signal controller objects.

**def findSignalControllerById(self, id: int) -> Tessng.ISignalController**

Retrieve signal controller object by ID.

**def findSignalControllerByName(self, name: str) -> Tessng.ISignalController**

Retrieve signal controller object by Name; returns the first if duplicates exist.

**def createSignalController(self, name: str) -> Tessng.ISignalController**

Create a signal controller.

Parameters:

[ in ] name: Name of the signal controller.

Return:

Signal controller object.

Example:

```python
# Signal Controller Name
signal_controller_name = "Shuanglong Avenue - Jiyin Avenue Intersection"
# Create Signal Controller
signal_controller = self.netiface.createSignalController(signal_controller_name)
```

#### 3.3.2.15. Traffic Signal Control Scheme

**def signalPlanCount(self) -> int**

Retrieve the number of traffic signal control scheme groups.

**def signalPlanIds(self) -> list[int]**

Retrieve the sequence of traffic signal control scheme IDs.

**def signalPlans(self) -> list[Tessng.ISignalPlan]**

Retrieve the sequence of traffic signal control scheme objects.

**def findSignalPlanById(self, id: int) -> Tessng.ISignalPlan**

Retrieve traffic signal control scheme object by ID.

**def findSignalPlanByName(self, name: str) -> Tessng.ISignalPlan**

Retrieve traffic signal control scheme object by Name.

**def createSignalPlan(self, pITrafficLight: Tessng.ISignalController, name: str, cycle: int, phasedifference: int, startTime: int, endTime: int) -> Tessng.ISignalPlan**

Create a traffic signal control scheme.

Parameters:

[ in ] pITrafficLight: signal controller object.

[ in ] name: scheme name.

[ in ] cycle: cycle duration.

[ in ] phasedifference: phase difference.

[ in ] startTime: start time.

[ in ] endTime: end time.

Return:

Traffic signal control scheme object.

Example:

```python
# Get the signal controller object
signal_controller = self.netiface.findSignalControllerById(1)
# Traffic signal control scheme name
signal_plan_name = "Off-peak Signal Plan"
# Cycle duration, Unit: s
cycle_time = 120
# Phase difference, Unit: s
phase_difference = 0
# Start time, Unit: s
start_time = 0
# End Time (Unit: s)
end_time = 3600
# Create traffic signal control scheme
signal_plan = self.netiface.createSignalPlan(signal_controller, signal_plan_name, cycle_time, phase_difference, start_time, end_time)
```

#### 3.3.2.16. Traffic signal phase

**def findSignalPhase(self, id: int) -> Tessng.ISignalPhase**

Get the traffic signal phase object by traffic signal phase ID.

**def createSignalPlanSignalPhase(self, SignalPlan:Tessng.ISignalPlan, name:str, lColor:list[Online.ColorInterval]) -> Tessng.ISignalPhase**

Create a traffic signal phase.

Parameters:

[ in ] SignalPlan: traffic signal control scheme object.

[ in ] name: Phase Name.

[ in ] lColor: List of light color objects.

Return:

Traffic signal phase object.

Example:

```python
from tessng import Online

# Retrieve traffic signal control phase object
signal_plan = self.netiface.findSignalPlanById(1)
# Phase Name
signal_phase_name = "East-West Through"
# Build list of light color objects
color = ["R", "G", "Y", "R"]
intervals = [30, 26, 3, 61]
color_interval_list = [
    Online.ColorInterval(color, duration)
    for color, duration in zip(colors, durations)
]
# Create traffic signal phase
signal_phase = self.netiface.createSignalPlanSignalPhase(signal_plan, signal_phase_name, color_interval_list)
```

**def removeSignalPhase(self, pPlan: Tessng.ISignalPlan, phaseId: int) -> None**

Remove an existing traffic signal phase. After removal, the original phase sequence is automatically reordered.

Parameters:

[ in ] pPlan: Traffic signal control scheme object.

[ in ] phaseID: ID of the phase to be removed.

#### 3.3.2.17. Traffic Signal Heads

**def signalLampCount(self) -> int**

Retrieve number of traffic signals.

**def signalLampIds(self) -> list[int]**

Retrieve sequence of traffic signal IDs.

**def signalLamps(self) -> list[Tessng.ISignalLamp]**

Retrieve sequence of traffic signal objects.

**def findSignalLamp(self, id: int) -> Tessng.ISignalLamp**

Retrieve traffic signal object by traffic signal ID.

**def createSignalLamp(self, pPhase: Tessng.ISignalPhase, name: str, laneId: int, toLaneId: int, distance: float) -> Tessng.ISignalLamp**

Create traffic signal.

Parameters:

[ in ] pPhase: Phase object.

[ in ] name: Traffic signal name.

[ in ] laneID: Lane ID where the traffic signal is located, or the upstream Lane ID on the lane connection.

[ in ] toLaneID: Downstream Lane ID on the lane connection where the traffic signal is located.

[ in ] distance: Distance from the traffic signal to the start of the lane or lane connection. Unit: pixel.

Return:

Traffic signal object.

Example:

```python
from tessng import m2p

# Get phase object
signal_phase = self.netiface.findSignalPhase(1)
# Traffic signal name
signal_lamp_name = "East Through"
# Lane ID
lane_id = 1
# Downstream Lane ID
to_lane_id = -1
# Position, Unit: m
distance = m2p(50)
# Create traffic signal
signal_lamp = self.netiface.createSignalLamp(signal_plan, signal_lamp_name, lane_id, to_lane_id, distance)
```

**def createTrafficSignalLamp(self, pTrafficLight: Tessng.ISignalController, name: str, laneId: int, toLaneId: int, distance: float) -> Tessng.ISignalLamp**

Create traffic signal.

Parameters:

[ in ] pTrafficLight: Signal controller.

[ in ] name: Traffic signal name.

[ in ] laneID: Lane ID where the traffic signal is located, or the upstream Lane ID on the lane connection.

[ in ] toLaneID: Downstream Lane ID on the lane connection where the traffic signal is located.

[ in ] distance: Distance from the traffic signal to the start of the lane or lane connection. Unit: pixel.

Return:

Traffic signal object.

**def addSignalPhaseToLamp(self, SignalPhaseId: int, signalLamp: Tessng.ISignalLamp) -> None**

Add a phase bound to the traffic signal.

Parameters:

[ in ] SignalPhaseID: Signal phase ID.

[ in ] signalLamp: Traffic signal object.

**def removeSignalPhaseFromLamp(self, SignalPhaseId: int, signalLamp: Tessng.ISignalLamp) -> None**

Removes a bound phase from the traffic signal; if only one phase remains in the list, the associated phase will be set to null.

Parameters:

[ in ] SignalPhaseID: Signal phase ID.

[ in ] signalLamp: Traffic signal object.

**def transferSignalPhase(self, pFromISignalPhase: Tessng.ISignalPhase, pToISignalPhase: Tessng.ISignalPhase, signalLamp: Tessng.ISignalLamp) -> None**

Replaces the bound phase of the traffic signal, but crossing signal controllers is not permitted.

Parameters:

[ in ] pFromISignalPhase: Original phase.

[ in ] pToISignalPhase: Target phase.

[ in ] signalLamp: Traffic signal object.

#### 3.3.2.18. Data Collector

**def vehiInfoCollectors(self) -> list[Tessng.IVehicleDrivInfoCollector]**

Retrieves the sequence of all data collector objects.

**def findVehiInfoCollector(self, id: int) -> Tessng.IVehicleDrivInfoCollector**

Obtains the data collector object by its ID.

**def createVehiCollectorOnLink(self, pLane: Tessng.ILane, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.IVehicleDrivInfoCollector**

Creates a data collector on a lane within a road segment.

Parameters:

[ in ] pLane: Lane object.

[ in ] dist: Distance from the start of the lane. Unit: pixel.

Return:

Data collector object.

Example:

```python
# Get Lane object
lane = self.netiface.findLane(1)
# Position, Unit: m
dist = 50
# Create data collector on Road Segment
collector = self.netiface.createVehiCollectorOnLink(lane, dist, UnitOfMeasure.Metric)
```

**def createVehiCollectorOnConnector(self, pLaneConnector: Tessng.ILaneConnector, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.IVehicleDrivInfoCollector**

Create data collector on the Lane Connection of a Connector Segment.

Parameters:

[ in ] pLaneConnector: Lane connection object.

[ in ] dist: Distance from the start of the Lane Connection. Unit: pixel.

Return:

Data collector object.

Example:

```python
# Get Lane Connection object
lane_connector = self.netiface.findLaneConnector(1, 4)
# Position, Unit: m
dist = 50
# Create data collector on Connector Segment
collector = self.netiface.createVehiCollectorOnConnector(lane_connector, dist, UnitOfMeasure.Metric)
```

**def removeVehiCollector(self, pCollector: Tessng.IVehicleDrivInfoCollector) -> bool**

Remove vehicle information collector.

Parameters:

[ in ] pCollector: Vehicle information collector object.

Return:

Indicates whether the removal was successful.

#### 3.3.2.19. Queue Counter

**def vehiQueueCounters(self) -> list[Tessng.IVehicleQueueCounter]**

Retrieve all queue counter object sequences.

**def findVehiQueueCounter(self, id: int) -> Tessng.IVehicleQueueCounter**

Obtain queue counter object by ID.

**def createVehiQueueCounterOnLink(self, pLane: Tessng.ILane, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.IVehicleQueueCounter**

Create vehicle queue counter on a Lane of a Road Segment.

Parameters:

[ in ] pLane: Lane object.

[ in ] dist: Distance from the start of the lane. Unit: pixel.

Return:

Queue counter object.

Example:

```python
# Get Lane object
lane = self.netiface.findLane(1)
# Position, Unit: m
dist = 80
# Create a queue counter on a road segment
counter = self.netiface.createVehiQueueCounterOnLink(lane, dist, UnitOfMeasure.Metric)
```

**def createVehiQueueCounterOnConnector(self, pLaneConnector: Tessng.ILaneConnector, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.IVehicleQueueCounter**

Create a vehicle queue counter on a lane connection of the connector segment.

Parameters:

[ in ] pLaneConnector: Lane connection object.

[ in ] dist: Distance from the start of the Lane Connection. Unit: pixel.

Return:

Queue counter object.

Example:

```python
# Get Lane Connection object
lane_connector = self.netiface.findLaneConnector(1, 4)
# Position, Unit: m
dist = 80
# Create a queue counter on a connector segment
counter = self.netiface.createVehiQueueCounterOnConnector(lane_connector, dist, UnitOfMeasure.Metric)
```

#### 3.3.2.20. Travel Time Detector

**def vehiTravelDetectors(self) -> list[Tessng.IVehicleTravelDetector]**

Retrieve the sequence of all vehicle travel time detector objects.

**def findVehiTravelDetector(self, id: int) -> Tessng.IVehicleTravelDetector**

Retrieve a vehicle travel time detector object by ID.

**def createVehicleTravelDetector_link2link(self, pStartLink: Tessng.ILink, pEndLink: Tessng.ILink, dist1: float, dist2: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[Tessng.IVehicleTravelDetector]**

Create a travel time detector from one road segment to another.

Parameters:

[ in ] pStartLink: Starting road segment object.

[ in ] pEndLink: Ending road segment object.

[ in ] dist1: Distance from the detector start point to the start of the road segment. Unit: pixel.

[ in ] dist2: Distance from the detector end point to the start of the road segment. Unit: pixel.

Return:

Travel time detector object.

Example:

```python
# Get the starting road segment object
start_link = self.netiface.findLink(1)
# Get the ending road segment object
end_link = self.netiface.findLink(2)
# Detector start position on the starting road segment, unit: m
start_dist = 10
# Detector end position on the ending road segment, unit: m
end_dist = 90
# Create a travel time detector with both start and end points on road segments
detectors = self.netiface.createVehicleTravelDetector_link2link(start_link, end_link, start_dist, end_dist, UnitOfMeasure.Metric)
```

**def createVehicleTravelDetector_link2conn(self, pStartLink: Tessng.ILink, pEndLaneConnector: Tessng.ILaneConnector, dist1: float, dist2: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[Tessng.IVehicleTravelDetector]**

Create a travel time detector from a road segment to a connector segment.

Parameters:

[ in ] pStartLink: Starting road segment object.

[ in ] pEndLaneConnector: End lane connection object.

[ in ] dist1: Distance from the detector start point to the start of the road segment. Unit: pixel.

[ in ] dist2: Detector end distance from the start point of the lane connection. Unit: pixel.

Return:

Travel time detector object.

Example:

```python
# Get the starting road segment object
start_link = self.netiface.findLink(1)
# Get the ending lane connection object
end_lane_connector = self.netiface.findLaneConnector(1, 4)
# Detector start position on the starting road segment, unit: m
start_dist = 10
# Detector end position on the ending lane connection, unit: m
end_dist = 10
# Create a travel time detector with start on road segment and end on connector segment
detectors = self.netiface.createVehicleTravelDetector_link2conn(start_link, end_lane_connector, start_dist, end_dist, UnitOfMeasure.Metric)
```

**def createVehicleTravelDetector_conn2link(self, pStartLaneConnector: Tessng.ILaneConnector, pEndLink: Tessng.ILink, dist1: float, dist2: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[Tessng.IVehicleTravelDetector]**

Create a travel time detector from Connector Segment to Road Segment.

Parameters:

[ in ] pStartLaneConnector: Starting Lane Connection object.

[ in ] pEndLink: Ending road segment object.

[ in ] dist1: Distance from the detector start point to the starting point of the Lane Connection. Unit: pixel.

[ in ] dist2: Distance from the detector end point to the start of the road segment. Unit: pixel.

Return:

Travel time detector object.

Example:

```python
# Get the starting Lane Connection object
start_lane_connector = self.netiface.findLaneConnector(1, 4)
# Get the ending road segment object
end_link = self.netiface.findLink(2)
# Position of the detector start point on the starting Lane Connection, unit: m
start_dist = 10
# Detector end position on the ending road segment, unit: m
end_dist = 90
# Create a travel time detector with start point on Connector Segment and end point on Road Segment
detectors = self.netiface.createVehicleTravelDetector_conn2link(start_lane_connector, end_link, start_dist, end_dist, UnitOfMeasure.Metric)
```

**def createVehicleTravelDetector_conn2conn(self, pStartLaneConnector: Tessng.ILaneConnector, pEndLaneConnector: Tessng.ILaneConnector, dist1: float, dist2: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[Tessng.IVehicleTravelDetector]**

Create a travel time detector from Connector Segment to Connector Segment.

Parameters:

[ in ] pStartLaneConnector: Starting Lane Connection object.

[ in ] pEndLaneConnector: End lane connection object.

[ in ] dist1: Distance from the detector start point to the starting point of the Lane Connection. Unit: pixel.

[ in ] dist2: Detector end distance from the start point of the lane connection. Unit: pixel.

Return:

Travel time detector object.

Example:

```python
# Get the starting Lane Connection object
start_lane_connector = self.netiface.findLaneConnector(1, 4)
# Get the ending road segment object
end_lane_connector = self.netiface.findLaneConnector(4, 7)
# Position of the detector start point on the starting Lane Connection, unit: m
start_dist = 10
# Detector end position on the ending lane connection, unit: m
end_dist = 90
# Create a travel time detector with both start and end points on Connector Segment
detectors = self.netiface.createVehicleTravelDetector_conn2conn(start_lane_connector, end_lane_connector, start_dist, end_dist, UnitOfMeasure.Metric)
```

#### 3.3.2.21. Guidance Arrows

**def guidArrowCount(self) -> int**

Get the number of guidance arrows.

**def guidArrowIds(self) -> list[int]**

Get the sequence of guidance arrow IDs.

**def guidArrows(self) -> list[Tessng.IGuIDArrow]**

Get the sequence of guidance arrow objects.

**def findGuidArrow(self, id: int) -> Tessng.IGuIDArrow**

Retrieve the guidance arrow object by guidance arrow ID.

**def createGuidArrow(self, pLane: Tessng.ILane, length: float, distToTerminal: float, arrowType: Online.GuideArrowType, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.IGuIDArrow**

Create a guidance arrow.

Parameters:

[ in ] pLane: Lane object.

[ in ] length: Length. Unit: pixel.

[ in ] distToTerminal: Distance to lane terminal. Unit: pixel.

[ in ] arrowType: Arrow type.

Return:

Guidance arrow object.

Example:

```python
from tessng import Online, UnitOfMeasure

lane = self.netiface.findLane(4)
if lane is not None:
    length = 4
    dist_to_terminal = 10
    arrow_type = Online.GuideArrowType.StraightRight
    guid_arrow = self.netiface.createGuidArrow(lane, length, dist_to_terminal, arrow_type, UnitOfMeasure.Metric)
```

**def removeGuidArrow(self, pArrow: Tessng.IGuIDArrow) -> None**

Remove a guidance arrow.

Parameters:

[ in ] pArrow: Guidance arrow object.

#### 3.3.2.22. Bus Route

**def buslines(self) -> list[Tessng.IBusLine]**

Retrieve the sequence of bus route objects.

**def findBusline(self, buslineId: int) -> Tessng.IBusLine**

Retrieve a bus route by bus route ID.

**def findBuslineByFirstLinkID(self, linkId: int) -> Tessng.IBusLine**

Retrieve a bus route by starting road segment ID.

**def createBusLine(self, lLink: list[Tessng.ILink]) -> Tessng.IBusLine**

Create a bus route. Adjacent road segments in the lLink list may be adjacent or non-adjacent within the road network; if non-adjacent, TESS NG will generate the shortest path between them. If two adjacent road segments in the lLink list are not adjacent in the road network and there is no shortest path between them, then the second adjacent road segment and all subsequent segments are invalid.

Parameters:
	[ in ] lLink, a sequence of road segment objects traversed by the bus route.

Return:

Bus route object.

Example:

```python
link1 = self.netiface.findLink(1)
link2 = self.netiface.findLink(2)
bus_line = self.netiface.createBusLine([link1, link2])
```

**def removeBusLine(self, pBusLine: Tessng.IBusLine) -> bool**

Remove bus route.

Parameters:

[ in ] pBusLine: bus route object.

#### 3.3.2.23. Bus Stop

**def busStations(self) -> list[Tessng.IBusStation]**

Obtain a sequence of bus stop objects.

**def findBusStation(self, stationId: int) -> Tessng.IBusStation**

Retrieve a bus stop object by its bus stop ID.

**def createBusStation(self, pLane: Tessng.ILane, length: float, dist: float, name: str = "", unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.IBusStation**

Create a bus stop.

Parameters:

[ in ] pLane: Lane object.

[ in ] length: length of the bus stop. Unit: pixel.

[ in ] dist: distance from the starting point of the bus stop to the start of the lane. Unit: pixel.

[ in ] name: Station Name.	

Return:

Bus station object.

Example:

```python
from tessng import UnitOfMeasure

lane = self.netiface.findLane(1)
bus_station = self.netiface.createBusStation(lane, 30, 50, "Bus station 1", UnitOfMeasure.Metric)
# Set station type 1: Curbside, 2: Bay
bus_station.setType(1)
```

**def removeBusStation(self, pStation: Tessng.IBusStation) -> bool**

Remove bus station.

Parameters:

[ in ] pStation: Bus station object.

#### 3.3.2.24. Bus Route - Station

**def findBusStationLineByStationID(self, stationId: int) -> list[Tessng.IBusStationLine]**

Retrieve bus route - station object by bus station ID.

**def addBusStationToLine(self, pBusLine: Tessng.IBusLine, pStation: Tessng.IBusStation) -> bool**

Associate a bus station with a bus route.

Parameters:

[ in ] pBusLine: bus route object.

[ in ] pStation: Bus station object.

**def removeBusStationFromLine(self, pBusLine: Tessng.IBusLine, pStation: Tessng.IBusStation) -> bool**

Disassociate the relationship between a bus station and a bus route.

Parameters:

[ in ] pBusLine: bus route object.

[ in ] pStation: Bus station object.

#### 3.3.2.25. Accident Area

**def accidentZones(self) -> list[Tessng.IAccidentZone]**

Retrieve all accident area objects.

**def findAccidentZone(self, accidentZoneId: int) -> Tessng.IAccidentZone**

Retrieve accident area object by accident area ID.

**def createAccidentZone(self, param: Online.DynaAccidentZoneParam) -> Tessng.IAccidentZone**

Create an accident area.

Parameters:

[ in ] param: Dynamic accident area information.

Return:

Accident area object.

Example:

```python
from tessng import Online, UnitOfMeasure

# Construction Parameters
param = Online.DynaAccidentZoneParam()
# Accident Area Name
param.name = "Accident Area"
# Road ID
param.roadId = 1
# Position, distance from the start point of the road segment or connector segment, unit: m
param.location = 100
# Length, unit: m
param.length = 50
# List of lane indices, starting from 0, continuous and sequential
param.mlFromLaneNumber = [0]
# Start Time (Unit: s)
param.startTime= 10
# Duration, unit: s
param.duration = 600
# Speed limit of adjacent lanes, unit: km/h
param.limitSpeed = 40
# Create accident area
accident_zone = self.netiface.createAccidentZone(param, UnitOfMeasure.Metric)
```

**def removeAccidentZone(self, pIAccidentZone: Tessng.IAccidentZone) -> None**

Remove accident area.

Parameters:

[ in ] pIAccidentZone: Accident area object.

#### 3.3.2.26. Construction Zone

**def roadWorkZones(self) -> list[Tessng.IRoadWorkZone]**

Retrieve all construction zone objects.

**def findRoadWorkZone(self, roadWorkZoneId: int) -> Tessng.IRoadWorkZone**

Get construction zone object by ID.

**def createRoadWorkZone(self, param: Online.DynaRoadWorkZoneParam, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.IRoadWorkZone**

Create construction zone.

Parameters:

[ in ] param: Construction zone parameters. Unit: pixel.

Return:

Construction Zone object.

Example:

```python
from tessng import Online, UnitOfMeasure

# Construction Parameters
param = Online.DynaRoadWorkZoneParam()
# Construction Zone Name
param.name= "Construction Zone"
# Road ID
param.roadId = 1
# Position, distance from the start point of the road segment or connector segment, unit: m
param.location = 200
# Length, unit: m
param.length = 50  # Length
param.upCautionLength = 70  # Advance Warning Length
param.upTransitionLength = 50  # Transition Zone Length
param.upBufferLength = 50  # Buffer Zone Length
param.downTransitionLength = 40  # Downstream Transition Zone Length
param.downTerminationLength = 40  # Termination Zone Length
# List of lane indices, starting from 0, continuous and sequential
param.mlFromLaneNumber = [0]
# Start Time (Unit: s)
param.startTime = 0
# Duration, unit: s
param.duration = 3600
# Speed limit of adjacent lanes, unit: km/h
param.limitSpeed = 40
# Create Construction Zone
road_work_zone = self.netiface.createRoadWorkZone(param, UnitOfMeasure.Metric)
```

**def removeRoadWorkZone(self, pIRoadWorkZone: Tessng.IRoadWorkZone) -> None**

Remove Construction Zone.

Parameters:

[ in ] pIRoadWorkZone: Construction Zone object.

**def updateRoadWorkZone(self, param: Online.DynaRoadWorkZoneParam, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

Update Construction Zone.

Parameters:

[ in ] param: Construction zone parameters. Unit: pixel.

#### 3.3.2.27. Restricted Zone

**def limitedZones(self) -> list[Tessng.ILimitedZone]**

Retrieve sequence of all Restricted Zone objects.

**def findLimitedZone(self, limitedZoneId: int) -> Tessng.ILimitedZone**

Retrieve Restricted Zone object by Restricted Zone ID.

**def createLimitedZone(self, param: Online.DynaLimitedZoneParam, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.ILimitedZone**

Create Restricted Zone.

Parameters:

[ in ] param: Restricted Zone parameters. Unit: pixel.

Return:

Restricted Zone object.

Example:

```python
from tessng import Online, UnitOfMeasure

# Construction Parameters
param = Online.DynaLimitedZoneParam()
# Restricted Zone Name
param.name = "Restricted Zone"
# Road ID
param.roadId = 1
# Position, distance from the start point of the road segment or connector segment, unit: m
param.location = 100
# Length, unit: m
param.length = 50
# List of lane indices, starting from 0, continuous and sequential
param.mlFromLaneNumber = [0]
# Start Time (Unit: s)
param.startTime = 0
# Duration, unit: s
param.duration = 600
# Speed limit of adjacent lanes, unit: km/h
param.limitSpeed = 40
# Create Restricted Zone
limited_zone = self.netiface.createLimitedZone(param, UnitOfMeasure.Metric)
```

**def removeLimitedZone(self, pILimitedZone: Tessng.ILimitedZone) -> None**

Remove Restricted Zone.

Parameters:

[ in ] pILimitedZone: Restricted Zone Object.

**def updateLimitedZone(self, param: Online.DynaLimitedZoneParam, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

Update Restricted Zone.

Parameters:

[ in ] param: Restricted Zone parameters. Unit: pixel.

#### 3.3.2.28. Reconstruction and Expansion Lane Borrowing

**def reconstructions(self) -> list[Tessng.IReconstruction]**

Retrieve All Reconstruction and Expansion Objects.

**def findReconstruction(self, reconstructionId: int) -> Tessng.IReconstruction**

Retrieve Reconstruction and Expansion Object by Reconstruction and Expansion ID.

**def createReconstruction(self, param: Online.DynaReconstructionParam, unit: UnitOfMeasure = UnitOfMeasure.Default) -> Tessng.IReconstruction**

Create Reconstruction and Expansion.

Parameters:

[ in ] param: Reconstruction and Expansion Parameters. Unit: pixel.

Return:

Reconstruction and Expansion Object.

Example:

```python
from tessng import Online, UnitOfMeasure

# Construction Parameters
param = Online.DynaReconstructionParam()
# Construction Zone ID
param.roadWorkZoneId = rwz_id
# Borrowed Road Segment ID
param.beBorrowedLinkId = 2
# Number of Borrowed Lanes
param.borrowedNum = 1
# Traffic Maintenance Opening Length, Unit: m
param.passagewayLength = 80
# Traffic Maintenance Opening Speed Limit, Unit: m/s
param.passagewayLimitedSpeed = 40 / 3.6
# Create Reconstruction and Expansion Lane Borrowing
reconstruction = self.netiface.createReconstruction(param, UnitOfMeasure.Metric)
```

**def removeReconstruction(self, pIReconstruction: Tessng.IReconstruction) -> None**

Remove Reconstruction and Expansion.

Parameters:

[ in ] pIReconstruction: Reconstruction and Expansion object.

**def updateReconStruction(self, param: Online.DynaReconstructionParam, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

Update Reconstruction and Expansion.

Parameters:

[ in ] param: Reconstruction and Expansion Parameters. Unit: pixel.

**def reCalcPassagewayLength(self, param: Online.DynaReconstructionParam, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Recalculate the length of the traffic guarantee opening, which can be derived from the detailed traffic guarantee parameters.

Parameters:

[ in ] param: Reconstruction and Expansion Parameters. Unit: pixel.

Return:

Length of the traffic guarantee opening.

#### 3.3.2.29. Speed Limit Zone

**def reduceSpeedAreas(self) -> list[Tessng.IReduceSpeedArea]**

Retrieve the sequence of all Speed Limit Zone objects.

**def findReduceSpeedArea(self, id: int) -> Tessng.IReduceSpeedArea**

Retrieve a Speed Limit Zone object by its ID.

**def createReduceSpeedArea(self, param: Online.DynaReduceSpeedAreaParam) -> Tessng.IReduceSpeedArea**

Create a Speed Limit Zone.

Parameters:

[ in ] param: Speed Limit Zone parameters. Unit: pixel.

Return:

Speed Limit Zone object.

**def removeReduceSpeedArea(self, pIReduceSpeedArea: Tessng.IReduceSpeedArea) -> None**

Remove a Speed Limit Zone.

Parameters:

[ in ] pIReduceSpeedArea: Speed Limit Zone object.

**def updateReduceSpeedArea(self, param: Online.DynaReduceSpeedAreaParam) -> bool**

Update the Speed Limit Zone.

Parameters:

[ in ] param: Speed Limit Zone parameters. Unit: pixel.

#### 3.3.2.30. Pedestrian Type

**def pedestrianTypes(self) -> list[Tessng.IPedestrianType]**

Retrieve the sequence of all Pedestrian Type objects.

#### 3.3.2.31. Pedestrian Composition

**def pedestrianCompositions(self) -> list[Online.Pedestrian.PedestrianComposition]**

Retrieve the complete sequence of pedestrian composition information.

**def createPedestrianComposition(self, name: str, mpCompositionRatio: dict[int, float]) -> int**

Create a pedestrian composition.

Parameters:

[ in ] name: Name of the composition.

[ in ] mpCompositionRatio: Composition details, where the key is the pedestrian type code and the value is the pedestrian type proportion.

Return:

Pedestrian composition ID; returns -1 if creation fails.

**def removePedestrianComposition(self, compositionId: int) -> bool**

Remove a pedestrian composition.

Parameters:

[ in ] compositionID: Pedestrian composition ID.

**def updatePedestrianComposition(self, compositionId: int, mpCompositionRatio: dict[int, float]) -> bool**

Update the pedestrian composition.

Parameters:

[ in ] compositionID: Pedestrian composition ID.

[ in ] mpCompositionRatio: Composition details, where the key is the pedestrian type code and the value is the pedestrian type proportion.

Return:

Indicates whether the update was successful.

#### 3.3.2.32. Pedestrian Surface Area Hierarchy

**def layerInfos(self) -> list[Online.Pedestrian.LayerInfo]**

Retrieve all hierarchy information.

**def addLayerInfo(self, name: str, height: float, visible: bool, locked: bool) -> Online.Pedestrian.LayerInfo**

Add a new hierarchy and return the information of the newly added hierarchy.

Parameters:

[ in ] name: Hierarchy name.

[ in ] height: Height of the hierarchy.

[ in ] visible: Visibility status.

[ in ] locked: Indicates whether locked. Once locked, the surface area cannot be modified.

**def removeLayerInfo(self, layerId: int) -> None**

Deleting a specific level will remove all elements contained within that level.

Parameters:

[ in ] layerID: Layer identifier.

**def updateLayerInfo(self, layerId: int, name: str, height: float, visible: bool, locked: bool) -> bool**

Update layer information.

Parameters:

[ in ] layerID: Layer identifier.

[ in ] name: Hierarchy name.

[ in ] height: Height of the hierarchy.

[ in ] visible: Visibility status.

[ in ] locked: Indicates whether locked. Once locked, the surface area cannot be modified.

Return:

Indicates whether the update was successful.

#### 3.3.2.33. Pedestrian Surface Area

**def pedestrianRegions(self) -> list[Tessng.IPedestrianRegion]**

Retrieve the sequence of all pedestrian surface area objects.

**def pedestrianRectRegions(self) -> list[Tessng.IPedestrianRectRegion]**

Retrieve the sequence of all rectangular surface area objects.

**def pedestrianTriangleRegions(self) -> list[Tessng.IPedestrianTriangleRegion]**

Retrieve the sequence of all triangular surface area objects.

**def pedestrianEllipseRegions(self) -> list[Tessng.IPedestrianEllipseRegion]**

Retrieve the sequence of all elliptical surface area objects.

**def pedestrianFanShapeRegions(self) -> list[Tessng.IPedestrianFanShapeRegion]**

Retrieve the sequence of all sector-shaped surface area objects.

**def pedestrianPolygonRegions(self) -> list[Tessng.IPedestrianPolygonRegion]**

Retrieve the sequence of all polygonal surface area objects.

**def pedestrianSIDeWalkRegions(self) -> list[Tessng.IPedestrianSIDeWalkRegion]**

Retrieve the sequence of all sidewalk objects.

**def pedestrianCrossWalkRegions(self) -> list[Tessng.IPedestrianCrossWalkRegion]**

Retrieve the sequence of all crosswalk objects.

**def findPedestrianRegion(self, id: int) -> Tessng.IPedestrianRegion**

Obtain the pedestrian surface area object by Pedestrian Surface Area ID.

**def findPedestrianRectRegion(self, id: int) -> Tessng.IPedestrianRectRegion**

Obtain the rectangular surface area object by Pedestrian Surface Area ID.

**def findPedestrianEllipseRegion(self, id: int) -> Tessng.IPedestrianEllipseRegion**

Obtain the elliptical surface area object by Pedestrian Surface Area ID.

**def findPedestrianTriangleRegion(self, id: int) -> Tessng.IPedestrianTriangleRegion**

Obtain the triangular surface area object by Pedestrian Surface Area ID.

**def findPedestrianFanShapeRegion(self, id: int) -> Tessng.IPedestrianFanShapeRegion**

Obtain the sector surface area object by Pedestrian Surface Area ID.

**def findPedestrianPolygonRegion(self, id: int) -> Tessng.IPedestrianPolygonRegion**

Obtain the polygon surface area object by Pedestrian Surface Area ID.

**def findPedestrianSIDeWalkRegion(self, id: int) -> Tessng.IPedestrianSIDeWalkRegion**

Obtain the sidewalk object by Pedestrian Surface Area ID.

**def findPedestrianCrossWalkRegion(self, id: int) -> Tessng.IPedestrianCrossWalkRegion**

Obtain the pedestrian crosswalk object by Pedestrian Surface Area ID.

**def createPedestrianRectRegion(self, startPoint: PySide2.QtCore.QPointF, endPoint: PySide2.QtCore.QPointF) -> Tessng.IPedestrianRectRegion**

Create a rectangular pedestrian surface area.

Parameters:

[ in ] startPoint: coordinates of the top-left corner.

[ in ] endPoint: coordinates of the bottom-right corner.

Return	

Rectangular pedestrian surface area object.

**def createPedestrianTriangleRegion(self, startPoint: PySide2.QtCore.QPointF, endPoint: PySide2.QtCore.QPointF) -> Tessng.IPedestrianTriangleRegion**

Create a triangular pedestrian surface area.

Parameters:

[ in ] startPoint: coordinates of the top-left corner.

[ in ] endPoint: coordinates of the bottom-right corner.

Return:

Triangular pedestrian surface area object.

**def createPedestrianEllipseRegion(self, startPoint: PySide2.QtCore.QPointF, endPoint: PySide2.QtCore.QPointF) -> Tessng.IPedestrianEllipseRegion**

Create an elliptical pedestrian surface area.

Parameters:

[ in ] startPoint: coordinates of the top-left corner.

[ in ] endPoint: coordinates of the bottom-right corner.

Return:	

Elliptical pedestrian surface area object.

**def createPedestrianFanShapeRegion(self, startPoint: PySide2.QtCore.QPointF, endPoint: PySide2.QtCore.QPointF) -> Tessng.IPedestrianFanShapeRegion**

Create a sector-shaped pedestrian surface area.

Parameters:

[ in ] startPoint: Center point coordinates.

[ in ] endPoint: Endpoint coordinates of the outer radius.

Return:

Sector-shaped pedestrian surface area object.

**def createPedestrianPolygonRegion(self, polygon: PySide2.QtGui.QPolygonF) -> Tessng.IPedestrianPolygonRegion**

Create a polygonal pedestrian surface area.

Parameters:

[ in ] polygon: Polygon vertices.

Return:

Polygonal pedestrian surface area object.

**def createPedestrianSIDeWalkRegion(self, vertexs: list[PySide2.QtCore.QPointF]) -> Tessng.IPedestrianSIDeWalkRegion**

Create a sidewalk.

Parameters:

[ in ] vertexes: List of vertices.

Return:	

Sidewalk object.

**def createPedestrianCrossWalkRegion(self, startPoint: PySide2.QtCore.QPointF, endPoint: PySide2.QtCore.QPointF) -> Tessng.IPedestrianCrossWalkRegion**

Create a pedestrian crosswalk.

Parameters:

[ in ] startPoint: coordinates of the top-left corner.

[ in ] endPoint: coordinates of the bottom-right corner.

Return:

Pedestrian crosswalk object.

**def createPedestrianStairRegion(self, startPoint: PySide2.QtCore.QPointF, endPoint: PySide2.QtCore.QPointF) -> Tessng.IPedestrianStairRegion**

Create stairs.

Parameters:

[ in ] startPoint: Start point coordinates.

[ in ] endPoint: End point coordinates.

Return:	

Stairs object.

**def removePedestrianRectRegion(self, pIPedestrianRectRegion: Tessng.IPedestrianRectRegion) -> None**

Delete rectangular pedestrian surface area.

Parameters:

[ in ] pIPedestrianRectRegion: Rectangular pedestrian surface area object.

**def removePedestrianTriangleRegion(self, pIPedestrianTriangleRegion: Tessng.IPedestrianTriangleRegion) -> None**

Delete triangular pedestrian surface area.

Parameters:

[ in ] pIPedestrianTriangleRegion: Triangular pedestrian surface area object.

**def removePedestrianEllipseRegion(self, pIPedestrianEllipseRegion: Tessng.IPedestrianEllipseRegion) -> None**

Delete elliptical pedestrian surface area.

Parameters:

[ in ] pIPedestrianEllipseRegion: Elliptical pedestrian surface area object.

**def removePedestrianFanShapeRegion(self, pIPedestrianFanShapeRegion: Tessng.IPedestrianFanShapeRegion) -> None**

Delete fan-shaped pedestrian surface area.

Parameters:

[ in ] pIPedestrianFanShapeRegion: Fan-shaped pedestrian surface area object.

**def removePedestrianPolygonRegion(self, pIPedestrianPolygonRegion: Tessng.IPedestrianPolygonRegion) -> None**

Delete polygonal Pedestrian Surface Area.

Parameters:

[ in ] pIPedestrianPolygonRegion: Polygonal Pedestrian Surface Area object.

**def removePedestrianSIDeWalkRegion(self, pIPedestrianSIDeWalkRegion: Tessng.IPedestrianSIDeWalkRegion) -> None**

Delete sidewalk.

Parameters:

[ in ] pIPedestrianSIDeWalkRegion: Sidewalk object.

**def removePedestrianCrossWalkRegion(self, pIPedestrianCrossWalkRegion: Tessng.IPedestrianCrossWalkRegion) -> None**

Delete pedestrian crosswalk.

Parameters:

[ in ] pIPedestrianCrossWalkRegion: Pedestrian crosswalk object.

**def removePedestrianStairRegion(self, pIPedestrianStairRegion: Tessng.IPedestrianStairRegion) -> None**

Delete staircase.

Parameters:

[ in ] pIPedestrianStairRegion: Staircase object.

#### 3.3.2.34. Pedestrian Origin Point

**def pedestrianPathStartPoints(self) -> list[Tessng.IPedestrianPathPoint]**

Get the sequence of all Pedestrian Origin Point objects.

**def findPedestrianPathStartPoint(self, id: int) -> Tessng.IPedestrianPathPoint**

Get Pedestrian Origin Point object by ID.

**def findPedestrianStartPointConfigInfo(self, id: int) -> Online.Pedestrian.PedestrianPathStartPointConfigInfo**

Get the configuration information of Pedestrian Origin Point by ID.

**def createPedestrianPathStartPoint(self, scenePos: PySide2.QtCore.QPointF) -> Tessng.IPedestrianPathPoint**

Create a Pedestrian Origin Point.

Parameters:

[ in ] scenePos: Scene coordinate.

Return:	

Pedestrian origin point object.

**def removePedestrianPathStartPoint(self, pIPedestrianPathStartPoint: Tessng.IPedestrianPathPoint) -> None**

Delete pedestrian origin point.

Parameters:

[ in ] pIPedestrianPathStartPoint: Pedestrian origin point object.

**def updatePedestrianStartPointConfigInfo(self, info: Online.Pedestrian.PedestrianPathStartPointConfigInfo) -> bool**

Update pedestrian origin point configuration.

Parameters:

[ in ] info: Pedestrian origin point configuration.

Return:	

Indicates whether the update was successful.

#### 3.3.2.35. Pedestrian End Point

**def pedestrianPathEndPoints(self) -> list[Tessng.IPedestrianPathPoint]**

Retrieve all pedestrian end point objects.

**def findPedestrianPathEndPoint(self, id: int) -> Tessng.IPedestrianPathPoint**

Retrieve pedestrian end point object by ID.

**def createPedestrianPathEndPoint(self, scenePos: PySide2.QtCore.QPointF) -> Tessng.IPedestrianPathPoint**

Create a pedestrian end point.

Parameters:

[ in ] scenePos: Scene coordinate.

Return:

Pedestrian end point object.

**def removePedestrianPathEndPoint(self, pIPedestrianPathEndPoint: Tessng.IPedestrianPathPoint) -> None**

Delete a pedestrian end point.

Parameters:

[ in ] pIPedestrianPathEndPoint: Pedestrian end point object.

#### 3.3.2.36. Pedestrian Decision Point

**def pedestrianPathDecisionPoints(self) -> list[Tessng.IPedestrianPathPoint]**

Retrieve all pedestrian decision point objects.

**def findPedestrianDecisionPoint(self, id: int) -> Tessng.IPedestrianPathPoint**

Retrieve pedestrian decision point object by pedestrian decision point ID.

**def findPedestrianDecisionPointConfigInfo(self, id: int) -> Online.Pedestrian.PedestrianDecisionPointConfigInfo**

Retrieve pedestrian decision point configuration information by pedestrian decision point ID.

**def createPedestrianDecisionPoint(self, scenePos: PySide2.QtCore.QPointF) -> Tessng.IPedestrianPathPoint**

Create a pedestrian decision point.

Parameters:

[ in ] scenePos: Scene coordinate.

Return:

Pedestrian decision point object.

**def removePedestrianDecisionPoint(self, pIPedestrianDecisionPoint: Tessng.IPedestrianPathPoint) -> None**

Delete a pedestrian decision point.

Parameters:

[ in ] pIPedestrianDecisionPoint: Pedestrian decision point object.

**def updatePedestrianDecisionPointConfigInfo(self, info: Online.Pedestrian.PedestrianDecisionPointConfigInfo) -> bool**

Update pedestrian decision point configuration information.

Parameters:

[ in ] info: Pedestrian decision point configuration information.

Return:	

Indicates whether the update was successful.

#### 3.3.2.37. Pedestrian Route

**def pedestrianPaths(self) -> list[Tessng.IPedestrianPath]**

Retrieve all pedestrian route objects, including local routes.

**def findPedestrianPath(self, id: int) -> Tessng.IPedestrianPath**

Retrieve pedestrian route by pedestrian route ID, including local routes.

**def createPedestrianPath(self, pStartPoint: Tessng.IPedestrianPathPoint, pEndPoint: Tessng.IPedestrianPathPoint, mIDdlePoints: list[PySide2.QtCore.QPointF]) -> Tessng.IPedestrianPath**

Create a pedestrian route (or pedestrian local route).

Parameters:

[ in ] pStartPoint: Pedestrian origin point (or pedestrian Decision point).

[ in ] pEndPoint: Pedestrian destination point.

[ in ] mIDdlePoints: A set of intermediate mandatory points.

Return:	

Pedestrian route object.

**def removePedestrianPath(self, pIPedestrianPath: Tessng.IPedestrianPath) -> None**

Delete pedestrian route.

Parameters:

[ in ] pIPedestrianPath: Pedestrian route object.

#### 3.3.2.38. Pedestrian traffic signal

**def crosswalkSignalLamps(self) -> list[Tessng.ICrosswalkSignalLamp]**

Retrieve all pedestrian crosswalk traffic signal objects.

**def findCrosswalkSignalLamp(self, id: int) -> Tessng.ICrosswalkSignalLamp**

Retrieve pedestrian crosswalk traffic signal object by ID.

**def addCrossWalkSignalPhaseToLamp(self, SignalPhaseId: int, signalLamp: Tessng.ISignalLamp) -> None**

Add pedestrian traffic signal.

Parameters:

[ in ] SignalPhaseID: Signal phase ID.

[ in ] signalLamp: Traffic signal object.

**def createCrossWalkSignalLamp(self, pTrafficLight: Tessng.ISignalController, name: str, crosswalkId: int, scenePos: PySide2.QtCore.QPointF, isPositive: bool) -> Tessng.ICrosswalkSignalLamp**

Create pedestrian crosswalk traffic signal.

Parameters:

[ in ] pTrafficLight: Signal controller object.

[ in ] name: Traffic signal name.

[ in ] crosswalkID: Pedestrian crosswalk ID.

​	[ in ] scenePos: Scene coordinates located within the pedestrian crosswalk.

​	[ in ] isPositive: Indicates whether the traffic signal control direction is positive.

Return:

​	Pedestrian crosswalk traffic signal object.

**def removeCrossWalkSignalLamp(self, pICrosswalkSignalLamp: Tessng.ICrosswalkSignalLamp) -> None**

​	Delete the pedestrian crosswalk traffic signal.

Parameters:

​	[ in ] pICrosswalkSignalLamp: Pedestrian crosswalk traffic signal object.

#### 3.3.2.39. Parking Lot Parking Headway Distribution

**def parkingTimeDis(self) -> list[Online.ParkingLot.DynaParkingTimeDis]**

​	Retrieve the list of parking lot parking headway distributions.

**def createParkingTimeDis(self, param: Online.ParkingLot.DynaParkingTimeDis) -> Online.ParkingLot.DynaParkingTimeDis**

​	Create a parking lot parking headway distribution.

Parameters:

​	[ in ] param: Parameters of the parking headway distribution.

**def removeParkingTimeDis(self, id: int) -> None**

​	Remove a parking lot parking headway distribution.

Parameters:

​	[ in ] ID: ID of the parking headway distribution.

**def updateParkingTimeDis(self, param: Online.ParkingLot.DynaParkingTimeDis) -> Online.ParkingLot.DynaParkingTimeDis**

Update the parking lot parking time interval distribution.

Parameters:

​	[ in ] param: Parameters of the parking headway distribution.

#### 3.3.2.40. Parking Area

**def parkingRegions(self) -> list[Tessng.IParkingRegion]**

Retrieve the sequence of all parking areas.

**def findParkingRegion(self, id: int) -> Tessng.IParkingRegion**

Retrieve a parking area by its ID.

**def createParkingRegion(self, param: Online.ParkingLot.DynaParkingRegion) -> Tessng.IParkingRegion**

Create a parking area.

Parameters:

[ in ] param: dynamic parking area information.

**def removeParkingRegion(self, pIParkingRegion: Tessng.IParkingRegion) -> None**

Remove a parking area.

Parameters:

[ in ] pIParkingRegion: parking area object.

**def removeParkingRegionByID(self, id: int) -> None**

Remove a parking area by its ID.

Parameters:

[ in ] ID: parking area ID.

**def updateParkingRegion(self, param: Online.ParkingLot.DynaParkingRegion) -> Tessng.IParkingRegion**

Update a parking area.

Parameters:

[ in ] param: dynamic parking area information.

#### 3.3.2.41. Parking Route Decision Point

**def parkingDecisionPoints(self) -> list[Tessng.IParkingDecisionPoint]**

Retrieve the sequence of all parking route decision points.

**def findParkingDecisionPoint(self, id: int) -> Tessng.IParkingDecisionPoint**

Obtain the parking route decision point object by parking route decision point ID.

**def createParkingDecisionPoint(self, pLink: Tessng.ILink, distance: float, name: str = "") -> Tessng.IParkingDecisionPoint**

Create a parking route decision point.

Parameters:

[ in ] pLink: The Road Segment where the Decision Point is located.

[ in ] distance: The distance from the start of the Road Segment to the Decision Point. Unit: pixel.

[ in ] name: Decision point name.

**def removeParkingDecisionPoint(self, pIParkingDecisionPoint: Tessng.IParkingDecisionPoint) -> None**

Remove a parking route decision point.

Parameters:

[ in ] pIParkingDecisionPoint: Parking route decision point object.

**def removeParkingDecisionPointByID(self, id: int) -> None**

Remove a parking route decision point by ID.

Parameters:

[ in ] ID: Parking route decision point ID.

#### 3.3.2.42. Parking Route

**def createParkingRouting(self, pDeciPoint: Tessng.IParkingDecisionPoint, pIParkingRegion: Tessng.IParkingRegion) -> Tessng.IParkingRouting**

Create a parking route.

Parameters:

[ in ] pDeciPoint: Parking decision point.

[ in ] pIParkingRegion: Parking region.

**def removeParkingRouting(self, pIParkingRouting: Tessng.IParkingRouting) -> None**

Remove a parking route.

Parameters:

[ in ] pIParkingRouting: Parking route object.

**def removeParkingRoutingByID(self, id: int) -> None**

Remove a parking route by its parking route ID.

Parameters:

[ in ] ID: Parking decision point ID.

#### 3.3.2.43. Toll Station Parking Headway Distribution

**def tollParkingTimeDis(self) -> list[Online.TollStation.DynaTollParkingTimeDis]**

Retrieve the sequence of toll station parking headway distributions.

**def createTollParkingTimeDis(self, param: Online.TollStation.DynaTollParkingTimeDis) -> Online.TollStation.DynaTollParkingTimeDis**

Create a toll station parking headway distribution.

Parameters:

​	[ in ] param: Parameters of the parking headway distribution.

**def removeTollParkingTimeDis(self, id: int) -> None**

Remove a toll station parking headway distribution.

Parameters:

​	[ in ] ID: ID of the parking headway distribution.

**def updateTollParkingTimeDis(self, param: Online.TollStation.DynaTollParkingTimeDis) -> Online.TollStation.DynaTollParkingTimeDis**

Update a toll station parking headway distribution.

Parameters:

​	[ in ] param: Parameters of the parking headway distribution.

#### 3.3.2.44. Toll Lane

**def tollLanes(self) -> list[Tessng.ITollLane]**

Retrieve the sequence of all toll lane objects.

**def findTollLane(self, id: int) -> Tessng.ITollLane**

Retrieve a toll lane object by its toll lane ID.

**def createTollLane(self, param: Online.TollStation.DynaTollLane) -> Tessng.ITollLane**

Create a toll lane.

Parameters:

[ in ] param: Dynamic toll lane information.

**def removeTollLane(self, pITollLane: Tessng.ITollLane) -> None**

Remove a toll lane.

Parameters:

[ in ] pITollLane: Toll lane object.

**def removeTollLaneByID(self, id: int) -> None**

Remove the toll lane by Lane ID.

Parameters:

[ in ] ID: Toll Lane ID.

**def updateTollLane(self, param: Online.TollStation.DynaTollLane) -> Tessng.ITollLane**

Update the toll lane.

Parameters:

[ in ] param: Dynamic toll lane information.

#### 3.3.2.45. Toll Route Decision Point

**def tollDecisionPoints(self) -> list[Tessng.ITollDecisionPoint]**

Retrieve the list of all toll route decision points.

**def findTollDecisionPoint(self, id: int) -> Tessng.ITollDecisionPoint**

Retrieve the toll route decision point by ID.

**def createTollDecisionPoint(self, pLink: Tessng.ILink, distance: float, name: str = "") -> Tessng.ITollDecisionPoint**

Create a toll route decision point.

Parameters:

[ in ] pLink: Road segment where the decision point is located.

[ in ] distance: The distance from the start of the Road Segment to the Decision Point. Unit: pixel.

[ in ] name: Decision point name.

**def removeTollDecisionPoint(self, pITollDecisionPoint: Tessng.ITollDecisionPoint) -> None**

Remove the toll route decision point.

Parameters:

[ in ] pITollLane: Toll route decision point object.

**def removeTollDecisionPointByID(self, id: int) -> None**

Remove the toll route decision point by ID.

Parameters:

[ in ] ID: Toll route decision point ID.

#### 3.3.2.46. Toll Route

**def createTollRouting(self, pDeciPoint: Tessng.ITollDecisionPoint, pITollLane: Tessng.ITollLane) -> Tessng.ITollRouting**

Create a toll route.

Parameters:

[ in ] pDeciPoint: Toll decision point.

[ in ] pITollLane: Toll lane.

**def removeTollRouting(self, pITollRouting: Tessng.ITollRouting) -> None**

Remove a toll route.

Parameters:

[ in ] pITollRouting: Toll route object.

**def removeTollRoutingByID(self, id: int) -> None**

Remove a toll route by ID.

Parameters:

[ in ] ID: Toll route ID.

#### 3.3.2.47. Node

**def getAllJunctions(self) -> dict[int, Tessng.IJunction]**

Retrieve all node object sequences.

**def findJunction(self, junctionId: int) -> Tessng.IJunction**

Retrieve a node object by ID.

**def createJunction(self, startPoint: PySide2.QtCore.QPointF, endPoint: PySide2.QtCore.QPointF, name: str) -> Tessng.IJunction**

Create a node.

Parameters:

[ in ] startPoint: Coordinates of the top-left starting point.

[ in ] endPoint: Coordinates of the bottom-right end point.

[ in ] name: Node name.

Return:

Node object.

**def removeJunction(self, junctionId: int) -> bool**

Delete a node.

Parameters:

[ in ] junctionID: Node ID.

Return:

Indicates whether the removal was successful.

**def updateJunctionName(self, junctionId: int, name: str) -> bool**

Update node name.

Parameters:

[ in ] junctionID: Node ID.

[ in ] name: New node name.

**def getJunctionFlows(self, junctionId: int) -> dict[int, dict[int, Online.Junction.FlowTurning]]**

Retrieve node turning movement information.

Parameters:

[ in ] junctionID: Node ID.

Return:

Mapping table of node turning movement information.

**def updateFlow(self, timeId: int, junctionId: int, turningId: int, inputFlowValue: int) -> bool**

Update turning movement flow.

Parameters:

[ in ] timeID: Time period ID.

[ in ] junctionID: Node ID.

[ in ] turningID: Turning movement ID.

[ in ] inputFlowValue: Input flow value (veh/h).

Return:

Indicates whether the update was successful.

**def updateFlowAlgorithmParams(self, theta: float, bpra: float, bprb: float, maxIterateNum: int, useNewPath: bool) -> bool**

Update flow algorithm parameters.

Parameters:

[ in ] theta: Parameter θ (0.01–1).

[ in ] bpra: BPR link resistance parameter A (0.05–0.5).

[ in ] bprb: BPR link resistance parameter B (1–10).

[ in ] maxIterateNum: Maximum number of iterations (1–5000).

[ in ] useNewPath: Whether to reconstruct static paths.

Return:

Indicates whether the update was successful.

**def updatePathBuildParams(self, deciPointPosFlag: bool, laneConnectorFlag: bool, minPathNum: int = 3) -> bool**

Update route construction parameters.

Parameters:

[ in ] deciPointPosFlag: Whether to consider the decision point position.

[ in ] laneConnectorFlag: Whether to consider lane connections.

[ in ] minPathNum: Minimum number of routes (default: 3).

Return:

Indicates whether the update was successful.

**def buildAndApplyPaths(self) -> dict[tuple[int, int], list[list[Tessng.ILink]]]**

Construct and apply routes.

Return:

Mapping table of route result information.

**def calculateFlows(self) -> dict[int, list[Online.Junction.FlowTurning]]**

Calculate and apply flow results.

Return:

Mapping table from time period ID to flow calculation results.

#### 3.3.2.48. Node Time Period

**def getFlowTimeIntervals(self) -> list[Online.Junction.FlowTimeInterval]**

Obtain all node time periods.

**def addFlowTimeInterval(self) -> Online.Junction.FlowTimeInterval**

Add a node time period.

Return:

Node time period information.

**def deleteFlowTimeInterval(self, timeId: int) -> bool**

Delete a node time period.

Parameters:

[ in ] timeID: Node time period ID.

Return:

Indicates whether deletion was successful.

**def updateFlowTimeInterval(self, timeId: int, startTime: int, endTime: int) -> Online.Junction.FlowTimeInterval**

Update time period.

Parameters:

[ in ] timeID: Node time period ID.

[ in ] startTime: Start time. Unit: s.

[ in ] endTime: End Time. Unit: s.

### 3.3.3. Simulation Interface (SimuInterface)

SimuInterface is a sub-interface of TessInterface. This interface enables starting, pausing, and stopping the simulation. It allows setting the simulation accuracy, retrieving vehicle objects and vehicle states during the simulation process, as well as obtaining sample and aggregated data detected by various detectors.

#### 3.3.3.1. Simulation Configuration

**def simuIntervalScheming(self) -> int**

Get simulation duration. Unit: s.

**def setSimuIntervalScheming(self, interval: int) -> None**

Set simulation duration. A value of 0 indicates no time limit. Unit: s.

**def simuAccuracy(self) -> int**

Get simulation accuracy.

**def setSimuAccuracy(self, accuracy: int) -> None**

Set simulation accuracy, i.e., the number of computations per second.

**def acceMultiples(self) -> int**

Get simulation acceleration factor.

**def setAcceMultiples(self, multiples: int) -> None**

Set the simulation acceleration factor.


**def byCpuTime(self) -> bool**

Specify whether the simulation time is determined by real time. Within a single computation cycle, there are two types of time: the elapsed real time and the simulation time determined by simulation accuracy. For example, if the simulation accuracy is 20 steps per second, one simulation step corresponds to 50 milliseconds of simulation time. By default, the simulation time for each computation cycle is determined by the simulation accuracy. During online simulation, if computing power is insufficient, a time discrepancy may exist between the simulation time based on simulation accuracy and real time.

**def setByCpuTime(self, bByCpuTime: bool) -> None**

Set whether simulation time is determined by real time. If set to True, the elapsed real time of each simulation cycle is used as the simulation time, ensuring synchronization between simulation time and real time.

**def isRecordTrace(self) -> bool**

Get whether vehicle trajectory recording is enabled.

**def setIsRecordTrace(self, bRecord: bool) -> None**

Set whether to enable vehicle trajectory recording.

**def setThreadCount(self, count: int) -> None**

Set the number of working threads.

**def batchNumber(self) -> int**

Get the current simulation batch.

**def batchIntervalReally(self) -> float**

Get the actual time of the current batch. Unit: ms.

**def simuTimeIntervalWithAcceMutiples(self) -> int**

Get the current simulated time. Unit: ms.

**def startMSecsSinceEpoch(self) -> int**

Get the real-world start time of the simulation. Unit: ms.

**def stopMSecsSinceEpoch(self) -> int**

Get the real-world end time of the simulation. Unit: ms.

#### 3.3.3.2. Simulation Status

**def isRunning(self) -> bool**

Get whether the simulation is currently running.

**def isPausing(self) -> bool**

Get whether the simulation is currently paused.

**def startSimu(self) -> None**

Start the simulation.

**def pauseSimu(self) -> None**

Pause the simulation.

**def stopSimu(self) -> None**

Stop the simulation.

**def pauseSimuOrNot(self) -> None**

Pause or resume the simulation. If the simulation is currently running, this method pauses it; if it is paused, this method resumes it.

#### 3.3.3.3.Vehicle

**def vehiCountTotal(self) -> int**

Retrieve the total number of vehicles, including those created but not yet entered into the road network, vehicles currently running, and vehicles that have exited the road network.

**def vehiCountRunning(self) -> int**

Retrieve the number of vehicles currently running at the current time.

**def getVehicle(self, vehiId: int) -> Tessng.IVehicle**

Retrieve the vehicle object by Vehicle ID.

**def allVehicle(self) -> list[Tessng.IVehicle]**

Retrieve the sequence of all vehicle objects.

**def allVehiStarted(self) -> list[Tessng.IVehicle]**

Retrieve the sequence of all vehicles currently running at the current time.

Example:

```python
from tessng import UnitOfMeasure

# Retrieve the list of vehicles currently running
all_vehicles = self.simuiface.allVehiStarted()
for vehicle in all_vehicles:
    print(f"Vehicle current abscissa: {vehicle.pos(UnitOfMeasure.Metric).x()} m")
    print(f"Vehicle current ordinate: {vehicle.pos(UnitOfMeasure.Metric).y()} m")
    print(f"Vehicle current elevation: {vehicle.v3z()()} m")
    print(f"Vehicle current road ID: {vehicle.roadId()}")
    print(f"Vehicle current road name: {vehicle.roadName()}")
    print(f"Vehicle is on link: {vehicle.roadIsLink()}")
    print(f"Vehicle current lane ID: {vehicle.laneId()}")
    if vehicle.roadIsLink():
        print(f"Vehicle current lane number: {vehicle.vehicleDriving().laneNumber()}")
    print(f"Vehicle distance to lane start point: {vehicle.vehicleDriving().distToStartPoint(True, True, UnitOfMeasure.Metric)} m")

    print(f"Vehicle current speed: {vehicle.currSpeed(UnitOfMeasure.Metric) * 3.6} km/h")
    print(f"Vehicle current desired speed: {vehicle.vehicleDriving().desirSpeed(UnitOfMeasure.Metric) * 3.6} km/h")
    print(f"Vehicle current acceleration: {vehicle.acce(UnitOfMeasure.Metric)} m/s²")
    print(f"Vehicle current heading angle: {vehicle.angle()} °")
```

**def vehisInLink(self, linkId: int) -> list[Tessng.IVehicle]**

Retrieve the sequence of vehicle objects on the specified Road Segment ID at the current time.

**def vehisInLane(self, laneId: int) -> list[Tessng.IVehicle]**

Retrieve the sequence of vehicle objects on the specified Lane ID at the current time.

**def vehisInConnector(self, connectorId: int) -> list[Tessng.IVehicle]**

Retrieve the sequence of vehicle objects on the specified Connector Segment ID at the current time.

**def vehisInLaneConnector(self, connectorId: int, fromLaneId: int, toLaneId: int) -> list[Tessng.IVehicle]**

Retrieve the sequence of vehicle objects on the lane connection specified by Connector Segment ID, upstream Lane ID, and downstream Lane ID at the current time.

Parameters:

​	[ in ] connectorID: Connector Segment ID.

​	[ in ] fromLaneID: Upstream Lane ID.

​	[ in ] toLaneID: Downstream Lane ID.

Return:

​	Sequence of vehicle objects.

**def getVehisStatus(self, batchNumber: int = 0, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[Online.VehicleStatus]**

​	Retrieve the status of all vehicles currently running.

Parameters:

​	[ in ] batchNumber: Batch number.

Return:

​	Sequence of vehicle statuses.

**def getVehiTrace(self, vehiId: int, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[Online.VehiclePosition]**

​	Retrieve the operation trajectory of a specified vehicle. Unit: pixel.

Parameters:

​	[ in ] vehiID: Vehicle ID.

Return:

​	Sequence of vehicle trajectory points.

**def createGVehicle(self, dynaVehi: Online.DynaVehiParam) -> Tessng.IVehicle**

​	Create a vehicle.

Parameters:

​	[ in ] dynaVehi: Dynamic vehicle information.

Return:

​	Vehicle object.

```python
from tessng import Online, m2p

# Create vehicle on Road Segment
# Construction Parameters
dvp1 = Online.DynaVehiParam()
# Vehicle type ID
dvp1.vehiTypeCode = 1
# Road Segment ID
dvp1.roadId = 4
# Lane Index
dvp1.laneNumber = 0
# Position, Unit: m
dvp1.dist = m2p(50)
# Speed, Unit: m/s
dvp1.speed = m2p(20)
# Color
dvp1.color = "#00AFF0"
# Dynamically create vehicle
vehicle1 = self.simuiface.createGVehicle(dvp)
if vehicle1:
    print(f"Vehicle created on link, ID: {vehicle1.id()}")

# Create vehicle on connector segment
# Construction Parameters
dvp2 = Online.DynaVehiParam()
# Vehicle type ID
dvp2.vehiTypeCode = 1
# Connector Segment ID
dvp2.roadId = 4
# Upstream road segment lane index
dvp2.laneNumber = 0
# Downstream road segment lane index
dvp2.toLaneNumber = 0
# Position, Unit: m
dvp2.dist = m2p(10)
# Speed, Unit: m/s
dvp2.speed = m2p(20)
# Color
dvp2.color = "#00AFF0"
# Dynamically create vehicle
vehicle2 = self.simuiface.createGVehicle(dvp2)
if vehicle2:
    print(f"Vehicle created on connector, ID: {vehicle2.id()}")
```

**def createBus(self, pBusLine: Tessng.IBusLine, startSimuDateTime: float) -> Tessng.IVehicle**

Create bus.

Parameters:

[ in ] pBusLine: bus route object.

[ in ] startSimuDateTime: Departure time. Unit: ms.

#### 3.3.3.4. Pedestrians

**def allPedestrianStarted(self) -> list[Tessng.IPedestrian]**

Retrieve the sequence of all currently active pedestrian objects.

**def getPedestriansStatusByRegionID(self, regionId: int) -> list[Online.Pedestrian.PedestrianStatus]**

Obtain status information of all pedestrians within the surface area at the current time by Pedestrian Surface Area ID.

Parameters:

[ in ] regionID: Polygon ID.

Return:

Sequence of pedestrian status information.

#### 3.3.3.5. Traffic Signals

**def getSignalPhasesColor(self) -> list[Online.SignalPhaseColor]**

Obtain the colors of all traffic control phases at the current time.

Return:

Sequence of phase colors.

Example:

```python
all_signal_phase_color = self.simuiface.getSignalPhasesColor()
for signal_phase_color in all_signal_phase_color:
    print(f"Signal Group ID: {signal_phase_color.signalGroupId}")
    print(f"Signal Phase ID: {signal_phase_color.phaseId}")
    print(f"Signal Phase Number: {signal_phase_color.phaseNumber}")
    print(f"Current Color: {signal_phase_color.color}")
    print(f"Current Color Set Time (ms): {signal_phase_color.mrIntervalSetted}")
    print(f"Current Color Duration (ms): {signal_phase_color.mrIntervalByNow}")
```

#### 3.3.3.6. Data Collector

**def getVehisInfoCollected(self) -> list[Online.VehiInfoCollected]**

Retrieve all vehicle information that has passed the data collector at the current time.

Example:

```python
all_vehi_info_collected = self.simuiface.getVehisInfoCollected()
for vehi_info in all_vehi_info_collected:
    print(f"Collector ID: {vehi_info.collectorId}")
    print(f"Simulation Time (s): {vehi_info.simuInterval}")
    print(f"Vehicle ID: {vehi_info.vehiId}")
```

**def getVehisInfoAggregated(self) -> list[Online.VehiInfoAggregated]**

Retrieve aggregated data collected by the data collector during the most recent aggregation period.

Example:

```python
all_vehi_info_aggregated = self.simuiface.getVehisInfoAggregated()
for vehi_info_agg in all_vehi_info_aggregated:
    print(f"Collector ID: {vehi_info_agg.collectorId}")
    print(f"Time Period ID: {vehi_info_agg.timeId}")
    print(f"Start Time (s): {vehi_info_agg.fromTime}")
    print(f"End Time (s): {vehi_info_agg.toTime}")
    print(f"Vehicle Count (veh): {vehi_info_agg.vehiCount}")
    print(f"Average Speed (km/h): {vehi_info_agg.avgSpeed}")
    print(f"Average Occupancy: {vehi_info_agg.occupancy}")
```

#### 3.3.3.7. Queue Counter

**def getVehisQueueCounted(self) -> list[Online.VehiQueueCounted]**

Retrieve vehicle queue information counted by the queue counter at the current time.

Example:

```python
all_vehi_queue_counted = self.simuiface.getVehisQueueCounted()
for vehi_queue in all_vehi_queue_counted:
    print(f"Counter ID: {vehi_queue.counterId}")
    print(f"Simulation Time (s): {vehi_queue.simuTime}")
    print(f"Queued Vehicle Count (veh): {vehi_queue.vehiCount}")
    print(f"Queue Length (m): {vehi_queue.queueLength}")
```

**def getVehisQueueAggregated(self) -> list[Online.VehiQueueAggregated]**

Retrieve aggregated data collected by the queue counter during the most recent aggregation period.

Example:

```python
all_vehi_queue_aggregated = self.simuiface.getVehisQueueAggregated()
for vehi_queue_agg in all_vehi_queue_aggregated:
    print(f"Counter ID: {vehi_queue_agg.counterId}")
    print(f"Time Period ID: {vehi_queue_agg.timeId}")
    print(f"Start Time (s): {vehi_queue_agg.fromTime}")
    print(f"End Time (s): {vehi_queue_agg.toTime}")
    print(f"Average Queued Vehicle Count (veh): {vehi_queue_agg.avgVehiCount}")
    print(f"Average Queue Length (m): {vehi_queue_agg.avgQueueLength}")
    print(f"Maximum Queue Length (m): {vehi_queue_agg.maxQueueLength}")
    print(f"Minimum Queue Length (m): {vehi_queue_agg.minQueueLength}")
```

**def queueRecently(self, queueCounterId: int, queueLength: float, vehiCount: int, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

Specify the most recent queue length and the number of queued vehicles for the queue counter.

Parameters:

[ in ] queueCounterID: Queue counter ID.

[ out ] queueLength: Queue length.

[ out ] vehiCount: Number of queued vehicles.

Return:

Indicates whether the retrieval was successful.

#### 3.3.3.8. Travel Time Detector

**def getVehisTravelDetected(self) -> list[Online.VehiTravelDetected]**

Retrieve the trip time detection information completed by the current time trip time detector.

Example:

```python
all_vehi_travel_detected = self.simuiface.getVehisTravelDetected()
for vehi_travel in all_vehi_travel_detected:
    print(f"Detector ID: {vehi_travel.detectedId}")
    print(f"Vehicle ID: {vehi_travel.vehiId}")
    print(f"Travel Time (s): {vehi_travel.travelTime}")
    print(f"Travel Distance (m): {vehi_travel.travelDistance}")
    print(f"Delay (s): {vehi_travel.delay}")
```

**def getVehisTravelAggregated(self) -> list[Online.VehiTravelAggregated]**

Retrieve the aggregated data collected by the trip time detector during the most recent aggregation period.

Example:

```python
all_vehi_travel_aggregated = self.simuiface.getVehisTravelAggregated()
for vehi_travel_agg in all_vehi_travel_aggregated:
    print(f"Detector ID: {vehi_travel_agg.detectedId}")
    print(f"Time Period ID: {vehi_travel_agg.timeId}")
    print(f"Start Time (s): {vehi_travel_agg.fromTime}")
    print(f"End Time (s): {vehi_travel_agg.toTime}")
    print(f"Vehicle Count: {vehi_travel_agg.vehiCount}")
    print(f"Average Travel Time (s): {vehi_travel_agg.avgTravelTime}")
    print(f"Average Travel Distance (m): {vehi_travel_agg.avgTravelDistance}")
    print(f"Average Delay (s): {vehi_travel_agg.avgDelay}")
```

### 3.3.4. GuiInterface

GuiInterface is a sub-interface of TessInterface. Through this interface, users can access and control TESSNG's main window, menu bar, toolbar, and status bar, allowing them to create menus and customize forms on the main window.

#### 3.3.4.1. Window

**def mainWindow(self) -> PySide2.QtWidgets.QMainWindow**

Retrieve the main window of TESSNG.

#### 3.3.4.2. Menu Bar

**def menuBar(self) -> PySide2.QtWidgets.QMenuBar**

Retrieve the menu bar container of TESSNG.


#### 3.3.4.3. Toolbar

**def addToolBar(self, name: str) -> PySide2.QtWidgets.QToolBar**

Added a custom toolbar.

Parameters:

[ in ] name: Toolbar Name.

Return:

Toolbar Object.

**def insertToolBar(self, before: PySide2.QtWidgets.QToolBar, name: str) -> PySide2.QtWidgets.QToolBar**

Insert a new toolbar before the specified toolbar.

Parameters:

[ in ] before: The existing toolbar before which the new toolbar will be inserted.

[ in ] name: Toolbar Name.

Return:

Toolbar Object.



## 3.4. Objects

Objects in TESS NG are divided into **Road Network Objects** and **Simulation Objects**. Road network objects include road segments, connector segments, etc., while simulation objects include vehicles and pedestrians.

### 3.4.1. Road Network

#### 3.4.1.1. Road Network (IRoadNet)

Basic road network interface. This interface is designed to preserve the attributes of externally imported road networks in TESS NG, such as the road network’s center point coordinates and geodetic coordinates.

**def id(self) -> int**

Retrieve the Road Network ID, corresponding to the number in the road network editing dialog.

**def netName(self) -> str**

Retrieve the Road Network Name.

**def url(self) -> str**

Source data path, which may be a local file or a network address.

**def type(self) -> str**

Source classification: "TESSNG" denotes native TESSNG data; "OpenDrive" denotes data imported from OpenDrive; "GeoJson" denotes data imported from GeoJson.

**def bkgUrl(self) -> str**

Retrieve the background path.

**def explain(self) -> str**

Retrieve the Road Network description.

**def otherAttrs(self) -> dict**

Other attribute JSON data.

**def centerPoint(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

Retrieve the Road Network center point location. Unit: pixel.

#### 3.4.1.2. Base Class for Roads (ISection)

The Road base class serves as the parent class for Road Segments and Connector Segments.

**def gtype(self) -> int**

Type, either GLinkType or GConnectorType. GLinkType represents Road Segments; GConnectorType represents Connector Segments.

**def isLink(self) -> bool**

Indicates whether it is a Road Segment.

**def id(self) -> int**

Get ID: if it is a Link, the ID is the Link's ID; if it is a Connector Segment, the ID is the Connector Segment ID.

**def sectionId(self) -> int**

Get ID: if it is a Link, the ID is the Link's ID; if it is a Connector Segment, the ID is the Connector Segment ID plus 1. 0000000, thereby distinguishing between Road Segments and Connector Segments.

**def name(self) -> str**

Get Section Name: the name of the Road Segment or Connector Segment.

**def setName(self, name: str) -> None**

Set Section Name.

**def v3z(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get Section Elevation. Unit: pixel.

**def length(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get Section Length. Unit: pixel.

**def laneObjects(self) -> list[Tessng.ILaneObject]**

List of superclass interfaces for Lane and Lane Connection.

**def fromSection(self, id: int) -> Tessng.ISection**

Get upstream Section by ID. If the current section is a Road Segment, an ID of 0 returns None; otherwise, returns the upstream Connector Segment with the specified ID. If the current section is a Connector Segment, an ID of 0 returns the upstream Road Segment; otherwise, returns None.

**def toSection(self, id: int) -> Tessng.ISection**

Get downstream Section by ID. If the current element is a road segment with ID 0, return None; otherwise, return the specified downstream connector segment by ID. If the current element is a connector segment with ID 0, return the downstream road segment; otherwise, return None.

**def setOtherAttr(self, otherAttr: dict) -> None**

Set other attributes of the road segment or connector segment.

**def castToLink(self) -> Tessng.ILink**

Convert to ILink; if the current element is a connector segment, return None.

**def castToConnector(self) -> Tessng.IConnector**

Convert to IConnector; if the current element is a road segment, return None.

**def polygon(self) -> PySide2.QtGui.QPolygonF**

Retrieve the polygon formed by the vertices of the Section's polygonal contour.

#### 3.4.1.3. Road Segment (ILink)

**def gtype(self) -> int**

Type, returns GLinkType.

**def id(self) -> int**

Retrieve the Road Segment ID.

**def length(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the length of the road segment. Unit: pixel.

**def width(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the width of the road segment. Unit: pixel.

**def z(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the elevation of the road segment. Unit: pixel.

**def v3z(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the elevation of the road segment, overriding the ISection method. Unit: pixel.

**def name(self) -> str**

Get the road segment name.

**def setName(self, name: str) -> None**

Set the road segment name.

**def linkType(self) -> str**

Get the road segment type, such as urban primary road, urban secondary road, sidewalk, etc.

**def setType(self, type: str) -> None**

Set the road segment type. There are 10 types: expressway, urban expressway, ramp, urban primary road, secondary road, local street, non-motorized lane, sidewalk, bus-only lane, and shared motor-non-motor vehicle lane.

**def laneCount(self) -> int**

Get the number of lanes.

**def limitSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the road segment speed limit. Unit: km/h.

**def setLimitSpeed(self, speed: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

Set the road segment speed limit. Unit: km/h.

Parameters: 

[ in ] speed: speed limit value.

**def minSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the road segment minimum speed limit. Unit: km/h.

**def lanes(self) -> list[Tessng.ILane]**

Lane interface list.

**def laneObjects(self) -> list[Tessng.ILaneObject]**

Interface list for Lanes and Lane Connections.

**def centerBreakPoints(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

Retrieve the set of breakpoints of the Road Segment Centerline. Unit: pixel.

**def leftBreakPoints(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

Retrieve the set of breakpoints of the left side line of the Road Segment. Unit: pixel.

**def rightBreakPoints(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

Retrieve the set of breakpoints of the right side line of the Road Segment. Unit: pixel.

**def centerBreakPoint3Ds(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

Retrieve the set of 3D breakpoints of the Road Segment Centerline. Unit: pixel.

**def leftBreakPoint3Ds(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

Retrieve the set of 3D breakpoints of the left side line of the Road Segment. Unit: pixel.

**def rightBreakPoint3Ds(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

Retrieve the set of 3D breakpoints of the right side line of the Road Segment. Unit: pixel.

**def fromConnectors(self) -> list[Tessng.IConnector]**

Retrieve the list of upstream Connector Segments.

**def toConnectors(self) -> list[Tessng.IConnector]**

Retrieve the list of downstream Connector Segments.

**def setOtherAttr(self, otherAttr: dict) -> None**

Set additional attributes of the Road Segment.

**def otherAttr(self) -> dict**

Retrieve additional attributes of the Road Segment.

**def setLaneTypes(self, lType: list[str]) -> None**

Set Lane attributes, including types: "Motor Vehicle Lane", "Mixed Motor Vehicle and Non-motor Vehicle Lane", "Non-motor Vehicle Lane", "Bus Exclusive Lane", with lane order from right to left.

**def setLaneOtherAtrrs(self, lAttrs: list[dict]) -> None**

Set other lane attributes.

**def distToStartPoint(self, p: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Distance from a point on the centerline to the start point. Unit: pixel.

Parameters: 

[ in ] p: Current point coordinates.

**def getPointByDist(self, dist: float, outPoint: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

Compute the point obtained by extending forward from the centerline start point by a distance dist. Returns False if the target point is not on the centerline; otherwise, returns True. Unit: pixel.

Parameters: 

[ in ] dist: Distance to extend forward from the centerline start point.

[ out ] outPoint: Point obtained by extending forward from the centerline start point by a distance dist.

Example:

```python
from tessng import UnitOfMeasure

# Obtain the coordinates of a point at a specific distance from the start of the road segment
out_point = QPointF()
result = link.getPointByDist(50, out_point, UnitOfMeasure.Metric)
if result:
    x = out_point.x()
    y = out_point.y()
```

**def getPointAndIndexByDist(self, dist: float, outPoint: PySide2.QtCore.QPointF, outIndex: int, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

Compute the point and segment index obtained by extending forward from the centerline start point by a distance dist. Returns False if the target point is not on the centerline; otherwise, returns True. Unit: pixel.

Parameters: 

[ in ] dist: Distance to extend forward from the centerline start point.

[ out ] outPoint: Point obtained by extending forward from the centerline start point by a distance dist.

[ out ] outIndex: The segment index at the position obtained by extending forward from the centerline start point by a distance of dist.

**def polygon(self) -> PySide2.QtGui.QPolygonF**

Retrieve the polygonal contour vertices of the Road Segment.

#### 3.4.1.4. Connector Segment (IConnector)

**def gtype(self) -> int**

Type: the connector segment type is GConnectorType.

**def id(self) -> int**

Retrieve the Connector Segment ID.

**def length(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the Connector Segment length. Unit: pixel.

**def z(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the Connector Segment elevation. Unit: pixel.

**def v3z(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the Connector Segment elevation. Unit: pixel.

**def name(self) -> str**

Retrieve the Connector Segment name.

**def setName(self, name: str) -> None**

Set the Connector Segment name.

**def fromLink(self) -> Tessng.ILink**

Retrieve the starting Road Segment.

**def toLink(self) -> Tessng.ILink**

Retrieve the target Road Segment.

**def limitSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the Connector Segment maximum speed limit. Unit: km/h.

**def minSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the Connector Segment minimum speed limit. Unit: km/h.

**def laneConnectors(self) -> list[Tessng.ILaneConnector]**

Retrieve the list of Lane Connections.

**def laneObjects(self) -> list[Tessng.ILaneObject]**

Interface list for Lanes and Lane Connections.

**def setLaneConnectorOtherAtrrs(self, lAttrs: list[dict]) -> None**

Set additional properties of the contained Lane Connections.

**def setOtherAttr(self, otherAttr: dict) -> None**

Set other attributes of the Connector Segment.

**def polygon(self) -> PySide2.QtGui.QPolygonF**

Retrieve the polygonal contour vertices of the Connector Segment.

#### 3.4.1.5. Lane Base Class (ILaneObject)

The Lane base class serves as the parent class for both Lane and Lane Connection.

**def gtype(self) -> int**

Type: GLaneType or GLaneConnectorType.

**def isLane(self) -> bool**

Indicates whether it is a Lane.

**def id(self) -> int**

Retrieve the ID: if it is a Lane, the ID corresponds to the Lane's ID; if it is a Lane Connection, the ID corresponds to the Lane Connection's ID.

**def length(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the Length. Unit: pixel.

**def section(self) -> Tessng.ISection**

Retrieve the associated ISection.

**def fromLaneObject(self, id: int) -> Tessng.ILaneObject**

Retrieve the upstream LaneObject by ID. If currently a Lane, an ID of 0 returns None; otherwise, returns the upstream Lane Connection with the specified ID. If currently a Connector Segment, an ID of 0 returns the upstream Lane; otherwise, returns None.

**def toLaneObject(self, id: int) -> Tessng.ILaneObject**

Retrieve the downstream LaneObject by ID. If the current object is a lane, returns None when id is 0; otherwise, returns the downstream lane connection with the specified ID. If the current object is a connector segment, returns the downstream lane when id is 0; otherwise, returns None.

**def centerBreakPoints(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

Retrieve the centerline breakpoint set. Unit: pixel.

**def leftBreakPoints(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

Retrieve the left boundary line breakpoint set. Unit: pixel.

**def rightBreakPoints(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

Retrieve the right boundary line breakpoint set. Unit: pixel.

**def centerBreakPoint3Ds(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

Retrieve the 3D centerline breakpoint set. Unit: pixel.

**def leftBreakPoint3Ds(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

Retrieve the 3D left boundary line breakpoint set. Unit: pixel.

**def rightBreakPoint3Ds(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

Retrieve the 3D right boundary line breakpoint set. Unit: pixel.

**def leftBreak3DsPartly(self, fromPoint: PySide2.QtCore.QPointF, toPoint: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

Retrieve the 3D partial left boundary breakpoint set. Unit: pixel.

Parameters: 

[ in ] fromPoint: a point on the centerline as the start point.

[ in ] toPoint: A point on the centerline serving as the end point.

**def rightBreak3DsPartly(self, fromPoint: PySide2.QtCore.QPointF, toPoint: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

Retrieve the 3D breakpoint set on the right side. Unit: pixel.

Parameters: 

[ in ] fromPoint: a point on the centerline as the start point.

[ in ] toPoint: A point on the centerline serving as the end point.

**def distToStartPoint(self, p: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Distance from a point on the centerline to the start point. Unit: pixel.

Parameters: 

[ in ] p: Current point coordinates.

**def distToStartPointWithSegmIndex(self, p: PySide2.QtCore.QPointF, segmIndex: int = 0, bOnCentLine: bool = True, unit: UnitOfMeasure = UnitOfMeasure: : Default) -> float**

Distance from a point on the centerline to the start point, with the additional condition of the segment index on the lane to which the point belongs. Unit: pixel.

Parameters: 

[ in ] p: Current point coordinates.

[ in ] segmIndex: The segment index on the lane where the point is located.

[ in ] bOnCentLine: Indicates whether the point is on the centerline.

**def getPointAndIndexByDist(self, dist: float, outPoint: PySide2.QtCore.QPointF, outIndex: int, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

Compute the point and segment index obtained by extending forward from the centerline start point by a distance dist. Returns False if the target point is not on the centerline; otherwise, returns True. Unit: pixel.

Parameters: 

[ in ] dist: Distance to extend forward from the centerline start point.

[ out ] outPoint: Point obtained by extending forward from the centerline start point by a distance dist.

[ out ] outIndex: The segment index at the position obtained by extending forward from the centerline start point by a distance of dist.

**def getPointByDist(self, dist: float, outPoint: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

Compute the point obtained by extending forward from the centerline start point by a distance dist. Returns False if the target point is not on the centerline; otherwise, returns True. Unit: pixel.

Parameters: 

[ in ] dist: Distance to extend forward from the centerline start point.

[ out ] outPoint: Point obtained by extending forward from the centerline start point by a distance dist.

**def setOtherAttr(self, attr: dict) -> None**

Set other attributes of the lane or lane connection.

**def castToLane(self) -> Tessng.ILane**

Convert ILaneObject to ILane; returns None if the current ILaneObject is a lane connection.

**def castToLaneConnector(self) -> Tessng.ILaneConnector**

Convert ILaneObject to ILaneConnector; returns None if the current ILaneObject is a lane.

#### 3.4.1.6. Lane (ILane)

**def gtype(self) -> int**

Type, lane type is GLaneType.

**def id(self) -> int**

Get Lane ID.

**def link(self) -> Tessng.ILink**

Get the Road Segment to which the lane belongs.

**def section(self) -> Tessng.ISection**

Get the Section to which the lane belongs.

**def length(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get lane Length. Unit: pixel.

**def width(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get lane width. Unit: pixel.

**def number(self) -> int**

Get Lane Index, starting from 0 (from outside to inside, i.e., numbered sequentially from right to left).

**def actionType(self) -> str**

Get the behavioral type of the lane.

**def fromLaneConnectors(self) -> list[Tessng.ILaneConnector]**

Get the list of upstream Lane Connections.

**def toLaneConnectors(self) -> list[Tessng.ILaneConnector]**

Get the list of downstream Lane Connections.

**def centerBreakPoints(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

Get the set of lane centerline breakpoints. Unit: pixel.

**def leftBreakPoints(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

Get the set of lane left boundary breakpoints. Unit: pixel.

**def rightBreakPoints(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

Get the set of lane right boundary breakpoints. Unit: pixel.

**def centerBreakPoint3Ds(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

Get the set of 3D lane centerline breakpoints. Unit: pixel.

**def leftBreakPoint3Ds(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

Obtain the three-dimensional breakpoint set of the lane's left boundary line. Unit: pixel.

**def rightBreakPoint3Ds(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

Obtain the three-dimensional breakpoint set of the lane's right boundary line. Unit: pixel.

**def leftBreak3DsPartly(self, fromPoint: PySide2.QtCore.QPointF, toPoint: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

Retrieve the 3D partial left boundary breakpoint set. Unit: pixel.

Parameters: 

[ in ] fromPoint: a point on the centerline as the start point.

[ in ] toPoint: A point on the centerline serving as the end point.

**def rightBreak3DsPartly(self, fromPoint: PySide2.QtCore.QPointF, toPoint: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

Retrieve the 3D breakpoint set on the right side. Unit: pixel.

Parameters: 

[ in ] fromPoint: a point on the centerline as the start point.

[ in ] toPoint: A point on the centerline serving as the end point.

**def distToStartPoint(self, p: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Distance from a point on the centerline to the start point. Unit: pixel.

Parameters: 

[ in ] p: Current point coordinates.

**def distToStartPointWithSegmIndex(self, p: PySide2.QtCore.QPointF, segmIndex: int = 0, bOnCentLine: bool = True, unit: UnitOfMeasure = UnitOfMeasure: : Default) -> float**

Distance from a point on the centerline to the start point, with the additional condition of the segment index on the lane to which the point belongs. Unit: pixel.

Parameters: 

[ in ] p: Coordinates of the point on the current centerline.

[ in ] segmIndex: The segment index on the lane where the point is located.

[ in ] bOnCentLine: Indicates whether the point is on the centerline.

**def getPointAndIndexByDist(self, dist: float, outPoint: PySide2.QtCore.QPointF, outIndex: int, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

Compute the point and segment index obtained by extending forward from the centerline start point by a distance dist. Returns False if the target point is not on the centerline; otherwise, returns True. Unit: pixel.

Parameters: 

[ in ] dist: Distance to extend forward from the centerline start point.

[ out ] outPoint: Point obtained by extending forward from the centerline start point by a distance dist.

[ out ] outIndex: The segment index at the position obtained by extending forward from the centerline start point by a distance of dist.

**def getPointByDist(self, dist: float, outPoint: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

Compute the point obtained by extending forward from the centerline start point by a distance dist. Returns False if the target point is not on the centerline; otherwise, returns True. Unit: pixel.

Parameters: 

[ in ] dist: Distance to extend forward from the centerline start point.

[ out ] outPoint: Point obtained by extending forward from the centerline start point by a distance dist.

Example:

```python
from tessng import UnitOfMeasure

# Obtain point coordinates at a specified distance from the lane start
out_point = QPointF()
result = lane_obj.getPointByDist(50, out_point, UnitOfMeasure.Metric)
if result:
    x = out_point.x()
    y = out_point.y()
```

**def setOtherAttr(self, attr: dict) -> None**

Set other lane attributes.

**def setLaneType(self, type: str) -> None**

Set the lane type.

Parameters: 

[ in ] type: Lane type, select one of the following: "Motor Vehicle Lane", "Mixed Motor and Non-Motor Lane", "Non-Motor Vehicle Lane", "Exclusive Bus Lane".

Example:

```python
# Set lane type
lane.setLaneType("MotorizedLane")
```

**def polygon(self) -> PySide2.QtGui.QPolygonF**

Obtain the polygonal outline vertices of the lane.

#### 3.4.1.7. Lane Connection (ILaneConnector)

**def gtype(self) -> int**

Type: GLaneType or GLaneConnectorType; lane connector segments are of type GLaneConnectorType.

**def id(self) -> int**

Retrieve Lane Connection ID.

**def connector(self) -> Tessng.IConnector**

Retrieve the Connector Segment associated with the Lane Connection.

**def section(self) -> Tessng.ISection**

Get the Section to which the lane belongs.

**def fromLane(self) -> Tessng.ILane**

Upstream Lane.

**def toLane(self) -> Tessng.ILane**

Downstream Lane.

**def length(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve Lane Connection Length. Unit: pixel.

**def centerBreakPoints(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

Retrieve Lane Connection Centerline Breakpoint Set. Unit: pixel.

**def leftBreakPoints(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

Retrieve Lane Connection Left Boundary Breakpoint Set. Unit: pixel.

**def rightBreakPoints(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

Retrieve Lane Connection Right Boundary Breakpoint Set. Unit: pixel.

**def centerBreakPoint3Ds(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

Retrieve Lane Connection Centerline 3D Breakpoint Set. Unit: pixel.

**def leftBreakPoint3Ds(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

Retrieve Lane Connection Left Boundary 3D Breakpoint Set. Unit: pixel.

**def rightBreakPoint3Ds(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

Retrieve Lane Connection Right Boundary 3D Breakpoint Set. Unit: pixel.

**def leftBreak3DsPartly(self, fromPoint: PySide2.QtCore.QPointF, toPoint: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

Retrieve Partial Left-Side 3D Breakpoint Set of the Lane Connection. Unit: pixel.

Parameters: 

[ in ] fromPoint: a point on the centerline as the start point.

[ in ] toPoint: A point on the centerline serving as the end point.

**def rightBreak3DsPartly(self, fromPoint: PySide2.QtCore.QPointF, toPoint: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtGui.QVector3D]**

Retrieve the three-dimensional breakpoint set of the right section of the Lane Connection. Unit: pixel.

Parameters: 

[ in ] fromPoint: a point on the centerline as the start point.

[ in ] toPoint: A point on the centerline serving as the end point.

**def distToStartPoint(self, p: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Distance from a point on the centerline to the start point. Unit: pixel.

Parameters: 

[ in ] p: Current point coordinates.

**def distToStartPointWithSegmIndex(self, p: PySide2.QtCore.QPointF, segmIndex: int, bOnCentLine: bool, unit: UnitOfMeasure = UnitOfMeasure: : Default) -> float**

Distance from a point on the centerline to the start point, with the additional condition of the segment index on the lane to which the point belongs. Unit: pixel.

Parameters: 

[ in ] p: Current point coordinates.

[ in ] segmIndex: Segment index.

[ in ] bOnCentLine: Indicates whether the point is on the centerline.

**def getPointAndIndexByDist(self, dist: float, outPoint: PySide2.QtCore.QPointF, outIndex: int, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

Compute the point and segment index obtained by extending forward from the centerline start point by a distance dist. Returns False if the target point is not on the centerline; otherwise, returns True. Unit: pixel.

Parameters: 

[ in ] dist: Distance to extend forward from the centerline start point.

[ out ] outPoint: Point obtained by extending forward from the centerline start point by a distance dist.

[ out ] outIndex: The segment index at the position obtained by extending forward from the centerline start point by a distance of dist.

**def getPointByDist(self, dist: float, outPoint: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

Compute the point obtained by extending forward from the centerline start point by a distance dist. Returns False if the target point is not on the centerline; otherwise, returns True. Unit: pixel.

Parameters: 

[ in ] dist: Distance to extend forward from the centerline start point.

[ out ] outPoint: Point obtained by extending forward from the centerline start point by a distance dist.

**def setOtherAttr(self, attr: dict) -> None**

Set other attributes of the Lane Connection.

#### 3.4.1.8. Connector Segment Area (IConnectorArea)

**def id(self) -> int**

Polygon ID, referring to an area formed by overlapping multiple Connectors.

**def allConnector(self) -> list[Tessng.IConnector]**

All Connector Segments related to the Polygon.

**def centerPoint(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

Retrieve the center position of the Polygon. Unit: pixel.

### 3.4.2. Departure Point

#### 3.4.2.1. Departure Point (IDispatchPoint)

**def id(self) -> int**

Retrieve the Departure Point ID.

**def name(self) -> str**

Retrieve the Departure Name.

**def link(self) -> Tessng.ILink**

Retrieve the road segment where the Departure Point is located.

**def addDispatchInterval(self, vehiCompId: int, interval: int, vehiCount: int) -> int**

Add departure interval to the Departure Point.

Parameters: 

[ in ] vehiCompId: Vehicle type composition ID.

[ in ] interval: Time interval. Unit: s.

[ in ] vehiCount: Number of departures.

Return value: 

Departure interval ID.

**def setDynaModified(self, bModified: bool) -> None**

Set whether dynamic modification is enabled. By default, after the departure information is dynamically modified, the entire file cannot be saved to prevent corruption of the original departure settings.

**def polygon(self) -> PySide2.QtGui.QPolygonF**

Retrieve the vertices of the polygonal outline of the departure point.

### 3.4.3. Decision Points and Vehicle Routes

#### 3.4.3.1. Decision Point (IDecisionPoint)

**def id(self) -> int**

Decision point ID.

**def name(self) -> str**

Decision point name.

**def link(self) -> Tessng.ILink**

Road segment where the decision point is located.

**def distance(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the distance from the start of the road segment. Unit: pixel.

**def routings(self) -> list[Tessng.IRouting]**

Associated decision routes.

**def setDynaModified(self, bModified: bool) -> None**

Set whether dynamic modification is enabled. By default, after the departure information is dynamically modified, the entire file cannot be saved to prevent corruption of the original departure settings.

Parameters: 

[ in ] bModified: Indicates whether it has been dynamically modified; True means dynamically modified, False means not.

**def polygon(self) -> PySide2.QtGui.QPolygonF**

Vertices of the decision point polygonal contour.

#### 3.4.3.2. Vehicle Routing (IRouting)

**def id(self) -> int**

Route ID.

**def calcuLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Calculate route length. Unit: pixel.

**def getLinks(self) -> list[Tessng.ILink]**

Obtain the sequence of road segments.

**def deciPointId(self) -> int**

Associated decision point ID.

**def contain(self, pRoad: Tessng.ISection) -> bool**

Determine whether the given road is on the current route.

Parameters: 

[ in ] pRoad: Road segment or connector segment.

**def nextRoad(self, pRoad: Tessng.ISection) -> Tessng.ISection**

Get the next road based on the given road.

Parameters: 

[ in ] pRoad: Road segment or connector segment.

### 3.4.4. Signal Control

#### 3.4.4.1. Signal Controller (ISignalController)

**def id(self) -> int**

Get signal controller ID.

**def name(self) -> str**

Get signal controller name.

**def setName(self, name: str) -> None**

Set the signal controller name.

Parameters: 

[ in ] name: New name.

**def addPlan(self, plan: Tessng.ISignalPlan) -> None**

Add a traffic signal control scheme.

Parameters: 

[ in ] plan: Traffic signal control scheme.

**def removePlan(self, plan: Tessng.ISignalPlan) -> None**

Remove a traffic signal control scheme.

Parameters: 

[ in ] plan: The traffic signal control scheme to remove.

**def plans(self) -> list[Tessng.ISignalPlan]**

Get all traffic signal control schemes.

**def isValid(self) -> bool**

Validate the signal controller.

#### 3.4.4.2. Traffic Signal Control Scheme (ISignalPlan)

**def id(self) -> int**

Get ID.

**def Name(self) -> str**

Get signal group name.

**def trafficName(self) -> str**

Get traffic signal control scheme name.

**def cycleTime(self) -> int**

Get signal cycle. Unit: s.

**def fromTime(self) -> int**

Get start time. Unit: s.

**def toTime(self) -> int**

Get end time. Unit: s.

**def phases(self) -> list[Tessng.ISignalPhase]**

Get phase list.

**def setName(self, name: str) -> None**

Set traffic signal control scheme name.

Parameters: 

[ in ] name: New name.

**def setcycleTime(self, period: int) -> None**

Set signal cycle. Unit: s.

Parameters: 

​	[ in ] period: Traffic signal cycle. Unit: s.

**def setFromTime(self, time: int) -> None**

​	Set start time. Unit: s.

Parameters: 

​	[ in ] time: Start time. Unit: s.

**def setToTime(self, time: int) -> None**

​	Set end time. Unit: s.

Parameters: 

​	[ in ] time: End time. Unit: s.

#### 3.4.4.3. Traffic Signal Phase (ISignalPhase)

**def id(self) -> int**

​	Phase ID.

**def phaseName(self) -> str**

​	Phase Name.

**def listColor(self) -> list[Online.ColorInterval]**

​	Get the list of phase lamp colors.

**def setColorList(self, lColor: list[Online.ColorInterval]) -> None**

​	Set the list of traffic signals.

Parameters: 

​	[ in ] lColor: Lamp color duration information, including traffic signal color and duration.

Example:

```python
# Construct a list of lamp color and duration objects
color_obj_list = [
    Online.ColorInterval("R", 10),   # Red, duration 10
    Online.ColorInterval("G", 60),   # Green, duration 60
    Online.ColorInterval("Y", 3),    # Yellow, duration 3
    Online.ColorInterval("R", 17)    # Red, duration 17
]
# Find the traffic signal phase with ID 7
signal_phase = netiface.findSignalPhase(7)
if signal_phase:
    # Set the list of light colors
	signal_phase.setColorList(color_list)
```

**def cycleTime(self) -> int**

​	Get the phase cycle. Unit: s.

**def phaseColor(self) -> Online.SignalPhaseColor**

​	Get the current phase light color.

**def signalPlan(self) -> Tessng.ISignalPlan**

​	Get the traffic signal control scheme to which the phase belongs.

**def signalLamps(self) -> list[Tessng.ISignalLamp]**

​	Get the list of related traffic signals.

**def setPhaseName(self, name: str) -> None**

​	Set the phase name.

Parameters: 

[ in ] name: New name.

#### 3.4.4.4. Traffic Signal Lamp Head (ISignalLamp)

**def id(self) -> int**

​	Get the traffic signal ID.

**def setSignalPhase(self, pPhase: Tessng.ISignalPhase) -> None**

​	Set the phase; the phase can be one from another traffic signal group.

Parameters: 

​	[ in ] pPhase: phase.

**def setPhaseNumber(self, num: int) -> None**

​	Set the phase index, starting from 1. If the index exceeds the total number of phases, no change will be made.

**def setLampColor(self, colorStr: str) -> None**

​	Set the traffic signal color.

Parameters: 

​	[ in ] colorStr: color expressed as a string; four options are available: "Red", "Green", "Yellow", "Gray", or alternatively "R", "G", "Y", "grey". 

**def color(self) -> str**

Retrieve the traffic signal color, where "R", "G", "Y", and "gray" represent "Red", "Green", "Yellow", and "Gray" respectively.

**def name(self) -> str**

Retrieve the traffic signal name.

**def setName(self, name: str) -> None**

Set the traffic signal name.

**def setDistToStart(self, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

Set the distance of the traffic signal from the start of the Road Segment. Unit: pixel.

Parameters: 

[ in ] dist: distance value.

**def signalPlan(self) -> Tessng.ISignalPlan**

Retrieve the traffic signal control scheme.

**def signalPhase(self) -> Tessng.ISignalPhase**

Retrieve the phase.

**def laneObject(self) -> Tessng.ILaneObject**

Retrieve the associated Lane or Lane Connection.

**def polygon(self) -> PySide2.QtGui.QPolygonF**

Retrieve the vertices of the traffic signal's polygonal contour.

**def angle(self) -> float**

Retrieve the traffic signal angle.

### 3.4.5. Data Collection Devices

#### 3.4.5.1. Data Collector (IVehicleDrivInfoCollector)

**def id(self) -> int**

Retrieve the collector ID.

**def collName(self) -> str**

​	Retrieve the collector name.

**def onLink(self) -> bool**

​	Indicates whether it is on the road segment; if True, connector() returns None.

**def link(self) -> Tessng.ILink**

​	The road segment where the collector is located.

**def connector(self) -> Tessng.IConnector**

​	The connector segment where the collector is located.

**def lane(self) -> Tessng.ILane**

​	Returns the lane if the collector is on the road segment; otherwise, returns None.

**def laneConnector(self) -> Tessng.ILaneConnector**

​	Returns the lane connection if the collector is on the connector segment; otherwise, returns None.

**def distToStart(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

​	Retrieve the distance from the collector to the start of the road segment. Unit: pixel.

**def point(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	Retrieve the position coordinates of the collector. Unit: pixel.

**def fromTime(self) -> int**

​	Collector start operation time. Unit: s.

**def toTime(self) -> int**

​	Collector stop operation time. Unit: s.

**def aggregateInterval(self) -> int**

​	Aggregation data time interval. Unit: s.

**def setName(self, name: str) -> None**

​	Set the collector name.

**def setDistToStart(self, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	Set the distance from the collector to the start of the road segment. Unit: pixel.

Parameters: 

[ in ] dist: distance value.

**def setFromTime(self, time: int) -> None**

Set the collector's working start time. Unit: s.

Parameters: 

[ in ] time: Working start time. Unit: s.

**def setToTime(self, time: int) -> None**

Set the collector's working end time. Unit: s.

Parameters: 

[ in ] time: Working end time. Unit: s.

**def setAggregateInterval(self, interval: int) -> None**

Set the collector's data aggregation interval. Unit: s.

**def polygon(self) -> PySide2.QtGui.QPolygonF**

Get the vertices of the collector's polygonal contour.

#### 3.4.5.2. Vehicle Queue Counter (IVehicleQueueCounter)

**def id(self) -> int**

Get the counter ID.

**def counterName(self) -> str**

Get the counter Name.

**def onLink(self) -> bool**

​	Indicates whether it is on the road segment; if True, connector() returns None.

**def link(self) -> Tessng.ILink**

Road Segment where the counter is located.

**def connector(self) -> Tessng.IConnector**

Connector Segment where the counter is located.

**def lane(self) -> Tessng.ILane**

Return the Lane if the counter is located on a Road Segment; otherwise, return None.

**def laneConnector(self) -> Tessng.ILaneConnector**

Return the Lane Connection if the counter is located on a Connector Segment; otherwise, return None.

**def distToStart(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the distance from the counter to the start of the road segment. Unit: pixel.

**def point(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

Get the coordinates of the counter position. Unit: pixel.

**def fromTime(self) -> int**

Counter operation start time. Unit: s.

**def toTime(self) -> int**

Counter operation stop time. Unit: s.

**def aggregateInterval(self) -> int**

Data aggregation interval of the counter. Unit: s.

**def setName(self, name: str) -> None**

Set the name of the counter.

Parameters: 

[ in ] name: Counter name.

**def setDistToStart(self, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

Set the distance from the counter to the start of the road segment. Unit: pixel.

Parameters: 

[ in ] dist: distance value.

**def setFromTime(self, time: int) -> None**

Set the operation start time. Unit: s.

**def setToTime(self, time: int) -> None**

Set the operation end time. Unit: s.

**def setAggregateInterval(self, interval: int) -> None**

Set the data aggregation interval. Unit: s.

**def polygon(self) -> PySide2.QtGui.QPolygonF**

Get the vertices of the counter’s polygonal outline.

#### 3.4.5.3. Travel Time Detector (IVehicleTravelDetector)

**def id(self) -> int**

Get the detector ID.

**def detectorName(self) -> str**

Get the detector Name.

**def isStartDetector(self) -> bool**

Indicates whether this is the detector start point.

**def isOnLink_startDetector(self) -> bool**

Indicates whether the detector start point is on the Road Segment; if not, the start point is on the Connector Segment.

**def isOnLink_endDetector(self) -> bool**

Indicates whether the detector end point is on the Road Segment; if not, the end point is on the Connector Segment.

**def link_startDetector(self) -> Tessng.ILink**

If the detector start point is on the Road Segment, returns the corresponding Road Segment; otherwise, returns None.

**def laneConnector_startDetector(self) -> Tessng.ILaneConnector**

If the detector start point is on the Connector Segment, returns the corresponding Lane Connection; otherwise, returns None.

**def link_endDetector(self) -> Tessng.ILink**

If the detector end point is on the Road Segment, returns the corresponding Road Segment; otherwise, returns None.

**def laneConnector_endDetector(self) -> Tessng.ILaneConnector**

If the detector end point is on the Connector Segment, returns the corresponding Lane Connection; otherwise, returns None.

**def distance_startDetector(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Gets the distance from the detector start point to the start of the Road Segment. Unit: pixel.

**def distance_endDetector(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the distance from the end detector to the start of the road segment. Unit: pixel.

**def point_startDetector(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

Get the coordinates of the start detector position. Unit: pixel.

**def point_endDetector(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

Get the coordinates of the end detector position. Unit: pixel.

**def fromTime(self) -> int**

Detector start operating time. Unit: s.

**def toTime(self) -> int**

Detector stop operating time. Unit: s.

**def aggregateInterval(self) -> int**

​	Aggregation data time interval. Unit: s.

**def setName(self, name: str) -> None**

Set the detector name.

**def setDistance_startDetector(self, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

Set the distance from the start detector to the start of the road segment. Unit: pixel.

Parameters: 

[ in ] dist: distance value.

**def setDistance_endDetector(self, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

Set the distance from the end detector to the start of the road segment. Unit: pixel.

Parameters: 

[ in ] dist: distance value.

**def setFromTime(self, time: int) -> None**

Set the detector start operating time. Unit: s.

Parameters: 

[ in ] time: Working start time. Unit: s.

**def setToTime(self, time: int) -> None**

Set the detector end operating time. Unit: s.

Parameters: 

[ in ] time: Working end time. Unit: s.

**def setAggregateInterval(self, interval: int) -> None**

Set the detector aggregation data time interval. Unit: s.

Parameters: 

[ in ] interval: Aggregated data time interval. Unit: s.

**def polygon_startDetector(self) -> PySide2.QtGui.QPolygonF**

Obtain the vertices of the polygonal contour at the start point of the travel time detector.

**def polygon_endDetector(self) -> PySide2.QtGui.QPolygonF**

Obtain the vertices of the polygonal contour at the end point of the travel time detector.

### 3.4.6. Guiding Arrows

#### 3.4.6.1. Guiding Arrows (IGuIDArrow)

**def id(self) -> int**

Obtain the ID of the guiding arrow.

**def lane(self) -> Tessng.ILane**

Obtain the lane where the guiding arrow is located.

**def length(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Obtain the length of the guiding arrow. Unit: pixel.

**def distToTerminal(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Obtain the distance from the guiding arrow to the endpoint. Unit: pixel.

**def arrowType(self) -> Online.GuideArrowType**

Obtain the type of the guiding arrow. The types include: straight, left turn, right turn, straight or left turn, straight or right turn, straight left turn or right turn, left turn or right turn, U-turn, straight or U-turn, and left turn or U-turn.

**def polygon(self) -> PySide2.QtGui.QPolygonF**

Retrieve the vertices of the polygonal outline of the guiding arrow.

### 3.4.7. Bus System

#### 3.4.7.1. Bus Route (IBusLine)

**def id(self) -> int**

Retrieve the bus route ID.

**def name(self) -> str**

Route Name.

**def length(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the length of the bus route. Unit: pixel.

**def dispatchFreq(self) -> int**

Departure interval. Unit: s.

**def dispatchStartTime(self) -> int**

Departure start time. Unit: s.

**def dispatchEndTime(self) -> int**

Departure end time. Unit: s.

**def desirSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the desired speed of the bus route. Unit: pixel/s.

**def passCountAtStartTime(self) -> int**

Initial passenger load.

**def links(self) -> list[Tessng.ILink]**

Road segments traversed by the bus route.

**def stations(self) -> list[Tessng.IBusStation]**

All stops on the route.

**def stationLines(self) -> list[Tessng.IBusStationLine]**

Bus stop route, parameters related to passenger boarding and alighting at stops along the current route.

**def setName(self, name: str) -> None**

Set the route name.

**def setDispatchFreq(self, freq: int) -> None**

Set the departure interval for the current bus route. Unit: s.

Parameters: 

[ in ] freq: Departure interval. Unit: s.

**def setDispatchStartTime(self, startTime: int) -> None**

Set the start departure time of the first bus on the current bus route. Unit: s.

Parameters: 

[ in ] startTime: Start departure time. Unit: s.

**def setDispatchEndTime(self, endTime: int) -> None**

Set the end departure time of the last bus on the current bus route. Unit: s.

Parameters: 

[ in ] endTime: End departure time. Unit: s.

**def setDesirSpeed(self, speed: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

Set the desired speed for the current bus route. Unit: pixel/s.

Parameters: 

[ in ] speed: Speed value.

**def setPassCountAtStartTime(self, count: int) -> None**

Set the initial passenger count.

#### 3.4.7.2. Bus Station (IBusStation)

**def id(self) -> int**

Get the bus station ID.

**def name(self) -> str**

Get the bus stop name.

**def laneNumber(self) -> int**

Get the lane index of the bus stop.

**def x(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the stop's X coordinate. Unit: pixel.

**def y(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the stop's Y coordinate. Unit: pixel.

**def length(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the stop length. Unit: pixel.

**def stationType(self) -> int**

Stop type, 1: Curbside, 2: Bay.

**def link(self) -> Tessng.ILink**

Road segment where the bus stop is located.

**def lane(self) -> Tessng.ILane**

Lane where the bus stop is located.

**def distance(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the distance from the stop to the start of the road segment. Unit: pixel.

**def setName(self, name: str) -> None**

Set the stop name.

Parameters: 

[ in ] name: New name.

**def setDistToStart(self, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

Set the distance from the stop to the start of the road segment. Unit: pixel.

Parameters: 

[ in ] dist: distance value.

**def setLength(self, length: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

Set the stop length. Unit: pixel.

Parameters: 

[ in ] length: length value.

**def setType(self, type: int) -> None**

Set the stop type.

Parameters: 

[ in ] type: Station type, 1 Curbside, 2 Bay-type.

**def polygon(self) -> PySide2.QtGui.QPolygonF**

Vertices of the polygonal outline of the bus stop.

#### 3.4.7.3. Bus Station - Route (IBusStationLine)

**def id(self) -> int**

Get the ID of the bus "Station-Route".

**def stationId(self) -> int**

Bus station ID.

**def lineId(self) -> int**

Bus route ID.

**def busParkingTime(self) -> int**

Vehicle dwell time. Unit: s.

**def getOutPercent(self) -> float**

Alighting percentage.

**def getOnTimePerPerson(self) -> float**

Average boarding time per passenger. Unit: s.

**def getOutTimePerPerson(self) -> float**

Average alighting time per passenger. Unit: s.

**def setBusParkingTime(self, time: int) -> None**

Set vehicle dwell time.

Parameters: 

[ in ] time: Vehicle dwell time. Unit: s.

**def setGetOutPercent(self, percent: float) -> None**

​	Set the alighting percentage.

Parameters: 

​	[ in ] percent: Alighting percentage.

**def setGetOnTimePerPerson(self, time: float) -> None**

​	Set the average boarding time per passenger.

Parameters: 

​	[ in ] time: Average boarding time per passenger. Unit: s.

**def setGetOutTimePerPerson(self, time: float) -> None**

​	Set the average alighting time per passenger.

Parameters: 

​	[ in ] time: Average alighting time per passenger. Unit: s.

### 3.4.8. Event Area

#### 3.4.8.1. Accident Zone (IAccidentZone)

**def id(self) -> int**

Get the Accident Zone ID.

**def name(self) -> str**

Get the Accident Zone Name.

**def location(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the distance from the start point of the associated Road Segment to the Accident Zone in the current time period. Unit: pixel.

**def zoneLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the length of the Accident Zone in the current time period. Unit: pixel.

**def limitedSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Obtain the current time limit in the accident area. Unit: Pixel (km/h).

**def section(self) -> Tessng.ISection**

Retrieve the road segment or connector segment where the accident area is located.

**def roadId(self) -> int**

Retrieve the ID of the road segment where the accident area is located.

**def roadType(self) -> str**

Retrieve the road type of the accident area location (road segment or connector segment).

**def laneObjects(self) -> list[Tessng.ILaneObject]**

Retrieve the list of lanes occupied by the accident area during the current time interval.

**def controlLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the control distance of the accident area for the current time interval (vehicles within this distance from the accident area's starting point are required to perform mandatory lane changing). Unit: pixel.

**def addAccidentZoneInterval(self, param: Online.DynaAccidentZoneIntervalParam) -> Tessng.IAccidentZoneInterval**

Add an accident interval.

Parameters: 

[ in ] param: Accident interval parameters.

**def removeAccidentZoneInterval(self, accidentZoneIntervalId: int) -> None**

Remove an accident interval.

Parameters: 

[ in ] accidentZoneIntervalId: Accident interval ID.

**def updateAccidentZoneInterval(self, param: Online.DynaAccidentZoneIntervalParam) -> bool**

Update an accident interval.

Parameters: 

[ in ] param: Accident interval parameters.

**def accidentZoneIntervals(self) -> list[Tessng.IAccidentZoneInterval]**

Retrieve all accident intervals.

**def findAccidentZoneIntervalById(self, accidentZoneIntervalId: int) -> Tessng.IAccidentZoneInterval**

Query accident interval by ID.

Parameters: 

[ in ] accidentZoneIntervalId: Accident interval ID.

**def findAccidentZoneIntervalByStartTime(self, startTime: int) -> Tessng.IAccidentZoneInterval**

Query accident intervals by start time.

Parameters: 

[ in ] startTime: Start time of the accident interval.

#### 3.4.8.2. Accident Zone Interval (IAccidentZoneInterval)

**def intervalId(self) -> int**

Retrieve the accident interval ID.

**def accidentZoneId(self) -> int**

Retrieve the associated accident zone ID.

**def startTime(self) -> int**

Retrieve the accident interval start time.

**def endTime(self) -> int**

Retrieve the accident interval end time.

**def length(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the length of the accident zone during the interval. Unit: pixel.

**def location(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the distance from the start point to the accident zone during the interval. Unit: pixel.

**def limitedSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the speed limit of the accident zone during the interval. Unit: pixel (km/h).

**def controlLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the control distance of the accident zone during the interval (vehicles within this distance from the accident zone start point are required to change lanes). Unit: pixel.

**def laneNumbers(self) -> list[int]**

Get the lane index occupied by the accident area during the specified time period.

#### 3.4.8.3. Construction Zone (IRoadWorkZone)

**def id(self) -> int**

Get the Construction Zone ID.

**def name(self) -> str**

Get the Construction Zone Name.

**def location(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the distance from the Construction Zone to the start point of the road segment. Unit: pixel.

**def zoneLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the Construction Zone length. Unit: pixel.

**def limitSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the Construction Zone speed limit. Unit: pixel (km/h).

**def sectionId(self) -> int**

Get the ID of the road segment or connector segment where the Construction Zone is located.

**def sectionName(self) -> str**

Get the name of the road segment or connector segment where the Construction Zone is located.

**def sectionType(self) -> str**

Get the road type where the Construction Zone is located: link for road segment, connector for connector segment.

**def laneObjects(self) -> list[Tessng.ILaneObject]**

Get the list of lanes occupied by the Construction Zone.

**def laneObjectIds(self) -> list[int]**

Retrieve the list of Lane IDs occupied by the Construction Zone.

**def upCautionLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the length of the upstream warning area of the Construction Zone. Unit: pixel.

**def upTransitionLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the length of the upstream transition area of the Construction Zone. Unit: pixel.

**def upBufferLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the length of the upstream buffer area of the Construction Zone. Unit: pixel.

**def downTransitionLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the length of the downstream transition area of the Construction Zone. Unit: pixel.

**def downTerminationLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the length of the downstream termination area of the Construction Zone. Unit: pixel.

**def duration(self) -> int**

Construction duration. If the duration exceeds this value after the simulation is created, the zone will be removed. Unit: s.

**def isBorrowed(self) -> bool**

Indicate whether the Construction Zone utilizes lane borrowing.

#### 3.4.8.4. Limited Zone (ILimitedZone)

**def id(self) -> int**

Retrieve the Limited Zone ID.

**def name(self) -> str**

Retrieve the Limited Zone Name.

**def location(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the distance from the start point of the road segment to the restricted area. Unit: pixel.

**def zoneLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the length of the restricted area. Unit: pixel.

**def limitSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the speed limit of the restricted area. Unit: pixel (km/h).

**def sectionId(self) -> int**

Retrieve the ID of the road segment or connector segment.

**def sectionName(self) -> str**

Retrieve the Name of the Section.

**def sectionType(self) -> str**

Retrieve the road type, where "link" indicates a road segment and "connector" indicates a connector segment.

**def laneObjects(self) -> list[Tessng.ILaneObject]**

Retrieve the list of related Lane objects.

**def duration(self) -> int**

Retrieve the restriction duration. It will be removed if its duration since simulation creation exceeds this value. Unit: s.

#### 3.4.8.5. Reconstruction and Expansion Lane Borrowing (IReconstruction)

**def id(self) -> int**

Retrieve the Reconstruction and Expansion ID.

**def roadWorkZoneId(self) -> int**

Retrieve the start construction zone ID of the Reconstruction and Expansion.

**def limitedZoneId(self) -> int**

Retrieve the ID of the borrowed restricted area.

**def passagewayLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the protected passage length. Unit: pixel.

**def duration(self) -> int**

Get the duration of reconstruction and expansion.

**def borrowedNum(self) -> int**

Get the number of borrowed lanes.

**def passagewayLimitedSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the speed limit at the protected passage opening. Unit: pixel (km/h).

**def dynaReconstructionParam(self) -> Online.DynaReconstructionParam**

Get the dynamic parameters of reconstruction and expansion.

#### 3.4.8.6. Speed Limit Zone (IReduceSpeedArea)

**def id(self) -> int**

Get the Speed Limit Zone ID.

**def name(self) -> str**

Get the Speed Limit Zone Name.

**def location(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the distance from the starting point. Unit: pixel.

**def areaLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the length of the Speed Limit Zone. Unit: pixel.

**def sectionId(self) -> int**

Retrieve the ID of the road segment or connector segment.

**def laneNumber(self) -> int**

Get the Lane Index.

**def toLaneNumber(self) -> int**

Get the target Lane Index.

**def addReduceSpeedInterval(self, param: Online.DynaReduceSpeedIntervalParam) -> Tessng.IReduceSpeedInterval**

Add a speed limit time period.

Parameters: 

[ in ] param: speed limit time period parameter.

**def removeReduceSpeedInterval(self, id: int) -> None**

Remove a speed limit time period.

Parameters: 

[ in ] id: speed limit time period ID.

**def updateReduceSpeedInterval(self, param: Online.DynaReduceSpeedIntervalParam) -> bool**

Update Speed Limit Interval.

Parameters: 

[ in ] param: speed limit time period parameter.

**def reduceSpeedIntervals(self) -> list[Tessng.IReduceSpeedInterval]**

Retrieve Speed Limit Interval List.

**def findReduceSpeedIntervalById(self, id: int) -> Tessng.IReduceSpeedInterval**

Retrieve Speed Limit Interval by ID.

Parameters: 

[ in ] id: speed limit time period ID.

**def findReduceSpeedIntervalByStartTime(self, startTime: int) -> Tessng.IReduceSpeedInterval**

Retrieve Speed Limit Interval by Start Time.

Parameters: 

[ in ] startTime: Start Time.

**def polygon(self) -> PySide2.QtGui.QPolygonF**

Retrieve Polygonal Contour.

#### 3.4.8.7. Speed Limit Interval (IReduceSpeedInterval)

**def id(self) -> int**

Retrieve Speed Limit Interval ID.

**def reduceSpeedAreaId(self) -> int**

Retrieve Associated Speed Limit Zone ID.

**def intervalStartTime(self) -> int**

Retrieve Start Time.

**def intervalEndTime(self) -> int**

Retrieve End Time.

**def addReduceSpeedVehiType(self, param: Online.DynaReduceSpeedVehiTypeParam) -> Tessng.IReduceSpeedVehiType**

Add Vehicle Type to Speed Limit.

Parameters: 

[ in ] param: Speed Limit Vehicle Type Parameter.

**def removeReduceSpeedVehiType(self, id: int) -> None**

Remove Vehicle Type from Speed Limit.

Parameters: 

[ in ] id: Speed Limit Vehicle Type ID.

**def updateReduceSpeedVehiType(self, param: Online.DynaReduceSpeedVehiTypeParam) -> bool**

Update Vehicle Type for Speed Limit.

Parameters: 

[ in ] param: Speed Limit Vehicle Type Parameter.

**def reduceSpeedVehiTypes(self) -> list[Tessng.IReduceSpeedVehiType]**

Retrieve List of Vehicle Types and Speed Limit Parameters for This Interval.

**def findReduceSpeedVehiTypeById(self, id: int) -> Tessng.IReduceSpeedVehiType**

Obtain the speed-limited vehicle type by ID.

Parameters: 

[ in ] id: Speed Limit Vehicle Type ID.

**def findReduceSpeedVehiTypeByCode(self, vehicleTypeCode: int) -> Tessng.IReduceSpeedVehiType**

Obtain the speed-limited vehicle type by vehicle type code.

Parameters: 

[ in ] vehicleTypeCode: Vehicle type code.

#### 3.4.8.8. Speed-limited Vehicle Type (IReduceSpeedVehiType)

**def id(self) -> int**

Get the speed-limited vehicle type ID.

**def intervalId(self) -> int**

Get the associated speed limit period ID.

**def reduceSpeedAreaId(self) -> int**

Retrieve Associated Speed Limit Zone ID.

**def vehiTypeCode(self) -> int**

Get the vehicle type code.

**def averageSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the average vehicle speed. Unit: pixel/s.

**def speedStandardDeviation(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the standard deviation of vehicle speed. Unit: pixel/s.

### 3.4.9. Pedestrian Module

#### 3.4.9.1. Obstacle Region (IObstacleRegion)

**def isObstacle(self) -> bool**

Get whether the region is an obstacle.

**def setObstacle(self, b: bool) -> None**

Set whether the region is an obstacle.

Parameters: 

[ in ] b: Whether it is an obstacle.

#### 3.4.9.2. Passenger Region (IPassengerRegion)

**def isBoardingArea(self) -> bool**

​	Get whether the region is designated as a boarding area.

**def setIsBoardingArea(self, b: bool) -> None**

​	Set whether the region is designated as a boarding area.

**def isAlightingArea(self) -> bool**

​	Get whether the region is designated as an alighting area.

**def setIsAlightingArea(self, b: bool) -> None**

​	Set whether the region is designated as an alighting area.

#### 3.4.9.3. Pedestrian Path Region Base Class (IPedestrianPathRegionBase)

**def getId(self) -> int**

​	Get the Polygon ID.

**def getName(self) -> str**

​	Get the Name of the region.

**def setName(self, name: str) -> None**

​	Set the Name of the region.

**def getRegionColor(self) -> PySide2.QtGui.QColor**

​	Get the Color of the region.

**def setRegionColor(self, color: PySide2.QtGui.QColor) -> None**

​	Set the Color of the region.

**def getPosition(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	Get the position of the region. Unit: pixel.

**def setPosition(self, scenePos: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	Set the position of the region. Unit: pixel.

Parameters: 

​	[ in ] scenePos: Position in the scene coordinate system.

**def getGType(self) -> int**

Get the type of the surface area.

#### 3.4.9.4. Pedestrian Surface Area (IPedestrianRegion)

**def getId(self) -> int**

​	Get the Polygon ID.

**def getName(self) -> str**

​	Get the Name of the region.

**def setName(self, name: str) -> None**

​	Set the Name of the region.

**def getRegionColor(self) -> PySide2.QtGui.QColor**

​	Get the Color of the region.

**def setRegionColor(self, color: PySide2.QtGui.QColor) -> None**

​	Set the Color of the region.

**def getPosition(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	Get the position of the region. Unit: pixel.

**def setPosition(self, scenePos: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	Set the position of the region. Unit: pixel.

Parameters: 

​	[ in ] scenePos: Position in the scene coordinate system.

**def getGType(self) -> int**

Get the type of the surface area.

**def getExpectSpeedFactor(self) -> float**

Get the desired speed coefficient.

**def setExpectSpeedFactor(self, val: float) -> None**

Set the desired speed coefficient.

Parameters: 

[ in ] val: Desired speed coefficient.

**def getElevation(self) -> float**

Get the elevation of the surface area.

**def setElevation(self, elevation: float) -> None**

Set the elevation of the surface area.

Parameters: 

[ in ] elevation: Elevation.

**def getPolygon(self) -> PySide2.QtGui.QPolygonF**

Get the polygon of the surface area.

**def getLayerId(self) -> int**

Get the layer ID where the surface area is located.

**def setLayerId(self, id: int) -> None**

Set the layer where the surface area is located; no changes will be made if the layer ID is invalid.

Parameters: 

[ in ] id: Layer ID.

#### 3.4.9.5. Rectangular Pedestrian Surface Area (IPedestrianRectRegion)

**def getId(self) -> int**

​	Get the Polygon ID.

**def getName(self) -> str**

​	Get the Name of the region.

**def setName(self, name: str) -> None**

​	Set the Name of the region.

**def getRegionColor(self) -> PySide2.QtGui.QColor**

​	Get the Color of the region.

**def setRegionColor(self, color: PySide2.QtGui.QColor) -> None**

​	Set the Color of the region.

**def getPosition(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	Get the position of the region. Unit: pixel.

**def setPosition(self, scenePos: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	Set the position of the region. Unit: pixel.

Parameters: 

​	[ in ] scenePos: Position in the scene coordinate system.

**def getGType(self) -> int**

Get the type of the surface area.

**def getExpectSpeedFactor(self) -> float**

Get the desired speed coefficient.

**def setExpectSpeedFactor(self, val: float) -> None**

Set the desired speed coefficient.

**def getElevation(self) -> float**

Get the elevation of the surface area.

**def setElevation(self, elevation: float) -> None**

Set the elevation of the surface area.

**def getPolygon(self) -> PySide2.QtGui.QPolygonF**

Get the polygon of the surface area.

**def getLayerId(self) -> int**

Get the layer ID where the surface area is located.

**def setLayerId(self, id: int) -> None**

Set the layer where the surface area is located; no changes will be made if the layer ID is invalid.

**def isObstacle(self) -> bool**

Get whether the region is an obstacle.

**def setObstacle(self, b: bool) -> None**

Set whether the region is an obstacle.

**def isBoardingArea(self) -> bool**

​	Get whether the region is designated as a boarding area.

**def setIsBoardingArea(self, b: bool) -> None**

​	Set whether the region is designated as a boarding area.

**def isAlightingArea(self) -> bool**

​	Get whether the region is designated as an alighting area.

**def setIsAlightingArea(self, b: bool) -> None**

​	Set whether the region is designated as an alighting area.

#### 3.4.9.6. Triangular Pedestrian Surface Area (IPedestrianTriangleRegion)

**def getId(self) -> int**

​	Get the Polygon ID.

**def getName(self) -> str**

​	Get the Name of the region.

**def setName(self, name: str) -> None**

​	Set the Name of the region.

**def getRegionColor(self) -> PySide2.QtGui.QColor**

​	Get the Color of the region.

**def setRegionColor(self, color: PySide2.QtGui.QColor) -> None**

​	Set the Color of the region.

**def getPosition(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	Get the position of the region. Unit: pixel.

**def setPosition(self, scenePos: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	Set the position of the region. Unit: pixel.

Parameters: 

​	[ in ] scenePos: Position in the scene coordinate system.

**def getGType(self) -> int**

Get the type of the surface area.

**def getExpectSpeedFactor(self) -> float**

Get the desired speed coefficient.

**def setExpectSpeedFactor(self, val: float) -> None**

Set the desired speed coefficient.

**def getElevation(self) -> float**

Get the elevation of the surface area.

**def setElevation(self, elevation: float) -> None**

Set the elevation of the surface area.

**def getPolygon(self) -> PySide2.QtGui.QPolygonF**

Get the polygon of the surface area.

**def getLayerId(self) -> int**

Get the layer ID where the surface area is located.

**def setLayerId(self, id: int) -> None**

Set the layer where the surface area is located; no changes will be made if the layer ID is invalid.

**def isObstacle(self) -> bool**

Get whether the region is an obstacle.

**def setObstacle(self, b: bool) -> None**

Set whether the region is an obstacle.

**def isBoardingArea(self) -> bool**

​	Get whether the region is designated as a boarding area.

**def setIsBoardingArea(self, b: bool) -> None**

​	Set whether the region is designated as a boarding area.

**def isAlightingArea(self) -> bool**

​	Get whether the region is designated as an alighting area.

**def setIsAlightingArea(self, b: bool) -> None**

​	Set whether the region is designated as an alighting area.

#### 3.4.9.7. Elliptical Pedestrian Surface Area (IPedestrianEllipseRegion)

**def getId(self) -> int**

​	Get the Polygon ID.

**def getName(self) -> str**

​	Get the Name of the region.

**def setName(self, name: str) -> None**

​	Set the Name of the region.

**def getRegionColor(self) -> PySide2.QtGui.QColor**

​	Get the Color of the region.

**def setRegionColor(self, color: PySide2.QtGui.QColor) -> None**

​	Set the Color of the region.

**def getPosition(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	Get the position of the region. Unit: pixel.

**def setPosition(self, scenePos: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	Set the position of the region. Unit: pixel.

Parameters: 

​	[ in ] scenePos: Position in the scene coordinate system.

**def getGType(self) -> int**

Get the type of the surface area.

**def getExpectSpeedFactor(self) -> float**

Get the desired speed coefficient.

**def setExpectSpeedFactor(self, val: float) -> None**

Set the desired speed coefficient.

**def getElevation(self) -> float**

Get the elevation of the surface area.

**def setElevation(self, elevation: float) -> None**

Set the elevation of the surface area.

**def getPolygon(self) -> PySide2.QtGui.QPolygonF**

Get the polygon of the surface area.

**def getLayerId(self) -> int**

Get the layer ID where the surface area is located.

**def setLayerId(self, id: int) -> None**

Set the layer where the surface area is located; no changes will be made if the layer ID is invalid.

**def isObstacle(self) -> bool**

Get whether the region is an obstacle.

**def setObstacle(self, b: bool) -> None**

Set whether the region is an obstacle.

**def isBoardingArea(self) -> bool**

​	Get whether the region is designated as a boarding area.

**def setIsBoardingArea(self, b: bool) -> None**

​	Set whether the region is designated as a boarding area.

**def isAlightingArea(self) -> bool**

​	Get whether the region is designated as an alighting area.

**def setIsAlightingArea(self, b: bool) -> None**

​	Set whether the region is designated as an alighting area.

#### 3.4.9.8. Fan-shaped Pedestrian Surface Area (IPedestrianFanShapeRegion)

**def getId(self) -> int**

​	Get the Polygon ID.

**def getName(self) -> str**

​	Get the Name of the region.

**def setName(self, name: str) -> None**

​	Set the Name of the region.

**def getRegionColor(self) -> PySide2.QtGui.QColor**

​	Get the Color of the region.

**def setRegionColor(self, color: PySide2.QtGui.QColor) -> None**

​	Set the Color of the region.

**def getPosition(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	Get the position of the region. Unit: pixel.

**def setPosition(self, scenePos: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	Set the position of the region. Unit: pixel.

Parameters: 

​	[ in ] scenePos: Position in the scene coordinate system.

**def getGType(self) -> int**

Get the type of the surface area.

**def getExpectSpeedFactor(self) -> float**

Get the desired speed coefficient.

**def setExpectSpeedFactor(self, val: float) -> None**

Set the desired speed coefficient.

**def getElevation(self) -> float**

Get the elevation of the surface area.

**def setElevation(self, elevation: float) -> None**

Set the elevation of the surface area.

**def getPolygon(self) -> PySide2.QtGui.QPolygonF**

Get the polygon of the surface area.

**def getLayerId(self) -> int**

Get the layer ID where the surface area is located.

**def setLayerId(self, id: int) -> None**

Set the layer where the surface area is located; no changes will be made if the layer ID is invalid.

**def isObstacle(self) -> bool**

Get whether the region is an obstacle.

**def setObstacle(self, b: bool) -> None**

Set whether the region is an obstacle.

**def isBoardingArea(self) -> bool**

​	Get whether the region is designated as a boarding area.

**def setIsBoardingArea(self, b: bool) -> None**

​	Set whether the region is designated as a boarding area.

**def isAlightingArea(self) -> bool**

​	Get whether the region is designated as an alighting area.

**def setIsAlightingArea(self, b: bool) -> None**

​	Set whether the region is designated as an alighting area.

**def getInnerRadius(self) -> float**

Get inner radius, Unit: meter.

**def getOuterRadius(self) -> float**

Get outer radius, Unit: meter.

**def getStartAngle(self) -> float**

Get starting angle, Unit: degree.

**def getSweepAngle(self) -> float**

Get sweep angle, Unit: degree.

#### 3.4.9.9. Polygonal Pedestrian Surface Area (IPedestrianPolygonRegion)

**def getId(self) -> int**

​	Get the Polygon ID.

**def getName(self) -> str**

​	Get the Name of the region.

**def setName(self, name: str) -> None**

​	Set the Name of the region.

**def getRegionColor(self) -> PySide2.QtGui.QColor**

​	Get the Color of the region.

**def setRegionColor(self, color: PySide2.QtGui.QColor) -> None**

​	Set the Color of the region.

**def getPosition(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	Get the position of the region. Unit: pixel.

**def setPosition(self, scenePos: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	Set the position of the region. Unit: pixel.

Parameters: 

​	[ in ] scenePos: Position in the scene coordinate system.

**def getGType(self) -> int**

Get the type of the surface area.

**def getExpectSpeedFactor(self) -> float**

Get the desired speed coefficient.

**def setExpectSpeedFactor(self, val: float) -> None**

Set the desired speed coefficient.

**def getElevation(self) -> float**

Get the elevation of the surface area.

**def setElevation(self, elevation: float) -> None**

Set the elevation of the surface area.

**def getPolygon(self) -> PySide2.QtGui.QPolygonF**

Get the polygon of the surface area.

**def getLayerId(self) -> int**

Get the layer ID where the surface area is located.

**def setLayerId(self, id: int) -> None**

Set the layer where the surface area is located; no changes will be made if the layer ID is invalid.

**def isObstacle(self) -> bool**

Get whether the region is an obstacle.

**def setObstacle(self, b: bool) -> None**

Set whether the region is an obstacle.

**def isBoardingArea(self) -> bool**

​	Get whether the region is designated as a boarding area.

**def setIsBoardingArea(self, b: bool) -> None**

​	Set whether the region is designated as a boarding area.

**def isAlightingArea(self) -> bool**

​	Get whether the region is designated as an alighting area.

**def setIsAlightingArea(self, b: bool) -> None**

​	Set whether the region is designated as an alighting area.

#### 3.4.9.10. Sidewalk Pedestrian Surface Area (IPedestrianSideWalkRegion)

**def getId(self) -> int**

​	Get the Polygon ID.

**def getName(self) -> str**

​	Get the Name of the region.

**def setName(self, name: str) -> None**

​	Set the Name of the region.

Parameters: 

[ in ] name: New name.

**def getRegionColor(self) -> PySide2.QtGui.QColor**

​	Get the Color of the region.

**def setRegionColor(self, color: PySide2.QtGui.QColor) -> None**

​	Set the Color of the region.

Parameters: 

[ in ] color: Surface area color.

**def getPosition(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	Get the position of the region. Unit: pixel.

**def setPosition(self, scenePos: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	Set the position of the region. Unit: pixel.

Parameters: 

​	[ in ] scenePos: Position in the scene coordinate system.

**def getGType(self) -> int**

Get the type of the surface area.

**def getExpectSpeedFactor(self) -> float**

Get the desired speed coefficient.

**def setExpectSpeedFactor(self, val: float) -> None**

Set the desired speed coefficient.

**def getElevation(self) -> float**

Get the elevation of the surface area.

**def setElevation(self, elevation: float) -> None**

Set the elevation of the surface area.

**def getPolygon(self) -> PySide2.QtGui.QPolygonF**

Get the polygon of the surface area.

**def getLayerId(self) -> int**

Get the layer ID where the surface area is located.

**def setLayerId(self, id: int) -> None**

Set the layer where the surface area is located; no changes will be made if the layer ID is invalid.

Parameters: 

[ in ] id: Layer ID.

**def getWidth(self) -> float**

Get sidewalk width.

**def setWidth(self, width: float) -> None**

Set sidewalk width.

Parameters: 

[ in ] width: Sidewalk width, Unit: m.

**def getVetexs(self) -> list[PySide2.QtWidgets.QGraphicsEllipseItem]**

Retrieve the sidewalk vertices, i.e., the initial polyline vertices.

**def getControl1Vetexs(self) -> list[PySide2.QtWidgets.QGraphicsEllipseItem]**

Retrieve Bezier curve control point P1 of the sidewalk.

**def getControl2Vetexs(self) -> list[PySide2.QtWidgets.QGraphicsEllipseItem]**

Retrieve Bezier curve control point P2 of the sidewalk.

**def getCandidateVetexs(self) -> list[PySide2.QtWidgets.QGraphicsEllipseItem]**

Retrieve candidate vertices.

**def removeVetex(self, index: int) -> None**

Delete the vertex at the specified index.

Parameters: 

[ in ] index: Vertex index.

**def insertVetex(self, pos: PySide2.QtCore.QPointF, index: int) -> None**

Insert a vertex at the specified index, with the initial position pos.

Parameters: 

[ in ] pos: Vertex position.

[ in ] index: Insertion index.

#### 3.4.9.11. Pedestrian Crosswalk Pedestrian Surface Area (IPedestrianCrossWalkRegion)

**def getId(self) -> int**

​	Get the Polygon ID.

**def getName(self) -> str**

​	Get the Name of the region.

**def setName(self, name: str) -> None**

​	Set the Name of the region.

Parameters: 

[ in ] name: New name.

**def getRegionColor(self) -> PySide2.QtGui.QColor**

​	Get the Color of the region.

**def setRegionColor(self, color: PySide2.QtGui.QColor) -> None**

​	Set the Color of the region.

Parameters: 

[ in ] color: Surface area color.

**def getPosition(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	Get the position of the region. Unit: pixel.

**def setPosition(self, scenePos: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	Set the position of the region. Unit: pixel.

Parameters: 

​	[ in ] scenePos: Position in the scene coordinate system.

**def getGType(self) -> int**

Get the type of the surface area.

**def getExpectSpeedFactor(self) -> float**

Get the desired speed coefficient.

**def setExpectSpeedFactor(self, val: float) -> None**

Set the desired speed coefficient.

**def getElevation(self) -> float**

Get the elevation of the surface area.

**def setElevation(self, elevation: float) -> None**

Set the elevation of the surface area.

**def getPolygon(self) -> PySide2.QtGui.QPolygonF**

Get the polygon of the surface area.

**def getLayerId(self) -> int**

Get the layer ID where the surface area is located.

**def setLayerId(self, id: int) -> None**

Set the layer where the surface area is located; no changes will be made if the layer ID is invalid.

**def getWidth(self) -> float**

Retrieve the pedestrian crosswalk width, Unit: m.

**def setWidth(self, width: float) -> None**

Set the crosswalk width, unit: meter.

**def getSceneLine(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QLineF**

Get the line segment from the start point to the end point of the crosswalk in the scene coordinate system. Unit: pixel.

**def getAngle(self) -> float**

Get the crosswalk inclination angle.

**def setAngle(self, angle: float) -> None**

Set the crosswalk inclination angle.

**def getRedLightSpeedFactor(self) -> float**

Get the red light clearance speed coefficient.

**def setRedLightSpeedFactor(self, factor: float) -> None**

Set the red light clearance speed coefficient.

**def getUnitDirectionFromStartToEnd(self) -> PySide2.QtGui.QVector2D**

Get the unit direction vector from the start point to the end point in the scene coordinate system.

**def getLocalUnitDirectionFromStartToEnd(self) -> PySide2.QtGui.QVector2D**

Get the unit direction from the start point to the end point in the crosswalk’s local coordinate system.

**def getStartControlPoint(self) -> PySide2.QtWidgets.QGraphicsEllipseItem**

Get the start control point.

**def getEndControlPoint(self) -> PySide2.QtWidgets.QGraphicsEllipseItem**

Get the end control point.

**def getLeftControlPoint(self) -> PySide2.QtWidgets.QGraphicsEllipseItem**

Get the left control point.

**def getRightControlPoint(self) -> PySide2.QtWidgets.QGraphicsEllipseItem**

Retrieve the right control point.

**def getPositiveDirectionSignalLamp(self) -> Tessng.ICrosswalkSignalLamp**

Retrieve the traffic signal controlling forward traffic.

**def getNegativeDirectionSignalLamp(self) -> Tessng.ICrosswalkSignalLamp**

Retrieve the traffic signal controlling reverse traffic.

**def isPositiveTrafficLightAdded(self) -> bool**

Check whether a traffic signal controlling forward traffic has been added.

**def isReverseTrafficLightAdded(self) -> bool**

Check whether a traffic signal controlling reverse traffic has been added.

#### 3.4.9.12. Pedestrian Stair Surface Area (IPedestrianStairRegion)

**def getId(self) -> int**

​	Get the Polygon ID.

**def getName(self) -> str**

​	Get the Name of the region.

**def setName(self, name: str) -> None**

​	Set the Name of the region.

**def getRegionColor(self) -> PySide2.QtGui.QColor**

​	Get the Color of the region.

**def setRegionColor(self, color: PySide2.QtGui.QColor) -> None**

​	Set the Color of the region.

**def getPosition(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

​	Get the position of the region. Unit: pixel.

**def setPosition(self, scenePos: PySide2.QtCore.QPointF, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

​	Set the position of the region. Unit: pixel.

Parameters: 

​	[ in ] scenePos: Position in the scene coordinate system.

**def getGType(self) -> int**

Get the type of the surface area.

**def getWidth(self) -> float**

Get the stair width, Unit: m.

**def setWidth(self, width: float) -> None**

Set the stair width, Unit: m.

**def getStartPoint(self) -> PySide2.QtCore.QPointF**

Retrieve the start point in the scene coordinate system.

**def getEndPoint(self) -> PySide2.QtCore.QPointF**

Retrieve the end point in the scene coordinate system.

**def getStartConnectionAreaLength(self) -> float**

Get the length of the starting connecting region, Unit: m.

**def getEndConnectionAreaLength(self) -> float**

Retrieve the length of the terminal connection area, Unit: m.

**def getStartRegionCenterPoint(self) -> PySide2.QtCore.QPointF**

Retrieve the center of the initial connection area in the scene coordinate system.

**def getEndRegionCenterPoint(self) -> PySide2.QtCore.QPointF**

Retrieve the center of the terminal connection area in the scene coordinate system.

**def getStartSceneRegion(self) -> PySide2.QtGui.QPainterPath**

Retrieve the shape of the initial connection area in the scene coordinate system.

**def getEndSceneRegion(self) -> PySide2.QtGui.QPainterPath**

Retrieve the shape of the terminal connection area in the scene coordinate system.

**def getMainQueueRegion(self) -> PySide2.QtGui.QPainterPath**

Retrieve the main body shape of the staircase in the scene coordinate system.

**def getFullQueueregion(self) -> PySide2.QtGui.QPainterPath**

Retrieve the overall shape of the staircase in the scene coordinate system.

**def getMainQueuePolygon(self) -> PySide2.QtGui.QPolygonF**

Retrieve the main body polygon of the staircase in the scene coordinate system.

**def getStairType(self) -> Tessng.StairType**

Retrieve the staircase type.

**def setStairType(self, type: Tessng.StairType) -> None**

Set the staircase type.

**def getStartLayerId(self) -> int**

Get the starting level.

**def setStartLayerId(self, id: int) -> None**

Set the starting level.

**def getEndLayerId(self) -> int**

Get the ending level.

**def setEndLayerId(self, id: int) -> None**

Set the ending level.

**def getTransmissionSpeed(self) -> float**

Get the conveyor speed, Unit: m/s.

**def setTransmissionSpeed(self, speed: float) -> None**

Set the conveyor speed, Unit: m/s.

**def getHeadroom(self) -> float**

Get the stair clearance height.

**def setHeadroom(self, headroom: float) -> None**

Set the stair clearance height.

**def getStartControlPoint(self) -> PySide2.QtWidgets.QGraphicsEllipseItem**

Get the start control point.

**def getEndControlPoint(self) -> PySide2.QtWidgets.QGraphicsEllipseItem**

Get the end control point.

**def getLeftControlPoint(self) -> PySide2.QtWidgets.QGraphicsEllipseItem**

Get the left control point.

**def getRightControlPoint(self) -> PySide2.QtWidgets.QGraphicsEllipseItem**

Retrieve the right control point.

**def getStartConnectionAreaControlPoint(self) -> PySide2.QtWidgets.QGraphicsEllipseItem**

Get the length control point of the starting connection area.

**def getEndConnectionAreaControlPoint(self) -> PySide2.QtWidgets.QGraphicsEllipseItem**

Get the length control point of the ending connection area.

#### 3.4.9.13. Pedestrian Path (IPedestrianPath)

**def getId(self) -> int**

Get the pedestrian path ID.

**def getPathStartPoint(self) -> Tessng.IPedestrianPathPoint**

Get the starting point of the pedestrian path.

**def getPathEndPoint(self) -> Tessng.IPedestrianPathPoint**

Get the ending point of the pedestrian path.

**def getPathMiddlePoints(self) -> list[Tessng.IPedestrianPathPoint]**

Get the intermediate points of the pedestrian path.

**def isLocalPath(self) -> bool**

Determine whether it is a local path.

#### 3.4.9.14. Pedestrian Path Point (IPedestrianPathPoint)

**def getId(self) -> int**

Retrieve the pedestrian path point ID.

**def getScenePos(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

Retrieve the position of the pedestrian path point in the scene coordinate system. Unit: pixel.

**def getRadius(self) -> float**

Retrieve the radius of the pedestrian path point. Unit: meters.

#### 3.4.9.15. Crosswalk Traffic Signal Lamp (ICrosswalkSignalLamp)

**def id(self) -> int**

​	Get the traffic signal ID.

**def setSignalPhase(self, pPhase: Tessng.ISignalPhase) -> None**

​	Set the phase; the phase can be one from another traffic signal group.

**def setPhaseNumber(self, num: int) -> None**

​	Set the phase index, starting from 1. If the index exceeds the total number of phases, no change will be made.

**def setLampColor(self, colorStr: str) -> None**

​	Set the traffic signal color.

Parameters: 

[ in ] colorStr: Color expressed as a string, with four possible values: "red", "green", "yellow", "gray", or "R", "G", "Y", "gray". 

**def color(self) -> str**

Retrieve the traffic signal color, where "R", "G", "Y", and "gray" represent "Red", "Green", "Yellow", and "Gray" respectively.

**def name(self) -> str**

Retrieve the traffic signal name.

**def setName(self, name: str) -> None**

Set the traffic signal name.

**def setDistToStart(self, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

Set the distance of the traffic signal from the start of the Road Segment. Unit: pixel.

Parameters: 

[ in ] dist: distance value.

**def signalPlan(self) -> Tessng.ISignalPlan**

Retrieve the traffic signal control scheme.

**def signalPhase(self) -> Tessng.ISignalPhase**

Retrieve the phase.

**def laneObject(self) -> Tessng.ILaneObject**

Retrieve the associated Lane or Lane Connection.

**def polygon(self) -> PySide2.QtGui.QPolygonF**

Retrieve the vertices of the traffic signal's polygonal contour.

**def angle(self) -> float**

Retrieve the traffic signal angle.

**def getICrossWalk(self) -> Tessng.IPedestrianCrossWalkRegion**

Retrieve the associated crosswalk.

### 3.4.10. Parking Lot Module

#### 3.4.10.1. Parking Stall (IParkingStall)

**def id(self) -> int**

Retrieve the parking space ID.

**def parkingRegionId(self) -> int**

Retrieve the associated parking region ID.

**def parkingRegion(self) -> Tessng.IParkingRegion**

Retrieve the associated parking region.

**def distance(self) -> float**

Retrieve the distance from the start of the road segment, unit: m.

**def stallType(self) -> int**

Retrieve the parking space type, consistent with vehicle type coding.

#### 3.4.10.2. Parking Region (IParkingRegion)

**def id(self) -> int**

Retrieve the parking region ID.

**def name(self) -> str**

Retrieve the parking region name.

**def setName(self, name: str) -> None**

Set the parking region name.

Parameters: 

[ in ] name: New name.

**def parkingStalls(self) -> list[Tessng.IParkingStall]**

Retrieve all parking spaces.

**def dynaParkingRegion(self) -> Online.ParkingLot.DynaParkingRegion**

Retrieve dynamic parking region information.

#### 3.4.10.3. Parking Route Decision Point (IParkingDecisionPoint)

**def id(self) -> int**

Retrieve the parking decision point ID.

**def name(self) -> str**

Retrieve the parking decision point name.

**def link(self) -> Tessng.ILink**

Retrieve the road segment where the parking decision point is located.

**def distance(self) -> float**

Retrieve the distance from the parking decision point to the start of the road segment, Unit: m.

**def routings(self) -> list[Tessng.IParkingRouting]**

Retrieve the associated parking routes.

**def updateParkDisInfo(self, tollDisInfoList: list[Online.ParkingLot.DynaParkDisInfo]) -> bool**

Update parking assignment information.

Parameters: 

[ in ] tollDisInfoList: List of parking assignment information.

**def parkDisInfoList(self) -> list[Online.ParkingLot.DynaParkDisInfo]**

Retrieve the list of parking assignment information.

**def polygon(self) -> PySide2.QtGui.QPolygonF**

Retrieve the polygonal contour of the parking decision point.

#### 3.4.10.4. Parking Routing (IParkingRouting)

**def id(self) -> int**

Retrieve the route ID.

**def parkingDeciPointId(self) -> int**

Retrieve the associated decision point ID.

**def parkingRegionId(self) -> int**

ID of the parking area reached by the route.

**def calcuLength(self) -> float**

Calculate the route length.

**def contain(self, pRoad: Tessng.ISection) -> bool**

Determine whether the given road is on the current route.

Parameters: 

[ in ] pRoad: Road segment or connector segment.

**def nextRoad(self, pRoad: Tessng.ISection) -> Tessng.ISection**

Get the next road based on the given road.

Parameters: 

[ in ] pRoad: Road segment or connector segment.

**def getLinks(self) -> list[Tessng.ILink]**

Obtain the sequence of road segments.

### 3.4.11. Toll Station Module

#### 3.4.11.1. Toll Point (ITollPoint)

**def id(self) -> int**

Retrieve the toll point ID.

**def distance(self) -> float**

Retrieve the distance from the start of the road segment, unit: m.

**def tollLaneId(self) -> int**

Retrieve the associated toll lane ID.

**def tollLane(self) -> Tessng.ITollLane**

Get the associated toll lane.

**def isEnabled(self) -> bool**

Get enable status.

**def setEnabled(self, enabled: bool) -> bool**

Set enable status.

Parameters: 

[ in ] enabled: Enable status.

**def tollType(self) -> int**

Get toll type.

**def setTollType(self, tollType: int) -> bool**

Set toll type.

Parameters: 

[ in ] tollType: Toll type.

**def timeDisId(self) -> int**

Get parking time distribution ID.

**def setTimeDisId(self, timeDisId: int) -> bool**

Set parking time distribution ID.

Parameters: 

[ in ] timeDisId: Time distribution ID.

#### 3.4.11.2. Toll Lane (ITollLane)

**def id(self) -> int**

Get toll lane ID.

**def name(self) -> str**

Get toll lane name.

**def distance(self) -> float**

Retrieve the distance from the start of the road segment, unit: m.

**def setName(self, name: str) -> None**

Set toll lane name.

Parameters: 

[ in ] name: New toll lane name.

**def setWorkTime(self, startTime: int, endTime: int) -> None**

Set working hours. The working hours correspond to the simulation time.

Parameters: 

[ in ] startTime: Start time. Unit: s.

​	[ in ] endTime: End Time. Unit: s.

**def dynaTollLane(self) -> Online.TollStation.DynaTollLane**

​	Obtain dynamic toll lane information.

**def tollPoints(self) -> list[Tessng.ITollPoint]**

​	Obtain all toll points of the toll lane.

#### 3.4.11.3. Toll Decision Point (ITollDecisionPoint)

**def id(self) -> int**

​	Obtain toll decision point ID.

**def name(self) -> str**

​	Obtain toll decision point Name.

**def link(self) -> Tessng.ILink**

​	Obtain the road segment where the toll decision point is located.

**def distance(self) -> float**

​	Obtain distance from the start of the road segment, Unit: m.

**def routings(self) -> list[Tessng.ITollRouting]**

​	Obtain related toll routes.

**def tollDisInfoList(self) -> list[Online.TollStation.DynaTollDisInfo]**

​	Obtain toll allocation information list.

**def updateTollDisInfoList(self, tollDisInfoList: list[Online.TollStation.DynaTollDisInfo]) -> None**

​	Update toll allocation information list.

Parameters: 

​	[ in ] tollDisInfoList: Toll allocation information list.

**def polygon(self) -> PySide2.QtGui.QPolygonF**

​	Obtain the polygonal outline of the toll decision point.

#### 3.4.11.4. Toll Routing (ITollRouting)

**def id(self) -> int**

Retrieve the route ID.

**def tollDeciPointId(self) -> int**

Obtain the ID of the associated toll decision point.

**def tollLaneId(self) -> int**

ID of the toll area reached by the route.

**def calcuLength(self) -> float**

Calculate the route length.

**def contain(self, pRoad: Tessng.ISection) -> bool**

Determine whether the given road is on the current route.

Parameters: 

[ in ] pRoad: Road segment or connector segment.

**def nextRoad(self, pRoad: Tessng.ISection) -> Tessng.ISection**

Get the next road based on the given road.

Parameters: 

[ in ] pRoad: Road segment or connector segment.

**def getLinks(self) -> list[Tessng.ILink]**

Obtain the sequence of road segments.

### 3.4.12. Node Module

#### 3.4.12.1. Node (IJunction)

**def getId(self) -> int**

Obtain the node ID.

**def name(self) -> str**

Obtain the node Name.

**def setName(self, strName: str) -> None**

Set the node Name.

Parameters: 

[ in ] strName: New Name.

**def getJunctionLinks(self) -> list[Tessng.ILink]**

Obtain the road segments within the node.

**def getJunctionConnectors(self) -> list[Tessng.IConnector]**

Obtain the connector segments within the node.

**def getAllTurnningInfo(self) -> list[Online.Junction.TurnningBaseInfo]**

Obtain all traffic flow direction information within the node.

**def getTurnningInfo(self, turningId: int) -> Online.Junction.TurnningBaseInfo**

Obtain specified traffic flow direction information within the node.

### 3.4.13. Vehicles and Pedestrians

#### 3.4.13.1. Vehicle (IVehicle)

Vehicle interface for accessing and controlling vehicles. This interface allows reading vehicle attributes, setting certain attributes, and during simulation, accessing current road conditions, adjacent vehicles in front, behind, left, and right, as well as their distances.

**def id(self) -> int**

Vehicle ID, composed as x * 100000 + y, where x is the departure point index starting from 1 and incrementing by 1 for each departure point, and y is the vehicle sequence number at each departure point, starting from 1 and incrementing by 1. The Vehicle ID for vehicles departing from the first departure point starts incrementing from 100001, and from 200001 for the second departure point.

**def startLink(self) -> Tessng.ILink**

The initial Road Segment when the vehicle enters the road network.

**def startSimuTime(self) -> int**

The initial time when the vehicle enters the road network.

**def roadId(self) -> int**

The ID of the Road Segment or Connector Segment where the vehicle is located.

**def road(self) -> None**

Road: returns ILink if the vehicle is on a Road Segment, or IConnector if on a Connector Segment.

**def section(self) -> Tessng.ISection**

The Section where the vehicle is located, i.e., either a Road Segment or a Connector Segment.

**def laneObj(self) -> Tessng.ILaneObject**

The Lane or Lane Connection where the vehicle is currently located.

**def segmIndex(self) -> int**

Segment index of the vehicle on the current LaneObject.

**def roadIsLink(self) -> bool**

Indicates whether the road on which the vehicle is located is a road segment.

**def roadName(self) -> str**

Road name.

**def initSpeed(self, speed: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Initial vehicle speed.

Parameters: 

[ in ] speed: Initial speed value. Unit: pixels/s.

**def initLane(self, laneNumber: int, dist: float = -1, speed: float = -1, unit: UnitOfMeasure = UnitOfMeasure: : Default) -> None**

Initialize the vehicle on the road segment.

Parameters: 

[ in ] laneNumber: Lane Index.

[ in ] dist: Distance from the starting point, unit: pixels.

[ in ] speed: Initial speed, unit: pixels/s.

**def initLaneConnector(self, laneNumber: int, toLaneNumber: int, dist: float = -1, speed: float = -1, unit: UnitOfMeasure = UnitOfMeasure: : Default) -> None**

Initialize the vehicle on the connector segment. Unit: pixels.

Parameters: 

[ in ] laneNumber: Starting Lane Index.

[ in ] toLaneNumber: Target Lane Index.

[ in ] dist: Distance from the starting point, unit: pixels.

[ in ] speed: Initial speed, unit: pixels/s.

**def setVehiType(self, code: int) -> None**

Set the vehicle type. The vehicle's type is determined at creation; this method can be used to change the vehicle type.

Parameters: 

[ in ] code: Vehicle type code.

**def setColor(self, color: str) -> None**

Set vehicle color.

Parameters: 

[ in ] color: Color in RGB format, e.g., "#EE0000".

Example:

```python
# Set vehicle color to blue
vehicle.setColor("#00AFF0")
```

**def length(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get vehicle Length. Unit: pixel.

**def setLength(self, len: float, bRestWidth: bool, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

Set vehicle Length. Unit: pixel.

Parameters: 

[ in ] len: Length value, unit: pixel or meter (depending on the unit parameter).

[ in ] bRestWidth: Whether to constrain the width proportionally.

**def laneId(self) -> int**

If toLaneId() is less than or equal to 0, laneId() returns the current Lane ID; if toLaneId() is greater than 0, the vehicle is on a Lane Connection, and laneId() returns the upstream Lane ID.

**def toLaneId(self) -> int**

Downstream Lane ID. If less than or equal to 0, the vehicle is on a lane of the road segment; otherwise, the vehicle is on a lane connection of the connector segment.

**def lane(self) -> Tessng.ILane**

Get the current lane; if the vehicle is on a lane connection, the upstream lane of the lane connection is returned.

**def toLane(self) -> Tessng.ILane**

If the vehicle is on a lane connection, return the downstream lane of the lane connection; if not currently on a lane connection, return None.

**def laneConnector(self) -> Tessng.ILaneConnector**

Get the current lane connection; if the vehicle is on a lane, return None.

**def currBatchNumber(self) -> int**

Current simulation computation batch.

**def roadType(self) -> int**

Road type where the vehicle is located. GLinkType represents Road Segments; GConnectorType represents Connector Segments.

**def limitMaxSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the maximum speed limit, unit: pixel/s.

**def limitMinSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the minimum speed limit, unit: pixel/s.

**def vehicleTypeCode(self) -> int**

Vehicle type code.

**def vehicleTypeName(self) -> str**

Get the vehicle type name, such as "Passenger Car".

**def name(self) -> str**

Obtain the vehicle Name.

**def vehicleDriving(self) -> Tessng.IVehicleDriving**

Obtain the vehicle driving behavior interface.

**def driving(self) -> None**

Control the vehicle. This method is invoked once for each active vehicle during every computation cycle.

**def pos(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> PySide2.QtCore.QPointF**

Obtain the current position. Unit: pixel.

**def zValue(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Obtain the current elevation. Unit: pixel.

**def acce(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Obtain the current acceleration. Unit: pixel.

**def currSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Obtain the current speed. Unit: pixel/s.

**def angle(self) -> float**

Current angle, 0° represents north, clockwise rotation.

**def isStarted(self) -> bool**

Indicates whether the vehicle is active. If False is returned, the vehicle has either exited the road network or has not yet entered the road.

**def vehicleFront(self) -> Tessng.IVehicle**

The leading vehicle object.

**def vehicleRear(self) -> Tessng.IVehicle**

The following vehicle object.

**def vehicleLFront(self) -> Tessng.IVehicle**

The front-left vehicle object.

**def vehicleLRear(self) -> Tessng.IVehicle**

The rear-left vehicle object.

**def vehicleRFront(self) -> Tessng.IVehicle**

The front-right vehicle object.

**def vehicleRRear(self) -> Tessng.IVehicle**

Right rear vehicle object.

**def vehiDistFront(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the distance to the preceding vehicle. Unit: pixel.

**def vehiSpeedFront(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the speed of the preceding vehicle. Unit: pixel/s.

**def vehiHeadwayFront(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the time headway to the preceding vehicle. Unit: second.

**def vehiDistRear(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the distance to the following vehicle. Unit: pixel.

**def vehiSpeedRear(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the speed of the following vehicle. Unit: pixel/s.

**def vehiHeadwaytoRear(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the time headway to the following vehicle. Unit: second.

**def vehiDistLLaneFront(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the distance to the left front vehicle. Unit: pixel.

**def vehiSpeedLLaneFront(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the speed of the left front vehicle. Unit: pixel.

**def vehiDistLLaneRear(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the distance to the left rear vehicle. Unit: pixel.

**def vehiSpeedLLaneRear(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the speed of the left rear vehicle. Unit: pixel.

**def vehiDistRLaneFront(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the distance to the right front vehicle. Unit: pixel.

**def vehiSpeedRLaneFront(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the speed of the right front vehicle. Unit: pixel.

**def vehiDistRLaneRear(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the distance to the right-rear vehicle. Unit: pixel.

**def vehiSpeedRLaneRear(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Retrieve the speed of the right-rear vehicle. Unit: pixel.

**def setDynaInfo(self, pDynaInfo: None) -> None**

Set dynamic information.

**def dynaInfo(self) -> None**

Retrieve dynamic information.

**def lLaneObjectVertex(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

Retrieve the set of inner points of the lane or lane connection centerline. Unit: pixel.

**def routing(self) -> Tessng.IRouting**

Current route.

**def picture(self) -> PySide2.QtGui.QPicture**

Retrieve vehicle image.

**def boundingPolygon(self) -> PySide2.QtGui.QPolygonF**

Retrieve the polygon formed by the four corners of the vehicle determined by its orientation and length.

**def setTag(self, tag: int) -> None**

Set the status represented by the label.

**def tag(self) -> int**

Retrieve the status represented by the label.

**def setTextTag(self, text: str) -> None**

Set text information used for temporarily storing data during runtime to aid development.

**def textTag(self) -> str**

Text information temporarily stored during runtime to aid development.

**def setJsonInfo(self, info: dict) -> None**

Set data in JSON format.

**def jsonInfo(self) -> dict**

Return data in JSON format.

**def jsonProperty(self, propName: str) -> any**

Return the value of a JSON field.

**def setJsonProperty(self, key: str, value: any) -> None**

Set a property in JSON data.

#### 3.4.13.2. Vehicle Driving Behavior (IVehicleDriving)

Vehicle driving behavior interface. Through this interface, lateral lane changes, setting vehicle orientation, controlling vehicle speed, coordinate position, and other parameters can be managed. **After obtaining the vehicle object `vehicle`, invoke using `vehicle.vehicleDriving().xxx()`.**

**def vehicle(self) -> Tessng.IVehicle**

The currently driven vehicle.

**def getRandomNumber(self) -> int**

Retrieve a random number.

**def nextPoint(self) -> bool**

Calculate the next position point. This process includes computing vehicle neighboring relationships, bus stop entry and exit, lane changing, acceleration, speed, travel distance, car-following type, trajectory type, and other factors.

**def zeroSpeedInterval(self) -> int**

Duration of the current speed being zero. Unit: ms.

**def isHavingDeciPointOnLink(self) -> bool**

Currently on a road segment and at a decision point.

**def followingType(self) -> int**

Type of the car-following vehicle, i.e., the type of the vehicle ahead of the current vehicle. Types include: 0: Stopped, 1: Normal, 5: Rapid deceleration, 6: Rapid acceleration, 7: Merging, 8: Crossing, 9: Cooperative deceleration, 10: Cooperative acceleration, 11: Decelerating while waiting to turn, 12: Accelerating while waiting to turn.

**def isOnRouting(self) -> bool**

Currently on the route.

**def stopVehicle(self) -> None**

Stop operation and remove the vehicle from the road network.

**def angle(self) -> float**

Rotation angle. Unit: degrees. 0 degrees points north, clockwise.

**def setAngle(self, angle: float) -> None**

Set the vehicle’s rotation angle.

Parameters: 

[ in ] angle: Rotation angle, 360 degrees in a full circle.

**def euler(self, bPositive: bool = False) -> PySide2.QtGui.QVector3D**

Returns the vehicle's Euler angles.

Parameters: 

[ in ] bPositive: Indicates whether the calculation is performed in the forward direction of the vehicle's heading; if bPositive is False, the calculation is performed in the reverse direction.

**def desirSpeed(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Gets the desired speed, unit: pixel/s.

**def getCurrRoad(self) -> Tessng.ISection**

Returns the current road segment or connector segment.

**def getNextRoad(self) -> Tessng.ISection**

Next road segment or connector segment.

**def differToTargetLaneNumber(self) -> int**

Difference from the target lane index; a non-zero value indicates a forced lane-changing intention. A value greater than 0 indicates a left lane change intention, less than 0 indicates a right lane change intention, and the absolute value represents the number of required forced lane changes.

**def toLeftLane(self, bFource: bool = False) -> None**

Left lane change.

Parameters: 

[ in ] bForce: Indicates whether to force a lane change; default is False.

Example:

```python
# Control the vehicle to change lane to the left
vehicle.vehicleDriving().toLeftLane()
```

**def toRightLane(self, bFource: bool = False) -> None**

Right lane change.

Parameters: 

[ in ] bForce: Indicates whether to force a lane change; default is False.

Example:

```python
# Control the vehicle to change lane to the right
vehicle.vehicleDriving().toRightLane()
```

**def laneNumber(self) -> int**

Current lane index, where 0 is the rightmost lane.

**def initTrace(self) -> None**

Initialize the trajectory.

**def setTrace(self, lPoint: list[PySide2.QtCore.QPointF], unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

Set the trajectory point set. Unit: pixel.

Parameters: 

[ in ] lPoint: Set of trajectory point coordinates.

**def calcTraceLength(self) -> None**

Calculate the trajectory length.

**def tracingType(self) -> int**

Return the trajectory type, classified as: 0: car following, 1: left lane change, 2: right lane change, 3: left virtual lane change, 4: right virtual lane change, 5: left turn waiting, 6: right turn waiting, 7: bay entry, 8: bay exit.

**def setTracingType(self, type: int) -> None**

Set the trajectory type.

**def setLaneNumber(self, number: int) -> None**

Set the current lane index.

Parameters: 

[ in ] number: Lane index.

**def currDistanceInRoad(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the traveled distance of the current road segment or connector segment. Unit: pixel.

**def setCurrDistanceInRoad(self, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

Set the traveled distance on the current Road Segment or Connector Segment. Unit: pixel.

Parameters: 

[ in ] dist: Distance.

**def setVehiDrivDistance(self, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

Set the total traveled mileage. Unit: pixel.

Parameters: 

[ in ] dist: Total mileage.

**def getVehiDrivDistance(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the total traveled mileage. Unit: pixel.

**def currDistanceInSegment(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get the traveled distance on the current segment. Unit: pixel.

**def setCurrDistanceInSegment(self, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

Set the traveled distance on the current segment. Unit: pixel.

Parameters: 

[ in ] dist: Distance.

**def setSegmentIndex(self, index: int) -> None**

Set the segment index.

**def setCurrDistanceInTrace(self, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

Set the traveled distance along the curved trajectory. Unit: pixel.

Parameters: 

[ in ] dist: Distance.

**def setX(self, posX: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

Set the horizontal coordinate. Unit: pixel.

Parameters: 

[ in ] posX: Horizontal coordinate.

**def setY(self, posY: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

Set the vertical coordinate. Unit: pixel.

Parameters: 

[ in ] posY: Y-coordinate.

**def setV3z(self, v3z: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> None**

Set elevation coordinate. Unit: pixel.

Parameters: 

[ in ] v3z: Elevation coordinate.

**def changingTrace(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> list[PySide2.QtCore.QPointF]**

Get lane change decision point set. Unit: pixel.

**def changingTraceLength(self, unit: UnitOfMeasure = UnitOfMeasure.Default) -> float**

Get lane change length. Unit: pixel.

**def distToStartPoint(self, fromVehiHead: bool = False, bOnCentLine: bool = True, unit: UnitOfMeasure = UnitOfMeasure: : Default) -> float**

Get distance from the start point on the lane or lane connection. Unit: pixel.

Parameters: 

[ in ] fromVehiHead: Whether to calculate from the vehicle head.

[ in ] bOnCentLine: Whether currently on the center line.

**def distToEndpoint(self, fromVehiHead: bool = False, bOnCentLine: bool = True, unit: UnitOfMeasure = UnitOfMeasure: : Default) -> float**

Get distance to the end point on the lane or lane connection. Unit: pixel.

Parameters: 

[ in ] fromVehiHead: Whether to calculate from the vehicle head.

[ in ] bOnCentLine: Whether currently on the center line.

**def setRouting(self, pRouting: Tessng.IRouting) -> bool**

Set route. The externally set route may not contain decision points and could be temporarily created; if the vehicle is not on this route, the setting will fail and return False.

Example:

```python
# 1. Use vehicle routes associated with existing decision points
routing1 = self.netiface.findRouting(1)
vehicle.vehicleDriving().setRouting(routing1)

# 2. Create vehicle routes not bound to decision points
link_id_list = [8, 16, 25]
link_list = [self.netiface.findLink(link_id) for link_id in link_id_list]
routing2 = self.netiface.createRouting(link_list)
vehicle.vehicleDriving().setRouting(routing2)
```

**def routing(self) -> Tessng.IRouting**

Current route.

**def moveToLane(self, pLane: Tessng.ILane, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

Move the vehicle to another lane. Unit: pixel.

Parameters: 

[ in ] pLane: Target lane.

[ in ] dist: Distance from the start of the target lane.

**def moveToLaneConnector(self, pLaneConnector: Tessng.ILaneConnector, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

Move the vehicle to another lane connection. Unit: pixel.

Parameters: 

[ in ] pLaneConnector: Target lane connection.

[ in ] dist: Distance from the start of the target lane connection.

**def move(self, pILaneObject: Tessng.ILaneObject, dist: float, unit: UnitOfMeasure = UnitOfMeasure.Default) -> bool**

Move the vehicle to another lane or lane connection. Unit: pixel.

Parameters: 

[ in ] pILaneObject: Target lane or lane connection.

[ in ] dist: Distance to the target starting point.

Example:

```python
from tessng import UnitOfMeasure

# Get Lane object
lane = self.netiface.findLane(6)
# Position, Unit: m
dist = 50
# Move the vehicle to the specified lane and position, enabling instantaneous relocation of the vehicle.
vehicle.vehicleDriving().move(lane, dist, UnitOfMeasure.Metric)
```

#### 3.4.13.3. Pedestrian (IPedestrian)

**def getId(self) -> int**

Retrieve pedestrian ID.

**def getRadius(self) -> float**

Retrieve pedestrian radius, unit: m.

**def getWeight(self) -> float**

Retrieve pedestrian mass, unit: kg.

**def getColor(self) -> str**

Retrieve pedestrian color, in RGB format, e.g.: "#EE0000".

**def getPos(self) -> PySide2.QtCore.QPointF**

Retrieve pedestrian current position, unit: m.

**def getAngle(self) -> float**

Retrieve pedestrian current angle in the Qt coordinate system, with the positive x-axis as 0 and positive direction counterclockwise.

**def getDirection(self) -> PySide2.QtGui.QVector2D**

Retrieve pedestrian current two-dimensional direction vector.

**def getElevation(self) -> float**

Retrieve pedestrian current elevation, unit: m.

**def getSpeed(self) -> PySide2.QtGui.QVector2D**

Retrieve pedestrian current speed, unit: m/s.

**def getDesiredSpeed(self) -> float**

Retrieve pedestrian desired speed, unit: m/s.

**def getMaxSpeed(self) -> float**

Retrieve pedestrian maximum speed limit, unit: m/s.

**def getAcce(self) -> PySide2.QtGui.QVector2D**

Retrieve pedestrian current acceleration, unit: m/s².

**def getMaxAcce(self) -> float**

Retrieve pedestrian maximum acceleration limit, unit: m/s².

**def getEuler(self) -> PySide2.QtGui.QVector3D**

Retrieve pedestrian Euler angles.

**def getSpeedEuler(self) -> PySide2.QtGui.QVector3D**

Retrieve pedestrian velocity Euler angles.

**def getWallFDirection(self) -> PySide2.QtGui.QVector2D**

Retrieve wall direction unit vector.

**def getRegion(self) -> Tessng.IPedestrianRegion**

Retrieve the pedestrian's current surface domain.

**def getPedestrianTypeId(self) -> int**

Retrieve pedestrian type ID.

**def stop(self) -> None**

Stop simulation; the pedestrian will be removed in the next simulation batch, releasing resources.

<div style="page-break-after: always;"></div>

# 4. High-frequency Interfaces

This section provides commonly used API code examples for secondary development of TESS NG.



## 4.1. Road Network Modeling

### 4.1.1. Creating Road Segments and Connector Segments

The code for creating road segments and connector segments is as follows. **Additionally, the open-source road network editing tool pytessng (implemented using TESS NG Python secondary development) supports importing data in OpenDrive, Shape, OpenStreetMap, and other formats to create road networks. For detailed usage, please refer to [pytessng · PyPI](https://pypi.org/project/pytessng/) .**

```python
from PySide2.QtCore import QPointF
from tessng import UnitOfMeasure

# ==================== Creating Road Segments ====================
# Create the first road segment: Cao'an Highway
start_point = QPointF(-300, 0)
end_point = QPointF(300, 0)
link_points = [start_point, end_point]
link1 = self.netiface.createLink(link_points, 7, "Cao'an Highway", True, UnitOfMeasure.Metric)
if link1 is not None:
    # List of lanes
    lanes = link1.lanes()
    # Print all lane IDs of this road segment
    print("Cao'an Highway lane ID list: ", [lane.id() for lane in lanes])
    # Create a departure point within the current road segment
    dp = self.netiface.createDispatchPoint(link1)
    if dp is not None:
        # Set departure intervals, including vehicle type composition, time intervals, and number of departures
        dp.addDispatchInterval(1, 2, 28)

# Create the second road segment
start_point = QPointF(-300, -25)
end_point = QPointF(300, -25)
link_points = [start_point, end_point]
link2 = self.netiface.createLink(link_points, 7, "Secondary Arterial Road", True, UnitOfMeasure.Metric)
if link2 is not None:
    # Create a departure point within the current road segment
    dp = self.netiface.createDispatchPoint(link2)
    if dp is not None:
        # Set departure intervals, including vehicle type composition, time intervals, and number of departures
        dp.addDispatchInterval(1, 3600, 3600)
    # Designate the outermost lane as a dedicated bus lane
    lanes = link2.lanes()
    lane = lanes[0]
    lane.setLaneType("Bus-only Lane")

# Create the third road segment
start_point = QPointF(-300, 25)
end_point = QPointF(-150, 25)
link_points = [start_point, end_point]
link3 = self.netiface.createLink(link_points, 3, "link3", True, UnitOfMeasure.Metric)
if link3 is not None:
    # Create a departure point within the current road segment
    dp = self.netiface.createDispatchPoint(link3)
    if dp is not None:
        # Set departure intervals, including vehicle type composition, time intervals, and number of departures
        dp.addDispatchInterval(1, 3600, 3600)

# Create the fourth road segment
start_point = QPointF(-50, 25)
end_point = QPointF(50, 25)
link_points = [start_point, end_point]
link4 = self.netiface.createLink(link_points, 3, "link4", True, UnitOfMeasure.Metric)

# Create the fifth road segment
start_point = QPointF(150, 25)
end_point = QPointF(300, 25)
link_points = [start_point, end_point]
link5 = self.netiface.createLink(link_points, 3, "Custom Speed Limit Segment", True, UnitOfMeasure.Metric)
if link5 is not None:
    # Set road segment speed limit, unit: km/h
    link5.setLimitSpeed(30)

# Create the sixth road segment
start_point = QPointF(-300, 50)
end_point = QPointF(300, 50)
link_points = [start_point, end_point]
link6 = self.netiface.createLink(link_points, 3, "Dynamic Dispatch Segment", True, UnitOfMeasure.Metric)
if link6 is not None:
    # Set road segment speed limit, unit: km/h
    link6.setLimitSpeed(80)

# Create the seventh road segment
start_point = QPointF(-300, 75)
end_point = QPointF(-250, 75)
link_points = [start_point, end_point]
link7 = self.netiface.createLink(link_points, 3, "link7", True, UnitOfMeasure.Metric)
if link7 is not None:
    # Set road segment speed limit, unit: km/h
    link7.setLimitSpeed(80)

# Create the eighth road segment
start_point = QPointF(-50, 75)
end_point = QPointF(300, 75)
link_points = [start_point, end_point]
link8 = self.netiface.createLink(link_points, 3, "link8", True, UnitOfMeasure.Metric)
if link8 is not None:
    # Set road segment speed limit, unit: km/h
    link8.setLimitSpeed(80)

# ==================== Create connector segment ====================
# Create the first connector segment, connecting link3 and link4
if link3 is not None and link4 is not None:
    from_lane_numbers = [1, 2, 3]
    to_lane_numbers = [1, 2, 3]
    connector1 = self.netiface.createConnector(link3.id(), link4.id(), from_lane_numbers, to_lane_numbers, "Connector 1", True)

# Create the second connector segment, connecting link4 and link5
if link4 is not None and link5 is not None:
    from_lane_numbers = [1, 2, 3]
    to_lane_numbers = [1, 2, 3]
    connector2 = self.netiface.createConnector(link4.id(), link5.id(), from_lane_numbers, to_lane_numbers, "Connector 2", True)

# Create the third connector segment, connecting link7 and link8
if link7 is not None and link8 is not None:
    from_lane_numbers = [1, 2, 3]
    to_lane_numbers = [1, 2, 3]
    connector3 = self.netiface.createConnector(link7.id(), link8.id(), from_lane_numbers, to_lane_numbers, "Dynamic Dispatch Connector", True)
```

### 4.1.2. Create various data collection devices

Various data collection devices include: data collectors, queue counters, and travel time detectors. The code for creating them is as follows.

```python
# ==================== Create data collector ====================
# Get Lane object
lane = self.netiface.findLane(1)
# Position, Unit: m
dist = 50
# Create data collector on Road Segment
collector = self.netiface.createVehiCollectorOnLink(lane, dist, UnitOfMeasure.Metric)

# Get Lane Connection object
lane_connector = self.netiface.findLaneConnector(1, 4)
# Position, Unit: m
dist = 50
# Create data collector on Connector Segment
collector = self.netiface.createVehiCollectorOnConnector(lane_connector, dist, UnitOfMeasure.Metric)

# ==================== Create queue counter ====================
# Get Lane object
lane = self.netiface.findLane(1)
# Position, Unit: m
dist = 80
# Create a queue counter on a road segment
counter = self.netiface.createVehiQueueCounterOnLink(lane, dist, UnitOfMeasure.Metric)

# Get Lane Connection object
lane_connector = self.netiface.findLaneConnector(1, 4)
# Position, Unit: m
dist = 80
# Create a queue counter on a connector segment
counter = self.netiface.createVehiQueueCounterOnConnector(lane_connector, dist, UnitOfMeasure.Metric)

# ==================== Create queue time detector ====================
# Get the starting road segment object
start_link = self.netiface.findLink(1)
# Get the ending road segment object
end_link = self.netiface.findLink(2)
# Detector start position on the starting road segment, unit: m
start_dist = 10
# Detector end position on the ending road segment, unit: m
end_dist = 90
# Create a travel time detector with both start and end points on road segments
detectors = self.netiface.createVehicleTravelDetector_link2link(start_link, end_link, start_dist, end_dist, UnitOfMeasure.Metric)

# Get the starting road segment object
start_link = self.netiface.findLink(1)
# Get the ending lane connection object
end_lane_connector = self.netiface.findLaneConnector(1, 4)
# Detector start position on the starting road segment, unit: m
start_dist = 10
# Detector end position on the ending lane connection, unit: m
end_dist = 10
# Create a travel time detector with start on road segment and end on connector segment
detectors = self.netiface.createVehicleTravelDetector_link2conn(start_link, end_lane_connector, start_dist, end_dist, UnitOfMeasure.Metric)

# Get the starting Lane Connection object
start_lane_connector = self.netiface.findLaneConnector(1, 4)
# Get the ending road segment object
end_link = self.netiface.findLink(2)
# Position of the detector start point on the starting Lane Connection, unit: m
start_dist = 10
# Detector end position on the ending road segment, unit: m
end_dist = 90
# Create a travel time detector with start point on Connector Segment and end point on Road Segment
detectors = self.netiface.createVehicleTravelDetector_conn2link(start_lane_connector, end_link, start_dist, end_dist, UnitOfMeasure.Metric)

# Get the starting Lane Connection object
start_lane_connector = self.netiface.findLaneConnector(1, 4)
# Get the ending road segment object
end_lane_connector = self.netiface.findLaneConnector(4, 7)
# Position of the detector start point on the starting Lane Connection, unit: m
start_dist = 10
# Detector end position on the ending lane connection, unit: m
end_dist = 90
# Create a travel time detector with both start and end points on Connector Segment
detectors = self.netiface.createVehicleTravelDetector_conn2conn(start_lane_connector, end_lane_connector, start_dist, end_dist, UnitOfMeasure.Metric)
```

### 4.1.3. Create directional arrows

The code for creating directional arrows is as follows.

```python
from tessng import Online, UnitOfMeasure

lane = self.netiface.findLane(4)
if lane is not None:
    length = 4
    dist_to_terminal = 10
    arrow_type = Online.GuideArrowType.StraightRight
    guid_arrow = self.netiface.createGuidArrow(lane, length, dist_to_terminal, arrow_type, UnitOfMeasure.Metric)
```

### 4.1.4. Creating Bus Stops and Bus Routes

​	The code for creating bus stops and bus routes is as follows.

```python
# Create bus stops
lane = self.netiface.findLane(1)
bus_station = self.netiface.createBusStation(lane, 30, 50, "Bus station 1", UnitOfMeasure.Metric)
# Set station type 1: Curbside, 2: Bay
bus_station.setType(1)

# Create bus routes
link1 = self.netiface.findLink(1)
link2 = self.netiface.findLink(2)
bus_line = self.netiface.createBusLine([link1, link2])

# Associate bus routes with bus stops
result = self.netiface.addBusStationToLine(bus_line, bus_station)
# Association successful
if result:
    # Retrieve all bus stops on a bus route
    station_line_list = bus_line.stationLines()
    # Retrieve the first bus stop
    station_line = station_line_list[0]
    # Set vehicle dwell time, Unit: s
    station_line.setBusParkingTime(20)
```

### 4.1.5. Creating Various Event Areas

​	Various event areas include accident areas, construction zones, restriction zones, and reconstruction and expansion detours. The code to create them is as follows.

```python
from tessng import Online, UnitOfMeasure

# ==================== Create accident area ====================
# Construction Parameters
param = Online.DynaAccidentZoneParam()
# Accident Area Name
param.name = "Accident Zone"
# Road ID
param.roadId = 1
# Position, distance from the start point of the road segment or connector segment, unit: m
param.location = 100
# Length, unit: m
param.length = 50
# List of lane indices, starting from 0, continuous and sequential
param.mlFromLaneNumber = [0]
# Start Time (Unit: s)
param.startTime= 10
# Duration, unit: s
param.duration = 600
# Speed limit of adjacent lanes, unit: km/h
param.limitSpeed = 40
# Create accident area
accident_zone = self.netiface.createAccidentZone(param, UnitOfMeasure.Metric)

# ==================== Create construction zone ====================
# Construction Parameters
param = Online.DynaRoadWorkZoneParam()
# Construction Zone Name
param.name= "Construction Zone"
# Road ID
param.roadId = 1
# Position, distance from the start point of the road segment or connector segment, unit: m
param.location = 200
# Length, unit: m
param.length = 50  # Length
param.upCautionLength = 70  # Advance Warning Length
param.upTransitionLength = 50  # Transition Zone Length
param.upBufferLength = 50  # Buffer Zone Length
param.downTransitionLength = 40  # Downstream Transition Zone Length
param.downTerminationLength = 40  # Termination Zone Length
# List of lane indices, starting from 0, continuous and sequential
param.mlFromLaneNumber = [0]
# Start Time (Unit: s)
param.startTime = 0
# Duration, unit: s
param.duration = 3600
# Speed limit of adjacent lanes, unit: km/h
param.limitSpeed = 40
# Create Construction Zone
road_work_zone = self.netiface.createRoadWorkZone(param, UnitOfMeasure.Metric)

# ==================== Create restriction zone ====================
# Construction Parameters
param = Online.DynaLimitedZoneParam()
# Restricted Zone Name
param.name = "Restricted Zone"
# Road ID
param.roadId = 1
# Position, distance from the start point of the road segment or connector segment, unit: m
param.location = 100
# Length, unit: m
param.length = 50
# List of lane indices, starting from 0, continuous and sequential
param.mlFromLaneNumber = [0]
# Start Time (Unit: s)
param.startTime = 0
# Duration, unit: s
param.duration = 600
# Speed limit of adjacent lanes, unit: km/h
param.limitSpeed = 40
# Create Restricted Zone
limited_zone = self.netiface.createLimitedZone(param, UnitOfMeasure.Metric)

# ==================== Create reconstruction and expansion detour ====================
# Construction Parameters
param = Online.DynaReconstructionParam()
# Construction Zone ID
param.roadWorkZoneId = rwz_id
# Borrowed Road Segment ID
param.beBorrowedLinkId = 2
# Number of Borrowed Lanes
param.borrowedNum = 1
# Traffic Maintenance Opening Length, Unit: m
param.passagewayLength = 80
# Traffic Maintenance Opening Speed Limit, Unit: m/s
param.passagewayLimitedSpeed = 40 / 3.6
# Create Reconstruction and Expansion Lane Borrowing
reconstruction = self.netiface.createReconstruction(param, UnitOfMeasure.Metric)
```



## 4.2. Demand Modeling

### 4.2.1. Setting Departures

​	Departures can be batch-configured through departure points **before simulation**, or dynamically created as individual vehicles **during simulation**.

(1) Before starting the simulation, the code for creating vehicle types, vehicle compositions, departure points, and departure flows is as follows.

```python
from tessng import _VehicleType

# ==================== Create Vehicle Type ====================
# Construction Parameters
vehicle_type = _VehicleType()
vehicle_type.vehicleTypeName = "Vehicle Type 1"  # Vehicle Type Name
vehicle_type.Length = 4.5  # Length, Unit: m
vehicle_type.lengthSD = 0.5  # Length Standard Deviation, Unit: m
vehicle_type.width = 2  # Width, Unit: m
vehicle_type.widthSD = 0.2  # Width Standard Deviation, Unit: m
vehicle_type.avgSpeed = 60  # Desired Speed, Unit: km/h
vehicle_type.speedSD = 10  # Desired Speed Standard Deviation, Unit: km/h
vehicle_type.avgAcce = 4  # Desired Acceleration, Unit: m/s²
vehicle_type.acceSD = 0.5  # Desired Acceleration Standard Deviation, Unit: m/s²
vehicle_type.avgDece = 6  # Desired Deceleration, Unit: m/s²
vehicle_type.deceSD = 0.5  # Desired Deceleration Standard Deviation, Unit: m/s²
vehicle_type.maxAcce = 5.5  # Maximum Acceleration, Unit: m/s²
vehicle_type.maxDece = 7.5  # Maximum Deceleration, Unit: m/s²
vehicle_type.maxSpeed = 80  # Maximum speed, Unit: km/h
vehicle_type.commercialVehicle = False  # Whether it is a commercial vehicle
vehicle_type.maxPassengerCapacity = 1  # Rated passenger capacity, Unit: persons
# Create vehicle type
result = self.netiface.createVehicleType(vehicle_type)
print(f"Vehicle type creation success: {result}")

# ==================== Create Vehicle Composition ====================
# Construct vehicle type proportion list
vehi_type_proportion_list = [
    Online.VehiComposition(1, 0.3),  # Passenger car, proportion 0.3
    Online.VehiComposition(2, 0.2),  # Large bus, proportion 0.2
    Online.VehiComposition(3, 0.1),  # Bus, proportion 0.1
    Online.VehiComposition(4, 0.4)   # Truck, proportion 0.4
]
# Create vehicle composition
vehi_composition_id = self.netiface.createVehicleComposition("New Vehicle Composition", vehi_type_proportion_list)

# ==================== Create Departure Point ====================
# Retrieve road segment object
link = self.netiface.findLink(1)
# Create departure point
dp = self.netiface.createDispatchPoint(link)
if dp is not None:
    # Add departure interval, including vehicle type composition, time interval, and departure count
    dp.addDispatchInterval(1, 600, 300)
    dp.addDispatchInterval(1, 600, 400)
```

(2) During the simulation, without using departure points, the code for creating a single vehicle at a specified location is as follows.

```python
from tessng import m2p

# ==================== Create Vehicle on Road Segment ====================
# Construction Parameters
dvp1 = Online.DynaVehiParam()
# Vehicle type ID
dvp1.vehiTypeCode = 1
# Road Segment ID
dvp1.roadId = 4
# Lane Index
dvp1.laneNumber = 0
# Position, Unit: m
dvp1.dist = m2p(50)
# Speed, Unit: m/s
dvp1.speed = m2p(20)
# Color
dvp1.color = "#00AFF0"
# Dynamically create vehicle
vehicle1 = self.simuiface.createGVehicle(dvp)
if vehicle1:
    print(f"Vehicle created on link, ID: {vehicle1.id()}")

# ==================== Create Vehicle on Connector Segment ====================
# Construction Parameters
dvp2 = Online.DynaVehiParam()
# Vehicle type ID
dvp2.vehiTypeCode = 1
# Connector Segment ID
dvp2.roadId = 4
# Upstream road segment lane index
dvp2.laneNumber = 0
# Downstream road segment lane index
dvp2.toLaneNumber = 0
# Position, Unit: m
dvp2.dist = m2p(10)
# Speed, Unit: m/s
dvp2.speed = m2p(20)
# Color
dvp2.color = "#00AFF0"
# Dynamically create vehicle
vehicle2 = self.simuiface.createGVehicle(dvp2)
if vehicle2:
    print(f"Vehicle created on connector, ID: {vehicle2.id()}")
```

### 4.2.2. Setting Route

Routes can be set to allocate flow proportions based on decision points either before or during the simulation, or a specific route can be directly assigned to an individual vehicle.	

(1) Before starting the simulation, the code for creating decision points and updating their routes and route flow proportions is as follows.

```python
from tessng import _RoutingFLowRatio, _DecisionPoint

# ============================== Create Decision Point ==============================
link = self.netiface.findLink(1)
location = 50
decision_point_name = "New Decision Point"
decision_point = self.netiface.createDecisionPoint(link, location, decision_point_name, UnitOfMeasure.Metric)

# ==================== Create Vehicle Routes for Decision Point ====================
# List of Road Segment IDs
link_id_list_1 = [1, 2]
link_id_list_2 = [1, 3]
link_id_list_3 = [1, 4]

# Construct the list of road segment objects
link_list_1 = [self.netiface.findLink(link_id) for link_id in link_id_list_1]
link_list_2 = [self.netiface.findLink(link_id) for link_id in link_id_list_2]
link_list_3 = [self.netiface.findLink(link_id) for link_id in link_id_list_3]

# Create Vehicle Routes for Decision Point
routing1 = self.netiface.createDeciRouting(decision_point, link_list_1)
routing2 = self.netiface.createDeciRouting(decision_point, link_list_2)
routing3 = self.netiface.createDeciRouting(decision_point, link_list_3)

# ==================== Update Decision Point Route Flow Ratio Configuration ====================
# Initialize left, straight, and right flow ratio objects
flowRatio_left = _RoutingFLowRatio()
flowRatio_left.RoutingFLowRatioID = 1
flowRatio_left.routingID = decisionRouting1.id()
flowRatio_left.startDateTime = 0
flowRatio_left.endDateTime = 999999
flowRatio_left.ratio = 2.0

flowRatio_straight = _RoutingFLowRatio()
flowRatio_straight.RoutingFLowRatioID = 2
flowRatio_straight.routingID = decisionRouting2.id()
flowRatio_straight.startDateTime = 0
flowRatio_straight.endDateTime = 999999
flowRatio_straight.ratio = 3.0

flowRatio_right = _RoutingFLowRatio()
flowRatio_right.RoutingFLowRatioID = 3
flowRatio_right.routingID = decisionRouting3.id()
flowRatio_right.startDateTime = 0
flowRatio_right.endDateTime = 999999
flowRatio_right.ratio = 1.0

# Initialize Decision Point data
decision_point_data = _DecisionPoint()
decision_point_data.deciPointID = decision_point.id()
decision_point_data.deciPointName = decision_point.name()
decisionPoint_pos = QPointF()
if decisionPoint.link().getPointByDist(decision_point.distance(), decisionPoint_pos): 
    decision_point_data.X = decisionPoint_pos.x()
    decision_point_data.Y = decisionPoint_pos.y()
    decision_point_data.Z = decision_point.link().z()

# Construct flow ratio list
flow_ratio_list = [flowRatio_left, flowRatio_straight, flowRatio_right]
# Update Decision Point Route Flow Ratio Configuration
updated_decision_point = self.netiface.updateDecipointPoint(decision_point_data, flow_ratio_list)
```

(2) During simulation, the code for dynamically modifying the route flow ratios of existing decision points is as follows.

```python
# MySimulator.py

def calcDynaFlowRatioParameters(self) -> list:
    # Current simulation calculation batch.
    batch_number = self.simuiface.batchNumber()
    # Modify the flow ratio of each route at a decision point during the 20th calculation batch.
    if batch_number == 20:
        # Vehicle allocation ratio for each route at a decision point during a specific time period.
        dfi = Online.DecipointFlowRatioByInterval()
        # Decision Point ID
        dfi.deciPointID = 5
        # Start Time (Unit: seconds)
        dfi.startDateTime = 1
        # End Time (Unit: seconds)
        dfi.endDateTime = 999999
        # Route Flow Ratio
        rfr1 = Online.RoutingFlowRatio(1, 3)
        rfr2 = Online.RoutingFlowRatio(2, 4)
        rfr3 = Online.RoutingFlowRatio(3, 3)
        dfi.mlRoutingFlowRatio = [rfr1, rfr2, rfr3]
        return [dfi]
    return []
```

(3) During simulation, the code for setting routes for vehicles is as follows.

```python
# 1. Use vehicle routes associated with existing decision points
routing1 = self.netiface.findRouting(1)
vehicle.vehicleDriving().setRouting(routing1)

# 2. Create vehicle routes not bound to decision points
link_id_list = [8, 16, 25]
link_list = [self.netiface.findLink(link_id) for link_id in link_id_list]
routing2 = self.netiface.createRouting(link_list)
vehicle.vehicleDriving().setRouting(routing2)
```




## 4.3 Traffic Signal Control

### 4.3.1 Create Signal Controller, Traffic Signal Control Scheme, Traffic Signal Phases, and Traffic Signals

Before starting the simulation, signal controllers, traffic signal control schemes, traffic signal phases, and traffic signals can be created sequentially. During this creation process, the binding relationships are established synchronously: **Traffic Signal → Traffic Signal Phase → Traffic Signal Control Scheme → Signal Controller**. The code is as follows.

```python
from tessng import Online

# ==================== Create a signal controller (usually one signal controller corresponds to one intersection). ====================
# Signal Controller Name
signal_controller_name = "Intersection of Shuanglong Avenue and Jiyin Avenue"
# Create Signal Controller
signal_controller = self.netiface.createSignalController(signal_controller_name)

# ==================== Create a traffic signal control scheme (a signal controller can be configured with multiple traffic signal control schemes for different time periods). ====================
# Get the signal controller object
signal_controller = self.netiface.findSignalControllerById(1)
# Traffic signal control scheme name
signal_plan_name = "Off-Peak Plan"
# Cycle duration, Unit: s
cycle_time = 120
# Phase difference, Unit: s
phase_difference = 0
# Start time, Unit: s
start_time = 0
# End Time (Unit: s)
end_time = 3600
# Create traffic signal control scheme
signal_plan = self.netiface.createSignalPlan(signal_controller, signal_plan_name, cycle_time, phase_difference, start_time, end_time)

# ==================== Create traffic signal phases (a traffic signal control scheme needs to assign phases for different directions or turning movements). ====================
# Retrieve traffic signal control phase object
signal_plan = self.netiface.findSignalPlanById(1)
# Phase Name
signal_phase_name = "East-West Through"
# Build list of light color objects
color = ["R", "G", "Y", "R"]
intervals = [30, 26, 3, 61]
color_interval_list = [
    Online.ColorInterval(color, duration)
    for color, duration in zip(colors, durations)
]
# Create traffic signal phase
signal_phase = self.netiface.createSignalPlanSignalPhase(signal_plan, signal_phase_name, color_interval_list)

# ==================== Create traffic signals (one phase controls the traffic signals of multiple lanes). ====================
# Get phase object
signal_phase = self.netiface.findSignalPhase(1)
# Traffic signal name
signal_lamp_name = "East Through 1"
# Lane ID
lane_id = 1
# Downstream Lane ID
to_lane_id = -1
# Position, Unit: m
distance = m2p(50)
# Create traffic signal
signal_lamp = self.netiface.createSignalLamp(signal_plan, signal_lamp_name, lane_id, to_lane_id, distance)
```

### 4.3.2. Controlling Traffic Signal Light Colors

Light color settings can be modified at two levels of granularity: by **traffic signal control phase** or by **individual traffic signal**.

(1) The code below demonstrates how to modify the light color and duration by traffic signal control phase before or during simulation.

```python
from tessng import Online

# Construct a list of lamp color and duration objects
color_obj_list = [
    Online.ColorInterval("R", 10),  # Red, duration 10
    Online.ColorInterval("G", 60),  # Green, duration 60
    Online.ColorInterval("Y", 3),  # Yellow, duration 3
    Online.ColorInterval("R", 17)  # Red, duration 17
]
# Find the traffic signal phase with ID 7
signal_phase = netiface.findSignalPhase(7)
if signal_phase:
    # Set the list of light colors
	signal_phase.setColorList(color_list)
```

After creating signal controllers, traffic signal control schemes, traffic signal phases, and traffic signals in the road network, if you need to modify the traffic signal control scheme of a single intersection during simulation, please refer to the following example code. Prior to use, record the phase IDs corresponding to each phase.

```python
from tessng import Online

def afterOneStep(self) -> None:
    # Get the current simulation time, Unit: ms
    simu_time = self.simuiface.simuIntervalScheming()
    
    # Arrive at the specified time point
    if simu_time == 60 * 1000:
        # List of traffic signal phase IDs and durations for different control phases within a single intersection's traffic signal control scheme
        signal_interval_mapping = {
            "East-West Through": {
                "signalPhaseId": 1,  # Corresponding traffic signal phase IDs
                "instervals": [0, 31, 3, 86],  # Corresponding list of durations for traffic signal colors (red, green, yellow, red)
            },
            "East-West Left Turn": {
                "signalPhaseId": 2,
                "instervals": [35, 21, 3, 61],
            },
            "North-South Through": {
                "signalPhaseId": 3,
                "instervals": [60, 31, 3, 26],
            },
            "North-South Left Turn": {
                "signalPhaseId": 4,
                "instervals": [95, 21, 3, 1],
            },
        }
    
        # Set according to traffic signal phases
        for signal_phase_name, signal_phase_data in signal_interval_mapping.items():
            # Get traffic signal phase ID
            signal_phase_id = signal_phase_data["signalPhaseId"]
            # Retrieve traffic signal control phase object
            signal_phase = self.netiface.findSignalPhase(signal_phase_id)
            if signal_phase is None:
                continue
            # Duration list
            instervals = signal_phase_data["instervals"]
            # Construct a list of lamp color and duration objects
            color_obj_list = [
                Online.ColorInterval("R", instervals[0]),  # Red
                Online.ColorInterval("G", instervals[1]),  # Green
                Online.ColorInterval("Y", instervals[2]),  # Yellow
                Online.ColorInterval("R", instervals[3]),  # Red
            ]
            # Set a new duration scheme for a traffic signal phase
            signal_phase.setColorList(color_list)
```

(2) During the simulation, the code for directly modifying the traffic light color by individual signal light is as follows. Since this operation essentially modifies or overrides the computed results of TESS NG, such adjustments **only take effect within the current frame**. This means that **the setting operation cannot be performed only once at a specific moment when the condition is met but must be continuously executed throughout the entire time interval during which the condition holds true.**

```python
# MySimulator.py
from tessng import ISignalLamp

def calcLampColor(self, pSignalLamp: ISignalLamp) -> bool:
    # Get the current simulation time, Unit: ms
    simu_time = self.simuiface.simuIntervalScheming()
    # If the traffic signal ID is 1 and within the specified time range, set it to green
	if pSignalLamp.id() == 1 && (60 * 1000 <= simu_time <= 90 * 1000): 
		pSignalLamp.setLampColor("G")
		return True
	return False
```



## 4.4. Vehicle Control

### 4.4.1. Setting Vehicle Desired Speed

During the simulation process, the code for setting the vehicle's desired speed is as follows.

```python
# Set the vehicle's desired speed, Unit: pixel/s
vehicle.setDesirSpeed(m2p(80 / 3.6))
```

### 4.4.2. Setting Vehicle Speed

During the simulation process, the code for setting the vehicle's speed is as follows.

```python
# MySimulator.py
from tessng import IVehicle, objreal, objUnitOfMeasure

# Unit: m/s
def ref_reSetSpeed_unit(self, vehicle: IVehicle, ref_inOutSpeed: objreal, ref_unit: objUnitOfMeasure) -> bool:
    if vehicle.id() == 100001:
        # Directly specify the vehicle’s speed
        ref_inOutSpeed.value = 80 / 3.6;
        return True
    return False
```

### 4.4.3. Setting Vehicle Acceleration

The code for setting vehicle acceleration is as follows.

```python
# MySimulator.py
from tessng import IVehicle, objreal, objUnitOfMeasure

# This function is executed before TESS NG calculates acceleration, unit: m/s²
def ref_calcAcce_unit(self, pIVehicle: IVehicle, ref_acce: objreal, ref_unit: objUnitOfMeasure) -> bool:
    if pIVehicle.roadName() == "Caoan Highway":
        # Calculate acceleration directly based on speed differences.
        if pIVehicle.currSpeed() > 20/3.6:
            ref_acce.value = -3
            return True;
        elif pIVehicle.currSpeed() > 10/3.6:
            ref_acce.value = -1
          	return True
	return False

# This function is executed after TESS NG calculates acceleration, unit: m/s²
def ref_reSetAcce_unit(self, pIVehicle: IVehicle, ref_inOutAcce: objreal, ref_unit: objUnitOfMeasure) -> bool:
    if pIVehicle.roadName() == "Caoan Highway":
        # Adjust the calculated acceleration based on the speed
        if pIVehicle.currSpeed() > 20/3.6:
            acce.value += -3
            return True
        elif pIVehicle.currSpeed() > 10/3.6:
            acce.value += -1
          	return True
	return False
```

### 4.4.4. Setting Vehicle Lane Changing

The code to control vehicle lane changing to the left or right is as follows.

```python
# Control the vehicle to change lane to the left
vehicle.vehicleDriving().toLeftLane()

# Control the vehicle to change lane to the right
vehicle.vehicleDriving().toRightLane()
```

The code to cancel vehicle lane changing is as follows.

```python
# MySimulator.py
from tessng import IVehicle

def reCalcDismissChangeLane(self, pIVehicle: IVehicle) -> bool:
    # Cancel all free lane changing when the distance to the end of the road segment is less than 50 m, thereby prohibiting free lane changing
	if pIVehicle.vehicleDriving().distToEndpoint(True, True, UnitOfMeasure.Metric) < 50:
        return True
    return False
```

### 4.4.5. Setting Vehicle Lane Restrictions

The code to set vehicle lane restrictions is as follows.

```python
# MySimulator.py
from tessng import IVehicle

def calcLimitedLaneNumber(self, pIVehicle: IVehicle) -> list[int]:
    # If the vehicle is on the road segment and its length exceeds 8 m, entering the innermost lane is prohibited
    if pIVehicle.roadIsLink() and pIVehicle.length(UnitOfMeasure.Metric) > 8:
       limit_lane_number = pIVehicle.lane().link().laneCount()
       return [limit_lane_number]
    return []
```

### 4.4.6. Setting Vehicle Route

The code to set vehicle route is as follows.

```python
# 1. Use vehicle routes associated with existing decision points
routing1 = self.netiface.findRouting(1)
vehicle.vehicleDriving().setRouting(routing1)

# 2. Create vehicle routes not bound to decision points
link_id_list = [8, 16, 25]
link_list = [self.netiface.findLink(link_id) for link_id in link_id_list]
routing2 = self.netiface.createRouting(link_list)
vehicle.vehicleDriving().setRouting(routing2)
```

### 4.4.7. Setting Vehicle Car-Following Parameters

The code to set vehicle car-following parameters is as follows. **Currently, only parameter modification for the IDM Car-Following Model is supported.**

```python
from tessng import m2p

# Set the desired acceleration unit for the vehicle: pixel/s²
vehicle.setDesirAcce(m2p(5.5))

# Set the vehicle's maximum deceleration, unit: pixel/s²
vehicle.setMaxDece(m2p(7.5))

# Set the vehicle's safe time headway, unit: seconds
vehicle.vehicleDriving().setSafeTimeInterval(1.5)

# Set the vehicle's stopping distance, unit: pixel
vehicle.vehicleDriving().setStoppingDistance(m2p(2))
```

### 4.4.8. Set Vehicle Jump

The code to configure vehicle jump is as follows.

```python
from PySide2.QtCore import QPointF
from tessng import UnitOfMeasure

# Target Point
target_point = QPointF(50, 50);
# Project the target point onto lanes within a specified nearby range to obtain the position information sequence.
locations = self.netiface.locateOnCrid(target_point, 9, UnitOfMeasure.Metric);  # Execute netiface.buildNetGrid(10) before use.
# If the lane object is located
if locations:
    location = locations[0]
    # Lane object
    lane_obj = location.pLaneObject
    # Position, Unit: m
    dist = location.distToStart

    # Move the vehicle to the specified lane and position, enabling instantaneous relocation of the vehicle.
    vehicle.vehicleDriving().move(lane_obj, dist, UnitOfMeasure.Metric)
```

### 4.4.9. Set Vehicle Information and Visualization

The code to configure vehicle information is as follows.

```python
# MySimulator.py
from tessng import IVehicle

def vehiRunInfo(self, pIVehicle: IVehicle) -> str:
	return f"The vehicle is currently on the road with ID={pIVehicle.roadId()}"
```

The code to set vehicle color is as follows.

```python
# Set vehicle color to blue
vehicle.setColor("#00AFF0")
```

The code to configure vehicle visualization is as follows.

```python
# MySimulator.py
from PySide2.QtCore import QPointF
from PySide2.QtGui import QPainter, QFont, QPainterPath, QFontMetrics, QColor
from tessng import IVehicle

def rePaintVehicle(self, pIVehicle: IVehicle, painter: QPainter) -> None:
    # Add vehicle name label on the vehicle body.
    label: str = vehicle.name()

    # Create a QFont object and set the font and size.
    font = QFont('Arial', 1)
    # Set the font to non-bold.
    font.setBold(False)

    # Create a QFontMetrics object to obtain font metric information.
    fontMetrics = QFontMetrics(font)
    # Obtain the bounding rectangle of the text
    boundingRect = fontMetrics.boundingRect(label)
    # Compute the text position
    new_x = -boundingRect.center().x() - vehicle.width() * 0.5
    new_y = -boundingRect.center().y()
    position = QPointF(new_x, new_y)

    # Create a QPainterPath object to render the text
    textPath = QPainterPath()
    # Add the text to the path
    textPath.addText(position, font, label)
    
    # Set the pen's scaling factor
    painter.scale(1, 1)
    # Fill the path to render the text
    painter.fillPath(textPath, QColor("#c94f4f"))
```



## 4.5. Simulation Control

### 4.5.1. Set Simulation Parameters

Before starting the simulation, the code to set simulation parameters is as follows.

```python
# MySimulator.py

# Configure the following parameters before starting the simulation
def beforeStart(self, keep_on: bool) -> None:
    # Set simulation speed multiplier
    self.simuiface.setAcceMultiples(5)
    # Set simulation duration, Unit: s
    self.simuiface.setSimuIntervalScheming(3600)
    # Set simulation accuracy
    self.simuiface.setSimuAccuracy(10)
    # Set random seed
    self.simuiface.setRandSeed(42)
    # Enable or disable vehicle trajectory recording
    self.simuiface.setIsRecordTrace(True)
    # Enable or disable pedestrian trajectory recording
    self.simuiface.setIsRecordPedestrianTrace(True)
```

### 4.5.2. Starting, Pausing, and Stopping the Simulation

The code for starting, pausing, and stopping the simulation is as follows.

```python
# Start the simulation, typically placed in afterLoadNet or afterStop
if not self.simuiface.isRunning() or self.simuiface.isPausing():
    self.simuiface.startSimu()

# Pause the simulation, typically placed in afterOneStep
if self.simuiface.isRunning():
    self.simuiface.pauseSimu()

# Stop the simulation, typically placed in afterOneStep
if self.simuiface.isRunning():
    self.simuiface.stopSimu()
```

### 4.5.3. Continuous Multiple Simulations

The code for executing continuous multiple simulations is as follows.

```python
# MySimulator.py

class MySimulator(PyCustomerSimulator):
    def __init__(self):
        super().__init__()
        # Represents the TESS NG interface
        self.iface = tessngIFace()
        # Represents the TESS NG simulation sub-interface
        self.simuiface: SimuInterface = self.iface.simuInterface()
        
        # Current simulation iteration
        self.current_simu_count = 0
        # Maximum simulation iterations
        self.max_simu_count = 10

    def afterStart(self) -> None:
        # Increment the simulation count by one
        self.current_simu_count += 1
    
    def afterOneStep(self) -> None:
        # Current simulation time, Unit: ms
        simu_time = self.simuiface.simuTimeIntervalWithAcceMutiples()
        if simu_time > 600 * 1000:
            # Stop simulation
            self.simuiface.stopSimu()
    
    def afterStop(self) -> None:
        # Maximum simulation count has not yet been reached
        if self.current_simu_count < self.max_simu_count:
            # Start simulation
            self.simuiface.startSimu()
```



## 4.6. Data Output

### 4.6.1. Output Road Network Geometric Linear Data

The road network consists of road segments and connector segments, where road segments are composed of lanes, and connector segments are composed of lane connections. Road segments, lanes, and lane connections each contain breakpoint sequences for the centerline, left boundary line, and right boundary line. Vehicles travel precisely along these lines formed by the breakpoints. The code to obtain the breakpoint data of road segments, lanes, and lane connections is as follows.

```python
# Retrieve the breakpoint coordinates of the centerline, left boundary line, and right boundary line of a specified road segment
link = self.netiface.findLink(1)
link_center_points = link.centerBreakPoint3Ds(UnitOfMeasure.Metric)
link_left_points = link.leftBreakPoint3Ds(UnitOfMeasure.Metric)
link_right_points = link.rightBreakPoint3Ds(UnitOfMeasure.Metric)

# Retrieve the breakpoint coordinates of the centerline, left boundary line, and right boundary line of a specified lane
lane = self.netiface.findLane(1)
lane_center_points = lane.centerBreakPoint3Ds(UnitOfMeasure.Metric)
lane_left_points = lane.leftBreakPoint3Ds(UnitOfMeasure.Metric)
lane_right_points = lane.rightBreakPoint3Ds(UnitOfMeasure.Metric)
        
# Acquire the breakpoint coordinates of the centerline, left boundary line, and right boundary line of a lane connection
lane_connector = self.netiface.findLaneConnector(1, 4)
lane_connector_center_points = lane_connector.centerBreakPoint3Ds(UnitOfMeasure.Metric)
lane_connector_left_points = lane_connector.leftBreakPoint3Ds(UnitOfMeasure.Metric)
lane_connector_right_points = lane_connector.rightBreakPoint3Ds(UnitOfMeasure.Metric)
```

### 4.6.2. Output Vehicle Trajectory Data

The code to retrieve vehicle data for a specific simulation frame during the simulation process is as follows.

```python
# Retrieve the list of vehicles currently running
all_vehicles = self.simuiface.allVehiStarted()
for vehicle in all_vehicles:
    print(f"Vehicle ID: {vehicle.id()}")
    print(f"Vehicle Name: {vehicle.name()}")
    print(f"Vehicle Type Code: {vehicle.vehicleTypeCode()}")
    print(f"Vehicle Type Name: {vehicle.vehicleTypeName()}")
    print(f"Vehicle Length: {vehicle.length(UnitOfMeasure.Metric)} m")

    print(f"Vehicle Current Abscissa: {vehicle.pos(UnitOfMeasure.Metric).x()} m")
    print(f"Vehicle Current Ordinate: {vehicle.pos(UnitOfMeasure.Metric).y()} m")
    print(f"Vehicle Current Elevation: {vehicle.v3z()()} m")
    print(f"Vehicle Current Road ID: {vehicle.roadId()}")
    print(f"Vehicle Current Road Name: {vehicle.roadName()}")
    print(f"Vehicle Is on Link: {vehicle.roadIsLink()}")
    print(f"Vehicle Current Lane ID: {vehicle.laneId()}")
    if vehicle.roadIsLink():
        print(f"Vehicle Current Lane Number: {vehicle.laneNumber()}")
    print(f"Vehicle Distance to Lane Start Point: {vehicle.vehicleDriving().distToStartPoint(True, True, UnitOfMeasure.Metric)} m")

    print(f"Vehicle Current Speed: {vehicle.currSpeed(UnitOfMeasure.Metric) * 3.6} km/h")
    print(f"Vehicle Current Desired Speed: {vehicle.vehicleDriving().desirSpeed(UnitOfMeasure.Metric) * 3.6} km/h")
    print(f"Vehicle Current Acceleration: {vehicle.acce(UnitOfMeasure.Metric)} m/s²")
    print(f"Vehicle Current Heading Angle: {vehicle.angle()} °")
```

### 4.6.3. Output Traffic Signal Data

The code to retrieve traffic signal data for a specific simulation frame during the simulation process is as follows.

```python
all_signal_phase_color = self.simuiface.getSignalPhasesColor()
for signal_phase_color in all_signal_phase_color:
    print(f"Signal Group ID: {signal_phase_color.signalGroupId}")
    print(f"Signal Phase ID: {signal_phase_color.phaseId}")
    print(f"Signal Phase Number: {signal_phase_color.phaseNumber}")
    print(f"Current Color: {signal_phase_color.color}")
    print(f"Current Color Set Time (ms): {signal_phase_color.mrIntervalSetted}")
    print(f"Current Color Duration (ms): {signal_phase_color.mrIntervalByNow}")
```

### 4.6.4. Output Data from Various Collection Devices

The collection devices include: data collectors, queue counters, and travel time detectors. During the simulation process, the code to obtain their sample data and aggregated data is as follows. Notably, **aggregated data can only be retrieved in the simulation frame corresponding to the end of the aggregation period**.

```python
# ==================== Sample Data from the Data Collector ====================
all_vehi_info_collected = self.simuiface.getVehisInfoCollected()
for vehi_info in all_vehi_info_collected:
    print(f"Collector ID: {vehi_info.collectorId}")
    print(f"Simulation Time (s): {vehi_info.simuInterval}")
    print(f"Vehicle ID: {vehi_info.vehiId}")

# ==================== Aggregated Data from the Data Collector ====================
all_vehi_info_aggregated = self.simuiface.getVehisInfoAggregated()
for vehi_info_agg in all_vehi_info_aggregated:
    print(f"Collector ID: {vehi_info_agg.collectorId}")
    print(f"Time Period ID: {vehi_info_agg.timeId}")
    print(f"Start Time (s): {vehi_info_agg.fromTime}")
    print(f"End Time (s): {vehi_info_agg.toTime}")
    print(f"Vehicle Count (veh): {vehi_info_agg.vehiCount}")
    print(f"Average Speed (km/h): {vehi_info_agg.avgSpeed}")
    print(f"Average Occupancy: {vehi_info_agg.occupancy}")

# ==================== Sample Data from the Queue Counter ====================
all_vehi_queue_counted = self.simuiface.getVehisQueueCounted()
for vehi_queue in all_vehi_queue_counted:
    print(f"Counter ID: {vehi_queue.counterId}")
    print(f"Simulation Time (s): {vehi_queue.simuTime}")
    print(f"Queued Vehicle Count (veh): {vehi_queue.vehiCount}")
    print(f"Queue Length (m): {vehi_queue.queueLength}")

# ==================== Aggregated Data from the Queue Counter ====================
all_vehi_queue_aggregated = self.simuiface.getVehisQueueAggregated()
for vehi_queue_agg in all_vehi_queue_aggregated:
    print(f"Counter ID: {vehi_queue_agg.counterId}")
    print(f"Time Period ID: {vehi_queue_agg.timeId}")
    print(f"Start Time (s): {vehi_queue_agg.fromTime}")
    print(f"End Time (s): {vehi_queue_agg.toTime}")
    print(f"Average Queued Vehicle Count (veh): {vehi_queue_agg.avgVehiCount}")
    print(f"Average Queue Length (m): {vehi_queue_agg.avgQueueLength}")
    print(f"Maximum Queue Length (m): {vehi_queue_agg.maxQueueLength}")
    print(f"Minimum Queue Length (m): {vehi_queue_agg.minQueueLength}")

# ==================== Sample Data from the Travel Time Detector ====================
all_vehi_travel_detected = self.simuiface.getVehisTravelDetected()
for vehi_travel in all_vehi_travel_detected:
    print(f"Detector ID: {vehi_travel.detectedId}")
    print(f"Vehicle ID: {vehi_travel.vehiId}")
    print(f"Travel Time (s): {vehi_travel.travelTime}")
    print(f"Travel Distance (m): {vehi_travel.travelDistance}")
    print(f"Delay (s): {vehi_travel.delay}")

# ==================== Aggregated Data from the Travel Time Detector ====================
all_vehi_travel_aggregated = self.simuiface.getVehisTravelAggregated()
for vehi_travel_agg in all_vehi_travel_aggregated:
    print(f"Detector ID: {vehi_travel_agg.detectedId}")
    print(f"Time Period ID: {vehi_travel_agg.timeId}")
    print(f"Start Time (s): {vehi_travel_agg.fromTime}")
    print(f"End Time (s): {vehi_travel_agg.toTime}")
    print(f"Vehicle Count: {vehi_travel_agg.vehiCount}")
    print(f"Average Travel Time (s): {vehi_travel_agg.avgTravelTime}")
    print(f"Average Travel Distance (m): {vehi_travel_agg.avgTravelDistance}")
    print(f"Average Delay (s): {vehi_travel_agg.avgDelay}")
```
<div style="page-break-after: always;"></div>

# 5. Industry Cases

The industry cases implemented through TESS NG secondary development are listed in the table below. For the complete code, please refer to the [GitHub](https://github.com/jIDa-traffic/TESSNG_SecondaryDev) or [Gitee](https://gitee.com/jidatraffic/tessng-secondary-doc) repositories.

|       Category       | Function Item                           |
| :--------------: | :------------------------------- |
|       Highway       | Construction Zone Simulation                       |
|                  | Accident and Incident Simulation                   |
|                  | Lane Speed Limit Management                     |
|                  | Lane Closure Simulation                     |
|                  | Hard Shoulder and Emergency Lane Opening             |
|                  | Ramp Signal Control                     |
|                  | Congestion Warning                         |
|                  | Highway Control Pre-evaluation System               |
|                  | Expressway Parameter Calibration                 |
|       City       | Single-point Signal Adaptive Control                   |
|                  | Intersection Lane Channelization Modification, Variable Lanes |
|                  | Mainline Coordination                         |
|                  | Vehicle Route Guidance                     |
|                  | Congestion Warning                         |
|                  | Lane Control Simulation                     |
|                  | Vehicle Accident Simulation                     |
|                  | Vehicle Speed Guidance (VMS Information Board)        |
|                  | Urban Road Parameter Calibration                 |
|                  | Bus Signal Priority                     |
|   V2X Autonomous Driving   | V2X Intersection                        |
|                  | Speed Guidance                         |
|                  | Vehicle Platooning                     |
| Autonomous Driving Cooperative Simulation | Carla Integration                        |
|                  | prescan Integration                      |
|                  | scanner Integration                      |
|                  | Traffic Digital Twin: Integration with UE5 and Unity   |
|                  | Autonomous Driving Test Scenario Design             |

<div style="page-break-after: always;"></div>

# 6. Notes

## 6.1. Software Activation

Users must activate the TESS NG secondary development environment upon first use. Trial users follow the same activation procedure as initial activation, which can be completed by using the JIDaTraffic_key in the Cert folder of the installation package.

The software trial period lasts 30 days. After the trial expires, the secondary development interfaces remain accessible, but custom plugins will no longer function. Commercial version users have no such limitations.

Additionally, you can **modify the `__workspace` parameter in the `config`** to specify the installation directory of TESS NG. After this configuration, all output files will be uniformly generated in this directory, while enabling activation file sharing (to avoid repeated activation) and 3D model file sharing (to prevent missing model files during 3D conversion).



## 6.2. Measurement Units

Since TESS NG is developed based on the Qt framework, whose graphics system uses pixels as the basic unit, its coordinate system inherently differs from the physical units of the real world (such as meters). Qt's drawing operations, interface layout, and interaction responses are all conducted based on pixel dimensions, using screen pixels by default as the reference for rendering and positioning, which does not directly correspond to physical spatial scales.	

Therefore, in the secondary development of TESS NG, whether it concerns the dimension definition of road network elements, the calculation and mapping of vehicle positions, or the rendering of custom graphics and the coordinate parsing of interactive operations, special attention must be given to the conversion logic between **pixels and metric units**. By default, 1 pixel corresponds to 1 meter; however, if the pixel ratio is altered due to operations such as importing a base map, unit conversion can be performed using the following methods:

- Metric to pixel conversion: def m2p(value: float) -> float
- Pixel to metric conversion: def p2m(value: float) -> float

Moreover, some methods within plugins and interfaces include a **UnitOfMeasure unit** parameter, whose default value is `UnitOfMeasure.Default` (i.e., pixel units). Passing `UnitOfMeasure.Metric` (which **must be imported via `from tessng import UnitOfMeasure`**) specifies the use of metric units (supporting both read and write operations). For example, `vehicle.currSpeed()` returns the vehicle's speed in pixel units, while `vehicle.currSpeed(UnitOfMeasure.Metric)` returns the vehicle's speed in metric units. It should be noted that since the `unit` parameter is usually positioned at the end of the method parameter list, **if this parameter needs to be explicitly specified, all preceding parameters with default values must also be explicitly provided accordingly**. This rule is uniformly stated here and will not be repeated in the interface details.



## 6.3. Coordinate System

Since TESS NG is developed based on the Qt framework, its coordinate system design directly inherits Qt's core conventions — to accommodate screen display and graphics rendering logic (where screen pixels typically use the top-left corner as the origin and the downward direction as the positive y-axis), it adopts a **y-axis pointing downward** coordinate system (the origin is usually at the top-left corner of the canvas/window, the x-axis extends horizontally to the right, and the y-axis extends vertically downward).

Therefore, during the TESS NG secondary development process, all scenarios involving coordinate calculations, graphic rendering (such as road network element positioning, vehicle position annotation, and custom graphic rendering), as well as mouse interaction positioning, must adhere to this **y-axis downward** coordinate system rule. Particularly when converting data or mapping positions between the real-world geographic coordinate system (usually with the y-axis upward) and custom coordinate systems, special attention must be given to the difference in axis direction to prevent graphic misalignment, erroneous position calculations, and other issues caused by misinterpretation of the coordinate system.



## 6.4. Importing Dependent Modules

Typically, required dependency modules must be imported at the beginning of the file, either by importing the entire module at once or only the necessary objects. An example is given below.

```python
# Import the entire module
from tessng import *

# Import specific objects
from tessng import tessngIFace, Online
```



## 6.5. Sub-plugin Functional Rules

Within simulation plugins, adjustments to vehicle Acceleration, Desired Speed, driving Speed, steering angle, and traffic signal light color settings are essentially corrections or overrides of TESS NG's precomputed results; therefore, such adjustments **are effective only within the current frame**. This implies that operations like traffic signal light color settings **cannot be applied just once at a particular moment when conditions are satisfied, but must be continuously maintained throughout the entire time interval during which the conditions persist**.



## 6.6. Usage Rules for Sub-plugin Functions that Modify Input Parameters

Since the underlying implementation of TESS NG is based on C++, which supports modifying basic types such as integers, floats, and booleans through pass-by-reference, while Python does not support reference modification for these types. To address this difference, functions that require modifying input parameters have the prefix "ref_" added to their names, and special types such as `objint`, `objreal`, and `objbool` have been defined.

For example, the original function `def reSetSpeed(self, vehicle, inOutSpeed) -> bool` will have a corresponding overloaded function `def ref_reSetSpeed(self, vehicle, ref_inOutSpeed) -> bool`. In this case, `ref_inOutSpeed` is of type `Tessng.objreal` and its value can be assigned using `ref_inOutSpeed.value = 1`.

These types of functions are primarily located in PyCustomerSimulator and PyCustomerNet. The interface documentation lists both functions without the `ref_` prefix and those with the `ref_` prefix:

- If there is a need to modify the passed-in values, functions prefixed with `ref_` should be used;
- If there is no need to modify the input value, such as in `def beforeStart(self, keepOn:bool) -> None`, either the function without the `ref_` prefix or the one with the `ref_` prefix can be used.



## 6.7. Rules for Calling Interface Methods

​	All functions only support invocation via **positional arguments** (e.g., `self.netiface.findLane(1)`), and do not support invocation via **keyword arguments** (e.g., `self.netiface.findLane(laneId=1)`).

<div style="page-break-after: always;"></div>

# 7. Frequently Asked Questions

### 1. Why does the secondary development code I wrote within the built-in functions of MySimulator have no effect?

**Answer:** This may be due to the trial period having expired, which results in the system lacking the authorization to load plugins, thus preventing the custom code from executing.

