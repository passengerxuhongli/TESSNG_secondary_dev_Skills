# 微观交通仿真软件 TESS NG 二次开发接口文档（Java版）

[TOC]

<div style="page-break-after: always;"></div>

# 1.简介

## 1.1.相关链接

* [上海济达交通科技有限公司官网](https://jidatraffic.com/#/home)
* [TESSNG 二次开发 官网文档](http://jidatraffic.com:82/)
* [TESS NG 二次开发 GitHub地址](https://github.com/jIDa-traffic/TESSNG_SecondaryDev)
* [TESS NG 二次开发 Gitee地址](https://gitee.com/jidatraffic/tessng-secondary-doc)



## 1.2.研发背景

​	**国产微观交通仿真软件 TESS NG** 融合了交通工程、软件工程与系统仿真等交叉学科的最新技术研发而成，具有以下显著特点：完全自主知识产权、便捷高效的建模能力、开放的外部接口模块，以及可定制化的用户服务等。

　　在功能扩展和项目建设过程中，TESS NG 通过强化设计，将大量功能的实现进行高度抽象，并将这些抽象逻辑与核心功能深度融合。抽象逻辑进一步细化为接口方法，而具体的接口实现则交由用户根据实际应用场景来完成。在这一架构设计下，TESS NG 已成功开发出车路协同、在线仿真、微宏观一体化仿真等插件模块，相关接口的设计与应用也日臻成熟。

　　TESS NG 的二次开发能力通过用户编写代码与软件进行交互实现，从而扩展功能与定制场景。用户不仅可以实现高度自动化和个性化的仿真业务，还能够构建符合特定需求的交通数字孪生和科研实验环境，这也是开展交通研究与应用的重要途径之一。

　　目前，TESS NG 的二次开发支持 **C++、Python 和 Java** 三种编程语言，三种语言的接口名称完全一致。



## 1.3.应用场景

​	TESS NG 的二次开发功能支持丰富多样的仿真场景构建，其可实现的应用场景广泛，包括但不限于以下表格所涵盖的内容。

| 序号 |     分类     |       场景       |                             应用                             |
| :--: | :----------: | :--------------: | :----------------------------------------------------------: |
|  1   |   城市仿真   |     信号控制     |                     单点webster信控算法                      |
|  2   |              |     公交优先     |                         干线绿波算法                         |
|  3   |              |   车辆路径诱导   | 通过调整车流在决策点的路径比例完成诱导<br/>对诱导点位下游道路排队长度的评价分析 |
|  4   |   高速仿真   |     匝道信控     |                  上匝道 ALINEA 信控算法应用                  |
|  5   |              |   车道限速管控   |                  高速公路车道限速动态化管理                  |
|  6   |              |   应急事件处理   |                    车辆事故与事件仿真模拟                    |
|  7   |              |     道路施工     |                        三类施工区仿真                        |
|  8   |     教学     | 连续交叉速度引导 |                     绿波车速诱导策略应用                     |
|  9   |              |    交通流还原    |                 高快速路跟驰换道模型参数标定                 |
|  10  |              |   AI 算法预研    |             基于强化学习的快速路可变限速优化研究             |
|  11  |   路网构建   |     路网编辑     |          路网、路段、连接段等仿真元素的增删改查操作          |
|  12  |              |     信控编辑     |         信号灯、灯组的增删改查及双环结构信控加载支持         |
|  13  |              |     需求编辑     | 发车点流量加载配置<br/>单车指定位置加载设置<br/>车辆组成自定义<br/>决策点与路径比例的增删改查 |
|  14  | 仿真过程控制 |     流程控制     | 仿真的开始、暂停、恢复与关闭操作<br/>仿真快照功能应用<br/>仿真信息、路网信息、车辆信息的获取<br/>车辆轨迹平面坐标与地理坐标转换<br/>加速度、仿真精度、随机种子等参数设置 |
|  15  |              |     动作控制     | 限速区、事故区、施工区的设置<br/>车辆移动、信息修改、变道及航向角调整<br/>信号灯颜色、路径、相位信息更新<br/>车道启闭、路方案、路径信息管理<br/>跟驰模型、换道模型参数修改 |
|  16  |              |     仿真输出     | 检测器与采集器的设置<br/>按指定时间频率输出数据<br/>检测器、采集器与仿真路网绑定关系获取<br/>车辆轨迹输出<br/>仿真路网结构化数据输出 |
|  17  | 交互界面开发 |      菜单栏      |      支持用户新增自定义菜单，达成与 TESS NG 软件的交互       |
|  18  |              |      工具栏      |     支持用户新增自定义工具栏，达成与 TESS NG 软件的交互      |



## 1.4.接口架构

​	TESS NG 通过实现 TessInterface 及其三个子接口，将自身主要功能暴露给用户，用户启动 TESS NG 后可以获取 TESS NG 的顶层接口，再通过顶层接口获取三个子接口，调用子接口方法。TESS NG 加载插件后可以调用插件实现的接口方法，用户可以在插件方法中通过 TessInterface 及其子接口控制仿真运行，及仿真过程中车辆驾驶行为、信号灯色、路径车辆分配等等。

​	二次开发的整体架构如下图所示。

<img src="http://129.211.28.237:5566/document/images/0_interface_architecture" alt="二次开发整体架构图" style="zoom: 50%;" />



## 1.5.更新日志

**【 2025-01-21 】**

- TESSNG内核由V3.1升级到V4.0，二次开发版本可使用V4.0专业版基础功能

- 【新增】ISignalPlan 信控方案接口，支持多时段信控方案，替代原有的ISignalGroup接口。

- 【新增】ISignalLamp 信号灯接口，支持创建信号灯并关联信号机。

- 【新增】ICrosswalkSignalLamp 行人信号灯接口，支持创建信号灯并关联信号机。

- 【新增】IRoadWorkZone 占道施工接口，支持创建施工区。

- 【新增】IAccIDentZone 事故区接口升级，包含IAccIDentZoneInterval事故时段，可创建多时段不同参数的事故区。

- 【新增】ILimitedZone 限制区，其本身为借道施工的一部分，可不直接使用，但用户也可以用它做一些自定义的限制形式的区域。

- 【新增】IReconstruction 借道施工（改扩建），可精细化生成，控制改扩建路网。

- 【新增】IReduceSpeedArea 新增限速区接口，可支持分时段IReduceSpeedInterval分车型IReduceSpeedVehiType进行车道限速。

- 【新增】新增收费站系列接口，包括收费车道ITollLane，收费决策点ITollDecisionPoint，收费路径ITollRouting，收费站停车点ITollPoint。

- 【新增】停车场系列接口，包括停车位IParkingStall，停车区域IParkingRegion，停车决策点IParkingDecisionPoint，停车路径IParkingRouting。

- 【新增】节点构建及路径重构接口IJunction，包括自动计算节点流向，输入观测值进行路径重构。

- 【新增】行人面域接口包括：行人面域基类IPedestrian，障碍物面域IObstacleRegion，行人上下客面域IPassengerRegion，椭圆面域。IPedestrianEllipseRegion，扇形面域IPedestrianFanShapeRegion，多边形面域IPedestrianPolygonRegion，矩形面域IPedestrianRectRegion，三角形面域IPedestrianTriangleRegion。

- 【新增】行人人行道面域IPedestrianSIDeWalkRegion接口。

- 【新增】行人人行横道（斑马线）IPedestrianCrossWalkRegion接口。

- 【新增】行人楼梯面域IPedestrianStairRegion接口。

- 【新增】行人人行横道信号灯接口ICrosswalkSignalLamp。

- 【新增】行人路径系列接口，包括：行人路径IPedestrianPath，行人路径途经点IPedestrianPathPoint。

- 【新增】NetInterface类下新增IJunction节点对象的增删改查，新增行人面域，路径的增删改查，新增事故区，施工区，改扩建，限速区，信号灯，信号机，信控方案，星空相位的增删改查，新增停车场，收费站的增删改查。

- 【新增】SimuInterface类下新增获取行人状态，运动中行人信息的接口，新增单步仿真的接口。

- 【优化】统一接口的单位，V3系列默认像素制，V4常用的速度，长度等概念改为米制单位，并提供unitOfMeasure参数显示指定单位类型，从而避免繁琐的m2p，p2m的转化。

  

**【 2025-09-30 】**

- 【新增】设置车辆安全时距和停车距离的接口 setSafeTimeInterval 和 setStoppingDistance。
- 【新增】读取和设置是否输出信号灯头数据的接口 isRecordSignalLampStatus 和 setIsRecordSignalLampStatus。
- 【移除】变道相关弃用的插件函数 reSetChangeLaneFreelyParam 和 isPassbyEventZone。

<div style="page-break-after: always;"></div>

# 2.快速入门

​	本节提供快速上手指南，通过安装运行、示例讲解和注意事项，读者可以迅速理解如何在本地环境中构建并运行 TESS NG 的 Java API 示例。这些内容为后续的插件开发与接口调用奠定实践基础，帮助开发者先跑通流程，再逐步深入功能扩展。



## 2.1.安装运行（Windows）

#### <span style="color: green;">Step1：下载示例代码包</span>

1. 在 [济达交通官网](https://www.jidatraffic.com/#/simulation) 下载 TESS NG 最新版本；

   <img src="http://129.211.28.237:5566/document/images/java_2_1_01" alt="图1" style="zoom: 60%;" />

2. 安装完成后，在软件目录的 **`SecondDev`** 文件夹中，可找到名为 **`TESS_JavaAPI_EXAMPLE`** 的 Java 版示例代码包。

   <img src="http://129.211.28.237:5566/document/images/java_2_1_02" alt="图2" style="zoom: 60%;" />

#### <span style="color: green;">Step2：配置开发环境</span>

1. **安装 JDK**：

   - 访问 [Java 官方下载页面](https://www.oracle.com/java/technologies/downloads/)，选择 **JDK 8 及以上版本**进行下载；
   - 以 JDK 21 版本为例，选择 Windows 的 x64 Installer，点击下载 `jdk-21_windows-x64_bin.exe ` 文件；
   - 双击下载完成的 `jdk-21_windows-x64_bin.exe` 文件，启动安装程序；
   - 跟随安装向导依次点击 “下一步”，可根据需求选择自定义安装目录；
   - 再次点击“下一步”，等待安装进度完成。

   <img src="http://129.211.28.237:5566/document/images/java_2_1_03" alt="图3" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/java_2_1_04" alt="图4" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/java_2_1_05" alt="图5" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/java_2_1_06" alt="图6" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/java_2_1_07" alt="图7" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/java_2_1_08" alt="图8" style="zoom: 60%;" />

2. **验证安装结果**：

   - 安装完成后，按下 `Win + R`，输入 `cmd` 打开系统终端；

   - 分别执行 `java -version` 和 `javac -version` 命令，若输出类似 `java version "21.0.8" 2025-07-15 LTS` 和 `javac 21.0.8` 的版本信息，说明安装成功。

   <img src="http://129.211.28.237:5566/document/images/java_2_1_09" alt="图9" style="zoom: 60%;" />

#### <span style="color: green;">Step3：选择并配置 IDE</span>

- 推荐使用 **JetBrains IntelliJ IDEA**（社区版或专业版均可），操作流程如下：

1. **安装 IDEA**：
   - 访问 [IntelliJ IDEA 官网](https://www.jetbrains.com/idea/)， 下载适用于 Windows 系统的安装包；
   - 双击下载的 `ideaIU-x.x.x.exe` 文件，启动安装程序；
   - 跟随安装向导点击 “下一步”，可根据需求选择自定义安装路径；
   - 点击 “安装”，等待安装进度完成。
   
   <img src="http://129.211.28.237:5566/document/images/java_2_1_10" alt="图10" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/java_2_1_11" alt="图11" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/java_2_1_12" alt="图12" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/java_2_1_13" alt="图13" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/java_2_1_14" alt="图14" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/java_2_1_15" alt="图15" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/java_2_1_16" alt="图16" style="zoom: 60%;" />
   
   <img src="http://129.211.28.237:5566/document/images/java_2_1_17" alt="图17" style="zoom: 60%;" />
   
2. **配置 JDK**：

   - 启动 IDEA，点击“打开”按钮，选择并打开 `TESS_JavaAPI_EXAMPLE` 文件夹；

   - 依次点击顶部菜单栏 “文件> 项目结构”，打开“项目结构”配置窗口；

   - 在左侧导航栏选择 “项目设置> 项目”，在右侧 “SDK” 选项中选择已安装的 JDK 目录，点击 “确定” 后，IDEA 会自动识别 JDK 版本及相关依赖，完成项目 SDK 的配置。

   <img src="http://129.211.28.237:5566/document/images/java_2_1_18" alt="图18" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/java_2_1_19" alt="图19" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/java_2_1_20" alt="图20" style="zoom: 60%;" />

#### <span style="color: green;">Step4：运行示例项目</span>

1. **启动代码**：

   - 点击 IDEA 顶部菜单栏的“当前文件> 编辑配置”，打开“运行/调试配置”窗口；
   - 点击左上角 “+” 号，选择 “应用程序”；
   - 在配置界面中：
     - 可将 “名称” 修改为自定义名称（如 “Main”）；
     - 在 “构建并运行” 区域的 “主类” 输入框中，点击右侧浏览按钮（或直接输入完整类名），从项目类结构中选择预设的主类 `Main`；
     -  在 “环境变量” 选项中，点击右侧 “浏览.env 文件和脚本” 按钮，在弹出的文件选择窗口中选中项目根目录下的 `.env` 文件完成导入；
     - 点击“确定”按钮。

   - 点击上方的 “运行” 按钮（绿色三角图标），或按下快捷键 `Shift + F10`，即可启动程序。

   <img src="http://129.211.28.237:5566/document/images/java_2_1_21" alt="图21" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/java_2_1_22" alt="图22" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/java_2_1_23" alt="图23" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/java_2_1_24" alt="图24" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/java_2_1_25" alt="图25" style="zoom: 60%;" />

2. **软件激活**：

   - 首次启动时会弹出 TESS NG 软件激活窗口，按提示完成激活（需使用有效授权）；
   - 激活成功后关闭窗口，再次点击 “运行” 按钮，即可正常启动示例项目。

   <img src="http://129.211.28.237:5566/document/images/java_2_1_26" alt="图26" style="zoom: 60%;" />

   <img src="http://129.211.28.237:5566/document/images/java_2_1_27" alt="图27" style="zoom: 60%;" />



## 2.2.示例讲解

#### <span style="color: dodgerblue;">Note 1：工程目录</span>

​	`TESS_JavaAPI_EXAMPLE` 遵循 Maven 项目标准目录结构（约定优于配置），区分源码、依赖库、编译输出目录，适配 Java 工程化开发流程，各目录及文件说明如下：

- **lib**：项目依赖 Jar 包存放目录，包含 TESSNG.jar，供项目编译与运行时引用
- **out**：TESS NG 输出目录
- **src**：项目源码根目录
  - **main**：主源码目录
    - **java**：Java 源码目录
      - **Main.java**：项目主入口类，负责初始化 TESS NG 实例并启动程序
      - **MyPlugin.java**：自定义插件实现类，负责初始化插件
      - **MyNet.java**：自定义路网插件实现类，可以在路网加载前后执行自定义操作，控制路网元素的绘制
      - **MySimulator.java**：自定义仿真插件实现类，可以在仿真前后以及仿真过程中执行自定义操作，既能全局控制仿真的启停逻辑，也能精细化干预单个车辆的驾驶行为
    - **native**
      - **win-x64**：Windows x64 平台的 Native 资源目录，包含项目依赖的 DLL 文件（动态链接库）与 QT 插件，确保 Java 层能正常调用 Native 功能

- **target**：Maven 构建工具的默认输出目录，存放项目打包产物（如 Jar 包）、编译后的字节码文件及依赖库，是项目部署时的核心产物目录
- **pom.xml**：Maven 项目核心配置文件，定义项目基本信息（如坐标、版本）、依赖库（通过 `<dependencies>` 节点管理）、构建规则（如编译插件、输出配置）

#### <span style="color: dodgerblue;">Note 2：插件注册机制与仿真控制逻辑</span>

​	很多 TESS NG 初用者常会困惑：自己编写的自定义插件代码是如何被 TESS NG 调用的？结合项目主入口文件`main.cpp`的实现逻辑，可清晰理解这一过程，同时需明确仿真场景的核心开发思路，具体说明如下：

1. 先解答核心疑问：**自定义代码如何被 TESS NG 调用？**关键在于 `Main.java` 中 `tessngFactory.build(myPlugin, workspacePath)` 这行代码。它是连接用户自定义插件与 TESS NG 仿真核心的 “桥梁”，`tessngFactory`（TESS NG 提供的工厂类）的`build`方法，会将用户通过 `MyPlugin myPlugin = new MyPlugin()`创建的自定义插件实例（`MyPlugin`是用户编写的插件类，封装了所有自定义逻辑），通过 TESS NG 底层接口注册到仿真核心。注册完成后，TESS NG 会在仿真运行的关键节点（如仿真启动、每一步仿真推进、仿真结束等），自动调用 `MyPlugin` 及其子插件 `MyNet` 和 `MySimulator` 中用户重写的钩子方法，无需手动编写 “调用代码”，从而实现功能拓展。

2. 再明确仿真场景开发的核心思路：初用者易陷入 “如何把 TESS NG 仿真嵌入自己计算代码” 的误区，正确做法是 “**将自定义计算代码嵌入 TESS NG 仿真流程**”。TESS NG 已提供成熟的仿真框架（如路网加载、仿真推进、界面交互等基础能力），`Main.java`的核心作用就是 “配置并启动这个框架”。用户无需自己搭建仿真框架，只需将计算代码（如自定义车辆行为、数据采集、特殊场景触发逻辑等）封装到 `MyPlugin` 及其子插件 `MyNet` 和 `MySimulator` 的特定方法中（例如 TESS NG 提供的每步仿真触发方法 `afterOneStep`、仿真启动触发方法 `afterStart`），待 `tessngFactory.build` 完成插件注册后，这些逻辑会被 TESS NG 自动嵌入仿真流程，随仿真推进执行。

   项目主入口类为Main.java，代码如下：

```java
package com.example;

import javax.json.Json;
import javax.json.JsonObject;
import com.jidatraffic.tessng.TessngFactory;

public class Main {
    // 加载库文件
    static {
        try {
            System.loadLibrary("TESS_WIN_Java");
        } catch (UnsatisfiedLinkError e) {
            System.err.println("Native code library failed to load. See the chapter on Dynamic Linking Problems in the SWIG Java documentation for help.\n" + e);
            System.exit(1);
        }
    }

    public static void main(String[] args) {
        // 构建工作空间路径
        String workspacePath = System.getProperty("user.dir") + "\\out";
        // 构建配置参数
        JsonObject jsonObject = Json.createObjectBuilder()
                .add("__secdevlang", "java")
                .add("__workspace", workspacePath)
                .add("__netfilepath", "")
                .add("__simuafterload", true)
                .build();

        // 创建自定义插件类实例
        MyPlugin myPlugin = new MyPlugin();
        // 创建 TESS NG 工厂类实例
        TessngFactory tessngFactory = new TessngFactory();
        // 通过工厂类构建 TESS NG 仿真核心对象
        tessngFactory.build(myPlugin, jsonObject);
        // 退出
        System.exit(0);
    }
}
```

#### <span style="color: dodgerblue;">Note 3：修改启动路网</span>

​	修改 `Main.java` 中的 `jsonObject` 配置属性：

- `"__netfilepath"`：用于指定 TESS NG 启动时默认加载的路网文件路径；

- `"__simuafterload"`：用于指定 TESS NG 加载路网文件后是否立即开启仿真。

  例如：


```java
JsonObject jsonObject = Json.createObjectBuilder()
                .add("__language", "java")
                .add("__workspace", workspacePath)
                .add("__netfilepath", "C:/TESSNG_4.1.0/Examles/杭州武林门区域路网公交优先方案.tess")
                .add("__simuafterload", true)
                .build();
```

#### <span style="color: dodgerblue;">Note 4：路网元素的增删查改及属性操作</span>

​	可通过 `netiface` 接口实现对路网元素（如路段、连接段等）的**新增、删除、查询、修改**，同时获取路网元素对象后，支持对其属性进行**查询**与**修改**。

- 以下示例为：路网元素的增删查改（通过 `netiface` 接口）。

```java
// 1. 查询所有路段：获取当前路网中所有路段的列表
ArrayList<ILink> links = netiface.links();

// 2. 按ID查询指定路段：获取ID为1的路段（若不存在则返回null）
ILink link = netiface.findLink(1);

// 3. 新增路段：传入路段顶点坐标（linkPoints）、车道数（7）、路段名称（"曹安公路"），创建并返回新路段对象
Point startPoint1 = new Point(m2p(-300), 0);
Point endPoint1 = new Point(m2p(300), 0);
ArrayList<Point> linkPoints1 = new ArrayList<>(Arrays.asList(startPoint1, endPoint1));
ILink link1 = netiface.createLink(linkPoints1, 7, "曹安公路", true, UnitOfMeasure.Metric);

// 4. 删除路段：传入需删除的路段对象（link1），从路网中移除该路段
netiface.removeLink(link1);
```

- 以下示例为：路网元素属性的查询与修改（通过元素对象）。


```java
// 1. 属性查询：获取路段link1的相关属性
int laneCount = link1.laneCount();  // 查询路段车道数（返回整数，如3）
qreal laneLength = link1.length();  // 查询路段长度（返回浮点数，单位：m）

// 2. 属性修改：修改路段link1的名称与限速
link1.setName("曹安公路");  // 设置路段名称为"曹安公路"
link1.setLimitSpeed(80);  // 设置路段限速为80km/h
```

#### <span style="color: dodgerblue;">Note 5：路网加载前后的自定义操作</span>

​	在自定义路网插件（`MyNet` 类）中，可通过重写 `beforeLoadNet` 和 `afterLoadNet` 方法，实现**路网加载前的预处理**与**路网加载后的后续操作**。

- 以下示例为：路网加载完成后，先判断当前路网是否存在路段；若不存在，则调用自定义方法 `createNet()` 创建基础路网（含路段、连接段、发车点等）。

```java
// MyNet.java：自定义路网插件的实现文件
@Override
public void afterLoadNet() {
    // 1. 查询当前路网中的路段总数
    int linkCount = netiface.linkCount();

    // 2. 若路网中无路段（linkCount == 0），则执行自定义路网创建逻辑
    if (linkCount == 0) {
        // 自定义方法：内部实现路段、连接段、发车点的创建逻辑
        createNetwork();
    }
}
```

#### <span style="color: dodgerblue;">Note 6：路网元素的显示控制</span>

​	在自定义路网插件（`MyNet` 类）中，可通过重写 `labelNameAndFont` 方法实现对路网元素（如路段、连接段）标签的精细化显示控制 —— 包括标签内容（显示名称 / ID / 不显示）、字体大小的自定义，满足不同场景下的路网可视化需求。

- 以下示例为：名称为“曹安公路”的路段的标签显示路段名称，其它路段标签显示ID，连接段标签则都显示名称。

```java
// MyNet.java：自定义路网插件的实现文件
@Override
    public void ref_labelNameAndFont(int itemType, long itemId, ObjInt ref_outPropName, ObjReal ref_outFontSize) {
        // 1. 仿真正在运行时，路段、车道不绘制标签，避免干扰仿真观察
        if (simuiface.isRunning()) {
            ref_outPropName.setValue(GraphicsItemPropName.None.swigValue());  // 不显示任何标签
            return;  // 直接返回，无需执行后续逻辑
        }

        // 2. 默认配置：标签显示元素ID，字体大小为6米
        ref_outPropName.setValue(GraphicsItemPropName.Id.swigValue());
        ref_outFontSize.setValue(6);

        // 3. 连接段特殊配置：全部显示名称（无论ID，统一以名称标识）
        if (itemType == NetItemType.getGConnectorType()) {
            ref_outPropName.setValue(GraphicsItemPropName.Name.swigValue());
        }
        // 4. 路段特殊配置：仅ID为1、5、6的路段显示名称，其余显示ID
        else if (itemType == NetItemType.getGLinkType()) {
            if (itemId == 1 || itemId == 5 || itemId == 6) {
                ref_outPropName.setValue(GraphicsItemPropName.Name.swigValue());
            }
        }
    }
```

#### <span style="color: dodgerblue;">Note 7：仿真信息的查询和修改</span>

​	可通过 `simuiface` 接口实现对**仿真核心参数**的查询与修改，包括仿真时长、精度、倍速等。

```java
// 1. 仿真信息查询：获取当前仿真的关键参数
long simuInterval = simuiface.simuIntervalScheming();  // 查询预设仿真总时长（单位：s）
int simuAccuracy = simuiface.simuAccuracy();  // 查询仿真精度
int simuMultiples = simuiface.acceMultiples();  // 查询仿真倍速
long simuTime = simuiface.simuTimeIntervalWithAcceMutiples();  // 查询当前已仿真时间（单位：ms）

// 2. 仿真信息修改：设置仿真的关键参数
simuiface.setSimuIntervalScheming(3600);  // 设置仿真总时长为3600s
simuiface.setSimuAccuracy(1);  // 设置仿真精度为1
simuiface.setAcceMultiples(5);  // 设置仿真倍速为5
```

#### <span style="color: dodgerblue;">Note 8：仿真车辆的增删查及属性操作</span>

​	可通过 `simuiface` 接口实现对**仿真车辆**的新增、删除、查询，同时支持获取车辆对象后，查询其所有属性，并修改**静态属性**（不随仿真动态变化的属性，如长度、最大速度）。

- 以下示例为：仿真车辆的增删查改（通过 `simuiface` 接口）。

```java
// 1. 查询车辆：获取指定范围的车辆列表
ArrayList<IVehicle> allVehicles = simuiface.allVehiStarted();  // 获取当前所有已启动的车辆
ArrayList<IVehicle> vehicles = simuiface.vehisInLink(1);  // 获取当前在ID为1的路段上行驶的车辆

// 2. 新增车辆：在指定路段动态创建车辆（需先配置车辆参数 DynaVehiParam）
DynaVehiParam dvp = new DynaVehiParam();  // 车辆动态参数对象
dvp.setVehiTypeCode(randomInt(0, 4) + 1);  // 随机设置车辆类型编码（1-4，对应不同车型）
dvp.setRoadId(6);  // 指定车辆初始所在路段ID（此处为6）
dvp.setLaneNumber(randomInt(0, 3));  // 随机设置初始车道号（0-2，对应路段的第1-3车道）
dvp.setDist(50);  // 车辆在路段上的初始距离（距路段起点50m）
dvp.setSpeed(20);  // 车辆初始速度（单位：m/s）
dvp.setColor("#00AFF0");  // 车辆显示颜色
// 调用接口创建车辆，返回新车辆对象（若创建失败则返回null）
IVehicle vehicle1 = simuiface.createGVehicle(dvp);
// 判断车辆是否创建成功
if (vehicle1 != null){
    System.out.println("在路段上创建了车辆：" + vehicle1.id());
}

// 3. 删除车辆：停止指定车辆（vehicle1）的行驶并从仿真中移除
simuiface.stopVehicleDriving(vehicle1);
```

- 以下示例为：车辆属性的查询与静态修改（通过车辆对象）。


```java
// 1. 属性查询：获取车辆vehicle的相关属性
String roadName = vehicle.roadName();  // 车辆所在路段名或连接段名
double speed = vehicle.currSpeed();  // 获取车辆的当前速度，单位：m/s

// 2. 属性修改：修改车辆vehicle的长度与限速
vehicle.setLength(5);  // 修改车辆的长度，单位：m
vehicle.setMaxSpeed(80/3.6);  // 修改车辆的最大速度，单位：m/s
```

#### <span style="color: dodgerblue;">Note 9：仿真车辆的动态属性修改</span>

​	车辆的**动态属性**（如实时速度、加速度，随仿真过程动态变化）无法直接通过车辆对象修改，需在**自定义仿真插件（`MySimulator` 类）** 中，重写特定对象方法实现 —— 本质是对 TESS NG 实时计算的动态数值进行修正或覆盖。

- 以下示例为：在 `reSetSpeed` 方法中，根据车辆 ID 和所在路段，强制指定部分车辆的实时速度（使 ID 2~N 的车辆跟随 ID 1 的车辆速度）。

```java
// MySimulator.java：自定义仿真插件的实现文件
@Override
public boolean ref_reSetSpeed(IVehicle vehicle, ObjReal refInOutSpeed) {
    // 1. 处理车辆ID（取余避免ID过长，仅保留后5位）
    long tmpVehicleId = vehicle.id() % 100000;

    // 2. 获取车辆当前所在路段名称
    String roadName = vehicle.roadName();

    // 3. 仅对"曹安公路"上的车辆执行速度控制逻辑
    if (roadName.equals("曹安公路")) {
        // 若为ID=1的车辆：记录其当前速度（作为基准速度）
        if (tmpVehicleId == 1) {
            planeSpeed = vehicle.currSpeed();
        } 
        // 若为ID 2~squareVehiCount的车辆：强制将其速度设为基准速度
        else if (tmpVehicleId >= 2 && tmpVehicleId <= squareVehiCount) {
            // 覆盖TESS NG计算的速度值
            refInOutSpeed.setValue(planeSpeed);
            // 返回true表示速度修改生效
            return true;
        }
    }
    // 返回false表示不修改速度，使用TESS NG默认计算值
    return false;
}
```

#### <span style="color: dodgerblue;">Note 10：特定仿真时机的自定义操作</span>

​	在自定义仿真插件（`MySimulator` 类）中，可通过重写 TESS NG 提供的特定方法，在**不同仿真节点触发自定义逻辑**：既支持在**仿真全局时机**（如仿真启动前、结束后）执行操作，也支持在**车辆特定行为时机**（如车辆创建、车辆移除、车辆换道前）触发逻辑，满足精细化的仿真定制需求。

- 通过重写 `beforeStart`（仿真启动前）和 `afterStop`（仿真结束后）方法，可实现仿真全局的预处理与后处理，例如初始化仿真参数、循环启动仿真、导出仿真结果等。以下示例为：仿真结束后，判断累计仿真次数是否 ≤ 3；若满足条件，则自动重新启动仿真（实现循环仿真）。

```java
// MySimulator.java：自定义仿真插件的实现文件
@Override
public void afterStop() {
    // 1. simuCount为自定义变量，用于统计累计仿真次数
    if (this.simuCount <= 3) {
        // 2. 调用接口重新启动仿真
        simuiface.startSimu();
    }
}
```

- 通过重写与车辆行为绑定的方法，可在车辆满足特定条件时触发逻辑，例如车辆创建后初始化属性、车辆移除后记录数据等。以下示例为：在仿真车辆创建后，根据车辆 ID 设置车辆的车型、位置和长度。

```java
// MySimulator.java：自定义仿真插件的实现文件
@Override
public void initVehicle(IVehicle vehicle) {
    // 1. 获取当前车辆的基础信息（所在路段名称、路段ID）
    String roadName = vehicle.roadName();  // 车辆当前所在路段/连接段的名称
    long roadId = vehicle.roadId();  // 车辆当前所在路段/连接段的ID

    // 2. 仅对「曹安公路」上的车辆执行特殊定制逻辑
    if (roadName.equals("曹安公路")) {
        // 处理车辆ID：取余100000，剔除首位数（首位数通常关联车辆来源，如发车点、公交线路）
        int tmpVehicleId = (int) (vehicle.id() % 100000);

        // 3. 针对特定ID的车辆，设置专属车型与初始位置
        if (tmpVehicleId == 1) {
            // 将ID=1的车辆设置为「12号车型」
            vehicle.setVehiType(12);
            // 初始化车辆的初始车道、位置和速度
            vehicle.initLane(3, m2p(105), 0);
        }
        // 中间可补充其他ID车辆的定制逻辑，如tmpVehicleId=2、3等

        // 4. 针对ID 23~28的车辆，设置特定长度
        if (tmpVehicleId >= 23 && tmpVehicleId <= 28) {
            vehicle.setLength(m2p(4.5), true);
        }
    }
}
```

<div style="page-break-after: always;"></div>

# 3.接口详情

​	本节将首先介绍**全局配置参数（config.json）**，然后依次介绍**插件（Plugin）**、**接口（Interface）** 和 **对象（Object）**三个层次的内容，帮助读者从整体到细节逐步理解 TESS NG 的二次开发模式。



## 3.1.全局配置参数

​	TESS NG 可识别的全局配置参数 config.json 如下: 

```json
{
	"__netfilepath": "xxx.tess", 		
	"__simuafterload": false, 
	"__timebycpu": false, 
	"__writesimuresult": true, 
	"__custsimubysteps": false,
    "__allowspopup": false
}
```

**__netfilepath**

​	 指定 TESSNG 启动后加载的路网文件路径，支持绝对路径或相对路径。若文件不存在，将默认打开空白路网。

**__simuafterload**

​	指定TESSNG加载路网文件后是否自动启动仿真，默认为 false。 

**__timebycpu**

​	指定仿真周期的时间计算依据：基于 CPU 时钟的现实时长，或基于仿真精度的时长，默认为 false。在线仿真且算力紧张时，可尝试将此属性设为 true。

**__writesimuresult**

​	控制是否输出仿真结果，默认为 true。若设为 false，仿真结束后不写入结果文件，且仿真过程中，车辆驶出路网一段时间后会被回收到可用队列，以减少内存占用。

**__custsimubysteps**

​	设置 TESSNG 调用插件方法的频次依据，默认为 false。设为 false 时，每个计算周期调用一次（不依据插件端设置的频次）；设为 true 时，将依据插件设置的频次调用其实现的方法。

**__allowspopup**

​	控制是否允许弹出提示弹窗，以避免阻塞程序运行，默认为 true。



## 3.2.插件

​	通常，软件的功能拓展通过定义插件接口并由用户实现插件来完成。TESS NG亦采用此模式，其包含顶级插件接口TessPlugin，以及JCustomerNet、JCustomerSimulator两个子插件接口。与仅能调用接口方法而无法改变内部运行逻辑的TessInterface接口不同，用户通过实现TessPlugin及其子接口的方法，能够深入TESS NG的内部运行过程，在路网加载、仿真过程等环节施加影响，进而改变其运行逻辑，实现更深层次的功能拓展。这两个子插件的所有方法均提供默认实现，用户可通过需求选择性实现部分或全部方法。

​	由于插件接口方法的调用场景与目的存在差异，为统一对插件接口方法的理解，多数方法采用如下结构形式：

```java
boolean method(type &outParam) 
{
    outParam.setValue(1);
	return true;
}
```

​	TESS NG调用这些方法时遵循如下逻辑：**若返回值为false，则视为用户无响应，将忽略该调用；若返回值为true，表明用户有响应，此时将通过参数outParam的值进行后续处理**。以示例中的场景为例：当曹安公路上的车辆排成队列时，需对飞机后方的车辆重新设置速度，使其与飞机保持一致，此时，JCustomerSimulator的子类MySimulator可通过实现 `ref_reSetSpeed` 方法来达成这一需求。

```java
@Override
public boolean ref_reSetSpeed(IVehicle vehicle, ObjReal refInOutSpeed) {
    long tmpVehicleId = vehicle.id() % 100000;
    String roadName = vehicle.roadName();
    if (roadName.equals("曹安公路")) {
        if (tmpVehicleId == 1) {
            planeSpeed = vehicle.currSpeed();
        } else if (tmpVehicleId >= 2 && tmpVehicleId <= squareVehiCount) {
            refInOutSpeed.setValue(planeSpeed);
            return true;
        }
    }
    return false;
}
```

​	TESS NG在计算车辆的速度后会调用插件的reSetSpeed方法，如果该方法返回true，视插件对此方法作出响应，这时再用outSpeed值取代原先计算的车速。TESS NG调用插件 `reSetSpeed` 方法的过程（C++代码）如下：

```cpp
if (gpTessPlugin && gpTessPlugin->customerSimulator())
{
   qreal outSpeed = mrCurrSpeed；
   if (gpTessPlugin->customerSimulator()->reSetSpeed(mpGVehicle，outSpeed))
   {
       mrCurrSpeed = outSpeed；
   }
}
```

### 3.2.1.顶级插件（TessPlugin）

​	TessPlugin是用户开发的顶级插件接口，下面有两个子插件接口：JCustomerNet、JCustomerSimulator，用户通过实现这两个子插件分别在路网、仿真过程两个方面与TESSNG进行交互。

**public void init()**

​	插件初始化，可在此实现方法里实例化JCustomerNet、JCustomerSimulator两个类的子类。

**public CustomerNet customerNet()**

​	返回customerNet对象。

**public CustomerSimulator customerSimulator()**

​	返回CustomerSimulator对象。


### 3.2.2.路网插件（JCustomerNet）

​	JCustomerNet是TessPlugin的子插件接口，用户通过实现该插件，可以在路网加载前后执行自定义操作，控制路网元素的绘制。

#### 3.2.2.1.路网加载

**public void beforeLoadNet()**

​	加载路网前调用，用户可以通过此方法在加载路网前作必要的初始化准备工作。

**public void afterLoadNet()**

​	加载路网后调用。

示例：

```java
@Override
public void afterLoadNet() {
    // 获取路段数量
    int linkCount = netiface.linkCount();
    // 如果路网上没有路段，则调用自定义的创建路网的方法
    if (linkCount == 0) {
        createNetwork();
    }
}
```

#### 3.2.2.2.路网元素绘制

**public boolean isPermitForCustDraw()**

​	是否允许调用客户绘制。本方法的目的是减少不必要的代码调用，消除对运行效率的负面影响。

返回：

​	是否绘制，true表示绘制，false表示不绘制，默认为true。

**public boolean isDrawLinkCenterLine(long linkId)**

​	是否绘制路段中心线。

参数：

​	[ in ] linkID：路段ID。

返回：

​	是否绘制，true表示绘制，false表示不绘制，默认为true。

示例：

```java
@Override
public boolean isDrawLinkCenterLine(long linkId) {
    // ID为1的路段不绘制中心线
    return linkId != 1;
}
```

**public boolean isDrawLinkCorner(long linkId)**

​	是否绘制路段四个拐角的圆形和正方型。

参数：

​	[ in ] linkID：路段ID。

返回：

​	是否绘制，true表示绘制，false表示不绘制，默认为true。

**public boolean isDrawLaneCenterLine(long laneId)**

​	是否绘制车道中心线。

参数：

​	[ in ] laneID：车道ID。

返回：

​	是否绘制，true表示绘制，false表示不绘制，默认为false。

**public boolean linkType(ArrayList\<String\> lType)**

​	路段类型。

参数：

​	[ in ] lType：用户定义的路段类型列表。

返回：

​	是否自定义。

**public boolean laneType(ArrayList\<String\> lType)**

​	车道类型。

参数：

​	[ in ] lType：用户定义的车道类型列表。

返回：

​	是否自定义。

**public boolean paint(int itemType, long itemID, Painter painter)**

​	绘制路网元素。

参数：

​	[ in ] itemType：路网元素类型。

​	[ in ] itemID：路网元素ID。

​	[ in ] painter：QPainter对象。

返回：

​	如果返回true，TESSNG认为插件已绘制，TESSNG不再绘制，否则TESSNG进行绘制。

**public boolean paintLaneObject(ILaneObject pILaneObj, Painter painter)**

​	绘制车道或车道连接。

参数：

​	[ in ] pILaneObj：车道或车道连接。

​	[ in ] painter：QPainter对象。

返回：

​	如果返回true，TESSNG认为插件已绘制，TESSNG不再绘制，否则TESSNG进行绘制。

**public boolean linkBuildGLanes(ILink pILink)**

​	创建车道。

参数：

​	[ in ] pILink：路段对象。

返回：

​	如果返回true，TESSNG认为插件已创建了车道，TESSNG不再创建。

**public boolean linkBrushColor(long linkID, Color color)**

​	路段笔刷颜色。

参数：

​	[ in ] linkID：路段ID。

​	[ out ] color：QColor对象。

返回：

​	true表示用color颜色绘制路段。

示例：

```java
@Override
public boolean linkBrushColor(long linkID, Color color) {
	// 指定路段设置为红色
	Set<Long> targetLinkIds = new HashSet<>();
    targetLinkIds.add(1L);
    targetLinkIds.add(2L);
    targetLinkIds.add(3L);
    if (targetLinkIds.contains(linkID)) {
        color[0] = new Color(255, 0, 0);
        return true;
    }
    return false;
}
```

~~**public boolean laneBrushAndPen(long laneID, QBrush brush, QPen pen)**~~

​	~~通过指定车道ID设置绘制车道的笔刷。~~

~~参数：~~

​	~~[ in ] laneID：车道ID。~~

​	~~[ out ] brush：QBrush 对象。~~

​	~~[ out ] pen：QPen 对象。~~

~~返回：~~

​	~~true表示用brush及pen参数绘制ID等于laneID的车道。~~

**public boolean connectorAreaBrushColor(long connAreaID, Color color)**

​	面域笔刷颜色。

参数：

​	[ in ] connAreaID：面域ID。

​	[ out ] color：笔刷颜色。

返回：

​	true表示TESSNG用color绘制面域。

**public void labelNameAndFont(int itemType, long itemId, ObjInt outPropName, ObjReal outFontSize)**

**public void ref_labelNameAndFont(int itemType, long itemId, ObjInt ref_outPropName, ObjReal ref_outFontSize)**

​	通过路网元素类型及ID确定用标签用ID或名称作为绘制内容。

参数：

​	[ in ] itemType：路段元素类型。

​	[ in ] itemID：路网元素ID。

​	[ out ] outPropName：枚举值。如果赋值GraphicsItemPropName.Id.swigValue()，则用ID作为绘制内容，如果赋值GraphicsItemPropName.Name.swigValue()，则用路网元素名作为绘制内容。

​	 [ out ] outFontSize：字体大小。单位：m。

返回：	

​	true表示通过设定的outPropName 值确定用ID或名称绘制标签，并且用指定大小绘制。

示例：

```java
@Override
public void ref_labelNameAndFont(int itemType, long itemId, ObjInt ref_outPropName, ObjReal ref_outFontSize) {
    // 如果仿真正在进行，路段和车道都不绘制标签
    if (simuiface.isRunning()) {
        ref_outPropName.setValue(GraphicsItemPropName.None.swigValue());
        return;
    }

    // 默认绘制ID
    ref_outPropName.setValue(GraphicsItemPropName.Id.swigValue());
    // 标签大小为6m
    ref_outFontSize.setValue(6);

    // 如果是连接段一律绘制名称
    if (itemType == NetItemType.getGConnectorType()) {
        ref_outPropName.setValue(GraphicsItemPropName.Name.swigValue());
    }
    // 如果是路段，则根据ID判断是否绘制名称
    else if (itemType == NetItemType.getGLinkType()) {
        if (itemId == 1 || itemId == 5 || itemId == 6) {
            ref_outPropName.setValue(GraphicsItemPropName.Name.swigValue());
        }
    }
}
```

### 3.2.3.仿真插件（JCustomerSimulator）

​	JCustomerSimulator是TessPlugin子插件接口，用户通过实现该插件，可以在仿真前后以及仿真过程中执行自定义操作，既能全局控制仿真的启停逻辑，也能精细化干预单个车辆的驾驶行为。

#### 3.2.3.1.仿真启停

**public void beforeStart(ObjBool keepOn)**

**public void ref_beforeStart(ObjBool ref_keepOn)**

​	用于实现启动仿真前的自定义操作。如果需要，用户可通过设置keepOn为false来放弃仿真。

参数：

​	[ out ] keepOn：是否继续，默认为true。

**public void afterStart()**

​	用于实现启动仿真后的自定义操作。

**public void afterStop()**

​	用于实现结束仿真后的自定义操作。

示例：

```java
@Override
public void afterStop() {
    // 如果仿真次数不足3次，则重启仿真
    if (this.simuCount <= 3) {
        simuiface.startSimu();
    }
}
```

**public void afterOneStep()**

​	用于实现完成一帧仿真后的自定义操作。这个时候所有车辆都完成同一个批次的计算。通常在这个方法中获取车辆轨迹、检测器数据、进行必要的小计等。在这个方法中进行的计算基本不影响仿真结果的一致性，但效率不高，如果计算量大对仿真效率会有影响。

**public void duringOneStep()**

​	该方法在各个工作线程进行同一批次的计算过程中调用，这时存在部分车辆计算完成，部分车辆仍在计算过程中。这个方法中的计算不够安全，但效率较高。

**public boolean calcSimuConfig(SimuConfig config)**

​	计算仿真参数 。

参数：

​	[ out ] config：仿真参数信息。

返回：

​	true表示用config中的参数更新仿真参数。如果仿真已启动，仿真精度及线程数不能更新，仿真时长及加速倍数可以更新。

#### 3.2.3.2.车辆控制

**public void initVehicle(IVehicle pIVehicle)**

​	用于实现车辆创建后的自定义操作。用户可以在这个方法里对车辆的车道序号、起始位置、车辆大小进行初始化。

参数：

​	[ in ] pIVehicle：车辆对象。

示例：

```java
@Override
public void initVehicle(IVehicle pIVehicle) {
    // 如果是小客车，则设为蓝色
    if (pIVehicle.vehicleTypeCode() == 1) {
        pIVehicle.setColor("#00AFF0");
    }
}
```

**public boolean isStopDriving(IVehicle pIVehicle)**

​	用于判断是否要停止车辆的运行。

参数：

​	[ in ] pIVehicle：车辆对象。

返回：

​	true表示将停止该车辆运行，移出路网。

示例：

```java
@Override
public boolean isStopDriving(IVehicle pIVehicle) {
    // 如果车辆进入12号路段，则移除
    if (pIVehicle.roadIsLink() && pIVehicle.roadId() == 12) {
        return true;
    }
    return false;
}
```

**public void beforeStopVehicle(IVehicle pIVehicle)**

​	用于实现车辆移除前的自定义操作。

参数：

​	[ in ] pIVehicle：车辆对象。 

**public void afterStopVehicle(IVehicle pIVehicle)**

​	用于实现车辆移除后的自定义操作。

参数：

​	[ in ] pIVehicle：车辆对象。

**public void afterStep(IVehicle pIVehicle)**

​	用于实现车辆完成一帧仿真后的自定义操作。可以在此获取车辆当前信息，如当前道路、位置、方向角、速度、期望速度、前后左右车辆等。

参数：

​	[ in ] pIVehicle：车辆对象。

**public boolean calcAcce(IVehicle pIVehicle, ObjReal acce)**

**public boolean calcAcce(IVehicle pIVehicle, ObjReal acce, ObjUnitOfMeasure unit)**

**public boolean ref_calcAcce(IVehicle pIVehicle, ObjReal acce)**

**public boolean ref_calcAcce_unit(IVehicle pIVehicle, ObjReal ref_acce, ObjUnitOfMeasure ref_unit)**

​	计算车辆的加速度。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ out ] acce：车辆加速度。单位：像素/s²。

返回：	

​	如果返回true，则将acce作为当前加速度。

示例：

```java
@Override
public boolean ref_calcAcce_unit(IVehicle pIVehicle, ObjReal acce, ObjUnitOfMeasure ref_unit) {
    if (pIVehicle.roadName() == "曹安公路") {
        // 根据速度不同，直接计算加速度
        if (pIVehicle.currSpeed() > 20/3.6) {
            acce.setValue(-3);
            return true;
        }
        else if (pIVehicle.currSpeed() > 10/3.6) {
            acce.setValue(-1);
            return true;
        }
    }
    return false;
}
```

**public boolean reSetAcce(IVehicle pIVehicle, ObjReal inOutAcce)**

**public boolean reSetAcce(IVehicle pIVehicle, ObjReal inOutAcce, ObjUnitOfMeasure unit)**

**public boolean ref_reSetAcce(IVehicle pIVehicle, ObjReal ref_inOutAcce)**

**public boolean ref_reSetAcce_unit(IVehicle pIVehicle, ObjReal ref_inOutAcce, ObjUnitOfMeasure ref_unit)**

​	重新计算车辆的加速度。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in, out ] inOutAcce：车辆加速度。单位：像素/s²。

返回：

​	如果返回true，则将inOutAcce作为当前加速度。

示例：

```java
@Override
public boolean ref_reSetAcce_unit(IVehicle pIVehicle, ObjReal inOutAcce, ObjUnitOfMeasure ref_unit) {
    if (pIVehicle.roadName() == "曹安公路") {
        // 根据速度不同，对已计算出的加速度进行修正
        if (pIVehicle.currSpeed() > 20/3.6) {
            acce.setValue(acce.getValue() + (-3));
            return true;
        }
        else if (pIVehicle.currSpeed() > 10/3.6) {
            acce.setValue(acce.getValue() + (-1));
            return true;
        }
    }
    return false;
}
```

**public boolean reCalcdesirSpeed(IVehicle pIVehicle, ObjReal inOutDesirSpeed)**

**public boolean reCalcdesirSpeed(IVehicle pIVehicle, ObjReal inOutDesirSpeed, ObjUnitOfMeasure unit)**

**public boolean ref_reCalcdesirSpeed(IVehicle pIVehicle, ObjReal ref_desirSpeed)**

**public boolean ref_reCalcdesirSpeed_unit(IVehicle pIVehicle, ObjReal ref_inOutDesirSpeed, ObjUnitOfMeasure ref_unit)**

​	重新计算车辆的期望速度。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in, out ] inOutDesirSpeed：车辆期望速度。单位：像素/s²。

返回：

​	如果返回true，则将inOutDesirSpeed作为期望速度。

**public boolean calcMaxLimitedSpeed(IVehicle pIVehicle, ObjReal inOutLimitedSpeed)**

**public boolean calcMaxLimitedSpeed(IVehicle pIVehicle, ObjReal inOutLimitedSpeed, ObjUnitOfMeasure unit)**

**public boolean ref_calcMaxLimitedSpeed(IVehicle pIVehicle, ObjReal ref_inOutLimitedSpeed)**

**public boolean ref_calcMaxLimitedSpeed_unit(IVehicle pIVehicle, ObjReal ref_inOutLimitedSpeed, ObjUnitOfMeasure ref_unit)**

​	重新计算车辆的当前最大限速。在没有插件干预的情况下，车辆速度大于道路限度时按道路最大限速行驶，在此方法的干预下，可以提高限速，让车辆大于道路限速行驶。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in, out ] inOutLimitedSpeed：车辆最大限速，单位：像素/秒。

返回：

​	如果返回true，则将inOutLimitedSpeed作为当前道路最大限速。

**public boolean calcSpeedLimitByLane(ILink pILink, int laneNumber, ObjReal outSpeed)**

**public boolean calcSpeedLimitByLane(ILink pILink, int laneNumber, ObjReal outSpeed, ObjUnitOfMeasure unit)**

**public boolean ref_calcSpeedLimitByLane(ILink pILink, int laneNumber, ObjReal ref_outSpeed)**

**public boolean ref_calcSpeedLimitByLane_unit(ILink pILink, int laneNumber, ObjReal ref_outSpeed, ObjUnitOfMeasure ref_unit)**

​	由车道确定的限制车速。

参数：

​	[ in ] pILink：路段对象。

​	[ in ] laneNumber：laneNumber：车道序号，最右侧编号为0。

​	[ in, out ] outSpeed：车辆限速。单位：km/h。

返回：	

​	如果返回true，则将outSpeed作为车道限速。

**public boolean reSetSpeed(IVehicle pIVehicle, ObjReal inOutSpeed)**

**public boolean reSetSpeed(IVehicle pIVehicle, ObjReal inOutSpeed, ObjUnitOfMeasure unit)**

**public boolean ref_reSetSpeed(IVehicle pIVehicle, ObjReal ref_inOutSpeed)**

**public boolean ref_reSetSpeed_unit(IVehicle pIVehicle, ObjReal ref_inOutSpeed, ObjUnitOfMeasure ref_unit)**

​	重新计算车辆的速度。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in, out ] inOutSpeed：车辆速度。单位：像素/s。

返回：

​	如果返回true，则将inOutSpeed作为车辆当前速度。

示例：

```java
@Override
public boolean ref_reSetSpeed_unit(IVehicle pIVehicle, ObjReal ref_inOutSpeed, ObjUnitOfMeasure ref_unit) {
    if (pIVehicle.id() == 100001) {
        // 直接指定车辆的速度
        ref_inOutSpeed.setValue(80 / 3.6);
        return true;
    }
    return false;
}
```

**public boolean reCalcAngle(IVehicle pIVehicle, ObjReal outAngle)**

**public boolean ref_reCalcAngle(IVehicle pIVehicle, ObjReal ref_outAngle)**

​	重新计算车辆的角度。北向为0度，顺时针。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in, out ] inOutAngle：车辆角度。单位：角度。

返回：

​	如果返回true，则将inOutAngle作为车辆当前角度。

**public boolean reSetFollowingType(IVehicle pIVehicle, ObjInt outTypeValue)**

**public boolean ref_reSetFollowingType(IVehicle pIVehicle, ObjInt ref_outTypeValue)**

​	重新设置车辆的跟驰类型。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ out ] outTypeValue：跟驰类型。0：停车，1：正常，5：急减速，6：急加速，7：汇入，8：穿越，9：协作减速，10：协作加速，11：减速待转，12：加速待转。

返回：	

​	如果返回true，则将outTypeValue作为车辆的跟驰类型。

**public boolean reSetFollowingParam(IVehicle pIVehicle, ObjReal inOutSafeInterval, ObjReal inOutSafeDistance)**

**public boolean reSetFollowingParam(IVehicle pIVehicle, ObjReal inOutSafeInterval, ObjReal inOutSafeDistance, ObjUnitOfMeasure unit)**

**public boolean ref_reSetFollowingParam(IVehicle pIVehicle, ObjReal ref_inOutSafeInterval, ObjReal ref_inOutSafeDistance)**

**public boolean ref_reSetFollowingParam_unit(IVehicle pIVehicle, ObjReal ref_inOutSafeInterval, ObjReal ref_inOutSafeDistance, ObjUnitOfMeasure ref_unit)**

​	重新设置车辆的跟驰模型的安全间距和安全时距。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in, out ] inOutSafeInterval：安全时距，单位：秒。

​	[ in, out ] inOutSafeDistance：安全间距，单位：像素。

返回：

​	如果返回true，则将inOutSafeInterval作为车辆的安全时距，将inOutSafeDistance作为车辆的安全间距。

**public ArrayList\<FollowingModelParam\> reSetFollowingParams()**

​	重新设置车辆的跟驰模型参数，使用得到跟驰模型数据取代当前仿真正在采用的跟驰模型，影响所有车辆。

返回：

​	跟驰参数列表，可对机动车和非机车的跟驰参数重新设置，**设置以后会一直被采用**，直到被新的参数所代替。

**public boolean reSetDistanceFront(IVehicle pIVehicle, ObjReal distance, ObjReal s0)**

**public boolean reSetDistanceFront(IVehicle pIVehicle, ObjReal distance, ObjReal s0, ObjUnitOfMeasure unit)**

**public boolean ref_reSetDistanceFront(IVehicle pIVehicle, ObjReal distance, ObjReal s0)**

**public boolean ref_reSetDistanceFront_unit(IVehicle pIVehicle, ObjReal ref_distance, ObjReal ref_s0, ObjUnitOfMeasure ref_unit)**

​	重新设置车辆的前车间距和停车距离。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in, out ] distance：当前车辆与前车的距离。单位：像素。

​	[ in, out ] s0：停车距离。单位：像素。

返回：

​	如果返回true，则将distance作为车辆的前车距，将s0作为车辆的停车距离。

**public boolean calcChangeLaneSafeDist(IVehicle pIVehicle, ObjReal dist)**

**public boolean calcChangeLaneSafeDist(IVehicle pIVehicle, ObjReal dist, ObjUnitOfMeasure unit)**

**public boolean ref_calcChangeLaneSafeDist(IVehicle pIVehicle, ObjReal ref_dist)**

**public boolean ref_calcChangeLaneSafeDist_unit(IVehicle pIVehicle, ObjReal ref_dist, ObjUnitOfMeasure ref_unit)**

​	计算车辆的安全变道距离。

参数：

​	[ in ] pIVehicle：车辆，计算该车辆安全变道距离。

​	[ in, out ] dist：安全变道距离。单位：像素。

返回：

​	如果返回true，则将dist作为车辆的安全变道距离。

**public boolean reCalcToLeftLane(IVehicle pIVehicle)**

​	计算是否要左强制变道，仅在TESSNG判定无需执行向左强制变道时生效，不能阻止TESSNG对车辆向左强制变道的控制。

参数：

​	[ in ] pIVehicle：车辆对象。

返回：

​	如果返回true，则控制车辆向左强制变道。

**public boolean reCalcToRightLane(IVehicle pIVehicle)**

​	计算是否要右强制变道，仅在TESSNG判定无需执行向右强制变道时生效，不能阻止TESSNG对车辆向右强制变道的控制。

参数：

​	[ in ] pIVehicle：车辆对象。

返回：

​	如果返回true，则控制车辆向右强制变道。

**public void beforeToLeftFreely(IVehicle pIVehicle, ObjBool bKeepOn)**

**public void ref_beforeToLeftFreely(IVehicle pIVehicle, ObjBool ref_keepOn)**

​	TESSNG计算是否向左自由变道前的处理。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in, out ] bKeepOn：是否继续，如果被赋值为false，则TESSNG不再计算是否可以向左自由变道。

**public void beforeToRightFreely(IVehicle pIVehicle, ObjBool bKeepOn)**

**public void ref_beforeToRightFreely(IVehicle pIVehicle, ObjBool ref_keepOn)**

​	TESSNG计算是否向右自由变道前的处理。

​	[ in ] pIVehicle：车辆对象。

​	[ in, out ] bKeepOn：是否继续，如果被赋值为false，则TESSNG不再计算是否可以向右自由变道。

**public boolean reCalcToLeftFreely(IVehicle pIVehicle)**

​	重新计算车辆是否要向左自由变道，仅在TESSNG判定无需执行向左自由变道时生效，不能阻止TESSNG对车辆向左自由变道的控制。

参数：

​	[ in ] pIVehicle：车辆对象。

返回：

​	如果返回true，则控制车辆向左自由变道。

**public boolean reCalcToRightFreely(IVehicle pIVehicle)**

​	重新计算车辆是否要向右自由变道，仅在TESSNG判定无需执行向右自由变道时生效，不能阻止TESSNG对车辆向右自由变道的控制。

参数：

​	[ in ] pIVehicle：车辆对象。

返回：

​	如果返回true，则控制车辆向右自由变道。

**public boolean reCalcDismissChangeLane(IVehicle pIVehicle)**

​	重新计算车辆是否撤销变道。

参数：

​	[ in ] pIVehicle：车辆对象。

返回：

​	如果返回true，且当前变道完成度不超过三分之一，则撤销当前变道行为。

示例：

```java
@Override
public boolean reCalcDismissChangeLane(IVehicle pIVehicle) {
	// 距离路段终点小于50m时撤销一切自由变道，达到禁止自由变道的效果
    if (pIVehicle.vehicleDriving().distToEndpoint(true, true, UnitOfMeasure.Metric) < 50) {
        return true;
    }
    return false;
}
```

**public ArrayList\<Int\> calcLimitedLaneNumber(IVehicle pIVehicle)**

​	计算限制车道序号：如管制、危险等，最右侧编号为0。

参数：

​	[ in ] pVehicle：车辆对象。

返回：

​	车道序号序列，保存车辆不可以驶入的车道序号。

示例：

```java
@Override
public ArrayList<Int> calcLimitedLaneNumber(IVehicle pIVehicle) {
    // 如果车辆在路段上且车辆长度大于8m，则禁止驶入最内侧车道
    if (pIVehicle.roadIsLink() && pIVehicle.length(UnitOfMeasure.Metric) > 8) {
        int limitLaneNumber = pIVehicle.lane().link().laneCount();
        List<Integer> restrictedLanes = new ArrayList<>();
        restrictedLanes.add(limitLaneNumber);
        return restrictedLanes;
    }
    return new ArrayList<>();
}
```

**public ArrayList\<ILaneConnector\> candIDateLaneConnectors(IVehicle pIVehicle, ArrayList\<ILaneConnector\> lInLC)**

​	计算当车辆离开路段时后续可经过的车道连接，用户可以从可通行的车道连接序列中筛选或重新计算。如果车辆有路径，则忽略。

参数：

​	[ in ] pVehicle：车辆对象。

​	[ in ] lInLC：已计算出的当前车道可达的所有车道连接。

返回：

​	后续可达的车道连接序列。

**public ILaneConnector candIDateLaneConnector(IVehicle pIVehicle, ILaneConnector pCurrLaneConnector)**

​	计算车辆后续要走的车道连接，此时车辆正跨出当前路段，将驶到pCurrLaneConnector上。此方法可以改变后续车道连接。如果返回的车道连接为空，TESSNG会忽略此方法的调用。如果返回的车道连接不在原有路径上，或者此方法设置了新路径且新路径不经过返回的车道连接，TESSNG调用此方法后会将路径设为空。

参数：

​	[ in ] pVehicle：车辆对象。

​	[ in ] pCurrLaneConnector：已计算出的当前车道要走的车道连接。

返回：

​	重新设置的车道连接。

**public void beforeNextPoint(IVehicle pIVehicle, ObjBool keepOn)**

**public void ref_beforeNextPoint(IVehicle pIVehicle, ObjBool ref_keepOn)**

​	计算车辆移动到下一点前的操作，用户可以通过此方法让TESSNG放弃对指定车辆到下一点的计算。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ out ] keepOn：是否继续，如果keepOn赋值为false，TESSNG放弃移动到下一点的计算，但不移出路网。

**public void beforeMergingToLane(IVehicle pIVehicle, ObjBool keepOn)**

**public void ref_beforeMergingToLane(IVehicle pIVehicle, ObjBool ref_keepOn)**

​	在车道连接上汇入车道前的计算，可以让TESS NG放弃汇入计算，以便于用户实现自己的汇入逻辑。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ out ] keepOn：是否放弃，如果keepOn赋值为false，TESSNG放弃汇入。

**public void beforeNextRoad(IVehicle pIVehicle, SWIGTYPE_p_p_QGraphicsItem pRoad, ObjBool keepOn)**

**public void ref_beforeNextRoad(IVehicle pIVehicle, SWIGTYPE_p_QGraphicsItem pRoad, ObjBool ref_keepOn)**

​	计算下一道路前的处理。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in ] pRoad：暂不使用的参数。

​	[ in, out ] keepOn：是否继续计算，如果keepOn赋值为false，TESSNG不再计算后续道路。

**public void afterCalcTracingType(IVehicle pIVehicle)**

​	计算跟驰类型后的处理。

参数：

​	[ in ] pIVehicle：车辆对象。

**public void busArriving(IVehicle pIVehicle, IBusStationLine pStationLine, int alightingCount, int alightingTime, int boardingCount, int boardingTime)**

​	公交到站后的处理。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in ] pStationLine：站点线路。

​	[ in ] alightingCount：下客人数。单位：人。

​	[ in ] alightingTime：下客所需总时间。单位：s。

​	[ in ] boardingCount：上客人数。单位：人。

​	[ in ] boardingTime：上客所需总时间。单位：s。

**public void leaveForNextLaneObj(IVehicle pIVehicle, ILaneObject pCurrLaneObj, ILaneObject pNextLaneObj)**

​	车辆即将跨道路时调用。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in ] pCurrLaneObj：当前车道对象。

​	[ in ] pNextLaneObj：即将进入的车道对象。

**public boolean travelOnChangingTrace(IVehicle pIVehicle)**

​	车辆行驶在变道轨迹上时调用。

参数：

​	[ in ] pIVehicle：车辆对象。

**public boolean leaveOffChangingTrace(IVehicle pIVehicle, double differ, ObjReal s)**

​	车辆驶出变道轨迹时调用。

参数：

​	[ in ] pIVehicle：车辆对象。

**public boolean isCalcVehicleVector3D()**

​	是否计算车辆3D属性，如欧拉角等。

返回：

​	如果返回true，表示需要计算车辆的3D属性。

**public Vector3D calcVehicleEuler(IVehicle pIVehicle, boolean bPosIDire)**

​	计算车辆的欧拉角。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ in ] bPosIDire：车头方向是否正向计算，如果bPosIDire为false则反向计算。

返回：

​	车辆的欧拉角。

**public String vehiRunInfo(IVehicle pIVehicle)**

​	控制车辆运行状态弹窗中的文本框的文本信息。在仿真过程中选中某辆车，且按下Ctrl+i可弹窗车辆运行状态弹窗。

返回：

​	显示在车辆运行状态弹窗中的文本框的文本信息。

示例：

```java
@Override
public String vehiRunInfo(IVehicle pIVehicle) {
    return String.format("车辆当前在ID=%d的道路上", pIVehicle.roadId());
}
```

**public boolean boundingRect(IVehicle pIVehicle, RectF outRect)**

​	获取车辆边界矩形。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ out ] outRect：车辆边界矩形。

**public boolean shape(IVehicle pIVehicle, QPainterPath outShape)**

​	获取车辆图形路径。

参数：

​	[ in ] pIVehicle：车辆对象。

​	[ out ] outShape：车辆形状路径。

~~**public boolean paintVehicle(IVehicle pIVehicle, Painter painter)**~~

​	~~绘制车辆。~~

~~参数：~~

​	~~[ in ] pIVehicle：车辆对象。~~

​	~~[ in ] painter：QPainter对象。~~

~~返回：~~	

​	~~如果返回true，TESSNG认为用户已经绘制车辆，TESSNG不再绘制车辆。~~

~~**public boolean paintVehicleWithRotation(IVehicle pIVehicle, Painter painter, double inOutRotation)**~~

​	~~绘制车辆，绘制前将车辆对象旋转指定角度。~~

~~参数：~~

​	~~[ in ] pIVehicle：车辆对象。~~

​	~~[ in ] painter：QPainter对象。~~

​	~~[ in ] inOutRotation：旋转的角度。单位：度。~~

~~返回：~~

​	~~如果返回true，TESSNG认为用户已经绘制车辆，TESSNG不再绘制车辆。~~

~~**public void rePaintVehicle(IVehicle pIVehicle, Painter painter)**~~

​	~~添加TESSNG绘制车辆后的自定义绘制内容。~~

~~参数：~~

​	~~[ in ] pIVehicle：车辆对象。~~

​	~~[ in ] painter：QPainter对象。~~

#### 3.2.3.3.信号灯控制

**public boolean beforeCalcLampColor(ObjBool keepOn)**

**public boolean ref_beforeCalcLampColor(ObjBool ref_keepOn)**

​	用于实现计算信号灯色前的自定义操作。

参数：

​	[ in, out ] 是否继续计算。

返回：	

​	如果返回true，且keepOn被赋值为false，则TESSNG不再计算信号灯色。

**public boolean calcLampColor(ISignalLamp pSignalLamp)**

​	计算信号灯的灯色。

参数：

​	[ in ] pSignalLamp：信号灯对象。

返回：

​	如果返回true，表明用户已修改了信号灯颜色，TESS NG不再计算灯色。

示例：

```java
@Override
public boolean calcLampColor(ISignalLamp pSignalLamp) {
    // 若信号灯ID为1，则设为绿色
	if (pSignalLamp.id() == 1) {
		pSignalLamp.setLampColor("G");
		return true;
	}
	return false;
}
```

#### 3.2.3.4.其他

**public void beforeCreateGVehiclesForBusLine(IBusLine pBusLine, ObjBool keepOn)**

**public void ref_beforeCreateGVehiclesForBusLine(IBusLine pBusLine, ObjBool ref_keepOn)**

​	用于实现创建公交车辆前的自定义操作。

参数：

​	[ in ] pBusLine：公交线路。

​	[ in, out ] keepOn：是否继续执行创建公交车辆。

返回：

​	如果返回true，且keepOn被赋值为false，则TESSNG不再创建公交车辆。

**public ArrayList\<DecipointFlowRatioByInterval\> calcDynaFlowRatioParameters()**

​	计算动态流量分配信息。

返回：

​	决策点流量分配信息序列。

示例：

```java
@Override
public ArrayList<DecipointFlowRatioByInterval> calcDynaFlowRatioParameters() {
    ArrayList<DecipointFlowRatioByInterval> result = new ArrayList<>();
    // 当前仿真计算批次
    long batchNumber = simuiface.batchNumber();
    // 在计算第20批次时修改某决策点各路径流量比
    if (batchNumber == 20) {
        // 一个决策点某个时段各路径车辆分配比
        DecipointFlowRatioByInterval dfi = new DecipointFlowRatioByInterval();
        // 决策点编号
        dfi.setDeciPointID(5);
        // 起始时间 单位：秒
        dfi.setStartDateTime(1);
        // 结束时间 单位：秒
        dfi.setEndDateTime(999999);
        // 路径流量比
        ArrayList<RoutingFlowRatio> ratios = new ArrayList<>();
        ratios.add(new RoutingFlowRatio(1, 3));
        ratios.add(new RoutingFlowRatio(2, 4));
        ratios.add(new RoutingFlowRatio(3, 3));
        dfi.setRoutingFlowRatios(ratios);
        result.add(dfi);
    }
    return result;
}
```

**public ArrayList\<DispatchInterval\> calcDynaDispatchParameters()**

​	计算动态发车信息。

返回：

​	动态发车信息序列。

示例：

```java
@Override
public ArrayList<DispatchInterval> calcDynaDispatchParameters() {
    DispatchInterval di = new DispatchInterval();
    // 发车点ID
    di.setDispatchId(1);
    // 开始时间，单位：s
    di.setFromTime(0);
    // 结束时间，单位：s
    di.setToTime(300);
    // 车辆数
    di.setVehiCount(300);
    // 车辆组成列表
    ArrayList<VehiComposition> composition = new ArrayList<>();
    composition.add(new VehiComposition(1, 60));
    composition.add(new VehiComposition(2, 40));
    di.setVehicleConsDetails(composition);
    ArrayList<DecipointFlowRatioByInterval> result = new ArrayList<>();
    result.add(di);
    return result;
}
```



## 3.3.接口

​	与侧重 “流程扩展与逻辑干预”的插件不同，接口聚焦于**“数据交互与状态调控”**，其包含顶级接口TessInterface ，以及NetInterface、SimuInterface两个子接口，为用户提供了路网、仿真两类核心信息的获取与设置能力，用户可通过它直接读取路网的拓扑结构、仿真的实时参数（如时间步长、车辆总数），也能主动修改这些信息以调整系统基础状态。

​	顶级接口对象具备全局变量的特性，可在代码的任意位置进行实例化。不过，从代码可维护性与使用便捷性的角度出发，我们更建议在**构造函数**中完成各接口的初始化操作，例如：

```java
// MySimulator.java
public class MySimulator extends JCustomerSimulator {
    // 代表TESS NG的接口
    private TessInterface iface;
    // 代表TESS NG 的路网子接口
    private NetInterface netiface;
    // 代表TESS NG 的仿真子接口
    private SimuInterface simuiface;

    public MySimulator() {
        super();
        iface = TESSNG.tessngIFace();
        netiface = iface.netInterface();
        simuiface = iface.simuInterface();
    }
```

### 3.3.1.顶级接口（TessInterface）

​	TessInterface 是TESSN对外暴露的顶级接口，下面有两个子接口：NetInterface、SimuInterface，分别用于访问或控制路网和仿真过程。

**public JsonObject config()**

​	获取json对象，其中保存了config.json配置文件中的信息，每次加载路网时会重新加载配置信息。

**public void setConfigProperty(String key, QVariant value)**

​	设置配置属性。

**public boolean loadPluginFromMem()**

​	加载插件。

**public void releasePlugins()**

​	卸载插件。

**public NetInterface netInterface()**

​	返回用于访问控制路网的接口NetInterface。

示例：

```java
netiface = iface.netInterface();
```

**public SimuInterface simuInterface()**

​	返回用于控制仿真过程的接口SimuInterface。

示例：

```java
simuiface = iface.simuInterface();
```

### 3.3.2.路网接口（NetInterface）

​	NetInterface是TessInterface的子接口，用于访问、控制路网元素的接口，通过这个接口可以对路段和连接段等路网元素进行查询、创建、删除和更改。

#### 3.3.2.1.路网

**public String netFilePath()**

​	获取路网文件全路径名，如果是专业数据保存的路网，返回的是路网ID。

示例：

```java
String netFilePath = netiface.netFilePath();
```

**public void saveRoadNet()**

​	保存当前路网文件。

**public void openNetFle(String filePath)**

​	打开路网文件。

参数：

​	[ in ] filePath：路网文件全路径名。

**public boolean createEmptyNetFile(String filePath, long dbver)**

​	创建空白路网。

参数：

​	[ in ] filePath：空白路网全路径名。

​	[ in ] dbver：数据库版本。

**public void openNetByNetId(long netId)**

​	从专业数据库加载路网。

**public IRoadNet netAttrs()**

​	获取路网属性对象。

**public IRoadNet roadNet()**

​	获取路网属性对象。同netAttrs。

**public IRoadNet setNetAttrs(String name, String sourceType, Point centerPoint, String backgroundUrl, JsonObject otherAttrsJson)**

​	设置路网基本信息。

参数：

​	[ in ] name：路网名称。

​	[ in ] sourceType：数据来源分类，默认为 "TESSNG"，表示路网由TESSNG软件直接创建。取值"OPENDRIVE"，表示路网是经过opendrive路网导入而来。

​	[ in ] centerPoint：中心点坐标所在路网，默认为(0，0)，用户也可以将中心点坐标保存到otherAttrsJson字段里。

​	[ in ] backgroundUrl：底图路径。

​	[ in ] otherAttrsJson：保存在json对象中的其它属性，如大地坐标等信息。

返回：

​	路网属性对象。

**public QGraphicsScene graphicsScene()**

​	获取场景对象。

**public QGraphicsView graphicsView()**

​	获取视图对象。

**public double sceneScale()**

​	获取场景中的像素比。单位：m/像素。

**public double sceneWidth(UnitOfMeasure unit)**

​	获取场景宽度。单位：像素。

**public double sceneHeigth(UnitOfMeasure unit)**

​	获取场景高度。单位：像素。

**public byte[] backgroundMap()**

​	获取背景图字节。

**public RectF boundingRect()**

​	获取路网边界。

**public long getIDByItemName(String name)**

​	通过路网元素名获取自增ID。

参数：

​	[ in ] name：路网元素名。

**public boolean initSequence(String schemaName)**

​	初始化数据库序列，对保存路网的专业数据库序列进行初始化，目前支持PostgreSql。

参数：

​	[ in ] schemaName：数据库的schema名称。

#### 3.3.2.2.道路

**public ArrayList\<ISection\> sections()**

​	获取所有道路。

#### 3.3.2.3.路段

**public int linkCount()**

​	获取路段数。

**public ArrayList\<Long\> linkIds()**

​	获取路段路段ID序列。

**public ArrayList\<ILink\> links()**

​	获取路段对象序列。

示例：

```java
for (Link link : netiface.links()) {
    System.out.println(link.id());
}
```

**public ILink findLink(long id)**

​	通过路段ID获取路段对象。

**public ArrayList\<Point\> linkCenterPoints(long linkID, UnitOfMeasure unit)**

​	获取指定路段中心线断点序列。单位：像素。

参数：

​	[ in ] linkID：指定路段ID。

**public ILink createLink(ArrayList\<Point\> lCenterPoint, int laneCount, String linkName, boolean bAddToScene, UnitOfMeasure unit)**

​	创建路段。单位：像素。

参数：

​	[ in ] lCenterPoint：路段中心线断点序列。

​	[ in ] laneCount：车道数。

​	[ in ] linkName：路段名称。

​	[ in ] bAddToScene：是否添加到场景。

返回：

​	路段对象。

示例：

```java
List<Point> linkPoints2D = new ArrayList<>();
linkPoints2D.add(new Point(-300, 0));
linkPoints2D.add(new Point(300, 0));
ILink link = netiface.createLink(linkPoints2D, 7, "曹安公路", true, UnitOfMeasure.Metric);
```

**public ILink createLink3D(ArrayList\<Vector3D\> lCenterV3, int laneCount, String linkName, boolean bAddToScene, UnitOfMeasure unit)**

​	创建3D路段。单位：像素。

参数：

​	[ in ] lCenterV3：路段中心线三维断点集。

​	[ in ] laneCount：车道数。

​	[ in ] linkName：路段名称。

​	[ in ] bAddToScene：是否添加到场景。

​	[ in ] unit：单位参数，默认为Default，Metric表示米制单位，Default表示无单位限制。

返回：

​	路段对象。

示例：

```java
List<Vector3D> linkPoints3D = new ArrayList<>();
linkPoints3D.add(new Vector3D(-300, 0, 10));
linkPoints3D.add(new Vector3D(300, 0, 20));
link = netiface.createLink3D(linkPoints3D, 7, "曹安公路", true, UnitOfMeasure.Metric);
```

**public ILink createLinkWithLaneWidth(ArrayList\<Point\> lCenterPoint, ArrayList\<Double\> lLaneWidth, String linkName, boolean bAddToScene, UnitOfMeasure unit)**

​	创建指定车道宽度的路段。单位：像素。

参数：

​	[ in ] lCenterPoint：路段中心线断点序列。

​	[ in ] lLaneWidth：车道宽度列表。

​	[ in ] linkName：路段名称。

​	[ in ] bAddToScene：是否添加到场景。

返回：

​	路段对象。

示例：

```java
List<Point> linkPointsWithWidth = new ArrayList<>();
linkPointsWithWidth.add(new Point(-300, 0));
linkPointsWithWidth.add(new Point(300, 0));

List<Double> laneWidthList = new ArrayList<>();
laneWidthList.add(1.0);
laneWidthList.add(3.5);
laneWidthList.add(3.5);
laneWidthList.add(3.5);

link = netiface.createLinkWithLaneWidth(linkPointsWithWidth, laneWidthList, "曹安公路", true, UnitOfMeasure.Metric);
       
```

**public ILink createLink3DWithLaneWidth(ArrayList\<Vector3D\> lCenterV3, ArrayList\<Double\> lLaneWidth, String linkName, boolean bAddToScene, UnitOfMeasure unit)**

​	创建指定车道宽度的3D路段。单位：像素。

参数：

​	[ in ] lCenterV3：路段中心线三维断点序列。

​	[ in ] lLaneWidth：车道宽度列表。

​	[ in ] linkName：路段名称。

​	[ in ] bAddToScene：是否添加到场景。

返回：

​	路段对象。

示例：

```java
List<Vector3D> linkPoints3DWithWidth = new ArrayList<>();
linkPoints3DWithWidth.add(new Vector3D(-300, 0, 10));
linkPoints3DWithWidth.add(new Vector3D(300, 0, 20));

List<Double> laneWidthList = new ArrayList<>();
laneWidthList.add(1.0);
laneWidthList.add(3.5);
laneWidthList.add(3.5);
laneWidthList.add(3.5);

link = netiface.createLink3DWithLaneWidth(linkPoints3DWithWidth, laneWidthList, "曹安公路", true, UnitOfMeasure.Metric);    
```

**public ILink createLink3DWithLanePoints(ArrayList\<Vector3D\> lCenterLineV3, ArrayList\<HashMap\<String, ArrayList\<Vector3D\>\>\> lanesWithPoints, String linkName, boolean bAddToScene, UnitOfMeasure unit)**

​	创建指定车道断点的3D路段。单位：像素。

参数：

​	[ in ] lCenterLineV3：路段中心线三维断点序列。

​	[ in ] lanesWithPoints：车道点集的集合。

​	[ in ] linkName：路段名称。

​	[ in ] bAddToScene：是否添加到场景。

返回：

​	路段对象。

示例：

```java
// 路段中心线
List<Vector3D> linkPoints = new ArrayList<>();
linkPoints.add(new Vector3D(-300, 0, 10));
linkPoints.add(new Vector3D(300, 0, 20));

// 构建车道点列表
List<Map<String, List<Vector3D>>> lanesPoints = new ArrayList<>();

// 第一个车道组
Map<String, List<Vector3D>> firstLaneGroup = new HashMap<>();

List<Vector3D> leftLane1 = new ArrayList<>();
leftLane1.add(new Vector3D(-300, 0, 10));
leftLane1.add(new Vector3D(300, 0, 20));
firstLaneGroup.put("left", leftLane1);

List<Vector3D> centerLane1 = new ArrayList<>();
centerLane1.add(new Vector3D(-300, 1.75, 10));
centerLane1.add(new Vector3D(300, 1.75, 20));
firstLaneGroup.put("center", centerLane1);

List<Vector3D> rightLane1 = new ArrayList<>();
rightLane1.add(new Vector3D(-300, 3.5, 10));
rightLane1.add(new Vector3D(300, 3.5, 20));
firstLaneGroup.put("right", rightLane1);

lanesPoints.add(firstLaneGroup);

// 第二个车道组
Map<String, List<Vector3D>> secondLaneGroup = new HashMap<>();

List<Vector3D> leftLane2 = new ArrayList<>();
leftLane2.add(new Vector3D(-300, -3.5, 10));
leftLane2.add(new Vector3D(300, -3.5, 20));
secondLaneGroup.put("left", leftLane2);

List<Vector3D> centerLane2 = new ArrayList<>();
centerLane2.add(new Vector3D(-300, -1.75, 10));
centerLane2.add(new Vector3D(300, -1.75, 20));
secondLaneGroup.put("center", centerLane2);

List<Vector3D> rightLane2 = new ArrayList<>();
rightLane2.add(new Vector3D(-300, 0, 10));
rightLane2.add(new Vector3D(300, 0, 20));
secondLaneGroup.put("right", rightLane2);

lanesPoints.add(secondLaneGroup);

link = netiface.createLink3DWithLanePoints(linkPoints, lanesPoints, "曹安公路", true, UnitOfMeasure.Metric);
```

**public ILink createLink3DWithLanePointsAndAttrs(ArrayList\<Vector3D\> lCenterLineV3, ArrayList\<HashMap\<String, ArrayList\<Vector3D\>\>\> lanesWithPoints, ArrayList\<String\> lLaneType, ArrayList\<JsonObject\> lAttr, String linkName, boolean bAddToScene, UnitOfMeasure unit)**

​	创建指定车道断点和属性的3D路段。单位：像素。

参数：

​	[ in ] lCenterLineV3：路段中心线三维断点序列。

​	[ in ] lanesWithPoints：车道点集的集合。

​	[ in ] lLaneType：车道类型序列。

​	[ in ] lAttr：车道附加属性序列。

​	[ in ] linkName：路段名称。

​	[ in ] bAddToScene：是否添加到场景。

返回：

​	路段对象。

**public void removeLink(ILink pLink)**

​	移除路段。

参数：

​	[ in ] pLink：路段对象。

示例：

```java
// 移除ID为1的路段
ILink link = netiface.findLink(1);
netiface.removeLink(link);
```

**public ILink updateLink(_Link link, ArrayList\<_Lane\> lLane, ArrayList\<Point\> lPoint, UnitOfMeasure unit)**

​	更新路段。单位：像素。

参数：

​	[ in ] link：路段基本信息。

​	[ in ] lLane：车道列表。

​	[ in ] lPoint：断点列表。

返回：

​	更新后的路段对象。

**public void moveLinks(ArrayList\<ILink\> lLink, Point offset, UnitOfMeasure unit)**

​	移动路段及相关连接段。单位：像素。

参数：

​	[ in ] lLink：路段对象序列。

​	[ in ] offset：偏移量。

示例：

```java
// 获取所有路段
ArrayList<ILink> links = netiface.links();
// 移动所有路段
netiface.moveLinks(links, Point(100, 100));
```

**public boolean judgeLinkToCross(long linkId)**

​	判断路段下游是否进入交叉口，以面域是否存在多连接段，以及当前路段与后续路段之间的角度为依据。

参数：

​	[ in ] linkID：路段ID。

返回：

​	路段下游是否进入交叉口。

#### 3.3.2.4.车道

**public ILane findLane(long id)**

​	通过车道ID获取车道对象。

**public ArrayList\<Point\> laneCenterPoints(long laneID, UnitOfMeasure unit)**

​	获取指定ID的车道中心线断点序列。单位：像素。

参数：

​	[ in ] laneID：车道ID。

返回：

​	指定车道的中心线断点序列。

#### 3.3.2.5.连接段

**public int connectorCount()**

​	获取连接段数。

**public ArrayList\<Long\> connectorIds()**

​	获取连接段ID序列。

**public ArrayList\<IConnector\> connectors()**

​	获取连接段对象序列。

**public IConnector findConnector(long id)**

​	通过连接段ID获取连接段对象。

**public IConnector findConnectorByLinkIds(long fromLinkID, long toLinkId)**

​	通过上游路段ID和下游路段ID获取连接段对象。

**public IConnector createConnector(long fromLinkID, long toLinkID, ArrayList\<Int\> lFromLaneNumber, ArrayList\<Int\> lToLaneNumber, String connName, boolean bAddToScene)**

​	创建连接段。

参数：

​	[ in ] fromLinkID：上游路段ID。

​	[ in ] toLinkID：下游路段ID。

​	[ in ] lFromLaneNumber：上游路段车道序号序列。

​	[ in ] LToLaneNumber：下游车道序号序列。

​	[ in ] connName：连接段名，默认为空，将以两条路段的ID连接起来作为名称。

​	[ in ] bAddToScene：创建后是否放入路网场景，默认为true。

返回：

​	连接段对象。

示例：

```java
//创建连接段。
ArrayList<Integer> fromLaneNumbers = new ArrayList<>(Arrays.asList(1, 2, 3));
ArrayList<Integer> toLaneNumbers = new ArrayList<>(Arrays.asList(1, 2, 3));
connector = netiface.createConnector(1, 2, fromLaneNumbers, toLaneNumbers, "连接段1");
}
```

**public IConnector createConnector3DWithPoints(long fromLinkID, long toLinkID, ArrayList\<Int\> lFromLaneNumber, ArrayList\<Int\> lToLaneNumber, ArrayList\<HashMap\<String, ArrayList\<Vector3D\>\>\> laneConnectorWithPoints, String connName, boolean bAddToScene, UnitOfMeasure unit)**

​	创建指定断点的3D连接段。单位：像素。

参数：

​	[ in ] fromLinkID：上游路段ID。

​	[ in ] toLinkID：下游路段ID。

​	[ in ] lFromLaneNumber：上游路段车道序号列表。

​	[ in ] lToLaneNumber：下游路段车道序号列表。

​	[ in ] laneConnectorWithPoints：车道连接点集的集合。

​	[ in ] connName：连接段名称。

​	[ in ] bAddToScene：是否添加到场景。

返回：

​	连接段对象。

**public void removeConnector(IConnector pConnector)**

​	移除连接段。

参数：

​	[ in ] pConnector：连接段对象。

**public IConnector updateConnector(_Connector connector)**

​	更新连接段。单位：像素。

参数：

​	[ in ] connector：连接段基本信息。

返回：

​	连接段对象。

#### 3.3.2.6.车道连接

**public ILaneConnector findLaneConnector(long id)**

​	通过车道连接ID获取车道连接对象。

**public ILaneConnector findLaneConnector(long fromLaneID, long toLaneId)**

​	通过上游车道ID和下游车道ID获取车道连接对象。

**public ArrayList\<CrossPoint\> crossPoints(ILaneConnector pLaneConnector)**

​	当前车道连接穿过其它车道连接形成的交叉点序列。

参数：

​	[ in ] pLaneConnector：车道连接对象。

返回：

​	交叉点序列。

#### 3.3.2.7.连接段面域

**public ArrayList\<IConnectorArea\> allConnectorArea()**

​	获取所有连接段面域对象序列。

**public IConnectorArea findConnectorArea(long id)**

​	通过面域ID获取面域对象。

#### 3.3.2.8.路网网格

**public void buildNetGrid(double width, UnitOfMeasure unit)**

​	路网网格化。

参数：

​	[ in ] width：单元格宽度。单位：像素。

**public ArrayList\<ISection\> findSectionOn1Cell(Point point, UnitOfMeasure unit)**

​	通过point获取所在单元格所有道路。

参数：

​	[ in ] point：获取点坐标。单位：像素。

返回：

​	道路对象序列。

**public ArrayList\<ISection\> findSectionOn4Cell(Point point, UnitOfMeasure unit)**

​	通过point获取最近4个单元格所有道路。

参数：

​	[ in ] point：获取点坐标。单位：像素。

返回：

​	道路对象序列。

**public ArrayList\<ISection\> findSectionOn9Cell(Point point, UnitOfMeasure unit)**

​	通过point获取最近9个单元格所有道路。

参数：

​	[ in ] point：获取点坐标。单位：像素。

返回：

​	道路对象序列。

**public ArrayList\<Location\> locateOnCrid(Point point, int cellCount, UnitOfMeasure unit)**

​	point周围若干个单元格里获取车道基类对象。

参数：

​	[ in ] point：获取点坐标。单位：像素。

​	[ in ] cellCount：单元格数，小于1时默认为1，大于1小于4时默认为4，大于4时默认为9。

返回：	

​	定位信息序列，按最短距离从小到大排序。

示例：

```java
// 目标点
Point targetPoint = new Point(50, 50);
// 将目标点投影到附近一定范围内的车道上，获取定位信息序列
ArrayList<Location> locations = netiface.locateOnCrid(targetPoint, 9, UnitOfMeasure.Metric);  // 使用前需要先执行netiface.buildNetGrid(10);
for (Location location: locations) {
    System.out.println("车道/车道连接ID为：" + location.getpLaneObject().id());
    System.out.println("投影点为：(" + location.getPoint().getX() + ", " + location.getPoint().getY() + ")");
    System.out.println("目标点与投影点的间距为：" + location.getLeastDist() + " m");
    System.out.println("投影点与车道起点的间距为：" + location.getDistToStart() + " m");
    System.out.println("投影点在所在车道的分段序号为：" + location.getSegmIndex());
}
```

**public ArrayList\<Location\> locateOnSections(Point point, ArrayList\<ISection\> lSection, double referDistance, UnitOfMeasure unit)**

​	通过point对道路列表中每一个道路所有车道求最短距离。

参数：

​	[ in ] point：获取点坐标。单位：像素。

​	[ in ] lSection：道路列表。

​	[ in ] referDistance：LaneObject上与point最近的点到LaneObject起点距离，只为提高计算效率，默认值为0。

返回：

​	定位信息序列，按最短距离从小到大排序。

#### 3.3.2.9.车型

**public boolean createVehicleType(_VehicleType _vt)**

​	创建车型。

参数：

​	[ in ] vt：车辆类型数据。需要指定与现有车型不同的车型名称，否则会创建失败。新创建车型的编码将自动设置为当前最大编码值加 1。

返回：

​	是否创建成功。

示例：

```java
// 构建参数
_VehicleType vehicleType = new _VehicleType();
vehicleType.setVehicleTypeName("新建车型1");  // 车型名称
vehicleType.setLength(4.5);  // 长度，单位：m
vehicleType.setLengthSD(0.5);  // 长度标准差，单位：m
vehicleType.setWidth(2);  // 宽度，单位：m
vehicleType.setWidthSD(0.2);  // 宽度标准差，单位：m
vehicleType.setAvgSpeed(60);  // 期望速度，单位：km/h
vehicleType.setSpeedSD(10);  // 期望速度标准差，单位：km/h
vehicleType.setAvgAcce(4);  // 期望加速度，单位：m/s²
vehicleType.setAcceSD(0.5);  // 期望加速度标准差，单位：m/s²
vehicleType.setAvgDece(6);  // 期望减速度，单位：m/s²
vehicleType.setDeceSD(0.5);  // 期望减速度标准差，单位：m/s²
vehicleType.setMaxAcce(5.5);  // 最大加速度，单位：m/s²
vehicleType.setMaxDece(7.5);  // 最大减速度，单位：m/s²
vehicleType.setMaxSpeed(80);  // 最大速度，单位：km/h
vehicleType.setCommercialVehicle(false);  // 是否是营运车辆
vehicleType.setMaxPassengerCapacity(1);  // 核载人数，单位：人
// 创建车型
boolean result = netiface.createVehicleType(vehicleType);
System.out.println("创建车型是否成功：" + result);
```

#### 3.3.2.10.车辆组成

**public long createVehicleComposition(String name, ArrayList\<VehicleComposition\> lVehiComp)**

​	创建车型组成。

参数：

​	[ in ] name：车型组成名。

​	[ in ] lVehiComp：不同车型占比序列。

返回：

​	车型组成ID，但如果车型组成名已存在或相关车型编码不存在或相关车型占比小于0则返回-1。

示例：

```java
// 创建车辆类型比例列表
List<VehiComposition> vehiTypeProportionList = new ArrayList<>(Arrays.asList(
    new VehiComposition(1, 0.3),  // 小客车，占比0.3
    new VehiComposition(2, 0.2),  // 大客车，占比0.2
    new VehiComposition(3, 0.1),  // 公交车，占比0.1
    new VehiComposition(4, 0.4)   // 货车，占比0.4
));

// 创建车辆组成
int vehiCompositionId = netiface.createVehicleComposition("动态创建车型组成", vehiTypeProportionList);
```

**public boolean removeVehicleComposition(long vehiCompId)**

​	移除车型组成。

参数：

​	[ in ] vehiCompID：车型组成ID。

#### 3.3.2.11.发车点

**public ArrayList\<IDispatchPoint\> dispatchPoints()**

​	获取所有发车点序列。

**public IDispatchPoint findDispatchPoint(long id)**

​	通过发车点ID获取发车点。

**public IDispatchPoint createDispatchPoint(ILink pLink, String dpName, boolean bAddToScene)**

​	创建发车点。

参数：

​	[ in ] pLink：路段，在其上创建发车点。

​	[ in ] dpName：发车点名称，默认为空，将以发车点ID作为名称。

​	[ in ] bAddToScene：创建后是否放入路网场景，默认为true。

示例：

```java
// 获取路段对象
ILink link = netiface.findLink(1);
// 创建发车点
IDispatchPoint dp = netiface.createDispatchPoint(link);
if (dp != null) {
    // 添加发车间隔，含车型组成、时间间隔、发车数
    dp.addDispatchInterval(1, 600, 300);
    dp.addDispatchInterval(1, 600, 300);
}
```

**public boolean removeDispatchPoint(IDispatchPoint pDispPoint)**

​	移除发车点。

参数：

​	[ in ] pDispPoint：发车点对象。

#### 3.3.2.12.决策点

**public ArrayList\<IDecisionPoint\> decisionPoints()**

​	获取所有决策点序列。

**public IDecisionPoint findDecisionPoint(long id)**

​	通过决策点ID获取决策点。

**public IDecisionPoint createDecisionPoint(ILink pLink, double distance, String name, UnitOfMeasure unit)**

​	创建决策点。

参数：

​	[ in ] pLink：决策点所在的路段。

​	[ in ] distance：决策点距离路段起点的距离。单位：像素。

​	[ in ] name：决策点的名称。

返回：

​	决策点对象。

示例：

```java
ILink link = netiface.findLink(1);
double location = 50;
String decisionPointName = "新建决策点";
IDecisionPoint decisionPoint = netiface.createDecisionPoint(link, location, decisionPointName, UnitOfMeasure.Metric);
```

**public IDecisionPoint updateDecipointPoint(\_DecisionPoint deciPoint, ArrayList\<_RoutingFLowRatio\> lFlowRatio)**

​	更新决策点及其各路径不同时间段流量比。

参数：

​	[ in ] deciPoint：决策点数据。

​	[ in ] lFlowRatio：各路径按时间段流量比的数据集合。


返回：

​	决策点对象。

示例：

```java
// 初始化左、直、右流量比对象
RoutingFlowRatio flowRatioLeft = new RoutingFlowRatio();
flowRatioLeft.routingFlowRatioID = 1;
flowRatioLeft.routingID = decisionRouting1.id();
flowRatioLeft.startDateTime = 0;
flowRatioLeft.endDateTime = 999999;
flowRatioLeft.ratio = 2.0;

RoutingFlowRatio flowRatioStraight = new RoutingFlowRatio();
flowRatioStraight.routingFlowRatioID = 2;
flowRatioStraight.routingID = decisionRouting2.id();
flowRatioStraight.startDateTime = 0;
flowRatioStraight.endDateTime = 999999;
flowRatioStraight.ratio = 3.0;

RoutingFlowRatio flowRatioRight = new RoutingFlowRatio();
flowRatioRight.routingFlowRatioID = 3;
flowRatioRight.routingID = decisionRouting3.id();
flowRatioRight.startDateTime = 0;
flowRatioRight.endDateTime = 999999;
flowRatioRight.ratio = 1.0;

// 初始化决策点数据
_DecisionPoint decisionPointData = new DecisionPointData();
_DecisionPoint.deciPointID = decisionPoint.id();
_DecisionPoint.deciPointName = decisionPoint.name();
Point decisionPointPos = new Point();
if (decisionPoint.link().getPointByDist(decisionPoint.distance(), decisionPointPos)) {
    decisionPointData.X = decisionPointPos.getX();
    decisionPointData.Y = decisionPointPos.getY();
    decisionPointData.Z = decisionPoint.link().z();
}

// 构造流量比列表
List<RoutingFlowRatio> flowRatioList = new ArrayList<>();
flowRatioList.add(flowRatioLeft);
flowRatioList.add(flowRatioStraight);
flowRatioList.add(flowRatioRight);

// 更新决策点的路径流量比配置
IDecisionPoint updatedDecisionPoint = netiface.updateDecipointPoint(decisionPointData, flowRatioList);
```

#### 3.3.2.13.车辆路径

**public IRouting findRouting(long id)**

​	通过路径ID获取路径对象。

**public IRouting createRouting(ArrayList\<ILink\> lILink)**

​	创建路径，不与决策点绑定。

参数：

​	[ in ] lILink：路段对象序列，需要是不间断的。

返回：

​	路径对象。

示例：

```java
// 路段ID列表
List<Integer> linkIdList = new ArrayList<>(Arrays.asList(1, 2, 3, 4));
// 构建路段对象列表
ArrayList<Link> linkList = new ArrayList<>();
for (int linkId : linkIdList) {
    linkList.add(netiface.findLink(linkId));
}
// 创建车辆路径
IRouting routing = netiface.createRouting(linkList);
```

**public IRouting createDeciRouting(IDecisionPoint pDeciPoint, ArrayList\<ILink\> lILink)**

​	为决策点添加车辆路径。

参数：

​	[ in ] pDeciPoint：决策点对象。

​	[ in ] lILink：路段对象序列，需要从决策点所在路段开始，且是不间断的。

返回：

​	路径对象。

**public boolean removeDeciRouting(IDecisionPoint pDeciPoint, IRouting pRouting)**

​	移除决策点的车辆路径。

参数：

​	[ in ] pDeciPoint：决策点对象。

​	[ in ] pRouting：路径对象。

返回：

​	是否移除成功。

**public IRouting shortestRouting(ILink pFromLink, ILink pToLink)**

​	计算两路段之间的最短路径。

参数：

​	[ in ] pFromLink：起始路段。

​	[ in ] pToLink：目标路段。

返回：	

​	路径对象。

#### 3.3.2.14.信号机

**public int signalControllerCount()**

​	获取信号机数量。

**public ArrayList\<Long\> signalControllerIds()**

​	获取信号机ID序列。

**public ArrayList\<ISignalController\> signalControllers()**

​	获取所有信号机对象序列。

**public ISignalController findSignalControllerById(long id)**

​	通过ID获取信号机对象。

**public ISignalController findSignalControllerByName(String name)**

​	通过名称获取信号机对象，如果同名返回第一个。

**public ISignalController createSignalController(String name)**

​	创建信号机。

参数：

​	[ in ] name：信号机名称。

返回：

​	信号机对象。

示例：

```java
// 信号机名称
String signalControllerName = "双龙大道-吉印大道交叉口";
// 创建信号机
ISignalController signalController = netiface.createSignalController(signalControllerName);
```

#### 3.3.2.15.信号控制方案

**public int signalPlanCount()**

​	获取信控方案组数。

**public ArrayList\<Long\> signalPlanIds()**

​	获取信控方案ID序列。

**public ArrayList\<ISignalPlan\> signalPlans()**

​	获取信控方案对象序列。

**public ISignalPlan findSignalPlanById(long id)**

​	通过ID获取信控方案对象。

**public ISignalPlan findSignalPlanByName(String name)**

​	通过名称获取信控方案对象。

**public ISignalPlan createSignalPlan(ISignalController pITrafficLight, String name, int cycle, int phasedifference, int startTime, int endTime)**

​	创建信控方案。

参数：

​	[ in ] pITrafficLight：信号机对象。

​	[ in ] name：方案名称。

​	[ in ] cycle：周期时长。

​	[ in ] phasedifference：相位差。

​	[ in ] startTime：起始时间。

​	[ in ] endTime：结束时间。

返回：

​	信控方案对象。

示例：

```java
// 获取信号机对象
ISignalController signalController = netiface.findSignalControllerByID(1);
// 信控方案名称
String signalPlanName = "平峰方案";
// 周期时长，单位：s
int cycleTime = 120;
// 相位差，单位：s
int phaseDifference = 0;
// 起始时间，单位：s
int startTime = 0;
// 结束时间，单位：s
int endTime = 3600;
// 创建信控方案
ISignalPlan signalPlan = netiface.createSignalPlan(signalController, signalPlanName, cycleTime, phaseDifference, startTime, endTime);
```

#### 3.3.2.16.信号灯相位

**public ISignalPhase findSignalPhase(long id)**

​	通过信号灯相位ID获取信号灯相位对象。

**public ISignalPhase createSignalPlanSignalPhase(ISignalPlan SignalPlan, String name, ArrayList\<ColorInterval\> lColor)**

​	创建信号灯相位。

参数：

​	[ in ] SignalPlan：信控方案对象。

​	[ in ] name：相位名称。

​	[ in ] lColor：灯色对象列表。

返回：

​	信号灯相位对象。

示例：

```java
// 获取信号配时方案
ISignalPlan signalPlan = netiface.findSignalPlanById(1);
// 相位名称
String signalPhaseName = "东西直行";
// 构建灯色对象列表
String[] colors = {"R", "G", "Y", "R"};
int[] intervals = {30, 26, 3, 61};
ArrayList<ColorInterval> colorIntervalList = new ArrayList<>();
for (int i = 0; i < colors.length; i++) {
    colorIntervalList.add(new ColorInterval(colors[i], intervals[i]));
}
// 创建信号灯相位
ISignalPhase signalPhase = netiface.createSignalPlanSignalPhase(signalPlan, signalPhaseName, colorIntervalList);
```

**public void removeSignalPhase(ISignalPlan pPlan, long phaseId)**

​	移除已有信号灯相位，相位移除后，原相位序列自动重排。

参数：

​	[ in ] pPlan：信控方案对象。

​	[ in ] phaseID：将要移除的相位ID。

#### 3.3.2.17.信号灯灯头

**public int signalLampCount()**

​	获取信号灯数。

**public ArrayList\<Long\> signalLampIds()**

​	获取信号灯ID序列。

**public ArrayList\<ISignalLamp\> signalLamps()**

​	获取信号灯对象序列。

**public ISignalLamp findSignalLamp(long id)**

​	通过信号灯ID获取信号灯对象。

**public ISignalLamp createSignalLamp(ISignalPhase pPhase, String name, long laneID, long toLaneID, double distance)**

​	创建信号灯。

参数：

​	[ in ] pPhase：相位对象。

​	[ in ] name：信号灯名称。

​	[ in ] laneID：信号灯所在车道ID，或所在车道连接上游车道ID。

​	[ in ] toLaneID：信号灯所在车道连接下游车道ID。

​	[ in ] distance：信号灯距车道或车道连接起点距离。单位：像素。

返回：

​	信号灯对象。

示例：

```java
// 获取相位对象
ISignalPhase signalPhase = netiface.findSignalPhase(1);
// 信号灯名称
String signalLampName = "东直1";
// 车道ID
long laneId = 1;
// 下游车道ID
long toLaneId = -1;
// 位置，单位：m
double distance = m2p(50);
// 创建信号灯
ISignalLamp signalLamp = netiface.createSignalLamp(signalPhase, signalLampName, laneId, toLaneId, distance);
```

**public ISignalLamp createTrafficSignalLamp(ISignalController pTrafficLight, String name, long laneID, long toLaneID, double distance)**

​	创建信号灯。

参数：

​	[ in ] pTrafficLight：信号机。

​	[ in ] name：信号灯名称。

​	[ in ] laneID：信号灯所在车道ID，或所在车道连接上游车道ID。

​	[ in ] toLaneID：信号灯所在车道连接下游道ID。

​	[ in ] distance：信号灯距车道或车道连接起点距离。单位：像素。

返回：

​	信号灯对象。

**public void addSignalPhaseToLamp(int SignalPhaseID, ISignalLamp signalLamp)**

​	信号灯添加绑定的相位。

参数：

​	[ in ] SignalPhaseID：信号相位ID。

​	[ in ] signalLamp：信号灯对象。

**public void removeSignalPhaseFromLamp(int SignalPhaseID, ISignalLamp signalLamp)**

​	信号灯移除某个绑定的相位，如果相位列表只存在一个相位则将关联的相位设置为空。

参数：

​	[ in ] SignalPhaseID：信号相位ID。

​	[ in ] signalLamp：信号灯对象。

**public void transferSignalPhase(ISignalPhase pFromISignalPhase, ISignalPhase pToISignalPhase, ISignalLamp signalLamp)**

​	信号灯更换绑定的相位，但不允许跨越信号机。

参数：

​	[ in ] pFromISignalPhase：原相位。

​	[ in ] pToISignalPhase：目标相位。

​	[ in ] signalLamp：信号灯对象。

#### 3.3.2.18.数据采集器

**public ArrayList\<IVehicleDrivInfoCollector\> vehiInfoCollectors()**

​	获取所有数据采集器对象序列。

**public IVehicleDrivInfoCollector findVehiInfoCollector(long id)**

​	通过ID获取数据采集器对象。

**public IVehicleDrivInfoCollector createVehiCollectorOnLink(ILane pLane, double dist, UnitOfMeasure unit)**

​	在路段的车道上创建数据采集器。

参数：

​	[ in ] pLane：车道对象。

​	[ in ] dist：距车道起点距离。单位：像素。

返回：

​	数据采集器对象。

示例：

```java
// 获取车道对象
ILane lane = netiface.findLane(1);
// 位置，单位：m
double dist = 50;
// 在路段上创建数据采集器
IVehicleDrivInfoCollector collector = netiface.createVehiCollectorOnLink(lane, dist, UnitOfMeasure.Metric);
```

**public IVehicleDrivInfoCollector createVehiCollectorOnConnector(ILaneConnector pLaneConnector, double dist, UnitOfMeasure unit)**

​	在连接段的车道连接上创建数据采集器。

参数：

​	[ in ] pLaneConnector：车道连接对象。

​	[ in ] dist：距车道连接起点距离。单位：像素。

返回：

​	数据采集器对象。

示例：

```java
// 获取车道连接对象
ILaneConnector laneConnector = netiface.findLaneConnector(1, 4);
// 位置，单位：m
double dist = 50;
// 在连接段上创建数据采集器
IVehicleDrivInfoCollector collector = netiface.createVehiCollectorOnConnector(laneConnector, dist, UnitOfMeasure.Metric);
```

**public boolean removeVehiCollector(IVehicleDrivInfoCollector pCollector)**

​	移除车辆信息采集器。

参数：

​	[ in ] pCollector：车辆信息采集器对象。

返回：

​	是否移除成功。

#### 3.3.2.19.排队计数器

**public ArrayList\<IVehicleQueueCounter\> vehiQueueCounters()**

​	获取所有排队计数器对象序列。

**public IVehicleQueueCounter findVehiQueueCounter(long id)**

​	通过ID获取排队计数器对象。

**public IVehicleQueueCounter createVehiQueueCounterOnLink(ILane pLane, double dist, UnitOfMeasure unit)**

​	在路段的车道上创建车辆排队计数器。

参数：

​	[ in ] pLane：车道对象。

​	[ in ] dist：距车道起点距离。单位：像素。

返回：

​	排队计数器对象。

示例：

```java
// 获取车道对象
ILane lane = netiface.findLane(1);
// 位置，单位：m
double dist = 80;
// 在路段上创建排队计数器
IVehicleQueueCounter counter = netiface.createVehiQueueCounterOnLink(lane, dist, UnitOfMeasure.Metric);
```

**public IVehicleQueueCounter createVehiQueueCounterOnConnector(ILaneConnector pLaneConnector, double dist, UnitOfMeasure unit)**

​	在连接段的车道连接上创建车辆排队计数器。

参数：

​	[ in ] pLaneConnector：车道连接对象。

​	[ in ] dist：距车道连接起点距离。单位：像素。

返回：

​	排队计数器对象。

示例：

```java
// 获取车道连接对象
laneConnector = netiface.findLaneConnector(1, 4);
// 位置，单位：m
double dist = 80;
// 在连接段上创建排队计数器
IVehicleQueueCounter counter = netiface.createVehiQueueCounterOnConnector(laneConnector, dist, UnitOfMeasure.Metric);
```

#### 3.3.2.20.行程时间检测器

**public ArrayList\<IVehicleTravelDetector\> vehiTravelDetectors()**

​	获取所有车辆行程时间检测器对象序列。

**public IVehicleTravelDetector findVehiTravelDetector(long id)**

​	通过ID获取车辆行程时间检测器对象。

**public ArrayList\<IVehicleTravelDetector\> createVehicleTravelDetector_link2link(ILink pStartLink, ILink pEndLink, double dist1, double dist2, UnitOfMeasure unit)**

​	创建路段到路段的行程时间检测器。

参数：

​	[ in ] pStartLink：起始路段对象。

​	[ in ] pEndLink：终止路段对象。

​	[ in ] dist1：检测器起点距路段起始点距离。单位：像素。

​	[ in ] dist2：检测器终点距路段起始点距离。单位：像素。

返回：

​	行程时间检测器对象。

示例：

```java
// 获取起始路段对象
ILink startLink = netiface.findLink(1);
// 获取终止路段对象
ILink endLink = netiface.findLink(2);
// 检测器起点在起始路段的位置，单位：m
double startDist = 10;
// 检测器终点在终止路段的位置，单位：m
double endDist = 90;
// 创建起点在路段、终点也在路段的行程时间检测器
ArrayList<IVehicleTravelDetector> detectors = netiface.createVehicleTravelDetector_link2link(startLink, endLink, startDist, endDist, UnitOfMeasure.Metric);
```

**public ArrayList\<IVehicleTravelDetector\> createVehicleTravelDetector_link2conn(ILink pStartLink, ILaneConnector pEndLaneConnector, double dist1, double dist2, UnitOfMeasure unit)**

​	创建路段到连接段的行程时间检测器。

参数：

​	[ in ] pStartLink：起始路段对象。

​	[ in ] pEndLaneConnector：终止车道连接对象。

​	[ in ] dist1：检测器起点距路段起始点距离。单位：像素。

​	[ in ] dist2：检测器终点距车道连接起始点距离。单位：像素。

返回：

​	行程时间检测器对象。

示例：

```java
// 获取起始路段对象
ILink startLink = netiface.findLink(1);
// 获取终止车道连接对象
ILaneConnector endLaneConnector = netiface.findLaneConnector(1, 4);
// 检测器起点在起始路段的位置，单位：m
double startDist = 10;
// 检测器终点在终止车道连接的位置，单位：m
double endDist = 10;
// 创建起点在路段、终点在连接段的行程时间检测器
ArrayList<IVehicleTravelDetector> detectors = netiface.createVehicleTravelDetector_link2conn(startLink, endLaneConnector, startDist, endDist, UnitOfMeasure.Metric);
```

**public ArrayList\<IVehicleTravelDetector\> createVehicleTravelDetector_conn2link(ILaneConnector pStartLaneConnector, ILink pEndLink, double dist1, double dist2, UnitOfMeasure unit)**

​	创建连接段到路段的行程时间检测器。

参数：

​	[ in ] pStartLaneConnector：起始车道连接对象。

​	[ in ] pEndLink：终止路段对象。

​	[ in ] dist1：检测器起点距车道连接起始点距离。单位：像素。

​	[ in ] dist2：检测器终点距路段起始点距离。单位：像素。

返回：

​	行程时间检测器对象。

示例：

```java
// 获取起始车道连接对象
ILink startLaneConnector = netiface.findLaneConnector(1, 4);
// 获取终止路段对象
ILaneConnector endLink = netiface.findLink(2);
// 检测器起点在起始车道连接的位置，单位：m
double startDist = 10;
// 检测器终点在终止路段的位置，单位：m
double endDist = 90;
// 创建起点在连接段、终点在路段的行程时间检测器
ArrayList<IVehicleTravelDetector> detectors = netiface.createVehicleTravelDetector_conn2link(startLaneConnector, endLink, startDist, endDist, UnitOfMeasure.Metric);
```

**public ArrayList\<IVehicleTravelDetector\> createVehicleTravelDetector_conn2conn(ILaneConnector pStartLaneConnector, ILaneConnector pEndLaneConnector, double dist1, double dist2, UnitOfMeasure unit)**

​	创建连接段到连接段的行程时间检测器。

参数：

​	[ in ] pStartLaneConnector：起始车道连接对象。

​	[ in ] pEndLaneConnector：终止车道连接对象。

​	[ in ] dist1：检测器起点距车道连接起始点距离。单位：像素。

​	[ in ] dist2：检测器终点距车道连接起始点距离。单位：像素。

返回：

​	行程时间检测器对象。

示例：

```java
// 获取起始车道连接对象
ILaneConnector startLaneConnector = netiface.findLaneConnector(1, 4);
// 获取终止路段对象
ILaneConnector endLaneConnector = netiface.findLaneConnector(4, 7);
// 检测器起点在起始车道连接的位置，单位：m
double startDist = 10;
// 检测器终点在终止车道连接的位置，单位：m
double endDist = 90;
// 创建起点在连接段、终点也在连接段的行程时间检测器
ArrayList<IVehicleTravelDetector> detectors = netiface.createVehicleTravelDetector_conn2conn(startLaneConnector, endLaneConnector, startDist, endDist, UnitOfMeasure.Metric);
```

#### 3.3.2.21.导向箭头

**public int guidArrowCount()**

​	获取导向箭头数。

**public ArrayList\<Long\> guidArrowIds()**

​	获取导向箭头ID序列。

**public ArrayList\<IGuidArrow\> guidArrows()**

​	获取导向箭头对象序列。

**public IGuidArrow findGuidArrow(long id)**

​	通过导向箭头ID获取导向箭头对象。

**public IGuidArrow createGuidArrow(ILane pLane, double length, double distToTerminal, GuideArrowType arrowType, UnitOfMeasure unit)**

​	创建导向箭头。

参数：

​	[ in ] pLane：车道对象。

​	[ in ] length：长度。单位：像素。

​	[ in ] distToTerminal：到车道终点距离。单位：像素。

​	[ in ] arrowType：箭头类型。

返回：

​	导向箭头对象。

示例：

```java
ILane lane = netiface.findLane(4);
if (lane != null) {
    double length = 4;
    double distToTerminal = 10;
    GuideArrowType arrowType = GuideArrowType.StraightRight;
	IGuidArrow guidArrow = netiface.createGuidArrow(lane, length, distToTerminal, arrowType, UnitOfMeasure.Metric);
}
```

**public void removeGuidArrow(IGuidArrow pArrow)**

​	移除导向箭头。

参数：

​	[ in ] pArrow：导向箭头对象。

#### 3.3.2.22.公交线路

**public ArrayList\<IBusLine\> buslines()**

​	获取公交线路对象序列。

**public IBusLine findBusline(long buslineId)**

​	通过公交线路ID获取公交线路。

**public IBusLine findBuslineByFirstLinkId(long linkId)**

​	通过公交线路起始路段ID获取公交线路。

**public IBusLine createBusLine(ArrayList\<ILink\> lLink)**

​	创建公交线路，lLink列表中相邻两路段可以是路网上相邻两路段，也可以不相邻，如果不相邻，TESSNG会在它们之间创建一条最短路径。如果lLink列表中相邻路段在路网上不相邻并且二者之间不存在最短路径，则相邻的第二条路段及后续路段无效。

参数：
	[ in ] lLink，公交线路经过的路段对象序列。

返回：

​	公交线路对象。

示例：

```java
ILink link1 = netiface.findLink(1);
ILink link2 = netiface.findLink(2);
ArrayList<ILink> links = new ArrayList<>(Arrays.asList(link1, link2));
IBusLine busLine = netiface.createBusLine(links);
```

**public boolean removeBusLine(IBusLine pBusLine)**

​	移除公交线路。

参数：

​	[ in ] pBusLine：公交线路对象。

#### 3.3.2.23.公交站点

**public ArrayList\<IBusStation\> busStations()**

​	获取公交站点对象序列。

**public IBusStation findBusStation(long stationId)**

​	通过公交站点ID获取公交站点对象。

**public IBusStation createBusStation(ILane pLane, double length, double dist, String name, UnitOfMeasure unit)**

​	创建公交站点。

参数：

​	[ in ] pLane：车道对象。

​	[ in ] length：站点长度。单位：像素。

​	[ in ] dist：站点起始点距车道起点距离。单位：像素。

​	[ in ] name：站点名称。	

返回：

​	公交站点对象。

示例：

```java
ILane lane = netiface.findLane(1);
IBusStation busStation = netiface.createBusStation(lane1, 30, 50, "公交站1", UnitOfMeasure.Metric);
// 设置站点类型 1：路边式、2：港湾式
busStation.setType(1);
```

**public boolean removeBusStation(IBusStation pStation)**

​	移除公交站点。

参数：

​	[ in ] pStation：公交站点对象。

#### 3.3.2.24.公交线路-站点

**public ArrayList\<IBusStationLine\> findBusStationLineByStationId(long stationId)**

​	通过公交站点ID获取公交线路-站点对象。

**public boolean addBusStationToLine(IBusLine pBusLine, IBusStation pStation)**

​	将公交站点关联到公交线路上。

参数：

​	[ in ] pBusLine：公交线路对象。

​	[ in ] pStation：公交站点对象。

**public boolean removeBusStationFromLine(IBusLine pBusLine, IBusStation pStation)**

​	将公交站点与公交线路的关联关系解除。

参数：

​	[ in ] pBusLine：公交线路对象。

​	[ in ] pStation：公交站点对象。

#### 3.3.2.25.事故区

**public ArrayList\<IAccidentZone\> accidentZones()**

​	获取所有事故区对象。

**public IAccidentZone findAccidentZone(long accidentZoneId)**

​	通过事故区ID获取事故区对象。

**public IAccidentZone createAccidentZone(DynaAccidentZoneParam param)**

​	创建事故区。

参数：

​	[ in ] param：动态事故区信息。

返回：

​	事故区对象。

示例：

```java
// 构建参数
DynaAccidentZoneParam param = new DynaAccidentZoneParam();
// 事故区名称
param.setName("事故区");
// 道路ID
param.setRoadId(1); 
// 位置，距路段或连接段起点距离，单位：m
param.setLocation(100);
// 长度，单位：m
param.setLength(50);
// 车道序号列表，从0开始，连续有序
ArrayList<Integer> fromLaneNumbers = new ArrayList<>(Arrays.asList(0));
accidentZoneParam.setMlFromLaneNumber(fromLaneNumbers);
// 开始时间，单位：s
param.setStartTime(10); 
// 持续时间，单位：s
param.setDuration(600); 
// 相邻车道限速，单位：km/h
param.setLimitedSpeed(40);
// 创建事故区
IAccidentZoneInterval accidentZone = netiface.createAccidentZone(param, UnitOfMeasure.Metric);
```

**public void removeAccidentZone(IAccidentZone pIAccidentZone)**

​	移除事故区。

参数：

​	[ in ] pIAccidentZone：事故区对象。

#### 3.3.2.26.施工区

**public ArrayList\<IRoadWorkZone\> roadWorkZones()**

​	获取所有施工区对象序列。

**public IRoadWorkZone findRoadWorkZone(long roadWorkZoneId)**

​	通过施工区ID获取施工区对象。

**public IRoadWorkZone createRoadWorkZone(DynaRoadWorkZoneParam param, UnitOfMeasure unit)**

​	创建施工区。

参数：

​	[ in ] param：施工区参数。单位：像素。

返回：

​	施工区对象。

示例：

```java
// 构建参数
DynaRoadWorkZoneParam param = new DynaRoadWorkZoneParam();
// 施工区名称
param.setName("施工区");
// 道路ID
param.setRoadId(1);
// 位置, 距离路段或连接段起点距离, 单位：m
param.setLocation(200);
// 长度, 单位：m
param.setLength(50);  // 长度
param.setUpCautionLength(70);  // 提前警示长度
param.setUpTransitionLength(50);  // 过渡区长度
param.setUpBufferLength(50);  // 缓冲区长度
param.setDownTransitionLength(40);  // 下游过渡区长度
param.setDownTerminationLength(40);  // 终止区长度
// 车道序号列表，从0开始，连续有序
ArrayList<Integer> fromLaneNumbers = new ArrayList<>(Arrays.asList(0));
param.setMlFromLaneNumber(fromLaneNumbers);
// 开始时间，单位：s
param.setStartTime(0);
// 持续时间，单位：s
param.setDuration(3600);
// 相邻车道限速，单位：km/h
param.setLimitSpeed(40);
// 创建施工区
IRoadWorkZone roadWorkZone = netiface.createRoadWorkZone(param, UnitOfMeasure.Metric);
```

**public void removeRoadWorkZone(IRoadWorkZone pIRoadWorkZone)**

​	移除施工区。

参数：

​	[ in ] pIRoadWorkZone：施工区对象。

**public boolean updateRoadWorkZone(DynaRoadWorkZoneParam param, UnitOfMeasure unit)**

​	更新施工区。

参数：

​	[ in ] param：施工区参数。单位：像素。

#### 3.3.2.27.限行区

**public ArrayList\<ILimitedZone\> limitedZones()**

​	获取所有限行区对象序列。

**public ILimitedZone findLimitedZone(long limitedZoneId)**

​	通过限行区ID获取限行区对象。

**public ILimitedZone createLimitedZone(DynaLimitedZoneParam param, UnitOfMeasure unit)**

​	创建限行区。

参数：

​	[ in ] param：限行区参数。单位：像素。

返回：

​	限行区对象。

示例：

```java
// 构建参数
DynaLimitedZoneParam param = new DynaLimitedZoneParam();
// 限行区名称
param.setName("限行区");
// 道路ID
param.setRoadId(1); 
// 位置，距路段或连接段起点距离，单位：m
param.setLocation(100);
// 长度，单位：m
param.setLength(50);
// 车道序号列表，从0开始，连续有序
ArrayList<Integer> fromLaneNumbers = new ArrayList<>(Arrays.asList(0));
accidentZoneParam.setMlFromLaneNumber(fromLaneNumbers);
// 开始时间，单位：s
param.setStartTime(10); 
// 持续时间，单位：s
param.setDuration(600); 
// 相邻车道限速，单位：km/h
param.setLimitedSpeed(40);
// 创建限行区
ILimitedZone limitedZone = netiface.createLimitedZone(param, UnitOfMeasure.Metric);
```

**public void removeLimitedZone(ILimitedZone pILimitedZone)**

​	移除限行区。

参数：

​	[ in ] pILimitedZone：限行区对象。

**public boolean updateLimitedZone(DynaLimitedZoneParam param, UnitOfMeasure unit)**

​	更新限行区。

参数：

​	[ in ] param：限行区参数。单位：像素。

#### 3.3.2.28.改扩建借道

**public ArrayList\<IReconstruction\> reconstructions()**

​	获取所有改扩建对象。

**public IReconstruction findReconstruction(long reconstructionId)**

​	通过改扩建ID获取改扩建对象。

**public IReconstruction createReconstruction(DynaReconstructionParam param, UnitOfMeasure unit)**

​	创建改扩建。

参数：

​	[ in ] param：改扩建参数。单位：像素。

返回：

​	改扩建对象。

示例：

```java
// 构建参数
DynaReconstructionParam param = new DynaReconstructionParam();
// 施工区ID
param.setRoadWorkZoneId(rwzId);
// 被借道的路段ID
param.setBeBorrowedLinkId(2);
// 被借道的车道数量
param.setBorrowedNum(1);
// 保通开口长度，单位：m
param.setPassagewayLength(80);
// 保通开口限速，单位：m/s
param.setPassagewayLimitedSpeed(40 / 3.6);
// 创建改扩建借道
IReconstruction reconstruction = netiface.createReconstruction(param, UnitOfMeasure.Metric);
```

**public void removeReconstruction(IReconstruction pIReconstruction)**

​	移除改扩建。

参数：

​	[ in ] pIReconstruction：改扩建对象。

**public boolean updateReconStruction(DynaReconstructionParam param, UnitOfMeasure unit)**

​	更新改扩建。

参数：

​	[ in ] param：改扩建参数。单位：像素。

**public double reCalcPassagewayLength(DynaReconstructionParam param, UnitOfMeasure unit)**

​	重新计算保通开口长度，可通过保通详细参数计算出保通开口长度。

参数：

​	[ in ] param：改扩建参数。单位：像素。

返回：

​	保通开口长度。

#### 3.3.2.29.限速区

**public ArrayList\<IReduceSpeedArea\> reduceSpeedAreas()**

​	获取所有限速区对象序列。

**public IReduceSpeedArea findReduceSpeedArea(long id)**

​	通过限速区ID获取限速区对象。

**public IReduceSpeedArea createReduceSpeedArea(DynaReduceSpeedAreaParam param)**

​	创建限速区。

参数：

​	[ in ] param：限速区参数。单位：像素。

返回：

​	限速区对象。

**public void removeReduceSpeedArea(IReduceSpeedArea pIReduceSpeedArea)**

​	移除限速区。

参数：

​	[ in ] pIReduceSpeedArea：限速区对象。

**public boolean updateReduceSpeedArea(DynaReduceSpeedAreaParam param)**

​	更新限速区。

参数：

​	[ in ] param：限速区参数。单位：像素。

#### 3.3.2.30.行人类型

**public ArrayList\<IPedestrianType\> pedestrianTypes()**

​	获取所有行人类型对象序列。

#### 3.3.2.31.行人组成

**public ArrayList\<PedestrianComposition\> pedestrianCompositions()**

​	获取所有行人组成信息序列。

**public long createPedestrianComposition(String name, HashMap\<int, double\> mpCompositionRatio)**

​	创建行人组成。

参数：

​	[ in ] name：组成名称。

​	[ in ] mpCompositionRatio：组成明细，key为行人类型编码，value为行人类型占比。

返回：

​	行人组成ID，如果创建失败返回-1。

**public boolean removePedestrianComposition(long compositionId)**

​	移除行人组成。

参数：

​	[ in ] compositionID：行人组成ID。

**public boolean updatePedestrianComposition(long compositionID, HashMap\<int, double\> mpCompositionRatio)**

​	更新行人组成。

参数：

​	[ in ] compositionID：行人组成ID。

​	[ in ] mpCompositionRatio：组成明细，key为行人类型编码，value为行人类型占比。

返回：

​	是否更新成功。

#### 3.3.2.32.行人面域层级

**public ArrayList\<LayerInfo\> layerInfos()**

​	获取所有层级信息。

**public LayerInfo addLayerInfo(String name, double height, boolean visible, boolean locked)**

​	新增层级，返回新增的层级信息。

参数：

​	[ in ] name：层级名称。

​	[ in ] height：层级高度。

​	[ in ] visible：是否可见。

​	[ in ] locked：是否锁定，锁定后面域不可以修改。

**public void removeLayerInfo(long layerId)**

​	删除某个层级，会删除层级当中的所有元素。

参数：

​	[ in ] layerID：层级ID。

**public boolean updateLayerInfo(long layerID, String name, double height, boolean visible, boolean locked)**

​	更新层级信息。

参数：

​	[ in ] layerID：层级ID。

​	[ in ] name：层级名称。

​	[ in ] height：层级高度。

​	[ in ] visible：是否可见。

​	[ in ] locked：是否锁定，锁定后面域不可以修改。

返回：

​	是否更新成功。

#### 3.3.2.33.行人面域

**public ArrayList\<IPedestrianRegion\> pedestrianRegions()**

​	获取所有行人面域对象序列。

**public ArrayList\<IPedestrianRectRegion\> pedestrianRectRegions()**

​	获取所有矩形面域对象序列。

**public ArrayList\<IPedestrianTriangleRegion\> pedestrianTriangleRegions()**

​	获取所有三角形面域对象序列。

**public ArrayList\<IPedestrianEllipseRegion\> pedestrianEllipseRegions()**

​	获取所有椭圆形面域对象序列。

**public ArrayList\<IPedestrianFanShapeRegion\> pedestrianFanShapeRegions()**

​	获取所有扇形面域对象序列。

**public ArrayList\<IPedestrianPolygonRegion\> pedestrianPolygonRegions()**

​	获取所有多边形面域对象序列。

**public ArrayList\<IPedestrianSIDeWalkRegion\> pedestrianSIDeWalkRegions()**

​	获取所有人行道对象序列。

**public ArrayList\<IPedestrianCrossWalkRegion\> pedestrianCrossWalkRegions()**

​	获取所有人行横道对象序列。

**public IPedestrianRegion findPedestrianRegion(long id)**

​	通过行人面域ID获取行人面域对象。

**public IPedestrianRectRegion findPedestrianRectRegion(long id)**

​	通过行人面域ID获取矩形面域对象。

**public IPedestrianEllipseRegion findPedestrianEllipseRegion(long id)**

​	通过行人面域ID获取椭圆形面域对象。

**public IPedestrianTriangleRegion findPedestrianTriangleRegion(long id)**

​	通过行人面域ID获取三角形面域对象。

**public IPedestrianFanShapeRegion findPedestrianFanShapeRegion(long id)**

​	通过行人面域ID获取扇形面域对象。

**public IPedestrianPolygonRegion findPedestrianPolygonRegion(long id)**

​	通过行人面域ID获取多边形面域对象。

**public IPedestrianSIDeWalkRegion findPedestrianSIDeWalkRegion(long id)**

​	通过行人面域ID获取人行道对象。

**public IPedestrianCrossWalkRegion findPedestrianCrossWalkRegion(long id)**

​	通过行人面域ID获取人行横道对象。

**public IPedestrianRectRegion createPedestrianRectRegion(Point startPoint, Point endPoint)**

​	创建矩形行人面域。

参数：

​	[ in ] startPoint：左上角坐标。

​	[ in ] endPoint：右下角坐标。

返回	

​	矩形行人面域对象。

**public IPedestrianTriangleRegion createPedestrianTriangleRegion(Point startPoint, Point endPoint)**

​	创建三角形行人面域。

参数：

​	[ in ] startPoint：左上角坐标。

​	[ in ] endPoint：右下角坐标。

返回：

​	三角形行人面域对象。

**public IPedestrianEllipseRegion createPedestrianEllipseRegion(Point startPoint, Point endPoint)**

​	创建椭圆行人面域。

参数：

​	[ in ] startPoint：左上角坐标。

​	[ in ] endPoint：右下角坐标。

返回：	

​	椭圆行人面域对象。

**public IPedestrianFanShapeRegion createPedestrianFanShapeRegion(Point startPoint, Point endPoint)**

​	创建扇形行人面域。

参数：

​	[ in ] startPoint：圆心坐标。

​	[ in ] endPoint：外半径终点坐标。

返回：

​	扇形行人面域对象。

**public IPedestrianPolygonRegion createPedestrianPolygonRegion(Vector\<Point\> polygon)**

​	创建多边形行人面域。

参数：

​	[ in ] polygon：多边形顶点。

返回：

​	多边形行人面域对象。

**public IPedestrianSIDeWalkRegion createPedestrianSIDeWalkRegion(ArrayList\<Point\> vertexs)**

​	创建人行道。

参数：

​	[ in ] vertexs：顶点列表。

返回：	

​	人行道对象。

**public IPedestrianCrossWalkRegion createPedestrianCrossWalkRegion(Point startPoint, Point endPoint)**

​	创建人行横道。

参数：

​	[ in ] startPoint：左上角坐标。

​	[ in ] endPoint：右下角坐标。

返回：

​	人行横道对象。

**public IPedestrianStairRegion createPedestrianStairRegion(Point startPoint, Point endPoint)**

​	创建楼梯。

参数：

​	[ in ] startPoint：起点坐标。

​	[ in ] endPoint：终点坐标。

返回：	

​	楼梯对象。

**public void removePedestrianRectRegion(IPedestrianRectRegion pIPedestrianRectRegion)**

​	删除矩形行人面域。

参数：

​	[ in ] pIPedestrianRectRegion：矩形行人面域对象。

**public void removePedestrianTriangleRegion(IPedestrianTriangleRegion pIPedestrianTriangleRegion)**

​	删除三角形行人面域。

参数：

​	[ in ] pIPedestrianTriangleRegion：三角形行人面域对象。

**public void removePedestrianEllipseRegion(IPedestrianEllipseRegion pIPedestrianEllipseRegion)**

​	删除椭圆行人面域。

参数：

[ in ] pIPedestrianEllipseRegion：椭圆行人面域对象。

**public void removePedestrianFanShapeRegion(IPedestrianFanShapeRegion pIPedestrianFanShapeRegion)**

​	删除扇形行人面域。

参数：

​	[ in ] pIPedestrianFanShapeRegion：扇形行人面域对象。

**public void removePedestrianPolygonRegion(IPedestrianPolygonRegion pIPedestrianPolygonRegion)**

​	删除多边形行人面域。

参数：

​	[ in ] pIPedestrianPolygonRegion：多边形行人面域对象。

**public void removePedestrianSIDeWalkRegion(IPedestrianSIDeWalkRegion pIPedestrianSIDeWalkRegion)**

​	删除人行道。

参数：

​	[ in ] pIPedestrianSIDeWalkRegion：人行道对象。

**public void removePedestrianCrossWalkRegion(IPedestrianCrossWalkRegion pIPedestrianCrossWalkRegion)**

​	删除人行横道。

参数：

​	[ in ] pIPedestrianCrossWalkRegion：人行横道对象。

**public void removePedestrianStairRegion(IPedestrianStairRegion pIPedestrianStairRegion)**

​	删除楼梯。

参数：

​	[ in ] pIPedestrianStairRegion：楼梯对象。

#### 3.3.2.34.行人发生点

**public ArrayList\<IPedestrianPathPoint\> pedestrianPathStartPoints()**

​	获取所有行人发生点对象序列。

**public IPedestrianPathPoint findPedestrianPathStartPoint(long id)**

​	通过行人发生点ID获取行人发生点对象。

**public Pedestrian.PedestrianPathStartPointConfigInfo findPedestrianStartPointConfigInfo(long id)**

​	通过行人发生点ID获取行人发生点配置信息。

**public IPedestrianPathPoint createPedestrianPathStartPoint(Point scenePos)**

​	创建行人发生点。

参数：

​	[ in ] scenePos：场景坐标。

返回：	

​	行人发生点对象。

**public void removePedestrianPathStartPoint(IPedestrianPathPoint pIPedestrianPathStartPoint)**

​	删除行人发生点。

参数：

​	[ in ] pIPedestrianPathStartPoint：行人发生点对象。

**public boolean updatePedestrianStartPointConfigInfo(PedestrianPathStartPointConfigInfo info)**

​	更新行人发生点配置信息。

参数：

​	[ in ] info：行人发生点配置信息。

返回：	

​	是否更新成功。

#### 3.3.2.35.行人结束点

**public ArrayList\<IPedestrianPathPoint\> pedestrianPathEndPoints()**

​	获取所有行人结束点对象序列。

**public IPedestrianPathPoint findPedestrianPathEndPoint(long id)**

​	通过ID获取行人结束点对象。

**public IPedestrianPathPoint createPedestrianPathEndPoint(Point scenePos)**

​	创建行人结束点。

参数：

​	[ in ] scenePos：场景坐标。

返回：

​	行人结束点对象。

**public void removePedestrianPathEndPoint(IPedestrianPathPoint pIPedestrianPathEndPoint)**

​	删除行人结束点。

参数：

​	[ in ] pIPedestrianPathEndPoint：行人结束点对象。

#### 3.3.2.36.行人决策点

**public ArrayList\<IPedestrianPathPoint\> pedestrianPathDecisionPoints()**

​	获取所有行人决策点对象序列。

**public IPedestrianPathPoint findPedestrianDecisionPoint(long id)**

​	通过行人决策点ID获取行人决策点对象。

**public PedestrianDecisionPointConfigInfo findPedestrianDecisionPointConfigInfo(long id)**

​	通过行人决策点ID获取行人决策点配置信息。

**public IPedestrianPathPoint createPedestrianDecisionPoint(Point scenePos)**

​	创建行人决策点。

参数：

​	[ in ] scenePos：场景坐标。

返回：

​	行人决策点对象。

**public void removePedestrianDecisionPoint(IPedestrianPathPoint pIPedestrianDecisionPoint)**

​	删除行人决策点。

参数：

​	[ in ] pIPedestrianDecisionPoint：行人决策点对象。

**public boolean updatePedestrianDecisionPointConfigInfo(PedestrianDecisionPointConfigInfo info)**

​	更新行人决策点配置信息。

参数：

​	[ in ] info：行人决策点配置信息。

返回：	

​	是否更新成功。

#### 3.3.2.37.行人路径

**public ArrayList\<IPedestrianPath\> pedestrianPaths()**

​	获取所有行人路径对象序列，包括局部路径。

**public IPedestrianPath findPedestrianPath(long id)**

​	通过行人路径ID获取行人路径，包括局部路径。

**public IPedestrianPath createPedestrianPath(IPedestrianPathPoint pStartPoint, IPedestrianPathPoint pEndPoint, ArrayList\<Point\> mIDdlePoints)**

​	创建行人路径（或行人局部路径）。

参数：

​	[ in ] pStartPoint：行人发生点（或行人决策点）。

​	[ in ] pEndPoint：行人结束点。

​	[ in ] mIDdlePoints：一组中间必经点。

返回：	

​	行人路径对象。

**public void removePedestrianPath(IPedestrianPath pIPedestrianPath)**

​	删除行人路径。

参数：

​	[ in ] pIPedestrianPath：行人路径对象。

#### 3.3.2.38.行人信号灯

**public ArrayList\<ICrosswalkSignalLamp\> crosswalkSignalLamps()**

​	获取所有人行横道红绿灯对象序列。

**public ICrosswalkSignalLamp findCrosswalkSignalLamp(long id)**

​	通过ID获取人行横道红绿灯对象。

**public void addCrossWalkSignalPhaseToLamp(int SignalPhaseID, ISignalLamp signalLamp)**

​	添加行人信号灯。

参数：

​	[ in ] SignalPhaseID：信号相位ID。

​	[ in ] signalLamp：信号灯对象。

**public ICrosswalkSignalLamp createCrossWalkSignalLamp(ISignalController pTrafficLight, String name, long crosswalkID, Point scenePos, boolean isPositive)**

​	创建人行横道信号灯。

参数：

​	[ in ] pTrafficLight：信号机对象。

​	[ in ] name：信号灯名称。

​	[ in ] crosswalkID：人行横道ID。

​	[ in ] scenePos：位于人行横道内的场景坐标。

​	[ in ] isPositive：信号灯管控方向是否为正向。

返回：

​	人行横道信号灯对象。

**public void removeCrossWalkSignalLamp(ICrosswalkSignalLamp pICrosswalkSignalLamp)**

​	删除人行横道信号灯。

参数：

​	[ in ] pICrosswalkSignalLamp：人行横道信号灯对象。

#### 3.3.2.39.停车场停车时距分布

**public ArrayList\<DynaParkingTimeDis\> parkingTimeDis()**

​	获取停车场停车时距分布列表。

**public DynaParkingTimeDis createParkingTimeDis(DynaParkingTimeDis param)**

​	创建停车场停车时距分布。

参数：

​	[ in ] param：停车时距分布参数。

**public void removeParkingTimeDis(long id)**

​	移除停车场停车时距分布。

参数：

​	[ in ] ID：停车时距分布ID。

**public DynaParkingTimeDis updateParkingTimeDis(DynaParkingTimeDis param)**

​	更新停车场停车时距分布。

参数：

​	[ in ] param：停车时距分布参数。

#### 3.3.2.40.停车区域

**public ArrayList\<IParkingRegion\> parkingRegions()**

​	获取所有停车区序列。

**public IParkingRegion findParkingRegion(long id)**

​	通过停车区域ID获取停车区域。

**public IParkingRegion createParkingRegion(DynaParkingRegion param)**

​	创建停车区域。

参数：

​	[ in ] param：动态停车区信息。

**public void removeParkingRegion(IParkingRegion pIParkingRegion)**

​	移除停车区域。

参数：

​	[ in ] pIParkingRegion：停车区域对象。

**public void removeParkingRegionById(long id)**

​	通过停车区域ID移除停车区域。

参数：

​	[ in ] ID：停车区域ID。

**public IParkingRegion updateParkingRegion(DynaParkingRegion param)**

​	更新停车区域。

参数：

​	[ in ] param：动态停车区域信息。

#### 3.3.2.41.停车路径决策点

**public ArrayList\<IParkingDecisionPoint\> parkingDecisionPoints()**

​	获取所有停车路径决策点序列。

**public IParkingDecisionPoint findParkingDecisionPoint(long id)**

​	通过停车路径决策点ID获取停车路径决策点对象。

**public IParkingDecisionPoint createParkingDecisionPoint(ILink pLink, double distance, String name)**

​	创建停车路径决策点。

参数：

​	[ in ] pLink：决策点所在的路段。

​	[ in ] distance：决策点距离路段起点的距离。单位：像素。

​	[ in ] name：决策点名称。

**public void removeParkingDecisionPoint(IParkingDecisionPoint pIParkingDecisionPoint)**

​	移除停车路径决策点。

参数：

​	[ in ] pIParkingDecisionPoint：停车路径决策点对象。

**public void removeParkingDecisionPointById(long id)**

​	通过停车路径决策点ID移除停车路径决策点。

参数：

​	[ in ] ID：停车路径决策点ID。

#### 3.3.2.42.停车路径

**public IParkingRouting createParkingRouting(IParkingDecisionPoint pDeciPoint, IParkingRegion pIParkingRegion)**

​	创建停车路径。

参数：

​	[ in ] pDeciPoint：停车决策点。

​	[ in ] pIParkingRegion：停车区域。

**public void removeParkingRouting(IParkingRouting pIParkingRouting)**

​	移除停车路径。

参数：

​	[ in ] pIParkingRouting：停车决策点对象。

**public void removeParkingRoutingById(long id)**

​	通过停车路径ID移除停车路径。

参数：

​	[ in ] ID：停车决策点ID。

#### 3.3.2.43.收费站停车时距分布

**public ArrayList\<DynaTollParkingTimeDis\> tollParkingTimeDis()**

​	获取收费站停车时距分布序列。

**public DynaTollParkingTimeDis createTollParkingTimeDis(DynaTollParkingTimeDis param)**

​	创建收费站停车时距分布。

参数：

​	[ in ] param：停车时距分布参数。

**public void removeTollParkingTimeDis(long id)**

​	移除收费站停车时距分布。

参数：

​	[ in ] ID：停车时距分布ID。

**public DynaTollParkingTimeDis updateTollParkingTimeDis(DynaTollParkingTimeDis param)**

​	更新收费站停车时距分布。

参数：

​	[ in ] param：停车时距分布参数。

#### 3.3.2.44.收费车道

**public ArrayList\<ITollLane\> tollLanes()**

​	获取所有收费车道对象序列。

**public ITollLane findTollLane(long id)**

​	通过收费车道ID获取收费车道对象。

**public ITollLane createTollLane(DynaTollLane param)**

​	创建收费车道。

参数：

​	[ in ] param：动态收费车道信息。

**public void removeTollLane(ITollLane pITollLane)**

​	移除收费车道。

参数：

​	[ in ] pITollLane：收费车道对象。

**public void removeTollLaneById(long id)**

​	通过收费车道ID移除收费车道。

参数：

​	[ in ] ID：收费车道ID。

**public ITollLane updateTollLane(DynaTollLane param)**

​	更新收费车道。

参数：

​	[ in ] param：动态收费车道信息。

#### 3.3.2.45.收费路径决策点

**public ArrayList\<ITollDecisionPoint\> tollDecisionPoints()**

​	获取所有收费路径决策点列表。

**public ITollDecisionPoint findTollDecisionPoint(long id)**

​	通过ID获取收费路径决策点。

**public ITollDecisionPoint createTollDecisionPoint(ILink pLink, double distance, String name)**

​	创建收费路径决策点。

参数：

​	[ in ] pLink：决策点所在路段。

​	[ in ] distance：决策点距离路段起点的距离。单位：像素。

​	[ in ] name：决策点名称。

**public void removeTollDecisionPoint(ITollDecisionPoint pITollDecisionPoint)**

​	移除收费路径决策点。

参数：

​	[ in ] pITollLane：收费路径决策点对象。

**public void removeTollDecisionPointById(long id)**

​	通过收费路径决策点ID移除收费路径决策点。

参数：

​	[ in ] ID：收费路径决策点ID。

#### 3.3.2.46.收费路径

**public ITollRouting createTollRouting(ITollDecisionPoint pDeciPoint, ITollLane pITollLane)**

​	创建收费路径。

参数：

​	[ in ] pDeciPoint：收费决策点。

​	[ in ] pITollLane：收费车道。

**public void removeTollRouting(ITollRouting pITollRouting)**

​	移除收费路径。

参数：

​	[ in ] pITollRouting：收费路径对象。

**public void removeTollRoutingById(long id)**

​	通过ID移除收费路径。

参数：

​	[ in ] ID：收费路径ID。

#### 3.3.2.47.节点

**public ArrayList\<IJunction\> getAllJunctions()**

​	获取所有节点对象序列。

**public IJunction findJunction(long junctionId)**

​	通过ID获取节点对象。

**public IJunction createJunction(Point startPoint, Point endPoint, String name)**

​	创建节点。

参数：

​	[ in ] startPoint：左上角起始点坐标。

​	[ in ] endPoint：右下角终点坐标。

​	[ in ] name：节点名称。

返回：

​	节点对象。

**public boolean removeJunction(long junctionId)**

​	删除节点。

参数：

​	[ in ] junctionID：节点ID。

返回：

​	是否移除成功。

**public boolean updateJunctionName(long junctionID, String name)**

​	更新节点名称。

参数：

​	[ in ] junctionID：节点ID。

​	[ in ] name：新的节点名称。

**public ArrayList\<FlowTurning\> getJunctionFlows(long junctionId)**

​	获取节点流向信息。

参数：

​	[ in ] junctionID：节点ID。

返回：

​	节点流向信息映射表。

**public boolean updateFlow(long timeID, long junctionID, long turningID, long inputFlowValue)**

​	更新流向流量。

参数：

​	[ in ] timeID：时间段ID。

​	[ in ] junctionID：节点ID。

​	[ in ] turningID：转向ID。

​	[ in ] inputFlowValue：输入流量值(veh/h)。

返回：

​	是否更新成功。

**public boolean updateFlowAlgorithmParams(double theta, double bpra, double bprb, long maxIterateNum, boolean useNewPath)**

​	更新流量算法参数。

参数：

​	[ in ] theta：参数θ(0.01-1)。

​	[ in ] bpra：BPR路阻参数A(0.05-0.5)。

​	[ in ] bprb：BPR路阻参数B(1-10)。

​	[ in ] maxIterateNum：最大迭代次数(1-5000)。

​	[ in ] useNewPath：是否重新构建静态路径。

返回：

​	是否更新成功。

**public boolean updatePathBuildParams(boolean deciPointPosFlag, boolean laneConnectorFlag, long minPathNum)**

​	更新路径构建参数。

参数：

​	[ in ] deciPointPosFlag：是否考虑决策点位置。

​	[ in ] laneConnectorFlag：是否考虑车道连接。

​	[ in ] minPathNum：最小路径数量(默认3)。

返回：

​	是否更新成功。

~~**public HashMap\<QPair<long, long>, ArrayList\<ArrayList\<ILink\>\>\> buildAndApplyPaths()**~~

​	~~构建并应用路径。~~

~~返回：~~

​	~~路径结果信息映射表。~~

~~**public HashMap\<long, ArrayList\<Junction.FlowTurning\>\> calculateFlows()**~~

​	~~计算并应用流量结果。~~

~~返回：~~

​	~~时间段ID到流量计算结果的映射表。~~

#### 3.3.2.48.节点时间段

**public ArrayList\<FlowTimeInterval\> getFlowTimeIntervals()**

​	获取所有节点时间段。

**public FlowTimeInterval addFlowTimeInterval()**

​	添加节点时间段。

返回：

​	节点时间段信息。

**public boolean deleteFlowTimeInterval(long timeId)**

​	删除节点时间段。

参数：

​	[ in ] timeID：节点时间段ID。

返回：

​	是否删除成功。

**public FlowTimeInterval updateFlowTimeInterval(long timeID, long startTime, long endTime)**

​	更新时间段。

参数：

​	[ in ] timeID：节点时间段ID。

​	[ in ] startTime：开始时间。单位：s。

​	[ in ] endTime：结束时间。单位：s。

### 3.3.3.仿真接口（SimuInterface）

​	SimuInterface是TessInterface的子接口，通过此接口可以启动、暂停、停止仿真，可以设置仿真精度，获取仿真过程中的车辆对象、车辆状态，获取几种检测器检测到的样本数据和集计数据等。

#### 3.3.3.1.仿真配置

**public long simuIntervalScheming()**

​	获取仿真时长。单位：s。

**public void setSimuIntervalScheming(long interval)**

​	设置仿真时长。设置值为0时表示不限时长。单位：s。

**public int simuAccuracy()**

​	获取仿真精度。

**public void setSimuAccuracy(int accuracy)**

​	设置仿真精度，即每秒计算次数。

**public int acceMultiples()**

​	获取仿真加速倍数。

**public void setAcceMultiples(int multiples)**

​	设置仿真加速倍数。


**public boolean byCpuTime()**

​	仿真时间是否由现实时间确定。一个计算周期存在两种时间，一种是现实经历的时间，另一种是由仿真精度决定的仿真时间，如果仿真精度为每秒20次，仿真一次相当于仿真了50毫秒。默认情况下，一个计算周期的仿真时间是由仿真精度决定的。在线仿真时如果算力不够，按仿真精度确定的仿真时间会与现实时间存在时差。

**public void setByCpuTime(boolean bByCpuTime)**

​	设置是否由现实时间确定仿真时间，如果设为true，每个仿真周期现实经历的时间作为仿真时间，这样仿真时间与现实时间相吻合。

**public boolean isRecordTrace()**

​	获取是否记录车辆轨迹。

**public void setIsRecordTrace(boolean bRecord)**

​	设置是否记录车辆轨迹。

**public void setThreadCount(int count)**

​	设置工作线程数。

**public long batchNumber()**

​	获取当前仿真批次。

**public double batchIntervalReally()**

​	获取当前批次实际时间。单位：ms。

**public long simuTimeIntervalWithAcceMutiples()**

​	获取获取当前已仿真时间。单位：ms。

**public long startMSecsSinceEpoch()**

​	获取仿真开始的现实时间。单位：ms。

**public long stopMSecsSinceEpoch()**

​	仿真结束的现实时间。单位：ms。

#### 3.3.3.2.仿真状态

**public boolean isRunning()**

​	获取仿真是否在运行状态。

**public boolean isPausing()**

​	获取仿真是否在暂停状态。

**public void startSimu()**

​	启动仿真。

**public void pauseSimu()**

​	暂停仿真。

**public void stopSimu()**

​	停止仿真。

**public void pauseSimuOrNot()**

​	暂停或恢复仿真。如果当前处于仿真运行状态，此方法暂停仿真，如果当前处于暂停状态，此方法继续仿真。

#### 3.3.3.3.车辆

**public long vehiCountTotal()**

​	获取车辆总数，包括已创建尚未进入路网的车辆、正在运行的车辆、已驶出路网的车辆。

**public long vehiCountRunning()**

​	获取当前时间正在运行的车辆数。

**public IVehicle getVehicle(long vehiId)**

​	通过车辆ID获取车辆对象。

**public ArrayList\<IVehicle\> allVehicle()**

​	获取所有车辆对象序列。

**public ArrayList\<IVehicle\> allVehiStarted()**

​	获取当前时间所有正在运行的车辆对象序列。

示例：

```java
// 获取当前正在运行的车辆列表
ArrayList<IVehicle> allVehicles = simuiface.allVehiStarted();
for (IVehicle vehicle : allVehicles) {
    System.out.println("车辆ID：" + vehicle.id());
    System.out.println("车辆名称：" + vehicle.name());
    System.out.println("车辆类型编码：" + vehicle.vehicleTypeCode());
    System.out.println("车辆类型名称：" + vehicle.vehicleTypeName());
    System.out.println("车辆长度：" + vehicle.length(UnitOfMeasure.Metric) + " m");

    System.out.println("车辆当前横坐标：" + vehicle.pos(UnitOfMeasure.Metric).getX() + " m");
    System.out.println("车辆当前纵坐标：" + vehicle.pos(UnitOfMeasure.Metric).getY() + " m");
    System.out.println("车辆当前高程：" + vehicle.v3z() + " m");
    System.out.println("车辆当前所在道路ID：" + vehicle.roadId());
    System.out.println("车辆当前所在道路名称：" + vehicle.roadName());
    System.out.println("车辆当前是否在路段：" + vehicle.roadIsLink());
    System.out.println("车辆当前所在车道ID：" + vehicle.laneId());
    if (vehicle.roadIsLink()) {
        System.out.println("车辆当前所在车道序号：" + vehicle.vehicleDriving().laneNumber());
    }
    System.out.println("车辆当前与车道起点的间距：" + vehicle.vehicleDriving().distToStartPoint(true, true, UnitOfMeasure.Metric) + " m");
    
    System.out.println("车辆当前速度：" + vehicle.currSpeed(UnitOfMeasure.Metric) * 3.6 + " km/h");
    System.out.println("车辆当前期望速度：" + vehicle.vehicleDriving().desirSpeed(UnitOfMeasure.Metric) * 3.6 + " km/h");
    System.out.println("车辆当前加速度：" + vehicle.acce(UnitOfMeasure.Metric) + " m/s²");
    System.out.println("车辆当前朝向角：" + vehicle.angle() + " °");
}
```

**public ArrayList\<IVehicle\> vehisInLink(long linkId)**

​	获取当前时间指定ID的路段上的车辆对象序列。

**public ArrayList\<IVehicle\> vehisInLane(long laneId)**

​	获取当前时间指定ID的车道上的车辆对象序列。

**public ArrayList\<IVehicle\> vehisInConnector(long connectorId)**

​	获取当前时间指定ID的连接段上的车辆对象序列。

**public ArrayList\<IVehicle\> vehisInLaneConnector(long connectorID, long fromLaneID, long toLaneId)**

​	获取当前时间指定连接段ID、上游车道ID和下游车道ID的车道连接上的车辆对象序列。

参数：

​	[ in ] connectorID：连接段ID。

​	[ in ] fromLaneID：上游车道ID。

​	[ in ] toLaneID：下游车道ID。

返回：

​	车辆对象序列。

**public ArrayList\<VehicleStatus\> getVehisStatus(long batchNumber, UnitOfMeasure unit)**

​	获取当前时间所有正在运行的车辆状态。

参数：

​	[ in ] batchNumber：批次号。

返回：

​	车辆状态序列。

**public ArrayList\<VehiclePosition\> getVehiTrace(long vehiID, UnitOfMeasure unit)**

​	获取指定车辆的运行轨迹。单位：像素。

参数：

​	[ in ] vehiID：车辆ID。

返回：

​	车辆轨迹点位序列。

**public IVehicle createGVehicle(DynaVehiParam dynaVehi)**

​	创建车辆。

参数：

​	[ in ] dynaVehi：动态车辆信息。

返回：

​	车辆对象。

```java
// 在路段上创建车辆
// 构建参数
DynaVehiParam dvp1 = new DynaVehiParam();
// 车型ID
dvp1.setVehiTypeCode(1);
// 路段ID
dvp1.setRoadId(4);
// 车道序号
dvp1.setLaneNumber(0);
// 位置，单位：m
dvp1.setDist(m2p(50));
// 速度，单位：m/s
dvp1.setSpeed(m2p(20));
// 颜色
dvp1.setColor("#00AFF0");
// 动态创建车辆
IVehicle vehicle1 = simuiface.createGVehicle(dvp1);
if (vehicle != null) {
    System.out.println("在路段上创建了车辆，其ID为：" + vehicle1.id());
}

// 在连接段上创建车辆
// 构建参数
DynaVehiParam dvp2 = new DynaVehiParam();
// 车型ID
dvp2.setVehiTypeCode(1);
// 连接段ID
dvp2.setRoadId(4);
// 上游路段的车道序号
dvp2.setLaneNumber(0);
// 下游路段的车道序号
dvp2.setToLaneNumber(0);
// 位置，单位：m
dvp2.setDist(m2p(50));
// 速度，单位：m/s
dvp2.setSpeed(m2p(20));
// 颜色
dvp2.setColor("#00AFF0");
// 动态创建车辆
IVehicle vehicle2 = simuiface.createGVehicle(dvp2);
if (vehicle2 != null) {
    System.out.println("在连接段上创建了车辆，其ID为：" + vehicle2.id());
}
```

**public IVehicle createBus(IBusLine pBusLine, double startSimuDateTime)**

​	创建公交车。

参数：

​	[ in ] pBusLine：公交线路对象。

​	[ in ] startSimuDateTime：发车时间。单位：ms。

#### 3.3.3.4.行人

**public ArrayList\<IPedestrian\> allPedestrianStarted()**

​	获取所有正在运行的行人对象序列。

**public ArrayList\<PedestrianStatus\> getPedestriansStatusByRegionId(long regionId)**

​	通过行人面域ID获取当前时间面域上所有行人的状态信息。

参数：

​	[ in ] regionID：面域ID。

返回：

​	行人状态信息序列。

#### 3.3.3.5.信号灯

**public ArrayList\<SignalPhaseColor\> getSignalPhasesColor()**

​	获取当前时间所有信号控制相位的颜色。

返回：

​	相位颜色序列。

示例：

```java
ArrayList<SignalPhaseColor> allSignalPhaseColor = simuiface.getSignalPhasesColor();
for (SignalPhaseColor signalPhaseColor: allSignalPhaseColor) {
    System.out.println("信号机ID：" + signalPhaseColor.getSignalGroupId());
    System.out.println("信控相位ID：" + signalPhaseColor.getPhaseId());
    System.out.println("信控相位序号：" + signalPhaseColor.getPhaseNumber());
    System.out.println("当前颜色：" + signalPhaseColor.getColor());
    System.out.println("当前颜色的设置时间(ms)：" + signalPhaseColor.getMrIntervalSetted());
    System.out.println("当前颜色的已持续时间(ms)：" + signalPhaseColor.getMrIntervalByNow());
}
```

#### 3.3.3.6.数据采集器

**public ArrayList\<VehiInfoCollected\> getVehisInfoCollected()**

​	获取当前时间完成穿越数据采集器的所有车辆信息。

示例：

```python
ArrayList<VehiInfoCollected> allVehiInfoCollected = simuiface.getVehisInfoCollected();
for (VehiInfoCollected vehiInfo: allVehiInfoCollected) {
    System.out.println("采集器ID：" + vehiInfo.getCollectorId());
    System.out.println("仿真时间(s)：" + vehiInfo.getSimuInterval());
    System.out.println("车辆ID：" + vehiInfo.getVehiId());
}
```

**public ArrayList\<VehiInfoAggregated\> getVehisInfoAggregated()**

​	获取最近集计时间段内数据采集器采集的集计数据。

示例：

```python
ArrayList<VehiInfoAggregated> allVehiInfoAggregated = simuiface.getVehisInfoAggregated();
for (VehiInfoAggregated vehiInfoAgg: allVehiInfoAggregated) {
    System.out.println("采集器ID：" + vehiInfoAgg.getCollectorId());
    System.out.println("时间段ID：" + vehiInfoAgg.getTimeId());
    System.out.println("起始时间(s)：" + vehiInfoAgg.getFromTime());
    System.out.println("结束时间(s)：" + vehiInfoAgg.getToTime());
    System.out.println("车辆数(veh)：" + vehiInfoAgg.getVehiCount());
    System.out.println("平均速度(km/h)：" + vehiInfoAgg.getAvgSpeed());
    System.out.println("平均占有率：" + vehiInfoAgg.getOccupancy());
}
```

#### 3.3.3.7.排队计数器

**public ArrayList\<VehiQueueCounted\> getVehisQueueCounted()**

​	获取当前时间排队计数器计数的车辆排队信息。

示例：

```python
ArrayList<VehiQueueCounted> allVehiQueueCounted = simuiface.getVehisQueueCounted();
for (VehiQueueCounted vehiQueue: allVehiQueueCounted) {
    System.out.println("计数器ID：" + vehiQueue.getCounterId());
    System.out.println("仿真时间(s)：" + vehiQueue.getSimuTime());
    System.out.println("排队车辆数(veh)：" + vehiQueue.getVehiCount());
    System.out.println("排队长度(m)：" + vehiQueue.getQueueLength());
}
```

**public ArrayList\<VehiQueueAggregated\> getVehisQueueAggregated()**

​	获取最近集计时间段内排队计数器采集的集计数据。

示例：

```python
ArrayList<VehiQueueAggregated> allVehiQueueAggregated = simuiface.getVehisQueueAggregated();
for (VehiQueueAggregated vehiQueueAgg: allVehiQueueAggregated) {
    System.out.println("计数器ID：" + vehiQueueAgg.getCounterId());
    System.out.println("时间段ID：" + vehiQueueAgg.getTimeId());
    System.out.println("起始时间(s)：" + vehiQueueAgg.getFromTime());
    System.out.println("结束时间(s)：" + vehiQueueAgg.getToTime());
    System.out.println("平均排队车辆数(veh)：" + vehiQueueAgg.getAvgVehiCount());
    System.out.println("平均排队长度(m)：" + vehiQueueAgg.getAvgQueueLength());
    System.out.println("最大排队长度(m)：" + vehiQueueAgg.getMaxQueueLength());
    System.out.println("最小排队长度(m)：" + vehiQueueAgg.getMinQueueLength());
}
```

**public boolean queueRecently(long queueCounterID, double queueLength, int vehiCount, UnitOfMeasure unit)**

​	指定排队计算器最近一次排队长度和排队车辆数。

参数：

​	[ in ] queueCounterID：排队计数器ID。

​	[ out ] queueLength：排队长度。

​	[ out ] vehiCount：排队车辆数。

返回：

​	是否获取成功。

#### 3.3.3.8.行程时间检测器

**public ArrayList\<VehiTravelDetected\> getVehisTravelDetected()**

​	获取当前时间行程时间检测器完成的行程时间检测信息。

示例：

```python
ArrayList<VehiTravelDetected> allVehiTravelDetected = simuiface.getVehisTravelDetected();
for (VehiTravelDetected vehiTravel: allVehiTravelDetected) {
    System.out.println("检测器ID：" + vehiTravel.getDetectedId());
    System.out.println("车辆ID：" + vehiTravel.getVehiId());
    System.out.println("行驶时间(s)：" + vehiTravel.getTravelTime());
    System.out.println("行驶距离(m)：" + vehiTravel.getTravelDistance());
    System.out.println("延误(s)：" + vehiTravel.getDelay());
}
```

**public ArrayList\<VehiTravelAggregated\> getVehisTravelAggregated()**

​	获取最近集计时间段内行程时间检测器采集的集计数据。

示例：

```python
ArrayList<VehiTravelAggregated> allVehiTravelAggregated = simuiface.getVehisTravelAggregated();
for (VehiTravelAggregated vehiTravelAgg: allVehiTravelAggregated) {
    System.out.println("检测器ID：" + vehiTravelAgg.getDetectedId());
    System.out.println("时间段ID：" + vehiTravelAgg.getTimeId());
    System.out.println("起始时间(s)：" + vehiTravelAgg.getFromTime());
    System.out.println("结束时间(s)：" + vehiTravelAgg.getToTime());
    System.out.println("车辆数：" + vehiTravelAgg.getVehiCount());
    System.out.println("平均行程时间(s)：" + vehiTravelAgg.getAvgTravelTime());
    System.out.println("平均行程距离(m)：" + vehiTravelAgg.getAvgTravelDistance());
    System.out.println("平均延误(s)：" + vehiTravelAgg.getAvgDelay());
}
```



## 3.4.对象

​	TESS NG中的对象可分为**路网对象**和**仿真对象**，其中，路网对象包括：路段、连接段等，仿真对象包括：车辆和行人。

### 3.4.1.路网

#### 3.4.1.1.路网（IRoadNet）

​	路网基本信息接口，设计此接口的目的是为了TESS NG在导入外源路网时能够保存这些路网的属性，如路网中心点坐标、路网大地坐标等。

**public long id()**

​	获取路网ID，即路网编辑弹窗中的编号。

**public String netName()**

​	获取路网名称。

**public String url()**

​	源数据路径，可以是本地文件，可以是网络地址。

**public String type()**

​	来源分类: "TESSNG"表示TESSNG自建；"OpenDrive"表示由OpenDrive数据导入；"GeoJson"表示由geojson数据导入。

**public String bkgUrl()**

​	获取背景路径。

**public String explain()**

​	获取路网说明。

**public JsonObject otherAttrs()**

​	其它属性json数据。

**public Point centerPoint(UnitOfMeasure unit)**

​	获取路网中心点位置。单位：像素。

#### 3.4.1.2.道路基类（ISection）

​	道路基类是路段和连接段的基类。

**public int gtype()**

​	类型，GLinkType 或 GConnectorType。GLinkType代表路段、GConnectorType代表连接段。

**public boolean isLink()**

​	是否是路段。

**public long id()**

​	获取ID，如果是Link，id是Link的ID，如果是连接段，id是连接段ID。

**public long sectionId()**

​	获取ID，如果是Link，id是Link的ID，如果是连接段，id是连接段ID+10000000，从而区分路段与连接段。

**public String name()**

​	获取Section名称，路段名或连接段名。

**public void setName(String name)**

​	设置Section名称。

**public double v3z(UnitOfMeasure unit)**

​	获取Section高程。单位：像素。

**public double length(UnitOfMeasure unit)**

​	获取Section长度。单位：像素。

**public ArrayList\<ILaneObject\> laneObjects()**

​	车道与车道连接的父类接口列表。

**public ISection fromSection(long id)**

​	通过ID获取上游Section。如果当前是路段，id 为 0 返回null，否则返回上游指定ID的连接段；如果当前是连接段，id 为 0 返回上游路段，否则返回null。

**public ISection toSection(long id)**

​	通过ID获取下游 Sction。如果当前是路段，id 为 0 返回null，否则返回下游指定ID的连接段；如果当前是连接段，id 为 0 返回下游路段，否则null。

**public void setOtherAttr(JsonObject otherAttr)**

​	设置路段或连接段其它属性。

**public ILink castToLink()**

​	转换成ILink，如果当前为连接段则null。

**public IConnector castToConnector()**

​	转换成IConnector，如果当前为路段则返回null。

**public Vector\<Point\> polygon()**

​	获取Section的多边型轮廓顶点构成的多边形。

#### 3.4.1.3.路段（ILink）

**public int gtype()**

​	类型，返回GLinkType。

**public long id()**

​	获取路段ID。

**public double length(UnitOfMeasure unit)**

​	获取路段长度。单位：像素。

**public double width(UnitOfMeasure unit)**

​	获取路段宽度。单位：像素。

**public double z(UnitOfMeasure unit)**

​	获取路段高程。单位：像素。

**public double v3z(UnitOfMeasure unit)**

​	获取路段高程，过载ISection的方法。单位：像素。

**public String name()**

​	获取路段名称。

**public void setName(String name)**

​	设置路段名称。

**public String linkType()**

​	获取路段类型，如: 城市主干道、城市次干道、人行道等。

**public void setType(String type)**

​	设置路段类型，路段类型有10种，分别为: 高速路、城市快速路、匝道、城市主要干道、次要干道、地方街道、非机动车道、人行道、公交专用道和机非共享。

**public int laneCount()**

​	获取车道数。

**public double limitSpeed(UnitOfMeasure unit)**

​	获取路段最高限速。单位: km/h。

**public void setLimitSpeed(double speed, UnitOfMeasure unit)**

​	设置路段最高限速。单位: km/h。

参数: 

​	[ in ] speed: 限速值。

**public double minSpeed(UnitOfMeasure unit)**

​	获取路段最低限速。单位: km/h。

**public ArrayList\<ILane\> lanes()**

​	车道接口列表。

**public ArrayList\<ILaneObject\> laneObjects()**

​	车道及车道连接的接口列表。

**public ArrayList\<Point\> centerBreakPoints(UnitOfMeasure unit)**

​	获取路段中心线断点集。单位：像素。

**public ArrayList\<Point\> leftBreakPoints(UnitOfMeasure unit)**

​	获取路段左侧线断点集。单位：像素。

**public ArrayList\<Point\> rightBreakPoints(UnitOfMeasure unit)**

​	获取路段右侧线断点集。单位：像素。

**public ArrayList\<Vector3D\> centerBreakPoint3Ds(UnitOfMeasure unit)**

​	获取路段中心线三维断点集。单位：像素。

**public ArrayList\<Vector3D\> leftBreakPoint3Ds(UnitOfMeasure unit)**

​	获取路段左侧线三维断点集。单位：像素。

**public ArrayList\<Vector3D\> rightBreakPoint3Ds(UnitOfMeasure unit)**

​	获取路段右侧线三维断点集。单位：像素。

**public ArrayList\<IConnector\> fromConnectors()**

​	获取上游连接段列表。

**public ArrayList\<IConnector\> toConnectors()**

​	获取下游连接段列表。

**public void setOtherAttr(JsonObject otherAttr)**

​	设置路段其它属性。

**public JsonObject otherAttr()**

​	获取路段其它属性。

**public void setLaneTypes(ArrayList\<String\> lType)**

​	设置车道属性，属性类型包括: "机动车道"、"机非共享"、"非机动车道"、"公交专用道"，车道顺序从右到左。

**public void setLaneOtherAtrrs(ArrayList\<JsonObject\> lAttrs)**

​	设置车道其它属性。

**public double distToStartPoint(Point p, UnitOfMeasure unit)**

​	中心线上一点到起点距离。单位：像素。

参数: 

​	[ in ] p: 当前点坐标。

**public boolean getPointByDist(double dist, Point outPoint, UnitOfMeasure unit)**

​	求中心线起点向前延伸dist距离后所在点，如果目标点不在中心线上返回false，否则返回true。单位：像素。

参数: 

​	[ in ] dist: 中心线起点向前延伸的距离。

​	[ out ] outPoint: 中心线起点向前延伸dist距离后所在点。

示例:

```java
// 获取距离路段起点一定距离的点位坐标
Point outPoint = new Point();
boolean result = link.getPointByDist(50, outPoint, UnitOfMeasure.Metric);
if (result) {
    double x = outPoint.x();
    double y = outPoint.y();
}
```

**public boolean getPointAndIndexByDist(double dist, Point outPoint, int outIndex, UnitOfMeasure unit)**

​	求中心线起点向前延伸dist距离后所在点及分段序号，如果目标点不在中心线上返回false，否则返回true。单位：像素。

参数: 

​	[ in ] dist: 中心线起点向前延伸的距离。

​	[ out ] outPoint: 中心线起点向前延伸dist距离后所在点。

​	[ out ] outIndex: 中心线起点向前延伸dist距离后所在分段序号。

**public Vector\<Point\> polygon()**

​	获取路段的多边型轮廓顶点。

#### 3.4.1.4.连接段（IConnector）

**public int gtype()**

​	类型，连接段类型为GConnectorType。

**public long id()**

​	获取连接段ID。

**public double length(UnitOfMeasure unit)**

​	获取连接段长度。单位：像素。

**public double z(UnitOfMeasure unit)**

​	获取连接段高程。单位：像素。

**public double v3z(UnitOfMeasure unit)**

​	获取连接段高程。单位：像素。

**public String name()**

​	获取连接段名称。

**public void setName(String name)**

​	设置连接段名称。

**public ILink fromLink()**

​	获取起始路段。

**public ILink toLink()**

​	获取目标路段。

**public double limitSpeed(UnitOfMeasure unit)**

​	获取连接段最高限速。单位: km/h。

**public double minSpeed(UnitOfMeasure unit)**

​	获取连接段最低限速。单位: km/h。

**public ArrayList\<ILaneConnector\> laneConnectors()**

​	获取车道连接列表。

**public ArrayList\<ILaneObject\> laneObjects()**

​	车道及车道连接的接口列表。

**public void setLaneConnectorOtherAtrrs(ArrayList\<JsonObject\> lAttrs)**

​	设置包含的车道连接其它属性。

**public void setOtherAttr(JsonObject otherAttr)**

​	设置连接段其它属性。

**public Vector\<Point\> polygon()**

​	获取连接段的多边型轮廓顶点。

#### 3.4.1.5.车道基类（ILaneObject）

​	车道基类是车道和车道连接的父类。

**public int gtype()**

​	类型，GLaneType或GLaneConnectorType。

**public boolean isLane()**

​	是否是车道。

**public long id()**

​	获取ID，如果是Lane，id是Lane的ID，如果是车道连接，id是车道连接ID。

**public double length(UnitOfMeasure unit)**

​	获取长度。单位：像素。

**public ISection section()**

​	获取所属的ISection。

**public ILaneObject fromLaneObject(long id)**

​	通过ID获取上游 LaneObject。如果当前是车道，id 为 0 返回null，否则返回上游指定ID的车道连接；如果当前是连接段，id 为 0 返回上游车道，否则返回null。

**public ILaneObject toLaneObject(long id)**

​	通过ID获取下游 LaneObject。如果当前是车道，id 为 0 返回null，否则返回下游指定ID的车道连接；如果当前是连接段，id 为 0 返回下游车道，否则返回null。

**public ArrayList\<Point\> centerBreakPoints(UnitOfMeasure unit)**

​	获取中心线断点集。单位：像素。

**public ArrayList\<Point\> leftBreakPoints(UnitOfMeasure unit)**

​	获取左侧线断点集。单位：像素。

**public ArrayList\<Point\> rightBreakPoints(UnitOfMeasure unit)**

​	获取右侧线断点集。单位：像素。

**public ArrayList\<Vector3D\> centerBreakPoint3Ds(UnitOfMeasure unit)**

​	获取中心线三维断点集。单位：像素。

**public ArrayList\<Vector3D\> leftBreakPoint3Ds(UnitOfMeasure unit)**

​	获取左侧线三维断点集。单位：像素。

**public ArrayList\<Vector3D\> rightBreakPoint3Ds(UnitOfMeasure unit)**

​	获取右侧线三维断点集。单位：像素。

**public ArrayList\<Vector3D\> leftBreak3DsPartly(Point fromPoint, Point toPoint, UnitOfMeasure unit)**

​	获取左侧部分三维断点集。单位：像素。

参数: 

​	[ in ] fromPoint: 中心线上某一点作为起点。

​	[ in ] toPoint: 中心线上某一点作为终点。

**public ArrayList\<Vector3D\> rightBreak3DsPartly(Point fromPoint, Point toPoint, UnitOfMeasure unit)**

​	获取右侧部分三维断点集。单位：像素。

参数: 

​	[ in ] fromPoint: 中心线上某一点作为起点。

​	[ in ] toPoint: 中心线上某一点作为终点。

**public double distToStartPoint(Point p, UnitOfMeasure unit)**

​	中心线上一点到起点距离。单位：像素。

参数: 

​	[ in ] p: 当前点坐标。

**public double distToStartPointWithSegmIndex(Point p, int segmIndex, boolean bOnCentLine, UnitOfMeasure unit)**

​	中心线上一点到起点距离，附加条件是该点所在车道上的分段序号。单位：像素。

参数: 

​	[ in ] p: 当前点坐标。

​	[ in ] segmIndex: 该点所在车道上的分段序号。

​	[ in ] bOnCentLine: 是否在中心线上。

**public boolean getPointAndIndexByDist(double dist, Point outPoint, int outIndex, UnitOfMeasure unit)**

​	求中心线起点向前延伸dist距离后所在点及分段序号，如果目标点不在中心线上返回false，否则返回true。单位：像素。

参数: 

​	[ in ] dist: 中心线起点向前延伸的距离。

​	[ out ] outPoint: 中心线起点向前延伸dist距离后所在点。

​	[ out ] outIndex: 中心线起点向前延伸dist距离后所在分段序号。

**public boolean getPointByDist(double dist, Point outPoint, UnitOfMeasure unit)**

​	求中心线起点向前延伸dist距离后所在点，如果目标点不在中心线上返回false，否则返回true。单位：像素。

参数: 

​	[ in ] dist: 中心线起点向前延伸的距离。

​	[ out ] outPoint: 中心线起点向前延伸dist距离后所在点。

**public void setOtherAttr(JsonObject attr)**

​	设置车道或车道连接其它属性。

**public ILane castToLane()**

​	将ILaneObject转换为ILane，如果当前ILaneObject是车道连接则返回null。

**public ILaneConnector castToLaneConnector()**

​	将ILaneObject转换为ILaneConnector，如果当前ILaneObject是车道则返回null。

#### 3.4.1.6.车道（ILane）

**public int gtype()**

​	类型，车道类型为GLaneType。

**public long id()**

​	获取车道ID。

**public ILink link()**

​	获取车道所在路段。

**public ISection section()**

​	获取车道所属Section。

**public double length(UnitOfMeasure unit)**

​	获取车道长度。单位：像素。

**public double width(UnitOfMeasure unit)**

​	获取车道宽度。单位：像素。

**public int number()**

​	获取车道序号，从0开始（自外侧往内侧，即自右向左依次编号）。

**public String actionType()**

​	获取车道的行为类型。

**public ArrayList\<ILaneConnector\> fromLaneConnectors()**

​	获取上游车道连接列表。

**public ArrayList\<ILaneConnector\> toLaneConnectors()**

​	获取下游车道连接列表。

**public ArrayList\<Point\> centerBreakPoints(UnitOfMeasure unit)**

​	获取车道中心线断点集。单位：像素。

**public ArrayList\<Point\> leftBreakPoints(UnitOfMeasure unit)**

​	获取车道左侧线断点集。单位：像素。

**public ArrayList\<Point\> rightBreakPoints(UnitOfMeasure unit)**

​	获取车道右侧线断点集。单位：像素。

**public ArrayList\<Vector3D\> centerBreakPoint3Ds(UnitOfMeasure unit)**

​	获取车道中心线三维断点集。单位：像素。

**public ArrayList\<Vector3D\> leftBreakPoint3Ds(UnitOfMeasure unit)**

​	获取车道左侧线三维断点集。单位：像素。

**public ArrayList\<Vector3D\> rightBreakPoint3Ds(UnitOfMeasure unit)**

​	获取车道右侧线三维断点集。单位：像素。

**public ArrayList\<Vector3D\> leftBreak3DsPartly(Point fromPoint, Point toPoint, UnitOfMeasure unit)**

​	获取左侧部分三维断点集。单位：像素。

参数: 

​	[ in ] fromPoint: 中心线上某一点作为起点。

​	[ in ] toPoint: 中心线上某一点作为终点。

**public ArrayList\<Vector3D\> rightBreak3DsPartly(Point fromPoint, Point toPoint, UnitOfMeasure unit)**

​	获取右侧部分三维断点集。单位：像素。

参数: 

​	[ in ] fromPoint: 中心线上某一点作为起点。

​	[ in ] toPoint: 中心线上某一点作为终点。

**public double distToStartPoint(Point p, UnitOfMeasure unit)**

​	中心线上一点到起点距离。单位：像素。

参数: 

​	[ in ] p: 当前点坐标。

**public double distToStartPointWithSegmIndex(Point p, int segmIndex, boolean bOnCentLine, UnitOfMeasure unit)**

​	中心线上一点到起点距离，附加条件是该点所在车道上的分段序号。单位：像素。

参数: 

​	[ in ] p: 当前中心线上该点坐标。

​	[ in ] segmIndex: 该点所在车道上的分段序号。

​	[ in ] bOnCentLine: 是否在中心线上。

**public boolean getPointAndIndexByDist(double dist, Point outPoint, int outIndex, UnitOfMeasure unit)**

​	求中心线起点向前延伸dist距离后所在点及分段序号，如果目标点不在中心线上返回false，否则返回true。单位：像素。

参数: 

​	[ in ] dist: 中心线起点向前延伸的距离。

​	[ out ] outPoint: 中心线起点向前延伸dist距离后所在点。

​	[ out ] outIndex: 中心线起点向前延伸dist距离后所在分段序号。

**public boolean getPointByDist(double dist, Point outPoint, UnitOfMeasure unit)**

​	求中心线起点向前延伸dist距离后所在点，如果目标点不在中心线上返回false，否则返回true。单位：像素。

参数: 

​	[ in ] dist: 中心线起点向前延伸的距离。

​	[ out ] outPoint: 中心线起点向前延伸dist距离后所在点。

示例:

```java
// 获取距离路段起点一定距离的点位坐标
Point outPoint = new Point();
boolean result = lane.getPointByDist(50, outPoint, UnitOfMeasure.Metric);
if (result) {
    double x = outPoint.x();
    double y = outPoint.y();
}
```

**public void setOtherAttr(JsonObject attr)**

​	设置车道其它属性。

**public void setLaneType(String type)**

​	设置车道类型。

参数: 

​	[ in ] type: 车道类型，选下列几种类型其中一种: "机动车道"、"机非共享"、"非机动车道"、"公交专用道"。

示例:

```java
// 设置车道类型
lane.setLaneType("机动车道");
```

**public Vector\<Point\> polygon()**

​	获取车道的多边型轮廓顶点。

#### 3.4.1.7.车道连接（ILaneConnector）

**public int gtype()**

​	类型，GLaneType或GLaneConnectorType，车道连接段为GLaneConnectorType。

**public long id()**

​	获取车道连接ID。

**public IConnector connector()**

​	获取车道连接所在连接段。

**public ISection section()**

​	获取车道所属Section。

**public ILane fromLane()**

​	上游车道。

**public ILane toLane()**

​	下游车道。

**public double length(UnitOfMeasure unit)**

​	获取车道连接长度。单位：像素。

**public ArrayList\<Point\> centerBreakPoints(UnitOfMeasure unit)**

​	获取车道连接中心线断点集。单位：像素。

**public ArrayList\<Point\> leftBreakPoints(UnitOfMeasure unit)**

​	获取车道连接左侧线断点集。单位：像素。

**public ArrayList\<Point\> rightBreakPoints(UnitOfMeasure unit)**

​	获取车道连接右侧线断点集。单位：像素。

**public ArrayList\<Vector3D\> centerBreakPoint3Ds(UnitOfMeasure unit)**

​	获取车道连接中心线三维断点集。单位：像素。

**public ArrayList\<Vector3D\> leftBreakPoint3Ds(UnitOfMeasure unit)**

​	获取车道连接左侧线三维断点集。单位：像素。

**public ArrayList\<Vector3D\> rightBreakPoint3Ds(UnitOfMeasure unit)**

​	获取车道连接右侧线三维断点集。单位：像素。

**public ArrayList\<Vector3D\> leftBreak3DsPartly(Point fromPoint, Point toPoint, UnitOfMeasure unit)**

​	获取车道连接左侧部分三维断点集。单位：像素。

参数: 

​	[ in ] fromPoint: 中心线上某一点作为起点。

​	[ in ] toPoint: 中心线上某一点作为终点。

**public ArrayList\<Vector3D\> rightBreak3DsPartly(Point fromPoint, Point toPoint, UnitOfMeasure unit)**

​	获取车道连接右侧部分三维断点集。单位：像素。

参数: 

​	[ in ] fromPoint: 中心线上某一点作为起点。

​	[ in ] toPoint: 中心线上某一点作为终点。

**public double distToStartPoint(Point p, UnitOfMeasure unit)**

​	中心线上一点到起点距离。单位：像素。

参数: 

​	[ in ] p: 当前点坐标。

**public double distToStartPointWithSegmIndex(Point p, int segmIndex, boolean bOnCentLine, UnitOfMeasure unit)**

​	中心线上一点到起点距离，附加条件是该点所在车道上的分段序号。单位：像素。

参数: 

​	[ in ] p: 当前点坐标。

​	[ in ] segmIndex: 分段序号。

​	[ in ] bOnCentLine: 是否在中心线上。

**public boolean getPointAndIndexByDist(double dist, Point outPoint, int outIndex, UnitOfMeasure unit)**

​	求中心线起点向前延伸dist距离后所在点及分段序号，如果目标点不在中心线上返回false，否则返回true。单位：像素。

参数: 

​	[ in ] dist: 中心线起点向前延伸的距离。

​	[ out ] outPoint: 中心线起点向前延伸dist距离后所在点。

​	[ out ] outIndex: 中心线起点向前延伸dist距离后所在分段序号。

**public boolean getPointByDist(double dist, Point outPoint, UnitOfMeasure unit)**

​	求中心线起点向前延伸dist距离后所在点，如果目标点不在中心线上返回false，否则返回true。单位：像素。

参数: 

​	[ in ] dist: 中心线起点向前延伸的距离。

​	[ out ] outPoint: 中心线起点向前延伸dist距离后所在点。

**public void setOtherAttr(JsonObject attr)**

​	设置车道连接其它属性。

#### 3.4.1.8.连接段面域（IConnectorArea）

**public long id()**

​	面域ID，面域是指若干Connector重叠形成的区域。

**public ArrayList\<IConnector\> allConnector()**

​	面域相关所有连接段。

**public Point centerPoint(UnitOfMeasure unit)**

​	获取面域中心点位置。单位：像素。

### 3.4.2.发车点

#### 3.4.2.1.发车点（IDispatchPoint）

**public long id()**

​	获取发车点ID。

**public String name()**

​	获取发车名称。

**public ILink link()**

​	获取发车点所在路段。

**public long addDispatchInterval(long vehiCompId, int interval, int vehiCount)**

​	为发车点增加发点间隔。

参数: 

​	[ in ] vehiCompId: 车型组成ID。

​	[ in ] interval: 时间段。单位: s。

​	[ in ] vehiCount: 发车数。

返回值: 

​	发车间隔ID。

**public void setDynaModified(boolean bModified)**

​	设置是否被动态修改，默认情况下发车信息被动态修改后，整个文件不能保存，以免破坏原有发车设置。

**public Vector\<Point\> polygon()**

​	获取发车点多边型轮廓的顶点。

### 3.4.3.决策点和车辆路径

#### 3.4.3.1.决策点（IDecisionPoint）

**public long id()**

​	决策点ID。

**public String name()**

​	决策点名称。

**public ILink link()**

​	决策点所在路段。

**public double distance(UnitOfMeasure unit)**

​	获取距路段起点距离。单位：像素。

**public ArrayList\<IRouting\> routings()**

​	相关决策路径。

**public void setDynaModified(boolean bModified)**

​	设置是否被动态修改，默认情况下发车信息被动态修改后，整个文件不能保存，以免破坏原有发车设置。

参数: 

​	[ in ] bModified: 是否被动态修改，true为被动态修改，false为未被动态修改。

**public Vector\<Point\> polygon()**

​	决策点多边型轮廓的顶点。

#### 3.4.3.2.车辆路径（IRouting）

**public long id()**

​	路径ID。

**public double calcuLength(UnitOfMeasure unit)**

​	计算路径长度。单位：像素。

**public ArrayList\<ILink\> getLinks()**

​	获取路段序列。

**public long deciPointId()**

​	所属决策点ID。

**public boolean contain(ISection pRoad)**

​	通过所给道路判断是否在当前路径上。

参数: 

​	[ in ] pRoad: 路段或连接段。

**public ISection nextRoad(ISection pRoad)**

​	通过所给道路求下一条道路。

参数: 

​	[ in ] pRoad: 路段或连接段。

### 3.4.4.信号控制

#### 3.4.4.1.信号机（ISignalController）

**public long id()**

​	获取信号机ID。

**public String name()**

​	获取信号机名称。

**public void setName(String name)**

​	设置信号机名称。

参数: 

​	[ in ] name: 新名称。

**public void addPlan(ISignalPlan plan)**

​	添加信控方案。

参数: 

​	[ in ] plan: 信控方案。

**public void removePlan(ISignalPlan plan)**

​	移除信控方案。

参数: 

​	[ in ] plan: 要移除的信控方案。

**public ArrayList\<ISignalPlan\> plans()**

​	获取所有信控方案。

**public boolean isValid()**

​	检查信号机的有效性。

#### 3.4.4.2.信号控制方案（ISignalPlan）

**public long id()**

​	获取ID。

**public String Name()**

​	获取灯组名。

**public String trafficName()**

​	获取信控方案名称。

**public int cycleTime()**

​	获取信号周期。单位: s。

**public long fromTime()**

​	获取起始时间。单位: s。

**public long toTime()**

​	获取结束时间。单位: s。

**public ArrayList\<ISignalPhase\> phases()**

​	获取相位列表。

**public void setName(String name)**

​	设置信控方案名称。

参数: 

​	[ in ] name: 新名称。

**public void setcycleTime(int period)**

​	设置信号周期。单位: s。

参数: 

​	[ in ] period: 信号周期。单位: s。

**public void setFromTime(long time)**

​	设置起始时间。单位: s。

参数: 

​	[ in ] time: 起始时间。单位: s。

**public void setToTime(long time)**

​	设置结束时间。单位: s。

参数: 

​	[ in ] time: 结束时间。单位: s。

#### 3.4.4.3.信号灯相位（ISignalPhase）

**public long id()**

​	相位ID。

**public String phaseName()**

​	相位名称。

**public ArrayList\<ColorInterval\> listColor()**

​	获取相位灯色列表。

**public void setColorList(ArrayList\<ColorInterval\> lColor)**

​	设置信号灯列表。

参数: 

​	[ in ] lColor: 灯色时长信息，包含信号灯颜色和信号灯时长。

示例:

```java
// 构建灯色和时长对象列表
ArrayList<ColorInterval> colorObjList = new ArrayList<>(Arrays.asList(
    new ColorInterval ("R", 10),  // 红色，时长 10
    new ColorInterval ("G", 60),  // 绿色，时长 60
    new ColorInterval ("Y", 3),  // 黄色，时长 3
    new ColorInterval ("R", 17)  // 红色，时长 17
));
// 查找ID为7的信号灯相位
SignalPhase signalPhase = netiface.findSignalPhase(7);
if (signalPhase != null) {
    // 设置灯色列表
    signalPhase.setColorList(colorObjList);
}
```

**public int cycleTime()**

​	获取相位周期。单位: s。

**public SignalPhaseColor phaseColor()**

​	获取当前相位灯色。

**public ISignalPlan signalPlan()**

​	获取相位所在信控方案。

**public ArrayList\<ISignalLamp\> signalLamps()**

​	获取相关信号灯列表。

**public void setPhaseName(String name)**

​	设置相位名称。

参数: 

​	[ in ] name: 新名称。

#### 3.4.4.4.信号灯灯头（ISignalLamp）

**public long id()**

​	获取信号灯ID。

**public void setSignalPhase(ISignalPhase pPhase)**

​	设置相位，所设相位可以是其它信号灯组的相位。

参数: 

​	[ in ] pPhase: 相位。

**public void setPhaseNumber(int num)**

​	设置相位序号，序号从1开始，如果num序号大于相位总数不进行设置。

**public void setLampColor(String colorStr)**

​	设置信号灯颜色。

参数: 

​	[ in ] colorStr: 字符串表达的颜色，有四种可选，分别是"红"、"绿"、"黄"、"灰"，或者是"R"、"G"、"Y"、"grey"。 

**public String color()**

​	获取信号灯色，"R"、“G”、“Y”、“gray”分别表示"红"、"绿"、"黄"、"灰"。

**public String name()**

​	获取信号灯名称。

**public void setName(String name)**

​	设置信号灯名称。

**public void setDistToStart(double dist, UnitOfMeasure unit)**

​	设置信号灯距路段起点距离。单位：像素。

参数: 

​	[ in ] dist: 距离值。

**public ISignalPlan signalPlan()**

​	获取信控方案。

**public ISignalPhase signalPhase()**

​	获取相位。

**public ILaneObject laneObject()**

​	获取所在车道或车道连接。

**public Vector\<Point\> polygon()**

​	获取信号灯多边型轮廓的顶点。

**public double angle()**

​	获取信号灯角度。

### 3.4.5.采集设备

#### 3.4.5.1.数据采集器（IVehicleDrivInfoCollector）

**public long id()**

​	获取采集器ID。

**public String collName()**

​	获取采集器名称。

**public boolean onLink()**

​	是否在路段上，如果true则connector()返回null。

**public ILink link()**

​	采集器所在路段。

**public IConnector connector()**

​	采集器所在连接段。

**public ILane lane()**

​	如果采集器在路段上返回所在车道，否则返回null。

**public ILaneConnector laneConnector()**

​	如果采集器在连接段上则返回车道连接，否则返回null。

**public double distToStart(UnitOfMeasure unit)**

​	获取采集器距路段起点距离。单位：像素。

**public Point point(UnitOfMeasure unit)**

​	获取采集器位置坐标。单位：像素。

**public long fromTime()**

​	采集器工作起始时间。单位: s。

**public long toTime()**

​	采集器工作停止时间。单位: s。

**public long aggregateInterval()**

​	集计数据时间间隔。单位: s。

**public void setName(String name)**

​	设置采集器名称。

**public void setDistToStart(double dist, UnitOfMeasure unit)**

​	设置采集器距路段起点距离。单位：像素。

参数: 

​	[ in ] dist: 距离值。

**public void setFromTime(long time)**

​	设置采集器工作起始时间。单位: s。

参数: 

​	[ in ] time: 工作起始时间。单位: s。

**public void setToTime(long time)**

​	设置采集器工作结束时间。单位: s。

参数: 

​	[ in ] time: 工作结束时间。单位: s。

**public void setAggregateInterval(int interval)**

​	设置采集器集计数据时间间隔。单位: s。

**public Vector\<Point\> polygon()**

​	获取采集器的多边型轮廓顶点。

#### 3.4.5.2.排队计数器（IVehicleQueueCounter）

**public long id()**

​	获取计数器ID。

**public String counterName()**

​	获取计数器名称。

**public boolean onLink()**

​	是否在路段上，如果true则connector()返回null。

**public ILink link()**

​	计数器所在路段。

**public IConnector connector()**

​	计数器所在连接段。

**public ILane lane()**

​	如果计数器在路段上返回所在车道，否则返回null。

**public ILaneConnector laneConnector()**

​	如果计数器在连接段上返回车道连接，否则返回null。

**public double distToStart(UnitOfMeasure unit)**

​	获取计数器距路段起点距离。单位：像素。

**public Point point(UnitOfMeasure unit)**

​	获取计数器位置坐标。单位：像素。

**public long fromTime()**

​	计数器工作起始时间。单位: s。

**public long toTime()**

​	计数器工作停止时间。单位: s。

**public long aggregateInterval()**

​	计数集计数据时间间隔。单位: s。

**public void setName(String name)**

​	设置计数器名称。

参数: 

​	[ in ] name: 计数器名称。

**public void setDistToStart(double dist, UnitOfMeasure unit)**

​	设置计数器距路段起点距离。单位：像素。

参数: 

​	[ in ] dist: 距离值。

**public void setFromTime(long time)**

​	设置工作起始时间。单位: s。

**public void setToTime(long time)**

​	设置工作结束时间。单位: s。

**public void setAggregateInterval(int interval)**

​	设置集计数据时间间隔。单位: s。

**public Vector\<Point\> polygon()**

​	获取计数器的多边型轮廓顶点。

#### 3.4.5.3.行程时间检测器（IVehicleTravelDetector）

**public long id()**

​	获取检测器ID。

**public String detectorName()**

​	获取检测器名称。

**public boolean isStartDetector()**

​	是否检测器起始点。

**public boolean isOnLink_startDetector()**

​	检测器起点是否在路段上，如果否，则起点在连接段上。

**public boolean isOnLink_endDetector()**

​	检测器终点是否在路段上，如果否，则终点在连接段上。

**public ILink link_startDetector()**

​	如果检测器起点在路段上则返回起点所在路段，否则返回null。

**public ILaneConnector laneConnector_startDetector()**

​	如果检测器起点在连接段上返回起点车道连接，否则返回null。

**public ILink link_endDetector()**

​	如果检测器终点在路段上返回终点所在路段，否则返回null。

**public ILaneConnector laneConnector_endDetector()**

​	如果检测器终点在连接段上返回终点车道连接，否则返回null。

**public double distance_startDetector(UnitOfMeasure unit)**

​	获取起点检测器距路段起点距离。单位：像素。

**public double distance_endDetector(UnitOfMeasure unit)**

​	获取终点检测器距路段起点距离。单位：像素。

**public Point point_startDetector(UnitOfMeasure unit)**

​	获取起点检测器位置坐标。单位：像素。

**public Point point_endDetector(UnitOfMeasure unit)**

​	获取终点检测器位置坐标。单位：像素。

**public long fromTime()**

​	检测器工作起始时间。单位: s。

**public long toTime()**

​	检测器工作停止时间。单位: s。

**public long aggregateInterval()**

​	集计数据时间间隔。单位: s。

**public void setName(String name)**

​	设置检测器名称。

**public void setDistance_startDetector(double dist, UnitOfMeasure unit)**

​	设置起点检测器距路段起点距离。单位：像素。

参数: 

​	[ in ] dist: 距离值。

**public void setDistance_endDetector(double dist, UnitOfMeasure unit)**

​	设置终点检测器距路段起点距离。单位：像素。

参数: 

​	[ in ] dist: 距离值。

**public void setFromTime(long time)**

​	设置检测器工作起始时间。单位: s。

参数: 

​	[ in ] time: 工作起始时间。单位: s。

**public void setToTime(long time)**

​	设置检测器工作结束时间。单位: s。

参数: 

​	[ in ] time: 工作结束时间。单位: s。

**public void setAggregateInterval(int interval)**

​	设置检测器集计数据时间间隔。单位: s。

参数: 

​	[ in ] interval: 集计数据时间间隔。单位: s。

**public Vector\<Point\> polygon_startDetector()**

​	获取行程时间检测器起始点多边型轮廓的顶点。

**public Vector\<Point\> polygon_endDetector()**

​	获取行程时间检测器终止点多边型轮廓的顶点。

### 3.4.6.导向箭头

#### 3.4.6.1.导向箭头（IGuidArrow）

**public long id()**

​	获取导向箭头ID。

**public ILane lane()**

​	获取导向箭头所在的车道。

**public double length(UnitOfMeasure unit)**

​	获取导向箭头长度。单位：像素。

**public double distToTerminal(UnitOfMeasure unit)**

​	获取导向箭头到终点距离。单位：像素。

**public GuideArrowType arrowType()**

​	获取导向箭头的类型，导向箭头的类型分为: 直行、左转、右转、直行或左转、直行或右转、直行左转或右转、左转或右转、掉头、直行或掉头和左转或掉头。

**public Vector\<Point\> polygon()**

​	获取导向箭头的多边型轮廓的顶点。

### 3.4.7.公交系统

#### 3.4.7.1.公交线路（IBusLine）

**public long id()**

​	获取公交线路ID。

**public String name()**

​	线路名称。

**public double length(UnitOfMeasure unit)**

​	获取公交线路长度。单位：像素。

**public int dispatchFreq()**

​	发车间隔。单位: s。

**public int dispatchStartTime()**

​	发车开始时间。单位: s。

**public int dispatchEndTime()**

​	发车结束时间。单位: s。

**public double desirSpeed(UnitOfMeasure unit)**

​	获取公交线路期望速度。单位: 像素/s。

**public int passCountAtStartTime()**

​	起始载客人数。

**public ArrayList\<ILink\> links()**

​	公交线路经过的路段。

**public ArrayList\<IBusStation\> stations()**

​	线路所有站点。

**public ArrayList\<IBusStationLine\> stationLines()**

​	公交站点线路，当前线路相关站点的上下客等参数。

**public void setName(String name)**

​	设置线路名称。

**public void setDispatchFreq(int freq)**

​	设置当前公交线路的发车间隔。单位: s。

参数: 

​	[ in ] freq: 发车间隔。单位: s。

**public void setDispatchStartTime(int startTime)**

​	设置当前公交线路上的公交首班车辆的开始发车时间。单位: s。

参数: 

​	[ in ] startTime: 开始发车时间。单位: s。

**public void setDispatchEndTime(int endTime)**

​	设置当前公交线路上的公交末班车辆的结束发车时间。单位: s。

参数: 

​	[ in ] endTime: 结束发车时间。单位: s。

**public void setDesirSpeed(double speed, UnitOfMeasure unit)**

​	设置当前公交线路的期望速度。单位: 像素/s。

参数: 

​	[ in ] speed: 速度值。

**public void setPassCountAtStartTime(int count)**

​	设置起始载客人数。

#### 3.4.7.2.公交站点（IBusStation）

**public long id()**

​	获取公交站点ID。

**public String name()**

​	获取公交站点名称。

**public int laneNumber()**

​	获取公交站点所在车道序号。

**public double x(UnitOfMeasure unit)**

​	获取站点X坐标。单位：像素。

**public double y(UnitOfMeasure unit)**

​	获取站点Y坐标。单位：像素。

**public double length(UnitOfMeasure unit)**

​	获取站点长度。单位：像素。

**public int stationType()**

​	站点类型，1: 路边式、2: 港湾式。

**public ILink link()**

​	公交站点所在路段。

**public ILane lane()**

​	公交站点所在车道。

**public double distance(UnitOfMeasure unit)**

​	获取站点距路段起点距离。单位：像素。

**public void setName(String name)**

​	设置站点名称。

参数: 

​	[ in ] name: 新名称。

**public void setDistToStart(double dist, UnitOfMeasure unit)**

​	设置站点距路段起点距离。单位：像素。

参数: 

​	[ in ] dist: 距离值。

**public void setLength(double length, UnitOfMeasure unit)**

​	设置站点长度。单位：像素。

参数: 

​	[ in ] length: 长度值。

**public void setType(int type)**

​	设置站点类型。

参数: 

​	[ in ] type: 站点类型，1 路侧式、2 港湾式。

**public Vector\<Point\> polygon()**

​	公交站点多边型轮廓的顶点。

#### 3.4.7.3.公交站点-线路（IBusStationLine）

**public long id()**

​	获取公交"站点-线路"ID。

**public long stationId()**

​	公交站点ID。

**public long lineId()**

​	公交线路ID。

**public int busParkingTime()**

​	车辆停靠时间。单位: s。

**public double getOutPercent()**

​	下客百分比。

**public double getOnTimePerPerson()**

​	平均每位乘客上车时间。单位: s。

**public double getOutTimePerPerson()**

​	平均每位乘客下车时间。单位: s。

**public void setBusParkingTime(int time)**

​	设置车辆停靠时间。

参数: 

​	[ in ] time: 车辆停靠时间。单位: s。

**public void setGetOutPercent(double percent)**

​	设置下客百分比。

参数: 

​	[ in ] percent: 下客百分比。

**public void setGetOnTimePerPerson(double time)**

​	设置平均每位乘客上车时间。

参数: 

​	[ in ] time: 平均每位乘客上车时间。单位: s。

**public void setGetOutTimePerPerson(double time)**

​	设置平均每位乘客下车时间。

参数: 

​	[ in ] time: 平均每位乘客下车时间。单位: s。

### 3.4.8.事件区域

#### 3.4.8.1.事故区（IAccidentZone）

**public long id()**

​	获取事故区ID。

**public String name()**

​	获取事故区名称。

**public double location(UnitOfMeasure unit)**

​	获取事故区当前时段距所在路段起点的距离。单位：像素。

**public double zoneLength(UnitOfMeasure unit)**

​	获取事故区当前时段长度。单位：像素。

**public double limitedSpeed(UnitOfMeasure unit)**

​	获取事故区当前时段限速。单位：像素(km/h)。

**public ISection section()**

​	获取事故区所在的路段或连接段。

**public long roadId()**

​	获取事故区所在路段的ID。

**public String roadType()**

​	获取事故区所在的道路类型(路段或连接段)。

**public ArrayList\<ILaneObject\> laneObjects()**

​	获取事故区当前时段占用的车道列表。

**public double controlLength(UnitOfMeasure unit)**

​	获取事故区当前时段控制距离（车辆距离事故区起点该距离内，强制变道）。单位：像素。

**public IAccidentZoneInterval addAccidentZoneInterval(DynaAccidentZoneIntervalParam param)**

​	添加事故时段。

参数: 

​	[ in ] param: 事故时段参数。

**public void removeAccidentZoneInterval(long accidentZoneIntervalId)**

​	移除事故时段。

参数: 

​	[ in ] accidentZoneIntervalId: 事故时段ID。

**public boolean updateAccidentZoneInterval(DynaAccidentZoneIntervalParam param)**

​	更新事故时段。

参数: 

​	[ in ] param: 事故时段参数。

**public ArrayList\<IAccidentZoneInterval\> accidentZoneIntervals()**

​	获取所有事故时段。

**public IAccidentZoneInterval findAccidentZoneIntervalById(long accidentZoneIntervalId)**

​	通过ID查询事故时段。

参数: 

​	[ in ] accidentZoneIntervalId: 事故时段ID。

**public IAccidentZoneInterval findAccidentZoneIntervalByStartTime(long startTime)**

​	通过开始时间查询事故时段。

参数: 

​	[ in ] startTime: 事故时段开始时间。

#### 3.4.8.2.事故区时段（IAccidentZoneInterval）

**public long intervalId()**

​	获取事故时段ID。

**public long accidentZoneId()**

​	获取所属事故区ID。

**public long startTime()**

​	获取事故时段开始时间。

**public long endTime()**

​	获取事故时段结束时间。

**public double length(UnitOfMeasure unit)**

​	获取事故区在该时段的长度。单位：像素。

**public double location(UnitOfMeasure unit)**

​	获取事故区在该时段的距起点距离。单位：像素。

**public double limitedSpeed(UnitOfMeasure unit)**

​	获取事故区在该时段的限速。单位: 像素(km/h)。

**public double controlLength(UnitOfMeasure unit)**

​	获取事故区在该时段的控制距离（车辆距离事故区起点该距离内，强制变道）。单位：像素。

**public ArrayList\<Int\> laneNumbers()**

​	获取事故区在该时段的占用车道序号。

#### 3.4.8.3.施工区（IRoadWorkZone）

**public long id()**

​	获取施工区ID。

**public String name()**

​	获取施工区名称。

**public double location(UnitOfMeasure unit)**

​	获取施工区距所在路段起点的距离。单位：像素。

**public double zoneLength(UnitOfMeasure unit)**

​	获取施工区长度。单位：像素。

**public double limitSpeed(UnitOfMeasure unit)**

​	获取施工区限速。单位: 像素（km/h）。

**public long sectionId()**

​	获取施工区所在路段或连接段的ID。

**public String sectionName()**

​	获取施工区所在路段或连接段的名称。

**public String sectionType()**

​	获取施工区所在道路的道路类型，link: 路段，connector: 连接段。

**public ArrayList\<ILaneObject\> laneObjects()**

​	获取施工区所占的车道列表。

**public ArrayList\<Long\> laneObjectIds()**

​	获取施工区所占的车道ID列表。

**public double upCautionLength(UnitOfMeasure unit)**

​	获取施工区上游警示区长度。单位：像素。

**public double upTransitionLength(UnitOfMeasure unit)**

​	获取施工区上游过渡区长度。单位：像素。

**public double upBufferLength(UnitOfMeasure unit)**

​	获取施工区上游缓冲区长度。单位：像素。

**public double downTransitionLength(UnitOfMeasure unit)**

​	获取施工区下游过渡区长度。单位：像素。

**public double downTerminationLength(UnitOfMeasure unit)**

​	获取施工区下游终止区长度。单位：像素。

**public long duration()**

​	施工持续时间，自仿真过程创建后，持续时间大于此值，则移除。单位: s。

**public boolean isBorrowed()**

​	获取施工区是否被借道。

#### 3.4.8.4.限行区（ILimitedZone）

**public long id()**

​	获取限行区ID。

**public String name()**

​	获取限行区名称。

**public double location(UnitOfMeasure unit)**

​	获取限行区距所在路段起点的距离。单位：像素。

**public double zoneLength(UnitOfMeasure unit)**

​	获取限行区长度。单位：像素。

**public double limitSpeed(UnitOfMeasure unit)**

​	获取限行区限速，单位: 像素(km/h)。

**public long sectionId()**

​	获取路段或连接段ID。

**public String sectionName()**

​	获取Section名称。

**public String sectionType()**

​	获取道路类型，"link"表示路段，"connector"表示连接段。

**public ArrayList\<ILaneObject\> laneObjects()**

​	获取相关车道对象列表。

**public long duration()**

​	获取限行持续时间，自仿真过程创建后，持续时间大于此值则删除。单位: s。

#### 3.4.8.5.改扩建借道（IReconstruction）

**public long id()**

​	获取改扩建ID。

**public long roadWorkZoneId()**

​	获取改扩建起始施工区ID。

**public long limitedZoneId()**

​	获取被借道限行区ID。

**public double passagewayLength(UnitOfMeasure unit)**

​	获取保通长度。单位：像素。

**public long duration()**

​	获取改扩建持续时间。

**public int borrowedNum()**

​	获取借道数量。

**public double passagewayLimitedSpeed(UnitOfMeasure unit)**

​	获取保通开口限速。单位: 像素（km/h）。

**public DynaReconstructionParam dynaReconstructionParam()**

​	获取改扩建动态参数。

#### 3.4.8.6.限速区（IReduceSpeedArea）

**public long id()**

​	获取限速区ID。

**public String name()**

​	获取限速区名称。

**public double location(UnitOfMeasure unit)**

​	获取距起点距离。单位：像素。

**public double areaLength(UnitOfMeasure unit)**

​	获取限速区长度。单位：像素。

**public long sectionId()**

​	获取路段或连接段ID。

**public int laneNumber()**

​	获取车道序号。

**public int toLaneNumber()**

​	获取目标车道序号。

**public IReduceSpeedInterval addReduceSpeedInterval(DynaReduceSpeedIntervalParam param)**

​	添加限速时段。

参数: 

​	[ in ] param: 限速时段参数。

**public void removeReduceSpeedInterval(long id)**

​	移除限速时段。

参数: 

​	[ in ] id: 限速时段ID。

**public boolean updateReduceSpeedInterval(DynaReduceSpeedIntervalParam param)**

​	更新限速时段。

参数: 

​	[ in ] param: 限速时段参数。

**public ArrayList\<IReduceSpeedInterval\> reduceSpeedIntervals()**

​	获取限速时段列表。

**public IReduceSpeedInterval findReduceSpeedIntervalById(long id)**

​	通过ID获取限速时段。

参数: 

​	[ in ] id: 限速时段ID。

**public IReduceSpeedInterval findReduceSpeedIntervalByStartTime(long startTime)**

​	通过起始时间获取限速时段。

参数: 

​	[ in ] startTime: 起始时间。

**public Vector\<Point\> polygon()**

​	获取多边型轮廓。

#### 3.4.8.7.限速时段（IReduceSpeedInterval）

**public long id()**

​	获取限速时段ID。

**public long reduceSpeedAreaId()**

​	获取所属限速区ID。

**public long intervalStartTime()**

​	获取开始时间。

**public long intervalEndTime()**

​	获取结束时间。

**public IReduceSpeedVehiType addReduceSpeedVehiType(DynaReduceSpeedVehiTypeParam param)**

​	添加限速车型。

参数: 

​	[ in ] param: 限速车型参数。

**public void removeReduceSpeedVehiType(long id)**

​	移除限速车型。

参数: 

​	[ in ] id: 限速车型ID。

**public boolean updateReduceSpeedVehiType(DynaReduceSpeedVehiTypeParam param)**

​	更新限速车型。

参数: 

​	[ in ] param: 限速车型参数。

**public ArrayList\<IReduceSpeedVehiType\> reduceSpeedVehiTypes()**

​	获取本时段限速车型及限速参数列表。

**public IReduceSpeedVehiType findReduceSpeedVehiTypeById(long id)**

​	通过id获取限速车型。

参数: 

​	[ in ] id: 限速车型ID。

**public IReduceSpeedVehiType findReduceSpeedVehiTypeByCode(long vehicleTypeCode)**

​	通过车型代码获取限速车型。

参数: 

​	[ in ] vehicleTypeCode: 车型代码。

#### 3.4.8.8.限速车型（IReduceSpeedVehiType）

**public long id()**

​	获取限速车型ID。

**public long intervalId()**

​	获取所属限速时段ID。

**public long reduceSpeedAreaId()**

​	获取所属限速区ID。

**public long vehiTypeCode()**

​	获取车型编码。

**public double averageSpeed(UnitOfMeasure unit)**

​	获取平均车速。单位: 像素/s。

**public double speedStandardDeviation(UnitOfMeasure unit)**

​	获取车速标准差。单位: 像素/s。

### 3.4.9.行人模块

#### 3.4.9.1.障碍物面域（IObstacleRegion）

**public boolean isObstacle()**

​	获取面域是否为障碍物。

**public void setObstacle(boolean b)**

​	设置面域是否为障碍物。

参数: 

​	[ in ] b: 是否为障碍物。

#### 3.4.9.2.乘客面域（IPassengerRegion）

**public boolean isBoardingArea()**

​	获取面域是否为上客区域。

**public void setIsBoardingArea(boolean b)**

​	设置面域是否为上客区域。

**public boolean isAlightingArea()**

​	获取面域是否为下客区域。

**public void setIsAlightingArea(boolean b)**

​	设置面域是否为下客区域。

#### 3.4.9.3.行人路径面域基类（IPedestrianPathRegionBase）

**public long getId()**

​	获取面域ID。

**public String getName()**

​	获取面域名称。

**public void setName(String name)**

​	设置面域名称。

**public Color getRegionColor()**

​	获取面域颜色。

**public void setRegionColor(Color color)**

​	设置面域颜色。

**public Point getPosition(UnitOfMeasure unit)**

​	获取面域位置。单位：像素。

**public void setPosition(Point scenePos, UnitOfMeasure unit)**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**public int getGType()**

​	获取面域类型。

#### 3.4.9.4.行人面域（IPedestrianRegion）

**public long getId()**

​	获取面域ID。

**public String getName()**

​	获取面域名称。

**public void setName(String name)**

​	设置面域名称。

**public Color getRegionColor()**

​	获取面域颜色。

**public void setRegionColor(Color color)**

​	设置面域颜色。

**public Point getPosition(UnitOfMeasure unit)**

​	获取面域位置。单位：像素。

**public void setPosition(Point scenePos, UnitOfMeasure unit)**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**public int getGType()**

​	获取面域类型。

**public double getExpectSpeedFactor()**

​	获取期望速度系数。

**public void setExpectSpeedFactor(double val)**

​	设置期望速度系数。

参数: 

​	[ in ] val: 期望速度系数。

**public double getElevation()**

​	获取面域高程。

**public void setElevation(double elevation)**

​	设置面域高程。

参数: 

​	[ in ] elevation: 高程。

**public Vector\<Point\> getPolygon()**

​	获取面域多边形。

**public long getLayerId()**

​	获取面域所在图层ID。

**public void setLayerId(long id)**

​	设置面域所在图层，如果图层ID非法，则不做任何改变。

参数: 

​	[ in ] id: 图层ID。

#### 3.4.9.5.矩形行人面域（IPedestrianRectRegion）

**public long getId()**

​	获取面域ID。

**public String getName()**

​	获取面域名称。

**public void setName(String name)**

​	设置面域名称。

**public Color getRegionColor()**

​	获取面域颜色。

**public void setRegionColor(Color color)**

​	设置面域颜色。

**public Point getPosition(UnitOfMeasure unit)**

​	获取面域位置。单位：像素。

**public void setPosition(Point scenePos, UnitOfMeasure unit)**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**public int getGType()**

​	获取面域类型。

**public double getExpectSpeedFactor()**

​	获取期望速度系数。

**public void setExpectSpeedFactor(double val)**

​	设置期望速度系数。

**public double getElevation()**

​	获取面域高程。

**public void setElevation(double elevation)**

​	设置面域高程。

**public Vector\<Point\> getPolygon()**

​	获取面域多边形。

**public long getLayerId()**

​	获取面域所在图层ID。

**public void setLayerId(long id)**

​	设置面域所在图层，如果图层ID非法，则不做任何改变。

**public boolean isObstacle()**

​	获取面域是否为障碍物。

**public void setObstacle(boolean b)**

​	设置面域是否为障碍物。

**public boolean isBoardingArea()**

​	获取面域是否为上客区域。

**public void setIsBoardingArea(boolean b)**

​	设置面域是否为上客区域。

**public boolean isAlightingArea()**

​	获取面域是否为下客区域。

**public void setIsAlightingArea(boolean b)**

​	设置面域是否为下客区域。

#### 3.4.9.6.三角形行人面域（IPedestrianTriangleRegion）

**public long getId()**

​	获取面域ID。

**public String getName()**

​	获取面域名称。

**public void setName(String name)**

​	设置面域名称。

**public Color getRegionColor()**

​	获取面域颜色。

**public void setRegionColor(Color color)**

​	设置面域颜色。

**public Point getPosition(UnitOfMeasure unit)**

​	获取面域位置。单位：像素。

**public void setPosition(Point scenePos, UnitOfMeasure unit)**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**public int getGType()**

​	获取面域类型。

**public double getExpectSpeedFactor()**

​	获取期望速度系数。

**public void setExpectSpeedFactor(double val)**

​	设置期望速度系数。

**public double getElevation()**

​	获取面域高程。

**public void setElevation(double elevation)**

​	设置面域高程。

**public Vector\<Point\> getPolygon()**

​	获取面域多边形。

**public long getLayerId()**

​	获取面域所在图层ID。

**public void setLayerId(long id)**

​	设置面域所在图层，如果图层ID非法，则不做任何改变。

**public boolean isObstacle()**

​	获取面域是否为障碍物。

**public void setObstacle(boolean b)**

​	设置面域是否为障碍物。

**public boolean isBoardingArea()**

​	获取面域是否为上客区域。

**public void setIsBoardingArea(boolean b)**

​	设置面域是否为上客区域。

**public boolean isAlightingArea()**

​	获取面域是否为下客区域。

**public void setIsAlightingArea(boolean b)**

​	设置面域是否为下客区域。

#### 3.4.9.7.椭圆形行人面域（IPedestrianEllipseRegion）

**public long getId()**

​	获取面域ID。

**public String getName()**

​	获取面域名称。

**public void setName(String name)**

​	设置面域名称。

**public Color getRegionColor()**

​	获取面域颜色。

**public void setRegionColor(Color color)**

​	设置面域颜色。

**public Point getPosition(UnitOfMeasure unit)**

​	获取面域位置。单位：像素。

**public void setPosition(Point scenePos, UnitOfMeasure unit)**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**public int getGType()**

​	获取面域类型。

**public double getExpectSpeedFactor()**

​	获取期望速度系数。

**public void setExpectSpeedFactor(double val)**

​	设置期望速度系数。

**public double getElevation()**

​	获取面域高程。

**public void setElevation(double elevation)**

​	设置面域高程。

**public Vector\<Point\> getPolygon()**

​	获取面域多边形。

**public long getLayerId()**

​	获取面域所在图层ID。

**public void setLayerId(long id)**

​	设置面域所在图层，如果图层ID非法，则不做任何改变。

**public boolean isObstacle()**

​	获取面域是否为障碍物。

**public void setObstacle(boolean b)**

​	设置面域是否为障碍物。

**public boolean isBoardingArea()**

​	获取面域是否为上客区域。

**public void setIsBoardingArea(boolean b)**

​	设置面域是否为上客区域。

**public boolean isAlightingArea()**

​	获取面域是否为下客区域。

**public void setIsAlightingArea(boolean b)**

​	设置面域是否为下客区域。

#### 3.4.9.8.扇形行人面域（IPedestrianFanShapeRegion）

**public long getId()**

​	获取面域ID。

**public String getName()**

​	获取面域名称。

**public void setName(String name)**

​	设置面域名称。

**public Color getRegionColor()**

​	获取面域颜色。

**public void setRegionColor(Color color)**

​	设置面域颜色。

**public Point getPosition(UnitOfMeasure unit)**

​	获取面域位置。单位：像素。

**public void setPosition(Point scenePos, UnitOfMeasure unit)**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**public int getGType()**

​	获取面域类型。

**public double getExpectSpeedFactor()**

​	获取期望速度系数。

**public void setExpectSpeedFactor(double val)**

​	设置期望速度系数。

**public double getElevation()**

​	获取面域高程。

**public void setElevation(double elevation)**

​	设置面域高程。

**public Vector\<Point\> getPolygon()**

​	获取面域多边形。

**public long getLayerId()**

​	获取面域所在图层ID。

**public void setLayerId(long id)**

​	设置面域所在图层，如果图层ID非法，则不做任何改变。

**public boolean isObstacle()**

​	获取面域是否为障碍物。

**public void setObstacle(boolean b)**

​	设置面域是否为障碍物。

**public boolean isBoardingArea()**

​	获取面域是否为上客区域。

**public void setIsBoardingArea(boolean b)**

​	设置面域是否为上客区域。

**public boolean isAlightingArea()**

​	获取面域是否为下客区域。

**public void setIsAlightingArea(boolean b)**

​	设置面域是否为下客区域。

**public double getInnerRadius()**

​	获取内半径，单位: 米。

**public double getOuterRadius()**

​	获取外半径，单位: 米。

**public double getStartAngle()**

​	获取起始角度，单位: 度。

**public double getSweepAngle()**

​	获取扫过角度，单位: 度。

#### 3.4.9.9.多边形行人面域（IPedestrianPolygonRegion）

**public long getId()**

​	获取面域ID。

**public String getName()**

​	获取面域名称。

**public void setName(String name)**

​	设置面域名称。

**public Color getRegionColor()**

​	获取面域颜色。

**public void setRegionColor(Color color)**

​	设置面域颜色。

**public Point getPosition(UnitOfMeasure unit)**

​	获取面域位置。单位：像素。

**public void setPosition(Point scenePos, UnitOfMeasure unit)**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**public int getGType()**

​	获取面域类型。

**public double getExpectSpeedFactor()**

​	获取期望速度系数。

**public void setExpectSpeedFactor(double val)**

​	设置期望速度系数。

**public double getElevation()**

​	获取面域高程。

**public void setElevation(double elevation)**

​	设置面域高程。

**public Vector\<Point\> getPolygon()**

​	获取面域多边形。

**public long getLayerId()**

​	获取面域所在图层ID。

**public void setLayerId(long id)**

​	设置面域所在图层，如果图层ID非法，则不做任何改变。

**public boolean isObstacle()**

​	获取面域是否为障碍物。

**public void setObstacle(boolean b)**

​	设置面域是否为障碍物。

**public boolean isBoardingArea()**

​	获取面域是否为上客区域。

**public void setIsBoardingArea(boolean b)**

​	设置面域是否为上客区域。

**public boolean isAlightingArea()**

​	获取面域是否为下客区域。

**public void setIsAlightingArea(boolean b)**

​	设置面域是否为下客区域。

#### 3.4.9.10.人行道行人面域（IPedestrianSIDeWalkRegion）

**public long getId()**

​	获取面域ID。

**public String getName()**

​	获取面域名称。

**public void setName(String name)**

​	设置面域名称。

参数: 

​	[ in ] name: 新名称。

**public Color getRegionColor()**

​	获取面域颜色。

**public void setRegionColor(Color color)**

​	设置面域颜色。

参数: 

​	[ in ] color: 面域颜色。

**public Point getPosition(UnitOfMeasure unit)**

​	获取面域位置。单位：像素。

**public void setPosition(Point scenePos, UnitOfMeasure unit)**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**public int getGType()**

​	获取面域类型。

**public double getExpectSpeedFactor()**

​	获取期望速度系数。

**public void setExpectSpeedFactor(double val)**

​	设置期望速度系数。

**public double getElevation()**

​	获取面域高程。

**public void setElevation(double elevation)**

​	设置面域高程。

**public Vector\<Point\> getPolygon()**

​	获取面域多边形。

**public long getLayerId()**

​	获取面域所在图层ID。

**public void setLayerId(long id)**

​	设置面域所在图层，如果图层ID非法，则不做任何改变。

参数: 

​	[ in ] id: 图层ID。

**public double getWidth()**

​	获取人行道宽度。

**public void setWidth(double width)**

​	设置人行道宽度。

参数: 

​	[ in ] width: 人行道宽度，单位: m。

**public ArrayList\<QGraphicsEllipseItem\> getVetexs()**

​	获取人行道顶点，即初始折线顶点。

**public ArrayList\<QGraphicsEllipseItem\> getControl1Vetexs()**

​	获取人行道贝塞尔曲线控制点P1。

**public ArrayList\<QGraphicsEllipseItem\> getControl2Vetexs()**

​	获取人行道贝塞尔曲线控制点P2。

**public ArrayList\<QGraphicsEllipseItem\> getCandidateVetexs()**

​	获取候选顶点。

**public void removeVetex(int index)**

​	删除第index个顶点。

参数: 

​	[ in ] index: 顶点索引。

**public void insertVetex(Point pos, int index)**

​	在第index个位置插入顶点，初始位置为pos。

参数: 

​	[ in ] pos: 顶点位置。

​	[ in ] index: 插入位置。

#### 3.4.9.11.人行横道行人面域（IPedestrianCrossWalkRegion）

**public long getId()**

​	获取面域ID。

**public String getName()**

​	获取面域名称。

**public void setName(String name)**

​	设置面域名称。

参数: 

​	[ in ] name: 新名称。

**public Color getRegionColor()**

​	获取面域颜色。

**public void setRegionColor(Color color)**

​	设置面域颜色。

参数: 

​	[ in ] color: 面域颜色。

**public Point getPosition(UnitOfMeasure unit)**

​	获取面域位置。单位：像素。

**public void setPosition(Point scenePos, UnitOfMeasure unit)**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**public int getGType()**

​	获取面域类型。

**public double getExpectSpeedFactor()**

​	获取期望速度系数。

**public void setExpectSpeedFactor(double val)**

​	设置期望速度系数。

**public double getElevation()**

​	获取面域高程。

**public void setElevation(double elevation)**

​	设置面域高程。

**public Vector\<Point\> getPolygon()**

​	获取面域多边形。

**public long getLayerId()**

​	获取面域所在图层ID。

**public void setLayerId(long id)**

​	设置面域所在图层，如果图层ID非法，则不做任何改变。

**public double getWidth()**

​	获取人行横道宽度，单位: 米。

**public void setWidth(double width)**

​	设置人行横道宽度，单位: 米。

**public QLineF getSceneLine(UnitOfMeasure unit)**

​	获取人行横道起点到终点的线段，场景坐标系下。单位：像素。

**public double getAngle()**

​	获取人行横道倾斜角度。

**public void setAngle(double angle)**

​	设置人行横道倾斜角度。

**public double getRedLightSpeedFactor()**

​	获取红灯清尾速度系数。

**public void setRedLightSpeedFactor(double factor)**

​	设置红灯清尾速度系数。

**public Vector2D getUnitDirectionFromStartToEnd()**

​	获取场景坐标系下从起点到终点的单位方向向量。

**public Vector2D getLocalUnitDirectionFromStartToEnd()**

​	获取人行横道本身坐标系下从起点到终点的单位方向。

**public QGraphicsEllipseItem getStartControlPoint()**

​	获取起点控制点。

**public QGraphicsEllipseItem getEndControlPoint()**

​	获取终点控制点。

**public QGraphicsEllipseItem getLeftControlPoint()**

​	获取左侧控制点。

**public QGraphicsEllipseItem getRightControlPoint()**

​	获取右侧控制点。

**public ICrosswalkSignalLamp getPositiveDirectionSignalLamp()**

​	获取管控正向通行的信号灯。

**public ICrosswalkSignalLamp getNegativeDirectionSignalLamp()**

​	获取管控反向通行的信号灯。

**public boolean isPositiveTrafficLightAdded()**

​	判断是否添加了管控正向通行的信号灯。

**public boolean isReverseTrafficLightAdded()**

​	判断是否添加了管控反向通行的信号灯。

#### 3.4.9.12.楼梯行人面域（IPedestrianStairRegion）

**public long getId()**

​	获取面域ID。

**public String getName()**

​	获取面域名称。

**public void setName(String name)**

​	设置面域名称。

**public Color getRegionColor()**

​	获取面域颜色。

**public void setRegionColor(Color color)**

​	设置面域颜色。

**public Point getPosition(UnitOfMeasure unit)**

​	获取面域位置。单位：像素。

**public void setPosition(Point scenePos, UnitOfMeasure unit)**

​	设置面域位置。单位：像素。

参数: 

​	[ in ] scenePos: 场景坐标系下的位置。

**public int getGType()**

​	获取面域类型。

**public double getWidth()**

​	获取楼梯宽度，单位: m。

**public void setWidth(double width)**

​	设置楼梯宽度，单位: m。

**public Point getStartPoint()**

​	获取起始点，场景坐标系下。

**public Point getEndPoint()**

​	获取终止点，场景坐标系下。

**public double getStartConnectionAreaLength()**

​	获取起始衔接区域长度，单位: m。

**public double getEndConnectionAreaLength()**

​	获取终止衔接区域长度，单位: m。

**public Point getStartRegionCenterPoint()**

​	获取起始衔接区域中心，场景坐标系下。

**public Point getEndRegionCenterPoint()**

​	获取终止衔接区域中心，场景坐标系下。

**public QPainterPath getStartSceneRegion()**

​	获取起始衔接区域形状，场景坐标系下。

**public QPainterPath getEndSceneRegion()**

​	获取终止衔接区域形状，场景坐标系下。

**public QPainterPath getMainQueueRegion()**

​	获取楼梯主体形状，场景坐标系下。

**public QPainterPath getFullQueueregion()**

​	获取楼梯整体形状，场景坐标系下。

**public Vector\<Point\> getMainQueuePolygon()**

​	获取楼梯主体多边形，场景坐标系下。

**public StairType getStairType()**

​	获取楼梯类型。

**public void setStairType(StairType type)**

​	设置楼梯类型。

**public long getStartLayerId()**

​	获取起始层级。

**public void setStartLayerId(long id)**

​	设置起始层级。

**public long getEndLayerId()**

​	获取终止层级。

**public void setEndLayerId(long id)**

​	设置终止层级。

**public double getTransmissionSpeed()**

​	获取传送速度，单位: m/s。

**public void setTransmissionSpeed(double speed)**

​	设置传送速度，单位: m/s。

**public double getHeadroom()**

​	获取楼梯净高。

**public void setHeadroom(double headroom)**

​	设置楼梯净高。

**public QGraphicsEllipseItem getStartControlPoint()**

​	获取起点控制点。

**public QGraphicsEllipseItem getEndControlPoint()**

​	获取终点控制点。

**public QGraphicsEllipseItem getLeftControlPoint()**

​	获取左侧控制点。

**public QGraphicsEllipseItem getRightControlPoint()**

​	获取右侧控制点。

**public QGraphicsEllipseItem getStartConnectionAreaControlPoint()**

​	获取起始衔接区域长度控制点。

**public QGraphicsEllipseItem getEndConnectionAreaControlPoint()**

​	获取终止衔接区域长度控制点。

#### 3.4.9.13.行人路径（IPedestrianPath）

**public long getId()**

​	获取行人路径ID。

**public IPedestrianPathPoint getPathStartPoint()**

​	获取行人路径起始点。

**public IPedestrianPathPoint getPathEndPoint()**

​	获取行人路径终点。

**public ArrayList\<IPedestrianPathPoint\> getPathMiddlePoints()**

​	获取行人路径中间点。

**public boolean isLocalPath()**

​	判断是否是局部路径。

#### 3.4.9.14.行人路径点（IPedestrianPathPoint）

**public long getId()**

​	获取行人路径点ID。

**public Point getScenePos(UnitOfMeasure unit)**

​	获取行人路径点场景坐标系下的位置。单位：像素。

**public double getRadius()**

​	获取行人路径点的半径，单位: m。

#### 3.4.9.15.人行横道信号灯（ICrosswalkSignalLamp）

**public long id()**

​	获取信号灯ID。

**public void setSignalPhase(ISignalPhase pPhase)**

​	设置相位，所设相位可以是其它信号灯组的相位。

**public void setPhaseNumber(int num)**

​	设置相位序号，序号从1开始，如果num序号大于相位总数不进行设置。

**public void setLampColor(String colorStr)**

​	设置信号灯颜色。

参数: 

​	[ in ] colorStr: 字符串表达的颜色，有四种可选，分别是"红"、"绿"、"黄"、"灰"，，或者是"R"、"G"、"Y"、"gray"。 

**public String color()**

​	获取信号灯色，"R"、“G”、“Y”、“gray”分别表示"红"、"绿"、"黄"、"灰"。

**public String name()**

​	获取信号灯名称。

**public void setName(String name)**

​	设置信号灯名称。

**public void setDistToStart(double dist, UnitOfMeasure unit)**

​	设置信号灯距路段起点距离。单位：像素。

参数: 

​	[ in ] dist: 距离值。

**public ISignalPlan signalPlan()**

​	获取信控方案。

**public ISignalPhase signalPhase()**

​	获取相位。

**public ILaneObject laneObject()**

​	获取所在车道或车道连接。

**public Vector\<Point\> polygon()**

​	获取信号灯多边型轮廓的顶点。

**public double angle()**

​	获取信号灯角度。

**public IPedestrianCrossWalkRegion getICrossWalk()**

​	获取所属人行横道。

### 3.4.10.停车场模块

#### 3.4.10.1.停车位（IParkingStall）

**public long id()**

​	获取停车位ID。

**public long parkingRegionId()**

​	获取所属停车区域ID。

**public IParkingRegion parkingRegion()**

​	获取所属停车区域。

**public double distance()**

​	获取距路段起始位置，单位: m。

**public int stallType()**

​	获取车位类型，与车辆类型编码一致。

#### 3.4.10.2.停车区域（IParkingRegion）

**public long id()**

​	获取停车区域ID。

**public String name()**

​	获取停车区域名称。

**public void setName(String name)**

​	设置停车区域名称。

参数: 

​	[ in ] name: 新名称。

**public ArrayList\<IParkingStall\> parkingStalls()**

​	获取所有停车位。

**public DynaParkingRegion dynaParkingRegion()**

​	获取动态停车区域信息。

#### 3.4.10.3.停车路径决策点（IParkingDecisionPoint）

**public long id()**

​	获取停车决策点ID。

**public String name()**

​	获取停车决策点名称。

**public ILink link()**

​	获取停车决策点所在路段。

**public double distance()**

​	获取停车决策点距路段起点距离，单位: m。

**public ArrayList\<IParkingRouting\> routings()**

​	获取相关停车路径。

**public boolean updateParkDisInfo(ArrayList\<DynaParkDisInfo\> tollDisInfoList)**

​	更新停车分配信息。

参数: 

​	[ in ] tollDisInfoList: 停车分配信息列表。

**public ArrayList\<DynaParkDisInfo\> parkDisInfoList()**

​	获取停车分配信息列表。

**public Vector\<Point\> polygon()**

​	获取停车决策点多边型轮廓。

#### 3.4.10.4.停车路径（IParkingRouting）

**public long id()**

​	获取路径ID。

**public long parkingDeciPointId()**

​	获取所属决策点ID。

**public long parkingRegionId()**

​	路径到达的停车区域id。

**public double calcuLength()**

​	计算路径长度。

**public boolean contain(ISection pRoad)**

​	通过所给道路判断是否在当前路径上。

参数: 

​	[ in ] pRoad: 路段或连接段。

**public ISection nextRoad(ISection pRoad)**

​	通过所给道路求下一条道路。

参数: 

​	[ in ] pRoad: 路段或连接段。

**public ArrayList\<ILink\> getLinks()**

​	获取路段序列。

### 3.4.11.收费站模块

#### 3.4.11.1.收费点（ITollPoint）

**public long id()**

​	获取收费点ID。

**public double distance()**

​	获取距路段起始位置，单位: m。

**public long tollLaneId()**

​	获取所属收费车道ID。

**public ITollLane tollLane()**

​	获取所属收费车道。

**public boolean isEnabled()**

​	获取是否启用。

**public boolean setEnabled(boolean enabled)**

​	设置启用状态。

参数: 

​	[ in ] enabled: 是否启用。

**public int tollType()**

​	获取收费类型。

**public boolean setTollType(int tollType)**

​	设置收费类型。

参数: 

​	[ in ] tollType: 收费类型。

**public int timeDisId()**

​	获取停车时间分布ID。

**public boolean setTimeDisId(int timeDisId)**

​	设置停车时间分布ID。

参数: 

​	[ in ] timeDisId: 时间分布ID。

#### 3.4.11.2.收费车道（ITollLane）

**public long id()**

​	获取收费车道ID。

**public String name()**

​	获取收费车道名称。

**public double distance()**

​	获取距路段起始位置，单位: m。

**public void setName(String name)**

​	设置收费车道名称。

参数: 

​	[ in ] name: 收费车道新名称。

**public void setWorkTime(long startTime, long endTime)**

​	设置工作时间，工作时间与仿真时间对应。

参数: 

​	[ in ] startTime: 开始时间。单位：s。

​	[ in ] endTime: 结束时间。单位：s。

**public DynaTollLane dynaTollLane()**

​	获取动态收费车道信息。

**public ArrayList\<ITollPoint\> tollPoints()**

​	获取收费车道所有收费点。

#### 3.4.11.3.收费决策点（ITollDecisionPoint）

**public long id()**

​	获取收费决策点ID。

**public String name()**

​	获取收费决策点名称。

**public ILink link()**

​	获取收费决策点所在路段。

**public double distance()**

​	获取距路段起点距离，单位: m。

**public ArrayList\<ITollRouting\> routings()**

​	获取相关收费路径。

**public ArrayList\<DynaTollDisInfo\> tollDisInfoList()**

​	获取收费分配信息列表。

**public void updateTollDisInfoList(ArrayList\<DynaTollDisInfo\> tollDisInfoList)**

​	更新收费分配信息列表。

参数: 

​	[ in ] tollDisInfoList: 收费分配信息列表。

**public Vector\<Point\> polygon()**

​	获取收费决策点多边型轮廓。

#### 3.4.11.4.收费路径（ITollRouting）

**public long id()**

​	获取路径ID。

**public long tollDeciPointId()**

​	获取所属收费决策点ID。

**public long tollLaneId()**

​	路径到达的收费区域id。

**public double calcuLength()**

​	计算路径长度。

**public boolean contain(ISection pRoad)**

​	通过所给道路判断是否在当前路径上。

参数: 

​	[ in ] pRoad: 路段或连接段。

**public ISection nextRoad(ISection pRoad)**

​	通过所给道路求下一条道路。

参数: 

​	[ in ] pRoad: 路段或连接段。

**public ArrayList\<ILink\> getLinks()**

​	获取路段序列。

### 3.4.12.节点模块

#### 3.4.12.1.节点（IJunction）

**public long getId()**

​	获取节点ID。

**public String name()**

​	获取节点名称。

**public void setName(String strName)**

​	设置节点名称。

参数: 

​	[ in ] strName: 新名称。

**public ArrayList\<ILink\> getJunctionLinks()**

​	获取节点内的路段。

**public ArrayList\<IConnector\> getJunctionConnectors()**

​	获取节点内的连接段。

**public ArrayList\<TurnningBaseInfo\> getAllTurnningInfo()**

​	获取节点内所有流向信息。

**public TurnningBaseInfo getTurnningInfo(long turningId)**

​	获取节点内指定流向信息。

### 3.4.13.车辆与行人

#### 3.4.13.1.车辆（IVehicle）

​	车辆接口，用于访问、控制车辆。通过此接口可以读取车辆属性，设置车辆部分属性，仿真过程读取当前道路情况、车辆前后左右相邻车辆及与它们的距离等。

**public long id()**

​	车辆ID，车辆ID的组成方式为 x * 100000 + y，每个发车点的x值不一样，从1开始递增，y是每个发车点所发车辆序号，从1开始递增。第一个发车点所发车辆ID从100001开始递增，第二个发车点所发车辆ID从200001开始递增。

**public ILink startLink()**

​	车辆进入路网时起始路段。

**public long startSimuTime()**

​	车辆进入路网时起始时间。

**public long roadId()**

​	车辆所在路段或连接段ID。

**public void road()**

​	道路，如果在路段上返回ILink，如果在连接段上返回IConnector。

**public ISection section()**

​	车辆所在的Section，即路段或连接段。

**public ILaneObject laneObj()**

​	车辆所在的车道或车道连接。

**public int segmIndex()**

​	车辆在当前LaneObject上分段序号。

**public boolean roadIsLink()**

​	车辆所在道路是否路段。

**public String roadName()**

​	道路名。

**public double initSpeed(double speed, UnitOfMeasure unit)**

​	初始化车速。

参数: 

​	[ in ] speed: 初始速度值。单位: 像素/s。

**public void initLane(int laneNumber, double dist, double speed, UnitOfMeasure unit)**

​	在路段上初始化车辆。

参数: 

​	[ in ] laneNumber: 车道序号。

​	[ in ] dist: 距起点距离，单位: 像素。

​	[ in ] speed: 初始速度，单位: 像素/s。

**public void initLaneConnector(int laneNumber, int toLaneNumber, double dist, double speed, UnitOfMeasure unit)**

​	在连接段上初始化车辆。单位：像素。

参数: 

​	[ in ] laneNumber: 起始车道序号。

​	[ in ] toLaneNumber: 目标车道序号。

​	[ in ] dist: 距起点距离，单位: 像素。

​	[ in ] speed: 初始速度，单位: 像素/s。

**public void setVehiType(int code)**

​	设置车辆类型，车辆被创建时已确定了类型，通过此方法可以改变车辆类型。

参数: 

​	[ in ] code: 车辆类型编码。

**public void setColor(String color)**

​	设置车辆颜色。

参数: 

​	[ in ] color: 颜色RGB，如: "#EE0000"。

示例：

```java
// 设置车辆颜色为蓝色
vehicle.setColor("#00AFF0");
```

**public double length(UnitOfMeasure unit)**

​	获取车辆长度。单位：像素。

**public void setLength(double len, boolean bRestWidth, UnitOfMeasure unit)**

​	设置车辆长度。单位：像素。

参数: 

​	[ in ] len: 长度值，单位: 像素或米(取决于unit参数)。

​	[ in ] bRestWidth: 是否同比例约束宽度。

**public long laneId()**

​	如果toLaneId() 小于等于0，那么laneId()获取的是当前所在车道ID，如果toLaneId()大于0，则车辆在车道连接上，laneId()获取的是上游车道ID。

**public long toLaneId()**

​	下游车道ID。如果小于等于0，车辆在路段的车道上，否则车辆在连接段的车道连接上。

**public ILane lane()**

​	获取当前车道，如果车辆在车道连接上，获取的是车道连接的上游车道。

**public ILane toLane()**

​	如果车辆在车道连接上，返回车道连接的下游车道，如果当前不在车道连接上，返回null。

**public ILaneConnector laneConnector()**

​	获取当前车道连接，如果在车道上，返回null。

**public long currBatchNumber()**

​	当前仿真计算批次。

**public int roadType()**

​	车辆所在道路类型。GLinkType代表路段、GConnectorType代表连接段。

**public double limitMaxSpeed(UnitOfMeasure unit)**

​	获取最大限速，单位: 像素/s。

**public double limitMinSpeed(UnitOfMeasure unit)**

​	获取最小限速，单位: 像素/s。

**public long vehicleTypeCode()**

​	车辆类型编码。

**public String vehicleTypeName()**

​	获取车辆类型名，如"小客车"。

**public String name()**

​	获取车辆名称。

**public IVehicleDriving vehicleDriving()**

​	获取车辆驾驶行为接口。

**public void driving()**

​	驱动车辆。在每个运算周期，每个在运行的车辆被调用一次该方法。

**public Point pos(UnitOfMeasure unit)**

​	获取当前位置。单位：像素。

**public double zValue(UnitOfMeasure unit)**

​	获取当前高程。单位：像素。

**public double acce(UnitOfMeasure unit)**

​	获取当前加速度。单位：像素。

**public double currSpeed(UnitOfMeasure unit)**

​	获取当前速度，单位: 像素/s。

**public double angle()**

​	当前角度，北向0度顺时针。

**public boolean isStarted()**

​	是否在运行，如果返回false，表明车辆已驰出路网或尚未上路。

**public IVehicle vehicleFront()**

​	前车对象。

**public IVehicle vehicleRear()**

​	后车对象。

**public IVehicle vehicleLFront()**

​	左前车对象。

**public IVehicle vehicleLRear()**

​	左后车对象。

**public IVehicle vehicleRFront()**

​	右前车对象。

**public IVehicle vehicleRRear()**

​	右后车对象。

**public double vehiDistFront(UnitOfMeasure unit)**

​	获取与前车距离。单位：像素。

**public double vehiSpeedFront(UnitOfMeasure unit)**

​	获取前车速度，单位: 像素/s。

**public double vehiHeadwayFront(UnitOfMeasure unit)**

​	获取与前车时距，单位: 秒。

**public double vehiDistRear(UnitOfMeasure unit)**

​	获取与后车距离。单位：像素。

**public double vehiSpeedRear(UnitOfMeasure unit)**

​	获取后车速度，单位: 像素/s。

**public double vehiHeadwaytoRear(UnitOfMeasure unit)**

​	获取与后车时距，单位: 秒。

**public double vehiDistLLaneFront(UnitOfMeasure unit)**

​	获取与左前车距离。单位：像素。

**public double vehiSpeedLLaneFront(UnitOfMeasure unit)**

​	获取左前车速度。单位：像素。

**public double vehiDistLLaneRear(UnitOfMeasure unit)**

​	获取与左后车距离。单位：像素。

**public double vehiSpeedLLaneRear(UnitOfMeasure unit)**

​	获取左后车速度。单位：像素。

**public double vehiDistRLaneFront(UnitOfMeasure unit)**

​	获取与右前车距离。单位：像素。

**public double vehiSpeedRLaneFront(UnitOfMeasure unit)**

​	获取右前车速度。单位：像素。

**public double vehiDistRLaneRear(UnitOfMeasure unit)**

​	获取与右后车距离。单位：像素。

**public double vehiSpeedRLaneRear(UnitOfMeasure unit)**

​	获取右后车速度。单位：像素。

**public void setDynaInfo(void pDynaInfo)**

​	设置动态信息。

**public void dynaInfo()**

​	获取动态信息。

**public ArrayList\<Point\> lLaneObjectVertex(UnitOfMeasure unit)**

​	获取车道或车道连接中心线内点集。单位：像素。

**public IRouting routing()**

​	当前路径。

**public QPicture picture()**

​	获取车辆图片。

**public Vector\<Point\> boundingPolygon()**

​	获取车辆由方向和长度决定的四个拐角构成的多边型。

**public void setTag(long tag)**

​	设置标签表示的状态。

**public long tag()**

​	获取标签表示的状态。

**public void setTextTag(String text)**

​	设置文本信息，用于在运行过程保存临时信息，方便开发。

**public String textTag()**

​	文本信息，运行过程临时保存的信息，方便开发。

**public void setJsonInfo(JsonObject info)**

​	设置json格式数据。

**public JsonObject jsonInfo()**

​	返回json格式数据。

**public QVariant jsonProperty(String propName)**

​	返回json字段值。

**public void setJsonProperty(String key, QVariant value)**

​	设置json数据属性。

#### 3.4.13.2.车辆驾驶行为（IVehicleDriving）

​	车辆驾驶行为接口，通过此接口可以控制车辆的左右变道、设置车辆角度，对车辆速度、坐标位置等进行控制等。**在获取车辆对象 `vehicle` 后，通过`vehicle.vehicleDriving().xxx()` 的方式调用。**

**public IVehicle vehicle()**

​	当前驾驶车辆。

**public long getRandomNumber()**

​	获取随机数。

**public boolean nextPoint()**

​	计算下一点位置，过程包括计算车辆邻车关系、公交车是否进站是否出站、是否变道、加速度、车速、移动距离、跟驰类型、轨迹类型等。

**public long zeroSpeedInterval()**

​	当前车速为零持续时间。单位：ms。

**public boolean isHavingDeciPointOnLink()**

​	当前是否在路段上且有决策点。

**public int followingType()**

​	跟驰车辆的类型，即当前车辆前车的类型，分为: 0: 停车，1: 正常，5: 急减速，6: 急加速，7: 汇入，8: 穿越，9: 协作减速，10: 协作加速，11: 减速待转，12: 加速待转。

**public boolean isOnRouting()**

​	当前是否在路径上。

**public void stopVehicle()**

​	停止运行，将车辆移出路网。

**public double angle()**

​	旋转角。单位：角度。北向0度，顺时针。

**public void setAngle(double angle)**

​	设置车辆旋转角。

参数: 

​	[ in ] angle: 旋转角，一周360度。

**public Vector3D euler(boolean bPositive)**

​	返回车辆欧拉角。

参数: 

​	[ in ] bPositive: 车头方向是否正向计算，如果bPosiDire为false则反向计算。

**public double desirSpeed(UnitOfMeasure unit)**

​	获取期望速度，单位: 像素/s。

**public ISection getCurrRoad()**

​	返回当前所在路段或连接段。

**public ISection getNextRoad()**

​	下一路段或连接段。

**public int differToTargetLaneNumber()**

​	与目标车道序号的差值，不等于0表示有强制变道意图，大于0有左变道意图，小于0有右变道意图，绝对值大于0表示需要强制变道次数。

**public void toLeftLane(boolean bFource)**

​	左变道。

参数: 

​	[ in ] bFource: 是否强制変道，默认为false。

示例：

```java
// 控制车辆向左变道
vehicle.vehicleDriving().toLeftLane();
```

**public void toRightLane(boolean bFource)**

​	右变道。

参数: 

​	[ in ] bFource: 是否强制変道，默认为false。

示例：

```java
// 控制车辆向右变道
vehicle.vehicleDriving().toRightLane();
```

**public int laneNumber()**

​	当前车道序号，最右侧序号为0。

**public void initTrace()**

​	初始化轨迹。

**public void setTrace(ArrayList\<Point\> lPoint, UnitOfMeasure unit)**

​	设置轨迹点集。单位：像素。

参数: 

​	[ in ] lPoint: 轨迹点坐标集合。

**public void calcTraceLength()**

​	计算轨迹长度。

**public int tracingType()**

​	返回轨迹类型，分为: 0: 跟驰，1: 左变道，2: 右变道，3: 左虚拟変道，4: 右虚拟变道，5: 左转待转，6: 右转待转，7: 入湾，8: 出湾。

**public void setTracingType(int type)**

​	设置轨迹类型。

**public void setLaneNumber(int number)**

​	设置当前车道序号。

参数: 

​	[ in ] number: 车道序号。

**public double currDistanceInRoad(UnitOfMeasure unit)**

​	获取当前路段或连接段已行驶距离。单位：像素。

**public void setCurrDistanceInRoad(double dist, UnitOfMeasure unit)**

​	设置当前路段或连接段已行驶距离。单位：像素。

参数: 

​	[ in ] dist: 距离。

**public void setVehiDrivDistance(double dist, UnitOfMeasure unit)**

​	设置已行驶总里程。单位：像素。

参数: 

​	[ in ] dist: 总里程。

**public double getVehiDrivDistance(UnitOfMeasure unit)**

​	获取已行驶总里程。单位：像素。

**public double currDistanceInSegment(UnitOfMeasure unit)**

​	获取当前分段已行驶距离。单位：像素。

**public void setCurrDistanceInSegment(double dist, UnitOfMeasure unit)**

​	设置当前分段已行驶距离。单位：像素。

参数: 

​	[ in ] dist: 距离。

**public void setSegmentIndex(int index)**

​	设置分段序号。

**public void setCurrDistanceInTrace(double dist, UnitOfMeasure unit)**

​	设置曲化轨迹上行驶的距离。单位：像素。

参数: 

​	[ in ] dist: 距离。

**public void setX(double posX, UnitOfMeasure unit)**

​	设置横坐标。单位：像素。

参数: 

​	[ in ] posX: 横坐标。

**public void setY(double posY, UnitOfMeasure unit)**

​	设置纵坐标。单位：像素。

参数: 

​	[ in ] posY: 纵坐标。

**public void setV3z(double v3z, UnitOfMeasure unit)**

​	设置高程坐标。单位：像素。

参数: 

​	[ in ] v3z: 高程坐标。

**public ArrayList\<Point\> changingTrace(UnitOfMeasure unit)**

​	获取变轨点集。单位：像素。

**public double changingTraceLength(UnitOfMeasure unit)**

​	获取变轨长度。单位：像素。

**public double distToStartPoint(boolean fromVehiHead, boolean bOnCentLine, UnitOfMeasure unit)**

​	获取在车道或车道连接上到起点距离。单位：像素。

参数: 

​	[ in ] fromVehiHead: 是否从车头计算。

​	[ in ] bOnCentLine: 当前是否在中心线上。

**public double distToEndpoint(boolean fromVehiHead, boolean bOnCentLine, UnitOfMeasure unit)**

​	获取在车道或车道连接上到终端距离。单位：像素。

参数: 

​	[ in ] fromVehiHead: 是否从车头计算。

​	[ in ] bOnCentLine: 当前是否在中心线上。

**public boolean setRouting(IRouting pRouting)**

​	设置路径，外界设置的路径不一定有决策点，可能是临时创建的，如果车辆不在此路径上则设置不成功并返回false。

示例：

```java
// 1. 使用现有的决策点的车辆路径
IRouting routing1 = netiface.findRouting(1);
vehicle.vehicleDriving().setRouting(routing1);

// 2. 创建不与决策点绑定的车辆路径
ArrayList<Integer> linkIdList = new ArrayList<>(Arrays.asList(8, 16, 25));
ArrayList<ILink> linkList = new ArrayList<>();
for (int linkId : linkIdList) {
    linkList.add(netiface.findLink(linkId));
}
IRouting routing2 = netiface.createRouting(linkList);
vehicle.vehicleDriving().setRouting(routing2);
```

**public IRouting routing()**

​	当前路径。

**public boolean moveToLane(ILane pLane, double dist, UnitOfMeasure unit)**

​	将车辆移到另一条车道上。单位：像素。

参数: 

​	[ in ] pLane: 目标车道。

​	[ in ] dist: 到目标车道起点距离。

**public boolean moveToLaneConnector(ILaneConnector pLaneConnector, double dist, UnitOfMeasure unit)**

​	将车辆移到另一条车道连接上。单位：像素。

参数: 

​	[ in ] pLaneConnector: 目标车道连接。

​	[ in ] dist: 到目标车道连接起点距离。

**public boolean move(ILaneObject pILaneObject, double dist, UnitOfMeasure unit)**

​	移动车辆到另一条车道或车道连接上。单位：像素。

参数: 

​	[ in ] pILaneObject: 目标车道或车道连接。

​	[ in ] dist: 到目标起点距离。

示例：

```java
// 获取车道对象
lane = netiface.findLane(6);
// 位置，单位：m
dist = 50;
// 移动车辆到指定车道和位置上，实现车辆位置的瞬移
vehicle.vehicleDriving().move(lane, dist, UnitOfMeasure.Metric);
```

#### 3.4.13.3.行人（IPedestrian）

**public long getId()**

​	获取行人ID。

**public double getRadius()**

​	获取行人半径，单位: m。

**public double getWeight()**

​	获取行人质量，单位: kg。

**public String getColor()**

​	获取行人颜色，RGB格式，如: "#EE0000"。

**public Point getPos()**

​	获取行人当前位置，单位: m。

**public double getAngle()**

​	获取行人当前角度，Qt坐标系下，x轴正方向为0，逆时针为正。

**public Vector2D getDirection()**

​	获取行人当前二维方向向量。

**public double getElevation()**

​	获取行人当前高程，单位: m。

**public Vector2D getSpeed()**

​	获取行人当前速度，单位: m/s。

**public double getDesiredSpeed()**

​	获取行人期望速度，单位: m/s。

**public double getMaxSpeed()**

​	获取行人最大速度限制，单位: m/s。

**public Vector2D getAcce()**

​	获取行人当前加速度，单位: m/s²。

**public double getMaxAcce()**

​	获取行人最大加速度限制，单位: m/s²。

**public Vector3D getEuler()**

​	获取行人欧拉角。

**public Vector3D getSpeedEuler()**

​	获取行人速度欧拉角。

**public Vector2D getWallFDirection()**

​	获取墙壁方向单位向量。

**public IPedestrianRegion getRegion()**

​	获取行人当前所在面域。

**public long getPedestrianTypeId()**

​	获取行人类型ID。

**public void stop()**

​	停止仿真，会在下一个仿真批次移除当前行人，释放资源。

<div style="page-break-after: always;"></div>

# 4.高频接口

​	本节提供 TESS NG 二次开发经常使用的接口代码案例。



## 4.1.路网建模

### 4.1.1.创建路段和连接段

​	创建路段和连接段的代码如下。**此外，开源路网编辑工具 pytessng （使用TESS NG Python 二次开发实现）支持支持导入 OpenDrive、shape、OpenStreetMap 等格式的数据来创建路网，具体使用方法可参考 [pytessng · PyPI](https://pypi.org/project/pytessng/)。**

```java
// ==================== 创建路段 ====================
// 创建第一条路段：曹安公路
Point startPoint1 = new Point(-300, 0);
Point endPoint1 = new Point(300, 0);
ArrayList<Point> linkPoints1 = new ArrayList<>(Arrays.asList(startPoint1, endPoint1));
ILink link1 = netiface.createLink(linkPoints1, 7, "曹安公路", true, UnitOfMeasure.Metric);
if (link1 != null) {
    // 车道列表（转换为ArrayList）
    ArrayList<ILane> lanes1 = new ArrayList<>(link1.lanes());
    // 打印该路段所有车道ID
    System.out.print("曹安公路车道ID列表：");
    for (ILane lane : lanes1) {
        System.out.print(lane.id() + " ");
    }
    System.out.println();
    // 在当前路段创建发车点
    IDispatchPoint dp1 = netiface.createDispatchPoint(link1);
    if (dp1 != null) {
        // 设置发车间隔，含车型组成、时间间隔、发车数
        dp1.addDispatchInterval(1, 2, 28);
    }
}

// 创建第二条路段
Point startPoint2 = new Point(-300, -25);
Point endPoint2 = new Point(300, -25);
ArrayList<Point> linkPoints2 = new ArrayList<>(Arrays.asList(startPoint2, endPoint2));
ILink link2 = netiface.createLink(linkPoints2, 7, "次干道", true, UnitOfMeasure.Metric);
if (link2 != null) {
    // 在当前路段创建发车点
    IDispatchPoint dp2 = netiface.createDispatchPoint(link2);
    if (dp2 != null) {
        dp2.addDispatchInterval(1, 3600, 3600);
    }
    // 将外侧车道设为公交专用道
    ArrayList<ILane> lanes2 = new ArrayList<>(link2.lanes());
    ILane lane = lanes2.get(0);
    lane.setLaneType("公交专用道");
}

// 创建第三条路段
Point startPoint3 = new Point(-300, 25);
Point endPoint3 = new Point(-150, 25);
ArrayList<Point> linkPoints3 = new ArrayList<>(Arrays.asList(startPoint3, endPoint3));
ILink link3 = netiface.createLink(linkPoints3, 3, "link3", true, UnitOfMeasure.Metric);
if (link3 != null) {
    IDispatchPoint dp3 = netiface.createDispatchPoint(link3);
    if (dp3 != null) {
        dp3.addDispatchInterval(1, 3600, 3600);
    }
}

// 创建第四条路段
Point startPoint4 = new Point(-50, 25);
Point endPoint4 = new Point(50, 25);
ArrayList<Point> linkPoints4 = new ArrayList<>(Arrays.asList(startPoint4, endPoint4));
ILink link4 = netiface.createLink(linkPoints4, 3, "link4", true, UnitOfMeasure.Metric);

// 创建第五条路段
Point startPoint5 = new Point(150, 25);
Point endPoint5 = new Point(300, 25);
ArrayList<Point> linkPoints5 = new ArrayList<>(Arrays.asList(startPoint5, endPoint5));
ILink link5 = netiface.createLink(linkPoints5, 3, "自定义限速路段", true, UnitOfMeasure.Metric);
if (link5 != null) {
    link5.setLimitSpeed(30); // 单位：km/h
}

// 创建第六条路段
Point startPoint6 = new Point(-300, 50);
Point endPoint6 = new Point(300, 50);
ArrayList<Point> linkPoints6 = new ArrayList<>(Arrays.asList(startPoint6, endPoint6));
ILink link6 = netiface.createLink(linkPoints6, 3, "动态发车路段", true, UnitOfMeasure.Metric);
if (link6 != null) {
    link6.setLimitSpeed(80);
}

// 创建第七条路段
Point startPoint7 = new Point(-300, 75);
Point endPoint7 = new Point(-250, 75);
ArrayList<Point> linkPoints7 = new ArrayList<>(Arrays.asList(startPoint7, endPoint7));
ILink link7 = netiface.createLink(linkPoints7, 3);
if (link7 != null) {
    link7.setLimitSpeed(80);
}

// 创建第八条路段
Point startPoint8 = new Point(-50, 75);
Point endPoint8 = new Point(300, 75);
ArrayList<Point> linkPoints8 = new ArrayList<>(Arrays.asList(startPoint8, endPoint8));
ILink link8 = netiface.createLink(linkPoints8, 3);
if (link8 != null) {
    link8.setLimitSpeed(80);
}

// ==================== 创建连接段 ====================
// 连接link3和link4
if (link3 != null && link4 != null) {
    ArrayList<Integer> fromLaneNumbers1 = new ArrayList<>(Arrays.asList(1, 2, 3));
    ArrayList<Integer> toLaneNumbers1 = new ArrayList<>(Arrays.asList(1, 2, 3));
    IConnector connector1 = netiface.createConnector(link3.id(), link4.id(), fromLaneNumbers1, toLaneNumbers1, "连接段1", true);
}

// 连接link4和link5
if (link4 != null && link5 != null) {
    ArrayList<Integer> fromLaneNumbers2 = new ArrayList<>(Arrays.asList(1, 2, 3));
    ArrayList<Integer> toLaneNumbers2 = new ArrayList<>(Arrays.asList(1, 2, 3));
    IConnector connector2 = netiface.createConnector(link4.id(), link5.id(), fromLaneNumbers2, toLaneNumbers2, "连接段2", true);
}

// 连接link7和link8
if (link7 != null && link8 != null) {
    ArrayList<Integer> fromLaneNumbers3 = new ArrayList<>(Arrays.asList(1, 2, 3));
    ArrayList<Integer> toLaneNumbers3 = new ArrayList<>(Arrays.asList(1, 2, 3));
    IConnector connector3 = netiface.createConnector(link7.id(), link8.id(), fromLaneNumbers3, toLaneNumbers3, "动态发车连接段", true);
}
```

### 4.1.2.创建各类采集设备

​	各类采集设备包括：数据采集器、排队计数器和行程时间检测器。创建它们的代码如下。

```java
// ==================== 创建数据采集器 ====================
// 获取车道对象
ILane lane = netiface.findLane(1);
// 位置，单位：m
double dist = 50;
// 在路段上创建数据采集器
IVehicleDrivInfoCollector collector = netiface.createVehiCollectorOnLink(lane, dist, UnitOfMeasure.Metric);

// 获取车道连接对象
ILaneConnector laneConnector = netiface.findLaneConnector(1, 4);
// 位置，单位：m
double dist = 50;
// 在连接段上创建数据采集器
IVehicleDrivInfoCollector collector = netiface.createVehiCollectorOnConnector(laneConnector, dist, UnitOfMeasure.Metric);

// ==================== 创建排队计数器 ====================
// 获取车道对象
ILane lane = netiface.findLane(1);
// 位置，单位：m
double dist = 80;
// 在路段上创建排队计数器
IVehicleQueueCounter counter = netiface.createVehiQueueCounterOnLink(lane, dist, UnitOfMeasure.Metric);

// 获取车道连接对象
laneConnector = netiface.findLaneConnector(1, 4);
// 位置，单位：m
double dist = 80;
// 在连接段上创建排队计数器
IVehicleQueueCounter counter = netiface.createVehiQueueCounterOnConnector(laneConnector, dist, UnitOfMeasure.Metric);

// ==================== 创建行程时间检测器 ====================
// 获取起始路段对象
ILink startLink = netiface.findLink(1);
// 获取终止路段对象
ILink endLink = netiface.findLink(2);
// 检测器起点在起始路段的位置，单位：m
double startDist = 10;
// 检测器终点在终止路段的位置，单位：m
double endDist = 90;
// 创建起点在路段、终点也在路段的行程时间检测器
ArrayList<IVehicleTravelDetector> detectors = netiface.createVehicleTravelDetector_link2link(startLink, endLink, startDist, endDist, UnitOfMeasure.Metric);

// 获取起始路段对象
ILink startLink = netiface.findLink(1);
// 获取终止车道连接对象
ILaneConnector endLaneConnector = netiface.findLaneConnector(1, 4);
// 检测器起点在起始路段的位置，单位：m
double startDist = 10;
// 检测器终点在终止车道连接的位置，单位：m
double endDist = 10;
// 创建起点在路段、终点在连接段的行程时间检测器
ArrayList<IVehicleTravelDetector> detectors = netiface.createVehicleTravelDetector_link2conn(startLink, endLaneConnector, startDist, endDist, UnitOfMeasure.Metric);

// 获取起始车道连接对象
ILink startLaneConnector = netiface.findLaneConnector(1, 4);
// 获取终止路段对象
ILaneConnector endLink = netiface.findLink(2);
// 检测器起点在起始车道连接的位置，单位：m
double startDist = 10;
// 检测器终点在终止路段的位置，单位：m
double endDist = 90;
// 创建起点在连接段、终点在路段的行程时间检测器
ArrayList<IVehicleTravelDetector> detectors = netiface.createVehicleTravelDetector_conn2link(startLaneConnector, endLink, startDist, endDist, UnitOfMeasure.Metric);

// 获取起始车道连接对象
ILaneConnector startLaneConnector = netiface.findLaneConnector(1, 4);
// 获取终止路段对象
ILaneConnector endLaneConnector = netiface.findLaneConnector(4, 7);
// 检测器起点在起始车道连接的位置，单位：m
double startDist = 10;
// 检测器终点在终止车道连接的位置，单位：m
double endDist = 90;
// 创建起点在连接段、终点也在连接段的行程时间检测器
ArrayList<IVehicleTravelDetector> detectors = netiface.createVehicleTravelDetector_conn2conn(startLaneConnector, endLaneConnector, startDist, endDist, UnitOfMeasure.Metric);
```

### 4.1.3.创建导向箭头

​	创建导向箭头的代码如下。

```java
ILane lane = netiface.findLane(4);
if (lane != null) {
    double length = 4;
    double distToTerminal = 10;
    GuideArrowType arrowType = GuideArrowType.StraightRight;
	IGuidArrow guidArrow = netiface.createGuidArrow(lane, length, distToTerminal, arrowType, UnitOfMeasure.Metric);
}
```

### 4.1.4.创建公交站点和线路

​	创建公交站点和公交线路的代码如下。

```java
// 创建公交站点
ILane lane = netiface.findLane(1);
IBusStation busStation = netiface.createBusStation(lane, 30, 50, "公交站1", UnitOfMeasure.Metric);
// 设置站点类型 1：路边式、2：港湾式
busStation.setType(1);

// 创建公交线路
ILink link1 = netiface.findLink(1);
ILink link2 = netiface.findLink(2);
ArrayList<ILink> links = new ArrayList<>(Arrays.asList(link1, link2));
IBusLine busLine = netiface.createBusLine(links);

// 关联公交线路和公交站点
boolean result = netiface.addBusStationToLine(busLine, busStation);
// 关联成功
if (result) {
	// 获取公交线路上的所有公交站点
    ArrayList<IBusStationLine> stationLineList = busLine.stationLines();
    // 获取第一个公交站点
    IBusStationLine stationLine = stationLineList.get(0);
    // 设置车辆停靠时间，单位：s
    stationLine.setBusParkingTime(20);
}
```

### 4.1.5.创建各类事件区域

​	各类事件区域包括：事故区、施工区、限行区和改扩建借道。创建它们的代码如下。

```java
// ==================== 创建事故区 ====================
// 构建参数
DynaAccidentZoneParam param = new DynaAccidentZoneParam();
// 事故区名称
param.setName("事故区");
// 道路ID
param.setRoadId(1); 
// 位置，距路段或连接段起点距离，单位：m
param.setLocation(100);
// 长度，单位：m
param.setLength(50);
// 车道序号列表，从0开始，连续有序
ArrayList<Integer> fromLaneNumbers = new ArrayList<>(Arrays.asList(0));
accidentZoneParam.setMlFromLaneNumber(fromLaneNumbers);
// 开始时间，单位：s
param.setStartTime(10); 
// 持续时间，单位：s
param.setDuration(600); 
// 相邻车道限速，单位：km/h
param.setLimitedSpeed(40);
// 创建事故区
IAccidentZoneInterval accidentZone = netiface.createAccidentZone(param, UnitOfMeasure.Metric);

// ==================== 创建施工区 ====================
// 构建参数
DynaRoadWorkZoneParam param = new DynaRoadWorkZoneParam();
// 施工区名称
param.setName("施工区");
// 道路ID
param.setRoadId(1);
// 位置, 距离路段或连接段起点距离, 单位：m
param.setLocation(200);
// 长度, 单位：m
param.setLength(50);  // 长度
param.setUpCautionLength(70);  // 提前警示长度
param.setUpTransitionLength(50);  // 过渡区长度
param.setUpBufferLength(50);  // 缓冲区长度
param.setDownTransitionLength(40);  // 下游过渡区长度
param.setDownTerminationLength(40);  // 终止区长度
// 车道序号列表，从0开始，连续有序
ArrayList<Integer> fromLaneNumbers = new ArrayList<>(Arrays.asList(0));
param.setMlFromLaneNumber(fromLaneNumbers);
// 开始时间，单位：s
param.setStartTime(0);
// 持续时间，单位：s
param.setDuration(3600);
// 相邻车道限速，单位：km/h
param.setLimitSpeed(40);
// 创建施工区
IRoadWorkZone roadWorkZone = netiface.createRoadWorkZone(param, UnitOfMeasure.Metric);

// ==================== 创建限行区 ====================
// 构建参数
DynaLimitedZoneParam param = new DynaLimitedZoneParam();
// 限行区名称
param.setName("限行区");
// 道路ID
param.setRoadId(1); 
// 位置，距路段或连接段起点距离，单位：m
param.setLocation(100);
// 长度，单位：m
param.setLength(50);
// 车道序号列表，从0开始，连续有序
ArrayList<Integer> fromLaneNumbers = new ArrayList<>(Arrays.asList(0));
accidentZoneParam.setMlFromLaneNumber(fromLaneNumbers);
// 开始时间，单位：s
param.setStartTime(10); 
// 持续时间，单位：s
param.setDuration(600); 
// 相邻车道限速，单位：km/h
param.setLimitedSpeed(40);
// 创建限行区
ILimitedZone limitedZone = netiface.createLimitedZone(param, UnitOfMeasure.Metric);

// ==================== 创建改扩建借道 ====================
// 构建参数
DynaReconstructionParam param = new DynaReconstructionParam();
// 施工区ID
param.setRoadWorkZoneId(rwzId);
// 被借道的路段ID
param.setBeBorrowedLinkId(2);
// 被借道的车道数量
param.setBorrowedNum(1);
// 保通开口长度，单位：m
param.setPassagewayLength(80);
// 保通开口限速，单位：m/s
param.setPassagewayLimitedSpeed(40 / 3.6);
// 创建改扩建借道
IReconstruction reconstruction = netiface.createReconstruction(param, UnitOfMeasure.Metric);
```



## 4.2.需求建模

### 4.2.1.设置发车

​	设置发车可在**仿真前通过发车点批量配置**，也可在**仿真过程中动态创建单车**。

​	（1）在仿真开启前，创建车型、车辆组成和发车点及发车流量的代码如下。

```java
// ==================== 创建车型 ====================
// 构建参数
_VehicleType vehicleType = new _VehicleType();
vehicleType.setVehicleTypeName("新建车型1");  // 车型名称
vehicleType.setLength(4.5);  // 长度，单位：m
vehicleType.setLengthSD(0.5);  // 长度标准差，单位：m
vehicleType.setWidth(2);  // 宽度，单位：m
vehicleType.setWidthSD(0.2);  // 宽度标准差，单位：m
vehicleType.setAvgSpeed(60);  // 期望速度，单位：km/h
vehicleType.setSpeedSD(10);  // 期望速度标准差，单位：km/h
vehicleType.setAvgAcce(4);  // 期望加速度，单位：m/s²
vehicleType.setAcceSD(0.5);  // 期望加速度标准差，单位：m/s²
vehicleType.setAvgDece(6);  // 期望减速度，单位：m/s²
vehicleType.setDeceSD(0.5);  // 期望减速度标准差，单位：m/s²
vehicleType.setMaxAcce(5.5);  // 最大加速度，单位：m/s²
vehicleType.setMaxDece(7.5);  // 最大减速度，单位：m/s²
vehicleType.setMaxSpeed(80);  // 最大速度，单位：km/h
vehicleType.setCommercialVehicle(false);  // 是否是营运车辆
vehicleType.setMaxPassengerCapacity(1);  // 核载人数，单位：人
// 创建车型
boolean result = netiface.createVehicleType(vehicleType);
System.out.println("创建车型是否成功：" + result);

// ==================== 创建车辆组成 ====================
// 构建车辆类型比例列表
List<VehiComposition> vehiTypeProportionList = new ArrayList<>(Arrays.asList(
    new VehiComposition(1, 0.3),  // 小客车，占比0.3
    new VehiComposition(2, 0.2),  // 大客车，占比0.2
    new VehiComposition(3, 0.1),  // 公交车，占比0.1
    new VehiComposition(4, 0.4)   // 货车，占比0.4
));
// 创建车辆组成
int vehiCompositionId = netiface.createVehicleComposition("动态创建车型组成", vehiTypeProportionList);

// ==================== 创建发车点 ====================
// 获取路段对象
ILink link = netiface.findLink(1);
// 创建发车点
IDispatchPoint dp = netiface.createDispatchPoint(link);
if (dp != null) {
    // 添加发车间隔，含车型组成、时间间隔、发车数
    dp.addDispatchInterval(1, 600, 300);
    dp.addDispatchInterval(1, 600, 300);
}
```

​	（2）在仿真过程中，不使用发车点，在指定位置创建单车的代码如下。

```java
// ==================== 在路段上创建车辆 ====================
// 构建参数
DynaVehiParam dvp1 = new DynaVehiParam();
// 车型ID
dvp1.setVehiTypeCode(1);
// 路段ID
dvp1.setRoadId(4);
// 车道序号
dvp1.setLaneNumber(0);
// 位置，单位：m
dvp1.setDist(m2p(50));
// 速度，单位：m/s
dvp1.setSpeed(m2p(20));
// 颜色
dvp1.setColor("#00AFF0");
// 动态创建车辆
IVehicle vehicle1 = simuiface.createGVehicle(dvp1);
if (vehicle != null) {
    System.out.println("在路段上创建了车辆，其ID为：" + vehicle1.id());
}

// ==================== 在连接段上创建车辆 ====================
// 构建参数
DynaVehiParam dvp2 = new DynaVehiParam();
// 车型ID
dvp2.setVehiTypeCode(1);
// 连接段ID
dvp2.setRoadId(4);
// 上游路段的车道序号
dvp2.setLaneNumber(0);
// 下游路段的车道序号
dvp2.setToLaneNumber(0);
// 位置，单位：m
dvp2.setDist(m2p(50));
// 速度，单位：m/s
dvp2.setSpeed(m2p(20));
// 颜色
dvp2.setColor("#00AFF0");
// 动态创建车辆
IVehicle vehicle2 = simuiface.createGVehicle(dvp2);
if (vehicle2 != null) {
    System.out.println("在连接段上创建了车辆，其ID为：" + vehicle2.id());
}
```

### 4.2.2.设置路径

​	设置路径可在**仿真开启前或仿真过程中基于决策点进行流量比例分配**，也可**直接为单个车辆指定行驶路线**。	

​	（1）在仿真开启前，创建决策点，并更新其路径和路径流量比例的代码如下。

```java
// ============================== 创建决策点 ==============================
ILink link = netiface.findLink(1);
double location = 50;
decisionPointName = "新建决策点";
IDecisionPoint decisionPoint = netiface.createDecisionPoint(link, location, decisionPointName, UnitOfMeasure.Metric);

// ==================== 创建决策点的车辆路径 ====================
// 路段ID列表
ArrayList<Integer> linkIdList1 = new ArrayList<>(Arrays.asList(1, 2));
ArrayList<Integer> linkIdList2 = new ArrayList<>(Arrays.asList(1, 3));
ArrayList<Integer> linkIdList3 = new ArrayList<>(Arrays.asList(1, 4));

// 构建路段对象列表
ArrayList<ILink> linkList1 = new ArrayList<>();
for (Integer linkId : linkIdList1) {
    linkList1.add(netiface.findLink(linkId));
}
ArrayList<ILink> linkList2 = new ArrayList<>();
for (Integer linkId : linkIdList2) {
    linkList2.add(netiface.findLink(linkId));
}
ArrayList<ILink> linkList3 = new ArrayList<>();
for (Integer linkId : linkIdList3) {
    linkList3.add(netiface.findLink(linkId));
}

// 创建决策点的车辆路径
IRouting routing1 = netiface.createDeciRouting(decisionPoint, linkList1);
IRouting routing2 = netiface.createDeciRouting(decisionPoint, linkList2);
IRouting routing3 = netiface.createDeciRouting(decisionPoint, linkList3);

// ==================== 更新决策点路径流量比配置 ====================
// 初始化左、直、右流量比对象
RoutingFlowRatio flowRatioLeft = new RoutingFlowRatio();
flowRatioLeft.routingFlowRatioID = 1;
flowRatioLeft.routingID = decisionRouting1.id();
flowRatioLeft.startDateTime = 0;
flowRatioLeft.endDateTime = 999999;
flowRatioLeft.ratio = 2.0;

RoutingFlowRatio flowRatioStraight = new RoutingFlowRatio();
flowRatioStraight.routingFlowRatioID = 2;
flowRatioStraight.routingID = decisionRouting2.id();
flowRatioStraight.startDateTime = 0;
flowRatioStraight.endDateTime = 999999;
flowRatioStraight.ratio = 3.0;

RoutingFlowRatio flowRatioRight = new RoutingFlowRatio();
flowRatioRight.routingFlowRatioID = 3;
flowRatioRight.routingID = decisionRouting3.id();
flowRatioRight.startDateTime = 0;
flowRatioRight.endDateTime = 999999;
flowRatioRight.ratio = 1.0;

// 初始化决策点数据
_DecisionPoint decisionPointData = new DecisionPointData();
_DecisionPoint.deciPointID = decisionPoint.id();
_DecisionPoint.deciPointName = decisionPoint.name();
Point decisionPointPos = new Point();
if (decisionPoint.link().getPointByDist(decisionPoint.distance(), decisionPointPos)) {
    decisionPointData.X = decisionPointPos.getX();
    decisionPointData.Y = decisionPointPos.getY();
    decisionPointData.Z = decisionPoint.link().z();
}

// 构造流量比列表
List<RoutingFlowRatio> flowRatioList = new ArrayList<>();
flowRatioList.add(flowRatioLeft);
flowRatioList.add(flowRatioStraight);
flowRatioList.add(flowRatioRight);

// 更新决策点的路径流量比配置
IDecisionPoint updatedDecisionPoint = netiface.updateDecipointPoint(decisionPointData, flowRatioList);
```

​	（2）在仿真过程中，动态修改已有决策点的路径流量比例代码如下。

```java
// MySimulator.java

@Override
public ArrayList<DecipointFlowRatioByInterval> calcDynaFlowRatioParameters() {
    ArrayList<DecipointFlowRatioByInterval> result = new ArrayList<>();
    // 当前仿真计算批次
    long batchNumber = simuiface.batchNumber();
    // 在计算第20批次时修改某决策点各路径流量比
    if (batchNumber == 20) {
        // 一个决策点某个时段各路径车辆分配比
        DecipointFlowRatioByInterval dfi = new DecipointFlowRatioByInterval();
        // 决策点编号
        dfi.setDeciPointID(5);
        // 起始时间 单位：秒
        dfi.setStartDateTime(1);
        // 结束时间 单位：秒
        dfi.setEndDateTime(999999);
        // 路径流量比
        ArrayList<RoutingFlowRatio> ratios = new ArrayList<>();
        ratios.add(new RoutingFlowRatio(1, 3));
        ratios.add(new RoutingFlowRatio(2, 4));
        ratios.add(new RoutingFlowRatio(3, 3));
        dfi.setRoutingFlowRatios(ratios);
        result.add(dfi);
    }
    return result;
}
```

​	（3）在仿真过程中，给车辆设置路径的代码如下。

```java
// 1. 使用现有的决策点的车辆路径
IRouting routing1 = netiface.findRouting(1);
vehicle.vehicleDriving().setRouting(routing1);

// 2. 创建不与决策点绑定的车辆路径
ArrayList<Integer> linkIdList = new ArrayList<>(Arrays.asList(8, 16, 25));
ArrayList<ILink> linkList = new ArrayList<>();
for (int linkId : linkIdList) {
    linkList.add(netiface.findLink(linkId));
}
IRouting routing2 = netiface.createRouting(linkList);
vehicle.vehicleDriving().setRouting(routing2);
```




## 4.3.信号控制

### 4.3.1.创建信号机、信控方案、信号灯相位和信号灯

​	在仿真开启前，可以依次创建信号机、信控方案、信号灯相位、信号灯，创建过程中同步建立了绑定关系：**信号灯→信号灯相位→信控方案→信号机**，代码如下。

```java
// ==================== 创建信号机（通常一个交叉口对应一个信号机） ====================
// 信号机名称
String signalControllerName = "双龙大道-吉印大道交叉口";
// 创建信号机
ISignalController signalController = netiface.createSignalController(signalControllerName);

// ==================== 创建信控方案（一个信号机在不同时段可配置多个信控方案） ====================
// 获取信号机对象
ISignalController signalController = netiface.findSignalControllerByID(1);
// 信控方案名称
String signalPlanName = "平峰方案";
// 周期时长，单位：s
int cycleTime = 120;
// 相位差，单位：s
int phaseDifference = 0;
// 起始时间，单位：s
int startTime = 0;
// 结束时间，单位：s
int endTime = 3600;
// 创建信控方案
ISignalPlan signalPlan = netiface.createSignalPlan(signalController, signalPlanName, cycleTime, phaseDifference, startTime, endTime);

// ==================== 创建信号灯相位（一个信控方案需为不同方向/转向分配相位） ====================
// 获取信号配时方案
ISignalPlan signalPlan = netiface.findSignalPlanById(1);
// 相位名称
String signalPhaseName = "东西直行";
// 构建灯色对象列表
String[] colors = {"R", "G", "Y", "R"};
int[] intervals = {30, 26, 3, 61};
ArrayList<ColorInterval> colorIntervalList = new ArrayList<>();
for (int i = 0; i < colors.length; i++) {
    colorIntervalList.add(new ColorInterval(colors[i], intervals[i]));
}
// 创建信号灯相位
ISignalPhase signalPhase = netiface.createSignalPlanSignalPhase(signalPlan, signalPhaseName, colorIntervalList);

// ==================== 创建信号灯（一个相位控制多条车道的信号灯） ====================
// 获取相位对象
ISignalPhase signalPhase = netiface.findSignalPhase(1);
// 信号灯名称
String signalLampName = "东直1";
// 车道ID
long laneId = 1;
// 下游车道ID
long toLaneId = -1;
// 位置，单位：m
double distance = m2p(50);
// 创建信号灯
ISignalLamp signalLamp = netiface.createSignalLamp(signalPhase, signalLampName, laneId, toLaneId, distance);
```

### 4.3.2.控制信号灯灯色

​	可以按**信控相位**或**单个信号灯**两种粒度修改灯色设置。

​	（1）在仿真开启前或仿真过程中，按信控相位修改灯色与时长的代码如下。

```java
// 构建灯色和时长对象列表
ArrayList<ColorInterval> colorObjList = new ArrayList<>(Arrays.asList(
    new ColorInterval ("R", 10),  // 红色，时长 10
    new ColorInterval ("G", 60),  // 绿色，时长 60
    new ColorInterval ("Y", 3),  // 黄色，时长 3
    new ColorInterval ("R", 17)  // 红色，时长 17
));
// 查找ID为7的信号灯相位
SignalPhase signalPhase = netiface.findSignalPhase(7);
if (signalPhase != null) {
    // 设置灯色列表
    signalPhase.setColorList(colorObjList);
}
```

​	在路网中已完成信号机、信控方案、信号灯相位及信号灯的创建后，若需在仿真过程中修改单个交叉口的信控方案，可参考以下示例代码。使用前，需预先记录各相位对应的相位ID。

```java
// 定义信控相位数据结构
class PhaseData {
    // 信号灯相位ID
    int signalPhaseId;
    List<Integer> intervals;

    PhaseData(int id, List<Integer> intervals) {
        this.signalPhaseId = id;
        this.intervals = intervals;
    }
}

@Override
public void afterOneStep() {
    // 获取当前仿真时间，单位：ms
    long simuTime = simuiface.simuIntervalScheming();
    
    // 到达指定时刻
    if (simuTime == 60 * 1000) {
        // 单个交叉口的信控相位映射
        Map<String, PhaseData> signalIntervalMapping = new HashMap<>();
        signalIntervalMapping.put("东西直行", new PhaseData(1, List.of(0, 31, 3, 86)));
        signalIntervalMapping.put("东西左转", new PhaseData(2, List.of(35, 21, 3, 61)));
        signalIntervalMapping.put("南北直行", new PhaseData(3, List.of(60, 31, 3, 26)));
        signalIntervalMapping.put("南北左转", new PhaseData(4, List.of(95, 21, 3, 1)));

        // 按信控相位设置
        for (Map.Entry<String, PhaseData> entry : signalIntervalMapping.entrySet()) {
            PhaseData phaseData = entry.getValue();
            // 获取信控相位ID
            long signlPhaseId = phaseData.signalPhaseId;
            // 获取信控相位对象
            ISignalPhase signalPhase = netInterface.findSignalPhase(signlPhaseId);
            if (signalPhase == null) {
                continue;
            }
            // 构建灯色和时长列表
            List<Online.ColorInterval> colorList = new ArrayList<>(List.of(
                new Online.ColorInterval("R", phaseData.intervals.get(0)),  // 红色
                new Online.ColorInterval("G", phaseData.intervals.get(1)),  // 绿色
                new Online.ColorInterval("Y", phaseData.intervals.get(2)),  // 黄色
                new Online.ColorInterval("R", phaseData.intervals.get(3))   // 红色
            ));
            // 设置新的时长方案
            signalPhase.setColorList(colorList);
        }
    }
}
```

​	（2）在仿真过程中，按单个信号灯直接修改灯色的代码如下。由于这种操作本质上是对 TESS NG 已计算结果的修正或覆盖，因此这类调整**仅在当前帧内生效**。这意味着，**不能仅在满足条件的某个时刻进行一次设置，而需要在整个符合条件的时间区间内持续执行设置操作**。

```java
// MySimulator.java

@Override
public boolean calcLampColor(ISignalLamp pSignalLamp) {
    // 获取当前仿真时间，单位：ms
    long simuTime = simuiface.simuIntervalScheming();
    // 若信号灯ID为1，且在指定时间范围内，则设为绿色
	if (pSignalLamp.id() == 1 && simuTime >= 60 * 1000 && simuTime <= 90 * 1000) {
		pSignalLamp.setLampColor("G");
		return true;
	}
	return false;
}
```



## 4.4.车辆控制

### 4.4.1.设置车辆期望速度

​	在仿真过程中，设置车辆期望速度的代码如下。

```java
// 设置车辆的期望速度，单位：像素/s
vehicle.setDesirSpeed(m2p(80 / 3.6));
```

### 4.4.2.设置车辆速度

​	在仿真过程中，设置车辆速度的代码如下。

```java
// MySimulator.java

// 单位：m/s
@Override
public boolean ref_reSetSpeed_unit(IVehicle pIVehicle, ObjReal ref_inOutSpeed, ObjUnitOfMeasure ref_unit) {
    if (pIVehicle.id() == 100001) {
        // 直接指定车辆的速度
        ref_inOutSpeed.setValue(80 / 3.6);
        return true;
    }
    return false;
}
```

### 4.4.3.设置车辆加速度

​	设置车辆加速度的代码如下。

```java
// MySimulator.java

// 该函数在 TESS NG 计算加速度之前计算，单位：m/s²
@Override
public boolean ref_calcAcce_unit(IVehicle pIVehicle, ObjReal acce, ObjUnitOfMeasure ref_unit) {
    if (pIVehicle.roadName() == "曹安公路") {
        // 根据速度不同，直接计算加速度
        if (pIVehicle.currSpeed() > 20/3.6) {
            acce.setValue(-3);
            return true;
        }
        else if (pIVehicle.currSpeed() > 10/3.6) {
            acce.setValue(-1);
            return true;
        }
    }
    return false;
}

// 该函数在 TESS NG 计算加速度之后计算单位：m/s²
@Override
public boolean ref_reSetAcce_unit(IVehicle pIVehicle, ObjReal inOutAcce, ObjUnitOfMeasure ref_unit) {
    if (pIVehicle.roadName() == "曹安公路") {
        // 根据速度不同，对已计算出的加速度进行修正
        if (pIVehicle.currSpeed() > 20/3.6) {
            acce.setValue(acce.getValue() + (-3);
            return true;
        }
        else if (pIVehicle.currSpeed() > 10/3.6) {
            acce.setValue(acce.getValue() + (-1));
            return true;
        }
    }
    return false;
}
```

### 4.4.4.设置车辆变道

​	控制车辆向左或向右变道的代码如下。

```java
// 控制车辆向左变道
vehicle.vehicleDriving().toLeftLane();

// 控制车辆向右变道
vehicle.vehicleDriving().toRightLane();
```

​	撤销车辆变道的代码如下。

```java
// MySimulator.java

@Override
public boolean reCalcDismissChangeLane(IVehicle pIVehicle) {
	// 距离路段终点小于50m时撤销一切自由变道，达到禁止自由变道的效果
    if (pIVehicle.vehicleDriving().distToEndpoint(true, true, UnitOfMeasure.Metric) < 50) {
        return true;
    }
    return false;
}
```

### 4.4.5.设置车辆车道限行

​	设置车辆车道限行的代码如下。

```java
// MySimulator.java

@Override
public ArrayList<Int> calcLimitedLaneNumber(IVehicle pIVehicle) {
    // 如果车辆在路段上且车辆长度大于8m，则禁止驶入最内侧车道
    if (pIVehicle.roadIsLink() && pIVehicle.length(UnitOfMeasure.Metric) > 8) {
        int limitLaneNumber = pIVehicle.lane().link().laneCount();
        List<Integer> restrictedLanes = new ArrayList<>();
        restrictedLanes.add(limitLaneNumber);
        return restrictedLanes;
    }
    return new ArrayList<>();
}
```

### 4.4.6.设置车辆路径

​	设置车辆路径的代码如下。

```java
// 1. 使用现有的决策点的车辆路径
IRouting routing1 = netiface.findRouting(1);
vehicle.vehicleDriving().setRouting(routing1);

// 2. 创建不与决策点绑定的车辆路径
ArrayList<Integer> linkIdList = new ArrayList<>(Arrays.asList(8, 16, 25));
ArrayList<ILink> linkList = new ArrayList<>();
for (int linkId : linkIdList) {
    linkList.add(netiface.findLink(linkId));
}
IRouting routing2 = netiface.createRouting(linkList);
vehicle.vehicleDriving().setRouting(routing2);
```

### 4.4.7.设置车辆跟驰参数

​	设置车辆跟驰参数的代码如下。**当前仅支持修改 IDM 跟驰模型的参数**。

```java
// 设置车辆的期望加速度单位：像素/s²
vehicle.setDesirAcce(m2p(5.5));

// 设置车辆最大减速度，单位：像素/s²
vehicle.setMaxDece(m2p(7.5));

// 设置车辆的安全时距，单位：s
vehicle.vehicleDriving().setSafeTimeInterval(1.5);

// 设置车辆的停车距离，单位：像素
vehicle.vehicleDriving().setStoppingDistance(m2p(2));
```

### 4.4.8.设置车辆跳跃

​	设置车辆跳跃的代码如下。

```java
// 目标点
Point targetPoint = new Point(50, 50);
// 将目标点投影到附近一定范围内的车道上，获取定位信息序列
ArrayList<Location> locations = netiface.locateOnCrid(targetPoint, 9, UnitOfMeasure.Metric);  // 使用前需要先执行netiface.buildNetGrid(10);
// 如果定位到了车道对象
if (!locations.isEmpty()) {
    Location location = locations.get(0);
    // 车道对象
    ILaneObject laneObj = location.getPLaneObject();
    // 位置，单位：m
    double dist = location.getDistToStart();

    // 移动车辆到指定车道和位置上，实现车辆位置的瞬移
    vehicle.vehicleDriving().move(laneObj, dist, UnitOfMeasure.Metric);
}
```

### 4.4.9.设置车辆信息和可视化

​	设置车辆信息的代码如下。

```java
// MySimulator.java
    
@Override
public String vehiRunInfo(IVehicle pIVehicle) {
    return String.format("车辆当前在ID=%d的道路上", pIVehicle.roadId());
}
```

​	设置车辆颜色的代码如下。

```java
// 设置车辆颜色为蓝色
vehicle.setColor("#00AFF0");
```



## 4.5.仿真控制

### 4.5.1.设置仿真参数

​	在仿真开启前，设置仿真参数的代码如下。

```java
// MySimulator.java

// 在仿真开启前设置以下参数
@Override
public void beforeStart(ObjBool keepOn) {
    // 设置仿真倍速
    simuiface.setAcceMultiples(5);
    // 设置仿真时长，单位：s
    simuiface.setSimuIntervalScheming(3600);
    // 设置仿真精度
    simuiface.setSimuAccuracy(10);
    // 设置随机种子
    simuiface.setRandSeed(42);
    // 设置是否记录车辆轨迹
    simuiface.setIsRecordTrace(True);
    // 设置是否记录行人轨迹
    simuiface.setIsRecordPedestrianTrace(True);
}
```

### 4.5.2.启动、暂停和停止仿真

​	启动、暂停和停止仿真的代码如下。

```java
// 开启仿真，一般写在 afterLoadNet 或 afterStop
if (!simuiface.isRunning() || simuiface.isPausing()) {
    simuiface.startSimu();
}

// 暂停仿真，一般写在 afterOneStep
if (simuiface.isRunning()) {
    simuiface.pauseSimu();
}

// 停止仿真，一般写在 afterOneStep
if (simuiface.isRunning()) {
    simuiface.stopSimu();
}
```

### 4.5.3.连续多次仿真

​	连续多次仿真的代码如下。

```java
// MySimulator.java

public class MySimulator extends JCustomerSimulator {
    // 代表TESS NG的接口
    private TessInterface iface;
    // 代表TESS NG 的路网子接口
    private NetInterface netiface;
    // 代表TESS NG 的仿真子接口
    private SimuInterface simuiface;

    // 当前仿真次数
    private int currentSimuCount = 0;
    // 最大仿真次数
    private int maxSimuCount = 10;

    public MySimulator() {
        super();
        iface = TESSNG.tessngIFace();
        netiface = iface.netInterface();
        simuiface = iface.simuInterface();
    }

    @Override
    public void afterStart() {
        // 仿真次数加一
		currentSimuCount += 1;
    }
    
    @Override
    public void afterOneStep() {
        // 当前仿真时间，单位：ms
        long simuTime = simuiface.simuTimeIntervalWithAcceMutiples();
        if (simuTime > 600 * 1000) {
            // 停止仿真
            simuiface.stopSimu();
        }
    }
    
    @Override
    public void afterStop() {
        // 还没到最大仿真次数
        if (currentSimuCount < maxSimuCount) {
            // 开启仿真
            simuiface.startSimu();
        }
    }
}
```



## 4.6.数据输出

### 4.6.1.输出路网几何线性数据

​	路网由路段和连接段组成，其中路段由车道构成，连接段由车道连接构成。路段、车道和车道连接均包含中心线、左边线和右边线的断点序列，车辆正是在这些由断点构成的线上行驶。获取路段、车道和车道连接断点数据的代码如下。

```java
// 获取某一路段的中心线、左边线和右边线的断点坐标
ILink link = netiface.findLink(1);
ArrayList<Vector3D>linkCenterPoints = link.centerBreakPoint3Ds(UnitOfMeasure.Metric);
ArrayList<Vector3D> linkLeftPoints = link.leftBreakPoint3Ds(UnitOfMeasure.Metric);
ArrayList<Vector3D> linkRightPoints = link.rightBreakPoint3Ds(UnitOfMeasure.Metric);

// 获取某一车道的中心线、左边线和右边线的断点坐标
ILane lane = netiface.findLane(1);
ArrayList<Vector3D> laneCenterPoints = lane.centerBreakPoint3Ds(UnitOfMeasure.Metric);
ArrayList<Vector3D> laneLeftPoints = lane.leftBreakPoint3Ds(UnitOfMeasure.Metric);
ArrayList<Vector3D> laneRightPoints = lane.rightBreakPoint3Ds(UnitOfMeasure.Metric);
        
// 获取某一车道连接的中心线、左边线和右边线的断点坐标
ILaneConnector laneConnector = netiface.findLaneConnector(1, 4);
ArrayList<Vector3D> laneConnectorCenterPoints = laneConnector.centerBreakPoint3Ds(UnitOfMeasure.Metric);
ArrayList<Vector3D> laneConnectorLeftPoints = laneConnector.leftBreakPoint3Ds(UnitOfMeasure.Metric);
ArrayList<Vector3D> laneConnectorRightPoints = laneConnector.rightBreakPoint3Ds(UnitOfMeasure.Metric);
```

### 4.6.2.输出车辆轨迹数据

​	在仿真过程中，获取某一帧仿真的车辆数据的代码如下。

```java
// 获取当前正在运行的车辆列表
ArrayList<IVehicle> allVehicles = simuiface.allVehiStarted();
for (IVehicle vehicle : allVehicles) {
    System.out.println("车辆ID：" + vehicle.id());
    System.out.println("车辆名称：" + vehicle.name());
    System.out.println("车辆类型编码：" + vehicle.vehicleTypeCode());
    System.out.println("车辆类型名称：" + vehicle.vehicleTypeName());
    System.out.println("车辆长度：" + vehicle.length(UnitOfMeasure.Metric) + " m");

    System.out.println("车辆当前横坐标：" + vehicle.pos(UnitOfMeasure.Metric).getX() + " m");
    System.out.println("车辆当前纵坐标：" + vehicle.pos(UnitOfMeasure.Metric).getY() + " m");
    System.out.println("车辆当前高程：" + vehicle.v3z() + " m");
    System.out.println("车辆当前所在道路ID：" + vehicle.roadId());
    System.out.println("车辆当前所在道路名称：" + vehicle.roadName());
    System.out.println("车辆当前是否在路段：" + vehicle.roadIsLink());
    System.out.println("车辆当前所在车道ID：" + vehicle.laneId());
    if (vehicle.roadIsLink()) {
        System.out.println("车辆当前所在车道序号：" + vehicle.vehicleDriving().laneNumber());
    }
    System.out.println("车辆当前与车道起点的间距：" + vehicle.vehicleDriving().distToStartPoint(true, true, UnitOfMeasure.Metric) + " m");
    
    System.out.println("车辆当前速度：" + vehicle.currSpeed(UnitOfMeasure.Metric) * 3.6 + " km/h");
    System.out.println("车辆当前期望速度：" + vehicle.vehicleDriving().desirSpeed(UnitOfMeasure.Metric) * 3.6 + " km/h");
    System.out.println("车辆当前加速度：" + vehicle.acce(UnitOfMeasure.Metric) + " m/s²");
    System.out.println("车辆当前朝向角：" + vehicle.angle() + " °");
}
```

### 4.6.3.输出信号灯数据

​	在仿真过程中，获取某一帧仿真的信号灯数据的代码如下。

```java
ArrayList<SignalPhaseColor> allSignalPhaseColor = simuiface.getSignalPhasesColor();
for (SignalPhaseColor signalPhaseColor: allSignalPhaseColor) {
    System.out.println("信号机ID：" + signalPhaseColor.getSignalGroupId());
    System.out.println("信控相位ID：" + signalPhaseColor.getPhaseId());
    System.out.println("信控相位序号：" + signalPhaseColor.getPhaseNumber());
    System.out.println("当前颜色：" + signalPhaseColor.getColor());
    System.out.println("当前颜色的设置时间(ms)：" + signalPhaseColor.getMrIntervalSetted());
    System.out.println("当前颜色的已持续时间(ms)：" + signalPhaseColor.getMrIntervalByNow());
}
```

### 4.6.4.输出各类采集设备数据

​	各类采集设备包括：数据采集器、排队计数器和行程时间检测器。在仿真过程中，获取它们的样本数据和集计数据的代码如下。其中，**集计数据仅能在集计时间段结束的那一帧仿真中获取**。

```java
// ==================== 数据采集器的样本数据 ====================
ArrayList<VehiInfoCollected> allVehiInfoCollected = simuiface.getVehisInfoCollected();
for (VehiInfoCollected vehiInfo: allVehiInfoCollected) {
    System.out.println("采集器ID：" + vehiInfo.getCollectorId());
    System.out.println("仿真时间(s)：" + vehiInfo.getSimuInterval());
    System.out.println("车辆ID：" + vehiInfo.getVehiId());
}

// ==================== 数据采集器的集计数据 ====================
ArrayList<VehiInfoAggregated> allVehiInfoAggregated = simuiface.getVehisInfoAggregated();
for (VehiInfoAggregated vehiInfoAgg: allVehiInfoAggregated) {
    System.out.println("采集器ID：" + vehiInfoAgg.getCollectorId());
    System.out.println("时间段ID：" + vehiInfoAgg.getTimeId());
    System.out.println("起始时间(s)：" + vehiInfoAgg.getFromTime());
    System.out.println("结束时间(s)：" + vehiInfoAgg.getToTime());
    System.out.println("车辆数(veh)：" + vehiInfoAgg.getVehiCount());
    System.out.println("平均速度(km/h)：" + vehiInfoAgg.getAvgSpeed());
    System.out.println("平均占有率：" + vehiInfoAgg.getOccupancy());
}

// ==================== 排队计数器的样本数据 ====================
ArrayList<VehiQueueCounted> allVehiQueueCounted = simuiface.getVehisQueueCounted();
for (VehiQueueCounted vehiQueue: allVehiQueueCounted) {
    System.out.println("计数器ID：" + vehiQueue.getCounterId());
    System.out.println("仿真时间(s)：" + vehiQueue.getSimuTime());
    System.out.println("排队车辆数(veh)：" + vehiQueue.getVehiCount());
    System.out.println("排队长度(m)：" + vehiQueue.getQueueLength());
}

// ==================== 排队计数器的集计数据 ====================
ArrayList<VehiQueueAggregated> allVehiQueueAggregated = simuiface.getVehisQueueAggregated();
for (VehiQueueAggregated vehiQueueAgg: allVehiQueueAggregated) {
    System.out.println("计数器ID：" + vehiQueueAgg.getCounterId());
    System.out.println("时间段ID：" + vehiQueueAgg.getTimeId());
    System.out.println("起始时间(s)：" + vehiQueueAgg.getFromTime());
    System.out.println("结束时间(s)：" + vehiQueueAgg.getToTime());
    System.out.println("平均排队车辆数(veh)：" + vehiQueueAgg.getAvgVehiCount());
    System.out.println("平均排队长度(m)：" + vehiQueueAgg.getAvgQueueLength());
    System.out.println("最大排队长度(m)：" + vehiQueueAgg.getMaxQueueLength());
    System.out.println("最小排队长度(m)：" + vehiQueueAgg.getMinQueueLength());
}

// ==================== 行程时间检测器的样本数据 ====================
ArrayList<VehiTravelDetected> allVehiTravelDetected = simuiface.getVehisTravelDetected();
for (VehiTravelDetected vehiTravel: allVehiTravelDetected) {
    System.out.println("检测器ID：" + vehiTravel.getDetectedId());
    System.out.println("车辆ID：" + vehiTravel.getVehiId());
    System.out.println("行驶时间(s)：" + vehiTravel.getTravelTime());
    System.out.println("行驶距离(m)：" + vehiTravel.getTravelDistance());
    System.out.println("延误(s)：" + vehiTravel.getDelay());
}

// ==================== 行程时间检测器的集计数据 ====================
ArrayList<VehiTravelAggregated> allVehiTravelAggregated = simuiface.getVehisTravelAggregated();
for (VehiTravelAggregated vehiTravelAgg: allVehiTravelAggregated) {
    System.out.println("检测器ID：" + vehiTravelAgg.getDetectedId());
    System.out.println("时间段ID：" + vehiTravelAgg.getTimeId());
    System.out.println("起始时间(s)：" + vehiTravelAgg.getFromTime());
    System.out.println("结束时间(s)：" + vehiTravelAgg.getToTime());
    System.out.println("车辆数：" + vehiTravelAgg.getVehiCount());
    System.out.println("平均行程时间(s)：" + vehiTravelAgg.getAvgTravelTime());
    System.out.println("平均行程距离(m)：" + vehiTravelAgg.getAvgTravelDistance());
    System.out.println("平均延误(s)：" + vehiTravelAgg.getAvgDelay());
}
```

<div style="page-break-after: always;"></div>

# 5.行业案例

​	基于 TESS NG 二次开发实现的行业案例如下表所示，完整代码请参见 [Github](https://github.com/jIDa-traffic/TESSNG_SecondaryDev) 仓库或 [Gitee](https://gitee.com/jidatraffic/tessng-secondary-doc) 仓库。

|       大类       | 功能项                           |
| :--------------: | :------------------------------- |
|       高速       | 施工区仿真                       |
|                  | 事故，事件仿真                   |
|                  | 车道限速管控                     |
|                  | 车道关闭仿真                     |
|                  | 硬路肩，应急车道开放             |
|                  | 匝道信号控制                     |
|                  | 拥堵预警                         |
|                  | 高速管控预评价系统               |
|                  | 高快速路参数标定                 |
|       城市       | 单点信控自适应                   |
|                  | 交叉口车道车道渠化变更，可变车道 |
|                  | 干线协调                         |
|                  | 车辆路径诱导                     |
|                  | 拥堵预警                         |
|                  | 车道管控仿真                     |
|                  | 车辆事故仿真                     |
|                  | 车辆速度引导（VMS信息板）        |
|                  | 城市道路参数标定                 |
|                  | 公交信号优先                     |
|   V2X 自动驾驶   | v2x交叉口                        |
|                  | 速度引导                         |
|                  | 车辆编队行驶                     |
| 自动驾驶联合仿真 | Carla对接                        |
|                  | prescan对接                      |
|                  | scanner对接                      |
|                  | 交通数字孪生：与UE5，unity结合   |
|                  | 自动驾驶测试场景设计             |

<div style="page-break-after: always;"></div>

# 6.注意事项

## 6.1.软件激活

​	用户在首次使用 TESS NG 二次开发时也需要激活，试用版用户与首次激活软件流程相同，采用安装包的 Cert 文件夹下的 JIDaTraffic_key 激活即可。

​	软件的试用期为30天，试用期结束后，二次开发的接口（Interface）仍可用，但自定义插件（Plugin）将无法使用。商业版用户使用不受限制。

​	另外，还可以**修改 `Main.java` 中的 `workspacePath` 参数**，将其指定为 TESS NG 的安装目录。这样设置后，所有输出文件将统一生成至该目录，同时能实现激活文件共享（避免重复激活）与 3D 模型文件共享（防止 3D 转换时找不到模型文件）



## 6.2.度量单位

​	由于 TESS NG 基于 Qt 框架开发，而 Qt 的图形系统以像素为基础单位，其坐标体系与现实世界的物理单位（如米）存在天然差异。Qt 的绘图操作、界面布局及交互响应均均围绕像素维度展开，默认以屏幕像素作为渲染和定位的基准，并不直接对应现实空间的物理尺度。	

​	因此，在 TESS NG 二次开发中，无论是路网元素的尺寸定义、车辆位置的计算映射，还是自定义图形的绘制、交互操作的坐标解析，都需要特别关注**像素与米制单位**的转换逻辑。默认情况下，1像素对应1m，但若因为导入底图等操作更改了像素比例，则可通过以下方法实现单位转换：

- 米制转换像素：public static double m2p(double value)
- 像素转换米制：public static double p2m(double value)

​	此外，插件与接口中部分方法包含 **UnitOfMeasure unit **参数，其默认值为`UnitOfMeasure.Default`（即像素单位），若传入`UnitOfMeasure.Metric`则表示采用米制单位（支持读写操作）。例如，`vehicle.currSpeed()`会返回车辆的像素单位速度，而`vehicle.currSpeed(UnitOfMeasure.Metric)`则返回车辆的米制单位速度。需要注意的是，由于`unit`参数通常位于方法参数列表的末尾，**若需显式指定该参数，则其之前所有带默认值的参数也必须显式传入对应值**。相关规则在此统一说明，接口详情中不再赘述。



## 6.3.坐标系

​	由于 TESS NG 基于 Qt 框架开发，其坐标系设计直接沿用了 Qt 的核心规则 ——Qt 为适配屏幕显示与图形渲染逻辑（屏幕像素通常以左上角为原点，向下为 y 轴正方向），采用 **y轴朝下**的坐标系（原点一般位于画布 / 窗口左上角，x 轴水平向右，y 轴垂直向下）。

​	因此，在 TESS NG 二次开发过程中，所有涉及坐标计算、图形绘制（如路网元素定位、车辆位置标注、自定义图形渲染）、鼠标交互定位等场景，均需遵循这一 **y轴朝下**的坐标系规则。尤其在与现实地理坐标系（通常 y 轴朝上）或自定义坐标体系进行数据转换、位置映射时，需特别注意坐标轴方向的差异，避免因坐标系理解偏差导致图形错位、位置计算错误等问题。



## 6.4.依赖类导入

​	通常需要在文件头部导入所需的依赖类，可按需导入单个类或整个包。示例如下。

```java
// 导入整个包
import com.jidatraffic.tessng.*;

// 导入指定类和静态方法
import com.jidatraffic.tessng.TESSNG;
import static com.jidatraffic.tessng.TESSNG.m2p;
```



## 6.5.子插件作用规则

​	在仿真插件中，对车辆加速度、期望速度、行驶速度、转向角度等参数的调整，以及对信号灯灯色的设置，实质上都是对 TESS NG 已计算结果的修正或覆盖，因此这类调整**仅在当前帧内生效**。这意味着像信号灯灯色设置这类操作，**不能仅在满足条件的某个时刻进行一次设置，而需要在整个符合条件的时间区间内持续设置**。



## 6.6.子插件修改传入值函数的使用规则

​	由于 TESS NG 底层基于 C++ 实现，而 C++ 支持通过引用传递修改整数、浮点数、布尔值等基础类型，Java 却不支持对这些类型进行引用修改。为解决这一差异，对于需要修改传入值的函数，我们会在其名称前添加 "ref_" 前缀，并专门设计了`objInt`、`objReal`、`objBool`等适配类型。

​	例如，原函数`public boolean reSetSpeed(IVehicle pIVehicle, ObjReal inOutSpeed)`会新增对应的`public boolean ref_reSetSpeed(IVehicle pIVehicle, ObjReal ref_inOutSpeed)`。其中，`ref_inOutSpeed`的类型为`objReal`，可通过`ref_inOutSpeed.setValue(1)`的方式进行赋值操作。

​	这类函数主要集中在 JCustomerSimulator 和 JCustomerNet 中，接口详情中会同时列出不带`ref_`前缀和带`ref_`前缀的函数：

- 若有修改传入值的需求，需使用带`ref_`前缀的函数；

- 若无修改传入值的需求，如`public void beforeStart(ObjBool keepOn)`，使用不带`ref_`前缀和带`ref_`前缀的函数都可。、

  


## 6.7.图像界面相关功能暂不可用

​	由于 TESS NG 基于 Qt 框架开发，而当前 Qt 框架暂未提供对 Java 语言的支持，因此在 Java 开发环境下，TESS NG 中与图像界面相关的功能暂时无法使用。

<div style="page-break-after: always;"></div>

# 7.问答列表

### 1. 为什么我在 MySimulator 自带函数中编写的二次开发代码没有生效？

**答：** 可能是由于试用期已结束，导致系统没有权限加载插件，从而使自定义代码无法执行。

